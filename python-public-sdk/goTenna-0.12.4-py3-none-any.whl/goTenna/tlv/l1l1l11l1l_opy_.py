# coding: utf8
import sys
l1l1ll_opy_ = sys.version_info [0] == 2
l1llll_opy_ = 2048
l11l1_opy_ = 7
def l1l1l1_opy_ (l1l1l_opy_):
    global l1ll11_opy_
    l1l111_opy_ = ord (l1l1l_opy_ [-1])
    l11_opy_ = l1l1l_opy_ [:-1]
    l111_opy_ = l1l111_opy_ % len (l11_opy_)
    ll_opy_ = l11_opy_ [:l111_opy_] + l11_opy_ [l111_opy_:]
    if l1l1ll_opy_:
        l1lll1_opy_ = unicode () .join ([unichr (ord (char) - l1llll_opy_ - (l1ll_opy_ + l1l111_opy_) % l11l1_opy_) for l1ll_opy_, char in enumerate (ll_opy_)])
    else:
        l1lll1_opy_ = str () .join ([chr (ord (char) - l1llll_opy_ - (l1ll_opy_ + l1l111_opy_) % l11l1_opy_) for l1ll_opy_, char in enumerate (ll_opy_)])
    return eval (l1lll1_opy_)
# Copyright (C) 2018 goTenna, Inc. This file is distributed as part of the
# goTenna USB SDK. See the associated license for more information.
# pylint: disable=line-too-long
l1l1l1_opy_ (u"ࠨࠢࠣࠢࡗ࡬ࡪࠦࡔࡍࡘࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࠦࡴࡰࠢࡦࡳࡳ࡬ࡩࡨࡷࡵࡩࠥࡧࠠࡨࡱࡗࡩࡳࡴࡡࠡࡦࡨࡺ࡮ࡩࡥ࠯ࠌࠍࡘ࡭࡫ࡳࡦࠢࡗࡐ࡛ࡹࠠࡢࡴࡨࠤ࡫ࡵࡲࠡ࡫ࡱࡸࡪࡸ࡮ࡢ࡮ࠣࡹࡸ࡫ࠠࡸࡪࡨࡲࠥࡩ࡯࡯ࡨ࡬࡫ࡺࡸࡩ࡯ࡩࠣࡥࠥࡪࡥࡷ࡫ࡦࡩࡀࠦࡴࡩࡧࡵࡩࠥ࡯ࡳࠡࡰࡲࠤࡳ࡫ࡥࡥࠢࡷࡳࠥࡧࡣࡤࡧࡶࡷࠥࡺࡨࡦ࡯ࠣࡩࡽࡺࡥࡳࡰࡤࡰࡱࡿ࠮ࠡࡖ࡫ࡩࡾࠦࡡࡳࡧࠣࡲࡴࡺࠠࡪࡰࡷࡩࡳࡪࡥࡥࠢࡷࡳࠥࡨࡥࠡࡵࡨࡲࡹࠦࡡࡤࡴࡲࡷࡸࠦࡴࡩࡧࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤࠤࡳ࡫ࡴࡸࡱࡵ࡯࠳ࠦࡔࡰࠢࡶ࡬ࡦࡸࡥࠡࡴࡤࡨ࡮ࡵࠠࡤࡱࡱࡪ࡮࡭ࡵࡳࡣࡷ࡭ࡴࡴࠠࡥࡣࡷࡥ࠱ࠦࡵࡴࡧࠣࡸ࡭࡫ࠠࡢࡲࡳࡶࡴࡶࡲࡪࡣࡷࡩࠥࡳࡥࡴࡵࡤ࡫ࡪ࠴ࠊࠣࠤࠥ૽")
# pylint: enable=line-too-long
import logging
import struct
import itertools
import goTenna.settings
import goTenna.constants
from goTenna.tlv import basic_tlv
_MODULE_LOGGER = logging.getLogger(__name__)
class l1l111lll1_opy_(basic_tlv.TLV):
    l1l1l1_opy_ (u"ࠢࠣࠤࠣࡘ࡭࡫ࠠࡕࡎ࡙ࠤࡸࡶࡥࡤ࡫ࡩࡽ࡮ࡴࡧࠡࡣࠣࡷࡪࡺࠠࡰࡨࠣࡪࡷ࡫ࡱࡶࡧࡱࡧࡾࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࡹࠠࠣࠤࠥ૾")
    l1ll11ll11_opy_ = 0x25
    _111111l11_opy_ = 0x80
    _111111111_opy_ = 0x01
    def __init__(self, rf_settings):
        l1l1l1_opy_ (u"ࠣࠤࠥࠤࡇࡻࡩ࡭ࡦࠣࡸ࡭࡫ࠠࡕࡎ࡙ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡧࡰࡖࡨࡲࡳࡧ࠮ࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡕࡊࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸࠦࡲࡧࡡࡶࡩࡹࡺࡩ࡯ࡩࡶ࠾࡚ࠥࡨࡦࠢࡲࡦ࡯࡫ࡣࡵࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡴࡩࡧࠣࡪࡷ࡫ࡱࡶࡧࡱࡧ࡮࡫ࡳࠡࡶࡲࠤࡨࡵ࡮ࡧ࡫ࡪࡹࡷ࡫࠮ࠡࡆࡲࡩࡸࠦ࡮ࡰࡶࠣࡲࡪ࡫ࡤࠡࡶࡲࠤࡧ࡫ࠠࡷࡣ࡯࡭ࡩ࠲ࠠࡴ࡫ࡱࡧࡪࠦࡴࡩ࡫ࡶࠤ࡙ࡒࡖࠡࡦࡲࡩࡸࠦ࡮ࡰࡶࠣࡩࡳࡩ࡯ࡥࡧࠣࡸࡷࡧ࡮ࡴ࡯࡬ࡸࠥࡶ࡯ࡸࡧࡵ࠰ࠥࡨࡵࡵࠢࡰࡹࡸࡺࠠࡤࡱࡱࡸࡦ࡯࡮ࠡࡥࡲࡱࡵࡲࡩࡢࡰࡷࠤ࡫ࡸࡥࡲࡷࡨࡲࡨࡿࠠࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲࠥࡉࡨࡢࡰࡱࡩࡱ࡙ࡰࡦࡥࡗࡐ࡛ࡀࠠࡕࡪࡨࠤࡨࡵ࡮ࡴࡶࡵࡹࡨࡺࡥࡥࠢࡲࡦ࡯࡫ࡣࡵࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨ૿")
        if not isinstance(rf_settings, goTenna.settings.RFSettings):
            raise TypeError(rf_settings)
        if not rf_settings.freqs_valid:
            raise ValueError((rf_settings.control_freqs, rf_settings.data_freqs))
        self.rf_settings = rf_settings
    def __eq__(self, other):
        return isinstance(other, l1l111lll1_opy_)\
            and isinstance(other.rf_settings, goTenna.settings.RFSettings)\
            and self.rf_settings.control_freqs == other.rf_settings.control_freqs\
            and self.rf_settings.data_freqs == other.rf_settings.data_freqs
    @property
    def l111ll1111_opy_(self):
        return self.l1ll11ll11_opy_
    @classmethod
    def deserialize(cls, l111l11ll1_opy_):
        number = int(len(l111l11ll1_opy_) / 5)
        fmt = l1l1l1_opy_ (u"ࠩࠤࠫ଀") + l1l1l1_opy_ (u"ࠪࡍࡇ࠭ଁ")*number
        res = struct.unpack(fmt, l111l11ll1_opy_)
        l11111ll11_opy_ = itertools.islice(res, 0, len(res), 2)
        flags = itertools.islice(res, 1, len(res), 2)
        l1lllll1lll_opy_ = goTenna.util.l1ll1lll1_opy_(l11111ll11_opy_, flags)
        l1lllll1ll1_opy_ = []
        l11111lll1_opy_ = []
        for l1llllll11l_opy_ in l1lllll1lll_opy_:
            if l1llllll11l_opy_[1] & cls._111111l11_opy_:
                l1lllll1ll1_opy_.append(l1llllll11l_opy_[0])
            else:
                l11111lll1_opy_.append(l1llllll11l_opy_[0])
        return cls(goTenna.settings.RFSettings(control_freqs=l1lllll1ll1_opy_,
                                               data_freqs=l11111lll1_opy_))
    def serialize(self):
        l1llllll1l1_opy_ = self.rf_settings.control_freqs + self.rf_settings.data_freqs
        fmt = l1l1l1_opy_ (u"ࠫࠦ࠭ଂ") + l1l1l1_opy_ (u"ࠬࡏࡂࠨଃ")*len(l1llllll1l1_opy_)
        flags = ([self._111111l11_opy_ | self._111111111_opy_]
                 * len(self.rf_settings.control_freqs))\
                + ([self._111111111_opy_] * len(self.rf_settings.data_freqs))
        args = []
        for elem in goTenna.util.l1ll1lll1_opy_(l1llllll1l1_opy_, flags):
            args.extend(list(elem))
        return struct.pack(fmt, *args)
class l1ll11llll_opy_(basic_tlv.TLV):
    l1l1l1_opy_ (u"ࠨࠢࠣࠢࡗࡐ࡛ࠦࡦࡰࡴࠣࡷࡪࡴࡤࡪࡰࡪࠤࡲࡧࡳ࡬ࡵࠣࡥࡳࡪࠠࡣ࡫ࡷࡶࡦࡺࡥࡴࠢࡷࡳࠥࡺࡨࡦࠢࡧࡩࡻ࡯ࡣࡦࠢࡤࡸࠥࡩ࡯࡯ࡨ࡬࡫ࡺࡸࡡࡵ࡫ࡲࡲࠥࡺࡩ࡮ࡧ࠱ࠎࠥࠦࠠࠡࠤࠥࠦ଄")
    l1ll11ll11_opy_ = 0x26
    def __eq__(self, other):
        return isinstance(other, l1ll11llll_opy_)\
            and self.rate == other.rate and self.mask == other.mask
    def __repr__(self):
        return l1l1l1_opy_ (u"ࠧ࠽ࡽࢀ࠾ࠥࡳࡡࡴ࡭ࡀࡿࢂࠦࡲࡢࡶࡨࡁࢀࢃ࠾ࠨଅ").format(self.__class__.__name__,
                                              self.mask, self.rate)
    @property
    def l111ll1111_opy_(self):
        return self.l1ll11ll11_opy_
    def __init__(self, mask, rate):
        l1l1l1_opy_ (u"ࠣࠤࠥࠎࠥࠦࠠࠡࠢࠣࠤࠥࡈࡵࡪ࡮ࡧࠤࡦࠦࡓࡦࡶࡐࡥࡸࡱࡒࡢࡶࡨࡘࡑ࡜࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡨࡵ࡮ࡴࡶࡤࡲࡹࡹ࠮ࡎࡣࡶ࡯ࠥࡳࡡࡴ࡭࠽ࠤ࡙࡮ࡥࠡ࡯ࡤࡷࡰࠦࡴࡰࠢࡥࡹ࡮ࡲࡤࠡࡶ࡫ࡩ࡚ࠥࡌࡗࠢࡺ࡭ࡹ࡮࠮ࠡࡏࡸࡷࡹࠦࡢࡦࠢࡤࡲࠥ࡫࡬ࡦ࡯ࡨࡲࡹࠦ࡯ࡧࠢ࠽ࡴࡾࡀࡡࡵࡶࡵ࠾ࡥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡣࡰࡰࡶࡸࡦࡴࡴࡴ࠰ࡐࡅࡘࡑࡓࡡ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡩ࡯࡯ࡵࡷࡥࡳࡺࡳ࠯ࡄ࡬ࡸࡷࡧࡴࡦࠢࡵࡥࡹ࡫࠺ࠡࡖ࡫ࡩࠥࡨࡩࡵࡴࡤࡸࡪࠦࡴࡰࠢࡥࡹ࡮ࡲࡤࠡࡶ࡫ࡩ࡚ࠥࡌࡗࠢࡺ࡭ࡹ࡮࠮ࠡࡏࡸࡷࡹࠦࡢࡦࠢࡤࠤࡻࡧ࡬ࡪࡦࠣࡦ࡮ࡺࡲࡢࡶࡨࠤ࡫ࡵࡲࠡࡶ࡫ࡩࠥ࡭ࡩࡷࡧࡱࠤࡲࡧࡳ࡬࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢଆ")
        if mask not in goTenna.constants.MASKS:
            raise ValueError(l1l1l1_opy_ (u"ࠩࡐࡥࡸࡱࠠࡼࡿࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡥࠥࡼࡡ࡭࡫ࡧࠤࡲࡧࡳ࡬ࠩଇ").format(mask))
        if not mask.bitrate_allowed(rate):
            raise ValueError(l1l1l1_opy_ (u"ࠪࡆ࡮ࡺࡲࡢࡶࡨࠤࢀࢃࠠࡪࡵࠣࡲࡴࡺࠠࡢ࡮࡯ࡳࡼ࡫ࡤࠡࡨࡲࡶࠥࡳࡡࡴ࡭ࠣࡿࢂ࠭ଈ")
                             .format(rate, mask))
        self.rate = rate
        self.mask = mask
    @classmethod
    def deserialize(cls, l111l11ll1_opy_):
        (l1lllllll11_opy_, l11111l1l1_opy_) = struct.unpack(l1l1l1_opy_ (u"ࠫࠦࡈࡂࠨଉ"), l111l11ll1_opy_)
        mask = None
        rate = None
        for m in goTenna.constants.MASKS:
            if l1lllllll11_opy_ == m.index:
                mask = m
        for b in mask.allowed_bitrates:
            if l11111l1l1_opy_ == b.index:
                rate = b
        return cls(mask, rate)
    def serialize(self):
        return struct.pack(l1l1l1_opy_ (u"ࠬࠧࡂࡃࠩଊ"), self.mask.index, self.rate.index)
class l1lllll1l1l_opy_(basic_tlv.TLV):
    l1l1l1_opy_ (u"ࠨࠢࠣࠢࡗࡐ࡛ࠦࡦࡰࡴࠣ࡭ࡳࡺࡥࡳࡰࡤࡰࠥ࡬ࡡࡶ࡮ࡷࠤ࡮ࡴࡦࡰ࠰ࠍࠤࠥࠦࠠࠣࠤࠥଋ")
    l1ll11ll11_opy_ = 0x29
    def __repr__(self):
        return l1l1l1_opy_ (u"ࠧ࠽ࡽࢀ࠾ࠥࢁࡽ࠿ࠩଌ").format(self.__class__.__name__, self.l11111l1ll_opy_)
    def __eq__(self, other):
        return isinstance(other, l1lllll1l1l_opy_)\
            and self.l11111l1ll_opy_ == other.l11111l1ll_opy_
    def __init__(self, l11111l1ll_opy_):
        l1l1l1_opy_ (u"ࠣࠤࠥࠎࠥࠦࠠࠡࠢࠣࠤࠥࡈࡵࡪ࡮ࡧࠤࡦࠦࡆࡢࡷ࡯ࡸࡎࡴࡦࡰࡖࡏ࡚࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡦ࡬ࡧࡹࠦࡦࡢࡷ࡯ࡸࡤࡧࡴࡵࡴࡶ࠾࡚ࠥࡨࡦࠢࡤࡸࡹࡸࡩࡣࡷࡷࡩࡸࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡦࡢࡷ࡯ࡸ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ଍")
        l111111ll1_opy_ = (l1l1l1_opy_ (u"ࠩࡩࡥࡺࡲࡴࡠࡲࡦࠫ଎"), l1l1l1_opy_ (u"ࠪࡪࡦࡻ࡬ࡵࡡ࡯ࡶࠬଏ"), l1l1l1_opy_ (u"ࠫ࡫ࡧࡵ࡭ࡶࡢࡷࡵ࠭ଐ"), l1l1l1_opy_ (u"ࠬ࡬ࡡࡶ࡮ࡷࡣࡹࡿࡰࡦࠩ଑"),
                         l1l1l1_opy_ (u"࠭ࡲ࠱ࠩ଒"), l1l1l1_opy_ (u"ࠧࡳ࠳ࠪଓ"), l1l1l1_opy_ (u"ࠨࡴ࠵ࠫଔ"), l1l1l1_opy_ (u"ࠩࡵ࠷ࠬକ"))
        if not hasattr(l11111l1ll_opy_, l1l1l1_opy_ (u"ࠪࡣࡤ࡭ࡥࡵ࡫ࡷࡩࡲࡥ࡟ࠨଖ")):
            raise TypeError(l1l1l1_opy_ (u"ࠫ࡫ࡧࡵ࡭ࡶࡢࡥࡹࡺࡲࡴࠢࡶ࡬ࡴࡻ࡬ࡥࠢࡥࡩࠥࡧࠠࡥ࡫ࡦࡸࡱ࡯࡫ࡦࠩଗ"))
        for key in l111111ll1_opy_:
            if not isinstance(l11111l1ll_opy_[key], int):
                raise TypeError(l1l1l1_opy_ (u"ࠬࡌࡡࡶ࡮ࡷࠤࡦࡺࡴࡳࡵࠣࡱࡺࡹࡴࠡࡤࡨࠤ࡮ࡴࡴࡴ࠮ࠣࡿࢂࠦࡩࡴࠢࡱࡳࡹ࠭ଘ")
                                .format(key))
            if l11111l1ll_opy_[key] < 0 or l11111l1ll_opy_[key] > 0xffffffff:
                raise ValueError(l1l1l1_opy_ (u"࠭ࡆࡢࡷ࡯ࡸࠥࡧࡴࡵࡴࡶࠤࡲࡻࡳࡵࠢࡩ࡭ࡹࠦࡩ࡯ࠢ࠶࠶ࠥࡨࡩࡵࡵࠪଙ"))
        self.l11111l1ll_opy_ = l11111l1ll_opy_
    @property
    def l111ll1111_opy_(self):
        return self.l1ll11ll11_opy_
    @classmethod
    def deserialize(cls, l111l11ll1_opy_):
        l11111l111_opy_ = struct.unpack(l1l1l1_opy_ (u"ࠧࠢࡎࡏࡐࡑࡒࡌࡍࡎࠪଚ"), l111l11ll1_opy_)
        attrs = {
            l1l1l1_opy_ (u"ࠨࡨࡤࡹࡱࡺ࡟ࡱࡥࠪଛ"): l11111l111_opy_[0],
            l1l1l1_opy_ (u"ࠩࡩࡥࡺࡲࡴࡠ࡮ࡵࠫଜ"): l11111l111_opy_[1],
            l1l1l1_opy_ (u"ࠪࡪࡦࡻ࡬ࡵࡡࡶࡴࠬଝ"): l11111l111_opy_[2],
            l1l1l1_opy_ (u"ࠫ࡫ࡧࡵ࡭ࡶࡢࡸࡾࡶࡥࠨଞ"): l11111l111_opy_[3],
            l1l1l1_opy_ (u"ࠬࡸ࠰ࠨଟ"): l11111l111_opy_[4],
            l1l1l1_opy_ (u"࠭ࡲ࠲ࠩଠ"): l11111l111_opy_[5],
            l1l1l1_opy_ (u"ࠧࡳ࠴ࠪଡ"): l11111l111_opy_[6],
            l1l1l1_opy_ (u"ࠨࡴ࠶ࠫଢ"): l11111l111_opy_[7]
        }
        return cls(attrs)
    def serialize(self):
        return struct.pack(l1l1l1_opy_ (u"ࠩࠤࡐࡑࡒࡌࡍࡎࡏࡐࠬଣ"),
                           self.l11111l1ll_opy_.get(l1l1l1_opy_ (u"ࠪࡪࡦࡻ࡬ࡵࡡࡳࡧࠬତ"), 0xaaaaaaaa),
                           self.l11111l1ll_opy_.get(l1l1l1_opy_ (u"ࠫ࡫ࡧࡵ࡭ࡶࡢࡰࡷ࠭ଥ"), 0xaaaaaaaa),
                           self.l11111l1ll_opy_.get(l1l1l1_opy_ (u"ࠬ࡬ࡡࡶ࡮ࡷࡣࡸࡶࠧଦ"), 0xaaaaaaaa),
                           self.l11111l1ll_opy_.get(l1l1l1_opy_ (u"࠭ࡦࡢࡷ࡯ࡸࡤࡺࡹࡱࡧࠪଧ"), 0xaaaaaaaa),
                           self.l11111l1ll_opy_.get(l1l1l1_opy_ (u"ࠧࡳ࠲ࠪନ"), 0xaaaaaaaa),
                           self.l11111l1ll_opy_.get(l1l1l1_opy_ (u"ࠨࡴ࠴ࠫ଩"), 0xaaaaaaaa),
                           self.l11111l1ll_opy_.get(l1l1l1_opy_ (u"ࠩࡵ࠶ࠬପ"), 0xaaaaaaaa),
                           self.l11111l1ll_opy_.get(l1l1l1_opy_ (u"ࠪࡶ࠸࠭ଫ"), 0xaaaaaaaa))
class l1llllll1ll_opy_(basic_tlv.TLV):
    l1l1l1_opy_ (u"ࠦࠧࠨࠠࡕࡎ࡙ࠤ࡫ࡵࡲࠡ࡮࡬ࡪࡪࡺࡩ࡮ࡧࠣࡷࡹࡧࡴࡪࡵࡷ࡭ࡨࡹ࠮ࠋࠢࠣࠤࠥࠨࠢࠣବ")
    l1ll11ll11_opy_ = 0x2a
    @property
    def l111ll1111_opy_(self):
        return self.l1ll11ll11_opy_
    def __repr__(self):
        return l1l1l1_opy_ (u"ࠬࡂࡻࡾ࠼ࠣࡿࢂࡄࠧଭ").format(self.__class__.__name__,
                                 self.l1111111ll_opy_)
    def __eq__(self, other):
        return isinstance(other, l1llllll1ll_opy_)\
            and self.l1111111ll_opy_ == other.l1111111ll_opy_
    @staticmethod
    def _111111lll_opy_():
        return [
            (l1l1l1_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࡳࡠࡱࡵ࡭࡬࡯࡮ࡢࡶࡨࡨࠬମ"), l1l1l1_opy_ (u"ࠧࡊࠩଯ")),
            (l1l1l1_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࡵࡢࡶࡪࡩࡥࡪࡸࡨࡨࠬର"), l1l1l1_opy_ (u"ࠩࡌࠫ଱")),
            (l1l1l1_opy_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࡷࡤࡸࡥ࡭ࡣࡼࡩࡩ࠭ଲ"), l1l1l1_opy_ (u"ࠫࡎ࠭ଳ")),
            (l1l1l1_opy_ (u"ࠬࡺࡸࡠࡶ࡬ࡱࡪࡥࡶࡩࡨࡢ࠴ࡵ࠻ࠧ଴"), l1l1l1_opy_ (u"࠭ࡉࠨଵ")),
            (l1l1l1_opy_ (u"ࠧࡵࡺࡢࡸ࡮ࡳࡥࡠࡸ࡫ࡪࡤ࠷ࠧଶ"), l1l1l1_opy_ (u"ࠨࡋࠪଷ")),
            (l1l1l1_opy_ (u"ࠩࡷࡼࡤࡺࡩ࡮ࡧࡢࡺ࡭࡬࡟࠳ࠩସ"), l1l1l1_opy_ (u"ࠪࡍࠬହ")),
            (l1l1l1_opy_ (u"ࠫࡹࡾ࡟ࡵ࡫ࡰࡩࡤࡼࡨࡧࡡ࠸ࠫ଺"), l1l1l1_opy_ (u"ࠬࡏࠧ଻")),
            (l1l1l1_opy_ (u"࠭ࡴࡹࡡࡷ࡭ࡲ࡫࡟ࡶࡪࡩࡣ࠵ࡶ࠵ࠨ଼"), l1l1l1_opy_ (u"ࠧࡊࠩଽ")),
            (l1l1l1_opy_ (u"ࠨࡶࡻࡣࡹ࡯࡭ࡦࡡࡸ࡬࡫ࡥ࠱ࠨା"), l1l1l1_opy_ (u"ࠩࡌࠫି")),
            (l1l1l1_opy_ (u"ࠪࡸࡽࡥࡴࡪ࡯ࡨࡣࡺ࡮ࡦࡠ࠴ࠪୀ"), l1l1l1_opy_ (u"ࠫࡎ࠭ୁ")),
            (l1l1l1_opy_ (u"ࠬࡺࡸࡠࡶ࡬ࡱࡪࡥࡵࡩࡨࡢ࠹ࠬୂ"), l1l1l1_opy_ (u"࠭ࡉࠨୃ")),
            (l1l1l1_opy_ (u"ࠧࡳࡺࡢࡸ࡮ࡳࡥࡠࡸ࡫ࡪࠬୄ"), l1l1l1_opy_ (u"ࠨࡋࠪ୅")),
            (l1l1l1_opy_ (u"ࠩࡵࡼࡤࡺࡩ࡮ࡧࡢࡹ࡭࡬ࠧ୆"), l1l1l1_opy_ (u"ࠪࡍࠬେ")),
            (l1l1l1_opy_ (u"ࠫࡧࡲࡥࡠࡥࡲࡱࡲࡧ࡮ࡥࡵࡢࡶࡪࡩࡶࡥࠩୈ"), l1l1l1_opy_ (u"ࠬࡏࠧ୉")),
            (l1l1l1_opy_ (u"࠭ࡢ࡭ࡧࡢࡱࡪࡹࡳࡢࡩࡨࡷࡤࡹࡥ࡯ࡶࠪ୊"), l1l1l1_opy_ (u"ࠧࡊࠩୋ")),
            (l1l1l1_opy_ (u"ࠨࡤ࡯ࡩࡤࡳࡥࡴࡵࡤ࡫ࡪࡥࡥࡳࡴࡲࡶࡸ࠭ୌ"), l1l1l1_opy_ (u"ࠩࡋ୍ࠫ")),
            (l1l1l1_opy_ (u"ࠪࡦࡦࡺࡴࡦࡴࡼࡣࡨࡿࡣ࡭ࡧࡶࠫ୎"), l1l1l1_opy_ (u"ࠫࡍ࠭୏")),
            (l1l1l1_opy_ (u"ࠬࡻࡰࡵ࡫ࡰࡩࠬ୐"), l1l1l1_opy_ (u"࠭ࡈࠨ୑")),
            (l1l1l1_opy_ (u"ࠧࡴࡻࡶࡸࡪࡳ࡟ࡵࡪࡨࡶࡲࡥࡥࡷࡧࡱࡸࡸ࠭୒"), l1l1l1_opy_ (u"ࠨࡊࠪ୓"))
        ]
    @staticmethod
    def _11111llll_opy_():
        l1llllll111_opy_ = l1l1l1_opy_ (u"ࠩࠤࠫ୔")
        for elem in l1llllll1ll_opy_._111111lll_opy_():
            l1llllll111_opy_ += elem[1]
        return l1llllll111_opy_
    def __init__(self, l1111111ll_opy_):
        l1l1l1_opy_ (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡃࡷ࡬ࡰࡩࠦࡡࠡࡎ࡬ࡪࡪࡺࡩ࡮ࡧࡌࡲ࡫ࡵࡔࡍࡘ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡤࡪࡥࡷࠤࡱ࡯ࡦࡦࡶ࡬ࡱࡪࡥࡡࡵࡶࡵࡷ࠿ࠦࡔࡩࡧࠣࡥࡹࡺࡲࡴࠢࡩࡳࡷࠦࡴࡩࡧࠣࡰ࡮࡬ࡥࡵ࡫ࡰࡩࠥ࡯࡮ࡧࡱ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣ୕")
        if not hasattr(l1111111ll_opy_, l1l1l1_opy_ (u"ࠫࡤࡥࡧࡦࡶ࡬ࡸࡪࡳ࡟ࡠࠩୖ")):
            raise TypeError(l1l1l1_opy_ (u"ࠬࡲࡩࡧࡧࡷ࡭ࡲ࡫࡟ࡢࡶࡷࡶࡸࠦ࡭ࡶࡵࡷࠤࡧ࡫ࠠࡢࠢࡧ࡭ࡨࡺ࡬ࡪ࡭ࡨࠫୗ"))
        for key in self._111111lll_opy_():
            if not isinstance(l1111111ll_opy_[key[0]], int):
                raise TypeError(l1l1l1_opy_ (u"࠭ࡻࡾࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡤࡲࠥ࡯࡮ࡵࠩ୘").format(key[0]))
            if l1111111ll_opy_[key[0]] < 0\
               or l1111111ll_opy_[key[0]] > {l1l1l1_opy_ (u"ࠧࡉࠩ୙"): 0xffff, l1l1l1_opy_ (u"ࠨࡋࠪ୚"): 0xffffffff}[key[1]]:
                raise ValueError(l1111111ll_opy_[key[0]])
        self.l1111111ll_opy_ = l1111111ll_opy_
    def serialize(self):
        l1lllllll1l_opy_ = [self.l1111111ll_opy_.get(elem[0], 0)
                    for elem in self._111111lll_opy_()]
        return struct.pack(self._11111llll_opy_(), *l1lllllll1l_opy_)
    @classmethod
    def deserialize(cls, l111l11ll1_opy_):
        l1111111l1_opy_ = struct.unpack(cls._11111llll_opy_(), l111l11ll1_opy_)
        return cls({elem[0]: l1111111l1_opy_[idx]
                    for idx, elem in enumerate(cls._111111lll_opy_())})
class l1lllllllll_opy_(basic_tlv.TLV):
    l1l1l1_opy_ (u"ࠤ࡚ࠥࠦࠥࡌࡗࠢࡷࡽࡵ࡫ࠠࡧࡱࡵࠤࡵ࡫ࡲࡪࡱࡧ࡭ࡨࠦࡩ࡯ࡨࡲࠎࠥࠦࠠࠡࠤࠥࠦ୛")
    l1ll11ll11_opy_ = 0x2b
    def __repr__(self):
        return l1l1l1_opy_ (u"ࠪࡀࢀࢃ࠺ࠡࡽࢀࡂࠬଡ଼").format(self.__class__.__name__, self.l11111l11l_opy_)
    def __eq__(self, other):
        return isinstance(other, l1lllllllll_opy_)\
            and self.l11111l11l_opy_ == other.l11111l11l_opy_
    @property
    def l111ll1111_opy_(self):
        return self.l1ll11ll11_opy_
    @staticmethod
    def _11111111l_opy_():
        return [
            (l1l1l1_opy_ (u"ࠫࡦࡼࡧࡠࡴࡶࡷ࡮ࡥࡶࡩࡨࠪଢ଼"), l1l1l1_opy_ (u"ࠬࡈࠧ୞")),
            (l1l1l1_opy_ (u"࠭ࡡࡷࡩࡢࡶࡸࡹࡩࡠࡷ࡫ࡪࠬୟ"), l1l1l1_opy_ (u"ࠧࡃࠩୠ")),
            (l1l1l1_opy_ (u"ࠨࡣࡹ࡫ࡤࡸࡥࡧ࡮ࡨࡧࡹ࡫ࡤࡠࡲࡲࡻࡪࡸ࡟ࡷࡪࡩࠫୡ"), l1l1l1_opy_ (u"ࠩࡅࠫୢ")),
            (l1l1l1_opy_ (u"ࠪࡥࡻ࡭࡟ࡳࡧࡩࡰࡪࡩࡴࡦࡦࡢࡴࡴࡽࡥࡳࡡࡸ࡬࡫࠭ୣ"), l1l1l1_opy_ (u"ࠫࡇ࠭୤")),
            (l1l1l1_opy_ (u"ࠬࡩࡨࡢࡰࡢࡦࡺࡹࡹࡠࡤࡤࡧࡰࡵࡦࡧࡵࠪ୥"), l1l1l1_opy_ (u"࠭ࡂࠨ୦")),
            (l1l1l1_opy_ (u"ࠧࡵࡪࡨࡶࡲࡧ࡬ࡠࡤࡤࡧࡰࡵࡦࡧࡵࠪ୧"), l1l1l1_opy_ (u"ࠨࡄࠪ୨")),
            (l1l1l1_opy_ (u"ࠩࡤࡺ࡬ࡥࡲࡴࡵ࡬ࡣࡧࡲࡥࠨ୩"), l1l1l1_opy_ (u"ࠪࡆࠬ୪")),
            (l1l1l1_opy_ (u"ࠫࡸࡿࡳࡵࡧࡰࡣࡩࡻࡴࡺࡡࡦࡽࡨࡲࡥࠨ୫"), l1l1l1_opy_ (u"ࠬࡈࠧ୬")),
            (l1l1l1_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࡳࡠࡵࡨࡲࡹ࠭୭"), l1l1l1_opy_ (u"ࠧࡃࠩ୮")),
            (l1l1l1_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࡵࡢࡶࡪࡩࡥࡪࡸࡨࡨࠬ୯"), l1l1l1_opy_ (u"ࠩࡅࠫ୰")),
            (l1l1l1_opy_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࡷࡤࡸࡥ࡭ࡣࡼࡩࡩ࠭ୱ"), l1l1l1_opy_ (u"ࠫࡇ࠭୲")),
            (l1l1l1_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪࡹ࡟ࡳࡧ࡭ࡩࡨࡺࡥࡥࠩ୳"), l1l1l1_opy_ (u"࠭ࡂࠨ୴")),
            (l1l1l1_opy_ (u"ࠧࡶࡲࡷ࡭ࡲ࡫ࠧ୵"), l1l1l1_opy_ (u"ࠨࡊࠪ୶"))
        ]
    @staticmethod
    def _11111llll_opy_():
        l1llllll111_opy_ = l1l1l1_opy_ (u"ࠩࠤࠫ୷")
        for elem in l1lllllllll_opy_._11111111l_opy_():
            l1llllll111_opy_ += elem[1]
        return l1llllll111_opy_
    def __init__(self, l11111l11l_opy_):
        if not hasattr(l11111l11l_opy_, l1l1l1_opy_ (u"ࠪࡣࡤ࡭ࡥࡵ࡫ࡷࡩࡲࡥ࡟ࠨ୸")):
            raise TypeError(l1l1l1_opy_ (u"ࠫࡵ࡫ࡲࡪࡱࡧ࡭ࡨࡥࡡࡵࡶࡵࡷࠥࡳࡵࡴࡶࠣࡦࡪࠦࡡࠡࡦ࡬ࡧࡹࡲࡩ࡬ࡧࠪ୹"))
        for key in self._11111111l_opy_():
            if not isinstance(l11111l11l_opy_[key[0]], int):
                raise TypeError(l1l1l1_opy_ (u"ࠬࢁࡽࠡ࡫ࡶࠤࡳࡵࡴࠡࡣࡱࠤ࡮ࡴࡴࠨ୺").format(key[0]))
            if l11111l11l_opy_[key[0]] < 0\
               or l11111l11l_opy_[key[0]] > {l1l1l1_opy_ (u"࠭ࡈࠨ୻"): 0xffff, l1l1l1_opy_ (u"ࠧࡃࠩ୼"): 0xff}[key[1]]:
                raise ValueError(l11111l11l_opy_[key[0]])
        self.l11111l11l_opy_ = l11111l11l_opy_
    def serialize(self):
        args = [self.l11111l11l_opy_.get(elem[0], 0)
                for elem in self._11111111l_opy_()]
        return struct.pack(self._11111llll_opy_(), *args)
    @classmethod
    def deserialize(cls, l111l11ll1_opy_):
        l1111111l1_opy_ = struct.unpack(cls._11111llll_opy_(), l111l11ll1_opy_)
        return cls({elem[0]: l1111111l1_opy_[idx]
                    for idx, elem in enumerate(cls._11111111l_opy_())})
class l1l1l111l1_opy_(basic_tlv.TLV):
    l1l1l1_opy_ (u"ࠣࠤࠥࠤ࡙ࡒࡖࠡࡶࡲࠤࡸࡶࡥࡤ࡫ࡩࡽࠥࡺࡲࡢࡰࡶࡱ࡮ࡺࠠࡱࡱࡺࡩࡷࠦࡡࡵࠢࡦࡳࡳ࡬ࡩࡨࡷࡵࡥࡹ࡯࡯࡯ࠢࡷ࡭ࡲ࡫࠮ࠋࠢࠣࠤࠥࠨࠢࠣ୽")
    l1ll11ll11_opy_ = 0x1D
    def __repr__(self):
        return l1l1l1_opy_ (u"ࠩ࠿ࡿࢂࡀࠠࡱࡱࡺࡩࡷࡃࡻࡾࡀࠪ୾").format(self.__class__.__name__,
                                       goTenna.constants.POWERLEVELS.name(self.power))
    def __eq__(self, other):
        return isinstance(other, l1l1l111l1_opy_) and self.power == other.power
    @property
    def l111ll1111_opy_(self):
        return self.l1ll11ll11_opy_
    def __init__(self, power):
        if not goTenna.constants.POWERLEVELS.valid(power):
            raise TypeError(l1l1l1_opy_ (u"ࠪࡔࡴࡽࡥࡳࠢࡰࡹࡸࡺࠠࡣࡧࠣࡺࡦࡲࡩࡥࠩ୿"))
        self.power = power
    def serialize(self):
        return struct.pack(l1l1l1_opy_ (u"ࠫࠦࡈࠧ஀"), self.power)
    @classmethod
    def deserialize(cls, l111l11ll1_opy_):
        l1111111l1_opy_ = struct.unpack(l1l1l1_opy_ (u"ࠬࠧࡂࠨ஁"), l111l11ll1_opy_)
        return cls(l1111111l1_opy_[0])
class l1ll111lll_opy_(basic_tlv.TLV):
    l1l1l1_opy_ (u"ࠨࠢࠣࠢࡗࡐ࡛ࠦࡴࡰࠢࡶࡴࡪࡩࡩࡧࡻࠣࡲࡪࡺࡷࡰࡴ࡮ࠤࡲࡵࡤࡦࠢࡤࡸࠥࡩ࡯࡯ࡨ࡬࡫ࡺࡸࡡࡵ࡫ࡲࡲࠥࡺࡩ࡮ࡧ࠱ࠎࠥࠦࠠࠡࠤࠥࠦஂ")
    l1ll11ll11_opy_ = 0x2E
    def __repr__(self):
        return l1l1l1_opy_ (u"ࠧ࠽ࡽࢀ࠾ࠥࡳࡥࡴࡪ࡬ࡲ࡬ࡃࡻࡾ࠮ࠣࡸࡽࡥ࡯ࡳ࡫ࡪ࡭ࡳࡧࡴࡦࡦࡀࡿࢂ࠲ࠠࡧ࡮ࡲࡳࡩࡀࠠࡴࡪࡲࡹࡹࡃࡻࡾ࠮ࠣ࡫ࡷࡵࡵࡱ࠿ࡾࢁ࠱ࠦࠧஃ") \
               l1l1l1_opy_ (u"ࠨࡲࡵ࡭ࡻࡧࡴࡦ࠿ࡾࢁ࠱ࠦࡥ࡮ࡧࡵ࡫ࡪࡴࡣࡺ࠿ࡾࢁࡃ࠭஄") \
               .format(self.__class__.__name__, self.l1l111l1ll_opy_, self.l1l1l11111_opy_,
                       self.l1l11lllll_opy_, self.l1ll111111_opy_, self.l1l1111l1l_opy_,
                       self.l1l1ll11ll_opy_)
    def __eq__(self, other):
        return isinstance(other, l1ll111lll_opy_) \
               and self.l1l111l1ll_opy_ == other.l1l111l1ll_opy_ \
               and self.l1l1l11111_opy_ == other.l1l1l11111_opy_ \
               and self.l1l11lllll_opy_ == other.l1l11lllll_opy_ \
               and self.l1ll111111_opy_ == other.l1ll111111_opy_ \
               and self.l1l1111l1l_opy_ == other.l1l1111l1l_opy_ \
               and self.l1l1ll11ll_opy_ == other.l1l1ll11ll_opy_
    @property
    def l111ll1111_opy_(self):
        return self.l1ll11ll11_opy_
    def __init__(self, l1l111l1ll_opy_, l1l1l11111_opy_, l1l11lllll_opy_,
                 l1ll111111_opy_, l1l1111l1l_opy_, l1l1ll11ll_opy_):
        self.l1l111l1ll_opy_ = l1l111l1ll_opy_
        self.l1l1l11111_opy_ = l1l1l11111_opy_
        self.l1l11lllll_opy_ = l1l11lllll_opy_
        self.l1ll111111_opy_ = l1ll111111_opy_
        self.l1l1111l1l_opy_ = l1l1111l1l_opy_
        self.l1l1ll11ll_opy_ = l1l1ll11ll_opy_
    def serialize(self):
        return struct.pack(l1l1l1_opy_ (u"ࠩࠤࡆࡇࡈࡂࡃࡄࠪஅ"), self.l1l111l1ll_opy_, self.l1l1l11111_opy_,
                           self.l1l11lllll_opy_, self.l1ll111111_opy_,
                           self.l1l1111l1l_opy_, self.l1l1ll11ll_opy_)
    @classmethod
    def deserialize(cls, l111l11ll1_opy_):
        (l1l111l1ll_opy_, l1l1l11111_opy_, l1l11lllll_opy_, l1ll111111_opy_,
         l1l1111l1l_opy_, l1l1ll11ll_opy_) = struct.unpack(l1l1l1_opy_ (u"ࠪࠥࡇࡈࡂࡃࡄࡅࠫஆ"), l111l11ll1_opy_)
        return cls(l1l111l1ll_opy_, l1l1l11111_opy_, l1l11lllll_opy_, l1ll111111_opy_,
                   l1l1111l1l_opy_, l1l1ll11ll_opy_)
class l1l1l1l1l1_opy_(basic_tlv.TLV):
    l1l1l1_opy_ (u"ࠦࠧࠨࠠࡕࡎ࡙ࠤࡹࡵࠠࡴࡲࡨࡧ࡮࡬ࡹࠡࡶ࡫ࡩࠥࡵࡰࡦࡴࡤ࡭ࡹࡵ࡮ࠡ࡯ࡲࡨࡪࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡤࡦࡸ࡬ࡧࡪࠐࠠࠡࠢࠣࠦࠧࠨஇ")
    l1ll11ll11_opy_ = 0x35
    def __repr__(self):
        return l1l1l1_opy_ (u"ࠬࡂࡻࡾ࠼ࠣࡱࡴࡪࡥ࠾ࡽࢀࡂࠬஈ").format(self.__class__.__name__,
                                      goTenna.constants.OperationModes.name(self.mode))
    def __eq__(self, other):
        return isinstance(other, l1l1l1l1l1_opy_) and self.mode == other.mode
    @property
    def l111ll1111_opy_(self):
        return self.l1ll11ll11_opy_
    def __init__(self, mode):
        l1l1l1_opy_ (u"ࠨࠢࠣࠢࡅࡹ࡮ࡲࡤࠡࡣࡱࠤࡔࡶࡥࡳࡣࡷ࡭ࡴࡴࡍࡰࡦࡨࡘࡑ࡜࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣ࡭ࡳࡺࠠࡰࡴࠣࡷࡹࡸࠠ࡮ࡱࡧࡩ࠿ࠦࡔࡩࡧࠣࡱࡴࡪࡥ࠭ࠢࡤࡷࠥࡺࡨࡦࠢࡱࡥࡲ࡫ࠠࡰࡴࠣࡺࡦࡲࡵࡦࠢࡲࡪࠥࡧࠠ࡮ࡧࡰࡦࡪࡸࠠࡰࡨࠣ࠾ࡵࡿ࠺ࡤ࡮ࡤࡷࡸࡀࡠࡨࡱࡗࡩࡳࡴࡡ࠯ࡥࡲࡲࡸࡺࡡ࡯ࡶࡶ࠲ࡔࡶࡥࡳࡣࡷ࡭ࡴࡴࡍࡰࡦࡨࡷࡥࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥࡴࠢࡎࡩࡾࡋࡲࡳࡱࡵ࠾ࠥࡏࡦࠡࡢࡣࡱࡴࡪࡥࡡࡢࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡺࡦࡲࡩࡥࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨஉ")
        if mode in (goTenna.constants.OperationModes.OFF,
                    goTenna.constants.OperationModes.NORMAL,
                    goTenna.constants.OperationModes.RELAY):
            self.mode = mode
        else:
            try:
                self.mode = goTenna.constants.OperationModes.mode(mode)
            except Exception:
                raise KeyError(mode)
    def serialize(self):
        return struct.pack(l1l1l1_opy_ (u"ࠧࠢࡄࠪஊ"), self.mode)
    @classmethod
    def deserialize(cls, l111l11ll1_opy_):
        l1111111l1_opy_ = struct.unpack(l1l1l1_opy_ (u"ࠨࠣࡅࠫ஋"), l111l11ll1_opy_)
        return cls(l1111111l1_opy_[0])
class l1ll11l1ll_opy_(basic_tlv.TLV):
    l1l1l1_opy_ (u"ࠤ࡚ࠥࠦࠥࡌࡗࠢࡷࡳࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡴࡩࡧࠣࡩࡲ࡫ࡲࡨࡧࡱࡧࡾࠦࡢࡦࡣࡦࡳࡳࠦࡳࡵࡣࡷࡩࠏࠦࠠࠡࠢࠥࠦࠧ஌")
    l1ll11ll11_opy_ = 0x34
    def __repr__(self):
        return l1l1l1_opy_ (u"ࠪࡀࢀࢃ࠺ࠡࡧࡱࡥࡧࡲࡥࡥ࠿ࡾࢁࡃ࠭஍").format(self.__class__.__name__,
                                         self.enabled)
    def __eq__(self, other):
        return isinstance(other, l1ll11l1ll_opy_)\
            and self.enabled == other.enabled
    @property
    def l111ll1111_opy_(self):
        return self.l1ll11ll11_opy_
    def __init__(self, enabled):
        l1l1l1_opy_ (u"ࠦࠧࠨࠠࡃࡷ࡬ࡰࡩࠦࡡ࡯ࠢࡈࡱࡪࡸࡧࡦࡰࡦࡽࡇ࡫ࡡࡤࡱࡱࡘࡑ࡜ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡥࡳࡴࡲࠠࡦࡰࡤࡦࡱ࡫ࡤ࠻࡚ࠢ࡬ࡪࡺࡨࡦࡴࠣࡸࡴࠦࡥ࡯ࡣࡥࡰࡪࠦࠨࡡࡢࡗࡶࡺ࡫ࡠࡡࠫࠣࡳࡷࠦࡤࡪࡵࡤࡦࡱ࡫ࠠࠩࡢࡣࡊࡦࡲࡳࡦࡢࡣ࠭ࠥࡺࡨࡦࠢࡥࡩࡦࡩ࡯࡯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷࡧࡩࡴࡧࡶࠤ࡙ࡿࡰࡦࡇࡵࡶࡴࡸ࠺ࠡࡋࡩࠤࡥࡦࡥ࡯ࡣࡥࡰࡪࡪࡠࡡࠢࡦࡥࡳࡴ࡯ࡵࠢࡥࡩࠥ࡯࡮ࡵࡧࡵࡴࡷ࡫ࡴࡦࡦࠣࡥࡸࠦࡡࠡࡤࡲࡳࡱࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥஎ")
        self.enabled = bool(enabled)
    def serialize(self):
        return struct.pack(l1l1l1_opy_ (u"ࠬࠧࡂࠨஏ"), self.enabled)
    @classmethod
    def deserialize(cls, l111l11ll1_opy_):
        (l1111111l1_opy_,) = struct.unpack(l1l1l1_opy_ (u"࠭ࠡࡃࠩஐ"), l111l11ll1_opy_)
        return cls(l1111111l1_opy_)
class l1l11l11ll_opy_(basic_tlv.TLV):
    l1l1l1_opy_ (u"ࠢࠣࠤࠣࡘࡑ࡜ࠠࡵࡱࠣࡷࡵ࡫ࡣࡪࡨࡼࠤ࡬࡫࡯ࠡ࡮ࡲࡧࡦࡺࡩࡰࡰࠣࡥࡹࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡴࡪ࡯ࡨ࠲ࠏࠦࠠࠡࠢࠥࠦࠧ஑")
    l1ll11ll11_opy_ = 0x1F
    def __repr__(self):
        return l1l1l1_opy_ (u"ࠨ࠾ࡾࢁ࠿ࠦࡲࡦࡩ࡬ࡳࡳࡃࡻࡾࡀࠪஒ").format(self.__class__.__name__,
                                        goTenna.constants.GEO_REGION.name(self.region))
    def __eq__(self, other):
        return isinstance(other, l1l11l11ll_opy_) and self.region == other.region
    @property
    def l111ll1111_opy_(self):
        return self.l1ll11ll11_opy_
    def __init__(self, region):
        if not goTenna.constants.GEO_REGION.valid(region):
            raise TypeError(l1l1l1_opy_ (u"ࠩࡓࡳࡼ࡫ࡲࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡹࡥࡱ࡯ࡤࠨஓ"))
        self.region = region
    def serialize(self):
        return struct.pack(l1l1l1_opy_ (u"ࠪࠥࡇ࠭ஔ"), self.region)
    @classmethod
    def deserialize(cls, l111l11ll1_opy_):
        l1111111l1_opy_ = struct.unpack(l1l1l1_opy_ (u"ࠫࠦࡈࠧக"), l111l11ll1_opy_)
        return cls(l1111111l1_opy_[0])
class l11lllllll_opy_(basic_tlv.TLV):
    l1l1l1_opy_ (u"ࠧࠨࠢࠡࡖࡏ࡚ࠥࡺ࡯ࠡࡵࡳࡩࡨ࡯ࡦࡺࠢࡷ࡬ࡪࠦࡘ࠮ࡥࡤࡴࡦࡨࡩ࡭࡫ࡷࡽࠥࡹࡴࡢࡶࡨࠎࠥࠦࠠࠡࠤࠥࠦ஖")
    l1ll11ll11_opy_ = 0x3b
    def __repr__(self):
        return l1l1l1_opy_ (u"࠭࠼ࡼࡿ࠽ࠤࡪࡴࡡࡣ࡮ࡨࡨࡂࢁࡽ࠿ࠩ஗").format(self.__class__.__name__,
                                         self.enabled)
    def __eq__(self, other):
        return isinstance(other, l11lllllll_opy_)\
            and self.enabled == other.enabled
    @property
    def l111ll1111_opy_(self):
        return self.l1ll11ll11_opy_
    def __init__(self, enabled):
        l1l1l1_opy_ (u"ࠢࠣࠤࠣࡆࡺ࡯࡬ࡥࠢࡤࡲࠥ࡞ࡃࡢࡲࡤࡦࡱ࡫ࡔࡍࡘࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡨ࡯ࡰ࡮ࠣࡩࡳࡧࡢ࡭ࡧࡧ࠾ࠥ࡝ࡨࡦࡶ࡫ࡩࡷࠦࡴࡰࠢࡨࡲࡦࡨ࡬ࡦࠢࠫࡤࡥ࡚ࡲࡶࡧࡣࡤ࠮ࠦ࡯ࡳࠢࡧ࡭ࡸࡧࡢ࡭ࡧࠣࠬࡥࡦࡆࡢ࡮ࡶࡩࡥࡦࠩࠡࡶ࡫ࡩࠥࡾ࠭ࡤࡣࡳࡥࡧ࡯࡬ࡪࡶࡼࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡢ࡫ࡶࡩࡸࠦࡔࡺࡲࡨࡉࡷࡸ࡯ࡳ࠼ࠣࡍ࡫ࠦࡠࡡࡧࡱࡥࡧࡲࡥࡥࡢࡣࠤࡨࡧ࡮࡯ࡱࡷࠤࡧ࡫ࠠࡪࡰࡷࡩࡷࡶࡲࡦࡶࡨࡨࠥࡧࡳࠡࡣࠣࡦࡴࡵ࡬ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ஘")
        self.enabled = bool(enabled)
    def serialize(self):
        return struct.pack(l1l1l1_opy_ (u"ࠨࠣࡅࠫங"), self.enabled)
    @classmethod
    def deserialize(cls, l111l11ll1_opy_):
        (l1111111l1_opy_,) = struct.unpack(l1l1l1_opy_ (u"ࠩࠤࡆࠬச"), l111l11ll1_opy_)
        return cls(l1111111l1_opy_)
class l1ll11l1l1_opy_(basic_tlv.TLV):
    l1l1l1_opy_ (u"ࠥࠦࠧࠦࡔࡍࡘࠣࡸࡴࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡢࠢࡶࡽࡸࡺࡥ࡮ࠢࡳࡶࡴࡶࡥࡳࡶࡼࠤࡹࡵࠠࡳࡧࡷࡶ࡮࡫ࡶࡦࠢࠥࠦࠧ஛")
    l1ll11ll11_opy_ = 0x28
    @staticmethod
    def l111111l1l_opy_(prop):
        try:
            for tlv in _1llllllll1_opy_:
                if isinstance(tlv, basic_tlv.TLV)\
                   and tlv.l1ll11ll11_opy_ == prop:
                    return tlv.__name__
        except Exception:
            return l1l1l1_opy_ (u"ࠫࡁࡻ࡮࡬ࡰࡲࡻࡳࡄࠧஜ")
    def __repr__(self):
        return l1l1l1_opy_ (u"ࠬࡂࡻࡾ࠼ࠣࡴࡷࡵࡰ࠾ࡽࢀࠤ࠭ࢁࡽࠪࡀࠪ஝")\
            .format(self.__class__.__name__,
                    self.prop,
                    self.l111111l1l_opy_(self.prop))
    def __eq__(self, other):
        return isinstance(other, l1ll11l1l1_opy_)\
            and self.prop == other.prop
    @property
    def l111ll1111_opy_(self):
        return self.l1ll11ll11_opy_
    def __init__(self, prop):
        l1l1l1_opy_ (u"ࠨࠢࠣࠢࡅࡹ࡮ࡲࡤࠡࡣࠣࡋࡪࡺࡐࡳࡱࡳࡩࡷࡺࡹࡕࡎ࡙ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡩ࡯ࡶࠣࡴࡷࡵࡰ࠻ࠢࡗ࡬ࡪࠦࡰࡳࡱࡳࡩࡷࡺࡹࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧஞ")
        self.prop = prop
        try:
            _ = struct.pack(l1l1l1_opy_ (u"ࠧࠢࡄࠪட"), self.prop)
        except struct.error:
            raise TypeError(l1l1l1_opy_ (u"ࠣࡲࡵࡳࡵࠦ࡭ࡶࡵࡷࠤ࡫࡯ࡴࠡ࡫ࡱࠤࡦࠦࡢࡺࡶࡨ࠰ࠥ࡯ࡳࠡࡽࢀࠦ஠")
                            .format(type(self.prop)))
    def serialize(self):
        return struct.pack(l1l1l1_opy_ (u"ࠩࠤࡆࠬ஡"), self.prop)
    @classmethod
    def deserialize(cls, l111l11ll1_opy_):
        return cls(struct.unpack(l1l1l1_opy_ (u"ࠪࠥࡇ࠭஢"), l111l11ll1_opy_)[0])
_1llllllll1_opy_ = [l11111ll1l_opy_ for l11111ll1l_opy_ in vars().values()
        if isinstance(l11111ll1l_opy_, type)
        and issubclass(l11111ll1l_opy_, basic_tlv.TLV)]