# coding: utf8
import sys
l1l1ll_opy_ = sys.version_info [0] == 2
l1llll_opy_ = 2048
l11l1_opy_ = 7
def l1l1l1_opy_ (l1l1l_opy_):
    global l1ll11_opy_
    l1l111_opy_ = ord (l1l1l_opy_ [-1])
    l11_opy_ = l1l1l_opy_ [:-1]
    l111_opy_ = l1l111_opy_ % len (l11_opy_)
    ll_opy_ = l11_opy_ [:l111_opy_] + l11_opy_ [l111_opy_:]
    if l1l1ll_opy_:
        l1lll1_opy_ = unicode () .join ([unichr (ord (char) - l1llll_opy_ - (l1ll_opy_ + l1l111_opy_) % l11l1_opy_) for l1ll_opy_, char in enumerate (ll_opy_)])
    else:
        l1lll1_opy_ = str () .join ([chr (ord (char) - l1llll_opy_ - (l1ll_opy_ + l1l111_opy_) % l11l1_opy_) for l1ll_opy_, char in enumerate (ll_opy_)])
    return eval (l1lll1_opy_)
# Copyright (C) 2018 goTenna, Inc. This file is distributed as part of the
# goTenna USB SDK. See the associated license for more information.
# pylint: disable=line-too-long
l1l1l1_opy_ (u"ࠥࠦࠧࠐࡰࡤࡤࡢࡧࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴ࠺ࠡࡃࠣࡱࡴࡪࡵ࡭ࡧࠣࡧࡴࡴࡴࡢ࡫ࡱ࡭ࡳ࡭ࠠࡤ࡮ࡤࡷࡸ࡫ࡳࠡࡣࡱࡨࠥࡳࡥࡵࡪࡲࡨࡸࠦࡦࡰࡴࠣࡰࡴࡽ࠭࡭ࡧࡹࡩࡱࠦࡣࡰ࡯ࡰࡹࡳ࡯ࡣࡢࡶ࡬ࡳࡳࠦࡷࡪࡶ࡫ࠤࡦࠦࡧࡰࡖࡨࡲࡳࡧࠠࡷ࡫ࡤࠤࡦࠦࡳࡦࡴ࡬ࡥࡱࠦ࡬ࡪࡰ࡮࠲ࠏࠐࡁࡑࡋࠣࡧࡴࡴࡳࡶ࡯ࡨࡶࡸࠦࡰࡳࡱࡥࡥࡧࡲࡹࠡࡦࡲࠤࡳࡵࡴࠡࡰࡨࡩࡩࠦࡴࡩ࡫ࡶࠤࡲࡵࡤࡶ࡮ࡨ࠿ࠥࡺࡨࡦࡻࠣࡷ࡭ࡵࡵ࡭ࡦࠣ࡭ࡳࡺࡥࡳࡣࡦࡸࠥࡽࡩࡵࡪࠣࡸ࡭࡫ࠠࡂࡒࡌࠤࡹ࡮ࡲࡰࡷࡪ࡬ࠥࡺࡨࡦࠢ࠽ࡴࡾࡀ࡭ࡰࡦ࠽ࡤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡶࡲࡰࡢࠣࡱࡴࡪࡵ࡭ࡧ࠱ࠎࠧࠨࠢࣴ")
# pylint: enable=line-too-long
import datetime
import time
import re
import struct
import tempfile
import binascii
import logging
import collections
import os.path
import serial
import serial.tools.list_ports
import six
import goTenna.constants
import goTenna.filelock
import goTenna.util
_MODULE_LOGGER = logging.getLogger(__name__)
ListedDevice = collections.namedtuple(l1l1l1_opy_ (u"ࠫࡑ࡯ࡳࡵࡧࡧࡈࡪࡼࡩࡤࡧࠪࣵ"),
                                      (l1l1l1_opy_ (u"ࠬࡶࡲࡰࡦࡸࡧࡹࣶ࠭"), l1l1l1_opy_ (u"࠭ࡳࡦࡴ࡬ࡥࡱࡥ࡮ࡶ࡯ࡥࡩࡷ࠭ࣷ"), l1l1l1_opy_ (u"ࠧࡪࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫࣸ")))
#: A named tuple returned from :py:meth:`l1l11l111_opy_.list_devices`
class l1l11l111_opy_(object):
    l1l1l1_opy_ (u"ࠣࠤࠥࠤࡆࡴࠠࡪࡰࡷࡩࡷࡴࡡ࡭ࠢࡦࡰࡦࡹࡳࠡࡴࡨࡴࡷ࡫ࡳࡦࡰࡷ࡭ࡳ࡭ࠠࡢࠢࡦࡳࡳࡴࡥࡤࡶ࡬ࡳࡳࠦࡴࡰࠢࡤࠤ࡬ࡵࡔࡦࡰࡱࡥࠥࡪࡥࡷ࡫ࡦࡩ࠳ࠐࠊࠡࠢࠣࠤࡎࡴࠠࡵࡪ࡬ࡷࠥࡼࡥࡳࡵ࡬ࡳࡳࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡁࡑࡋ࠯ࠤࡹ࡮ࡥࠡࡥࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲࠥ࡯ࡳࠡ࡮࡬ࡱ࡮ࡺࡥࡥࠢࡷࡳࠥࡧࠠࡴࡧࡵ࡭ࡦࡲࠠࡱࡱࡵࡸࠥࡺࡲࡢࡰࡶࡱ࡮ࡺࡴࡦࡦࠣࡳࡻ࡫ࡲࠡࡗࡖࡆ࠳ࠐࠊࠡࠢࠣࠤ࡙࡮ࡩࡴࠢࡦࡰࡦࡹࡳࠡ࡯ࡤࡽࠥࡨࡥࠡࡷࡶࡩࡩࠦࡡࡴࠢࡤࠤࡨࡵ࡮ࡵࡧࡻࡸࠥࡳࡡ࡯ࡣࡪࡩࡷ࠲ࠠࡪࡰࠣࡻ࡭࡯ࡣࡩࠢࡦࡥࡸ࡫ࠠࡪࡶࠣ࡬ࡴࡲࡤࡴࠢࡷ࡬ࡪࠦࡰࡰࡴࡷࠤࡴࡶࡥ࡯ࠢࡷ࡬ࡷࡵࡵࡨࡪࠣࡸ࡭࡫ࠠࡤࡱࡱࡸࡪࡾࡴ࠯ࠢࡌࡪࠥࡴ࡯ࡵࠢࡸࡷࡪࡪࠠࡢࡵࠣࡥࠥࡩ࡯࡯ࡶࡨࡼࡹࠦ࡭ࡢࡰࡤ࡫ࡪࡸࠬࠡࡶ࡫ࡩࠥࡩࡡ࡭࡮ࡨࡶࠥ࡯ࡳࠡࡴࡨࡷࡵࡵ࡮ࡴ࡫ࡥࡰࡪࠦࡦࡰࡴࠣࡳࡵ࡫࡮ࡪࡰࡪࠤࡹ࡮ࡥࠡࡲࡲࡶࡹࠦࡢࡦࡨࡲࡶࡪࠦࡲࡦࡳࡸࡩࡸࡺࡩ࡯ࡩࠣࡨࡦࡺࡡࠡࡶࡵࡥࡳࡹ࡭ࡪࡵࡶ࡭ࡴࡴ࠮ࠋࠢࠣࠤࠥࠨࣹࠢࠣ")
    l11ll11ll_opy_ = 115200
    _LOGGER = _MODULE_LOGGER.getChild(l1l1l1_opy_ (u"ࠩࡊࡳ࡙࡫࡮࡯ࡣࡓࡇࡇࣺ࠭"))
    @staticmethod
    def l1l11l1l1_opy_(l11llllll_opy_):
        l1l1l1_opy_ (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡈࡧࡷࠤࡹ࡮ࡥࠡࡨࡸࡰࡱࠦࡡࡣࡵࡲࡰࡺࡺࡥࠡࡲࡤࡸ࡭ࠦࡴࡰࠢࡷ࡬ࡪࠦ࡬ࡰࡥ࡮ࡪ࡮ࡲࡥࠡࡶ࡫ࡥࡹࠦࡷࡦࠢࡺ࡭ࡱࡲࠠࡶࡵࡨࠤ࡫ࡵࡲࠡࡶ࡫ࡩࠥࡹࡰࡦࡥ࡬ࡪ࡮࡫ࡤࠡࡦࡨࡺ࡮ࡩࡥࠡࡲࡤࡸ࡭࠴ࠠࡘࡧࠣࡻ࡮ࡲ࡬ࠡࡪࡲࡰࡩࠦࡴࡩ࡫ࡶࠤࡱࡵࡣ࡬ࠢࡲࡴࡪࡴࠠࡧࡱࡵࠤࡹ࡮ࡥࠡ࡮࡬ࡪࡪࡺࡩ࡮ࡧࠣࡳ࡫ࠦࡴࡩࡧࠣࡋࡴ࡚ࡥ࡯ࡰࡤࡔࡈࡈࠠࡰࡤ࡭ࡩࡨࡺࠬࠡࡵࡲࠤࡹ࡮ࡡࡵࠢࡲࡸ࡭࡫ࡲࠡࡶ࡫ࡶࡪࡧࡤࡴࠢࡲࡶࠥࡵࡴࡩࡧࡵࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠣࡧࡦࡴࠠࡶࡵࡨࠤࡹ࡮ࡥࠡࡲࡵࡩࡸ࡫࡮ࡤࡧࠣࡳ࡫ࠦࡴࡩࡧࠣࡰࡴࡩ࡫ࠡࡣࡶࠤࡦࠦࡣࡶࡧࠣࡸࡴࠦࡡࡷࡱ࡬ࡨࠥࡩ࡯࡯ࡰࡨࡧࡹ࡯࡮ࡨࠢࡷࡳࠥࡧࠠࡥࡧࡹ࡭ࡨ࡫ࠠࡵࡪࡤࡸࠥ࡯ࡳࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡦࡳࡳࡴࡥࡤࡶࡨࡨ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡺࡥࡷࡴࡩ࡯ࡩ࠽ࠤ࡙࡮ࡩࡴࠢࡰࡩࡹ࡮࡯ࡥࠢࡶ࡬ࡴࡻ࡬ࡥࠢࡥࡩࠥࡩࡡ࡭࡮ࡨࡨࠥࡧࡳࠡࡨࡨࡻࠥࡺࡩ࡮ࡧࡶࠤࡦࡹࠠࡱࡱࡶࡷ࡮ࡨ࡬ࡦ࠮ࠣࡥࡳࡪࠠࡪࡶࡶࠤࡷ࡫ࡳࡶ࡮ࡷࠤࡸࡺ࡯ࡳࡧࡧ࠰ࠥࡺ࡯ࠡࡲࡵࡩࡻ࡫࡮ࡵࠢࡰࡳࡩ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡱࡩࠤࡹ࡮ࡥࠡࡧࡱࡺ࡮ࡸ࡯࡯࡯ࡨࡲࡹࠦ࡯ࡳࠢࡣࡤࡹ࡫࡭ࡱࡨ࡬ࡰࡪ࠴ࡴࡦ࡯ࡳࡨ࡮ࡸࡠࡡࠢ࡬ࡲࠥࡨࡥࡵࡹࡨࡩࡳࠦࡣࡢ࡮࡯ࡷ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡺࡥࡷࡴࡩ࡯ࡩ࠽ࠤࡇ࡫ࡣࡢࡷࡶࡩࠥࡺࡨࡦࠢ࡯ࡳࡨࡧࡴࡪࡱࡱࠤࡴ࡬ࠠࡵࡪࡨࠤࡹ࡫࡭ࡱࡱࡵࡥࡷࡿࠠࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠣࡹࡸ࡫ࡤࠡࡨࡲࡶࠥࡺࡨࡦࠢ࡯ࡳࡨࡱࠠࡥࡧࡳࡩࡳࡪࡳࠡࡱࡱࠤࡹ࡮ࡥࠡࡧࡱࡺ࡮ࡸ࡯࡯࡯ࡨࡲࡹ࠲ࠠࡪࡶࠣ࡭ࡸࠦࡰࡰࡵࡶ࡭ࡧࡲࡥࠡࡶ࡫ࡥࡹࠦࡤࡪࡨࡩࡩࡷ࡫࡮ࡵࠢࡦࡥࡱࡲࡳࠡࡶࡲࠤࡹ࡮ࡩࡴࠢࡰࡩࡹ࡮࡯ࡥ࠮ࠣࡨ࡮࡬ࡦࡦࡴࡨࡲࡹࠦࡴࡩࡴࡨࡥࡩࡹࠠࡪࡰࠣࡥࡳࠦࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠰ࠥࡵࡲࠡࡦ࡬ࡪ࡫࡫ࡲࡦࡰࡷࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠣࡱࡦࡿࠠࡨࡧࡷࠤࡩ࡯ࡦࡧࡧࡵࡩࡳࡺࠠࡳࡧࡶࡹࡱࡺࡳࠡࡣࡱࡨࠥࡩ࡯࡯ࡨ࡯࡭ࡨࡺ࠮ࠡࡗࡶࡩࡷࡹࠠࡴࡪࡲࡹࡱࡪࠠࡦ࡫ࡷ࡬ࡪࡸࠠࡦࡰࡶࡹࡷ࡫ࠠࡵࡪࡤࡸࠥࡺࡨࡦࠢࡨࡲࡻ࡯ࡲࡰࡰࡰࡩࡳࡺࡳࠡࡣࡵࡩࠥࡺࡨࡦࠢࡶࡥࡲ࡫ࠠࡣࡧࡷࡻࡪ࡫࡮ࠡࡣࡳࡴࠥ࡯࡮ࡴࡶࡤࡲࡹ࡯ࡡࡵ࡫ࡲࡲࡸ࠲ࠠࡰࡴࠣࡷࡪࡺࠠࡡࡢࡷࡩࡲࡶࡦࡪ࡮ࡨ࠲ࡹ࡫࡭ࡱࡦ࡬ࡶࡥࡦࠠࡵࡱࠣࡷࡴࡳࡥࡵࡪ࡬ࡲ࡬ࠦ࡫࡯ࡱࡺࡲ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡺࡥࡷࡴࡩ࡯ࡩ࠽ࠤࡇ࡫ࡣࡢࡷࡶࡩࠥࡺࡨࡪࡵࠣࡱࡪࡺࡨࡰࡦࠣࡨࡪࡶࡥ࡯ࡦࡶࠤࡴࡴࠠࡩࡣࡶ࡬࡮ࡴࡧࠡࡶ࡫ࡩࠥࡶࡡࡵࡪࠣࡸࡴࠦࡴࡩࡧࠣࡪ࡮ࡲࡥ࠭ࠢ࡬ࡸࠥࡽࡩ࡭࡮ࠣࡴࡪࡸࡦࡰࡴࡰࠤࡦࠦࡦࡶ࡮࡯ࠤ࡫࡯࡬ࡦࡲࡤࡸ࡭ࠦ࡮ࡰࡴࡰࡥࡱ࡯ࡺࡢࡶ࡬ࡳࡳࠦ࡯࡯ࠢࡷ࡬ࡪࠦࡩ࡯ࡲࡸࡸ࠱ࠦࡳࡰࠢࡩࡳࡷࠦࡩ࡯ࡵࡷࡥࡳࡩࡥࠡࡢࡣ࠳࡭ࡵ࡭ࡦ࠱࠱࠲࠴ࡪࡥࡷ࠱ࡷࡸࡾ࡛ࡓࡃࡃࡆࡑ࠵ࡦࡠࠡࡹ࡬ࡰࡱࠦࡨࡢࡸࡨࠤࡹ࡮ࡥࠡࡵࡤࡱࡪࠦ࡬ࡰࡥ࡮ࡪ࡮ࡲࡥࠡࡣࡶࠤࡥࡦ࠯ࡥࡧࡹ࠳ࡹࡺࡹࡖࡕࡅࡅࡈࡓ࠰ࡡࡢ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣࣻ")
        l1l1111l1_opy_ = goTenna.util.s2b(os.path.abspath(l11llllll_opy_))
        l1l1l11l1_opy_ = os.path.join(tempfile.gettempdir(),
                                l1l1l1_opy_ (u"ࠫ࠳࡭࡯ࡵࡧࡱࡲࡦ࠳ࠧࣼ")
                                + hex(binascii.crc_hqx(l1l1111l1_opy_, 0))[2:])
        l1l11l111_opy_._LOGGER.info(l1l1l1_opy_ (u"ࠧࡻࡳࡪࡰࡪࠤࡱࡵࡣ࡬ࡨ࡬ࡰࡪࠦࡻࡾࠤࣽ").format(l1l1l11l1_opy_))
        return l1l1l11l1_opy_
    def __init__(self, port, timeout=10, force=False):
        l1l1l1_opy_ (u"ࠨࠢࠣࠢࡆࡶࡪࡧࡴࡦࠢࡤࠤࡌࡵࡔࡦࡰࡱࡥࡕࡉࡂ࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡸࡺࡲࠡࡲࡲࡶࡹࡀࠠࡕࡪࡨࠤࡵࡧࡴࡩࠢࡷࡳࠥࡺࡨࡦࠢࡳࡳࡷࡺࠠࡵࡱࠣࡳࡵ࡫࡮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡩࡰࡴࡧࡴࠡࡶ࡬ࡱࡪࡵࡵࡵ࠼ࠣࡘ࡭࡫ࠠࡵ࡫ࡰࡩࡴࡻࡴࠡࡨࡲࡶࠥ࡫ࡡࡤࡪࠣࡧࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡤࡲࡳࡱࠦࡦࡰࡴࡦࡩ࠿ࠦࡗࡩࡧࡷ࡬ࡪࡸࠠࡵࡱࠣࡪࡴࡸࡣࡦࠢࡤࡧࡶࡻࡩࡳࡧࠣࡸ࡭࡫ࠠ࡭ࡱࡦ࡯ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡰࡲࡸࡪࡀࠠࡕࡪ࡬ࡷࠥࡩ࡬ࡢࡵࡶࠤࡼ࡯࡬࡭ࠢࡤࡧࡶࡻࡩࡳࡧࠣࡥࠥࡲ࡯ࡤ࡭ࠣࠬࡺࡹࡩ࡯ࡩࠣࡥࠥࡶ࡬ࡢࡶࡩࡳࡷࡳ࠭ࡴࡲࡨࡧ࡮࡬ࡩࡤࠢ࡯ࡳࡨࡱࡩ࡯ࡩࠣࡱࡪࡺࡨࡰࡦࠬࠤࡴࡴࠠࡢࠢࡷࡩࡲࡶࠠࡧ࡫࡯ࡩࠥࡨࡡࡴࡧࡧࠤࡴࡴࠠࡵࡪࡨࠤࡵࡧࡴࡩࠢࡷࡳࠥࡺࡨࡦࠢࡳࡳࡷࡺࠬࠡࡣࡱࡨࠥ࡮࡯࡭ࡦࠣ࡭ࡹࠦࡦࡰࡴࠣ࡭ࡹࡹࠠࡦࡰࡷ࡭ࡷ࡫ࠠ࡭࡫ࡩࡩࡹ࡯࡭ࡦ࠰ࠣࡍ࡫ࠦࡴࡩ࡫ࡶࠤ࡮ࡹࠠࡵࡪࡨࠤࡸ࡫ࡣࡰࡰࡧࠤ࡮ࡴࡳࡵࡣࡱࡧࡪࠦࡣࡳࡧࡤࡸࡪࡪࠠࡰࡰࠣࡥࠥ࡭ࡩࡷࡧࡱࠤࡵࡧࡴࡩ࠮ࠣ࡭ࡹࠦࡷࡪ࡮࡯ࠤࡷࡧࡩࡴࡧࠣࡥࡳࠦࡥࡹࡥࡨࡴࡹ࡯࡯࡯࠰ࠣࡍ࡫ࠦࡠࡡࡨࡲࡶࡨ࡫ࡠࡡࠢ࡬ࡷࠥࡦࡠࡕࡴࡸࡩࡥࡦࠬࠡࡶ࡫ࡩࠥࡲ࡯ࡤ࡭ࠣࡻ࡮ࡲ࡬ࠡࡤࡨࠤ࡫ࡵࡲࡤࡣࡥࡰࡾࠦࡡࡤࡳࡸ࡭ࡷ࡫ࡤ࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡡࡪࡵࡨࡷࠥࡘࡵ࡯ࡶ࡬ࡱࡪࡋࡲࡳࡱࡵ࠾ࠥࡏࡦࠡࡣࡱࡳࡹ࡮ࡥࡳࠢ࡬ࡲࡸࡺࡡ࡯ࡥࡨࠤࡴ࡬ࠠࡵࡪ࡬ࡷࠥࡩ࡬ࡢࡵࡶࠤ࡮ࡹࠠࡩࡱ࡯ࡨ࡮ࡴࡧࠡࡣࠣࡪ࡮ࡲࡥࠡ࡮ࡲࡧࡰ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦࣾ")
        self.port = serial.Serial(port=None, baudrate=self.l11ll11ll_opy_,
                                  write_timeout=1.0, timeout=0.25,
                                  inter_byte_timeout=0.001)
        self.port.port = port # this is too l11ll1lll_opy_ l1l1l1l11_opy_. help
        self.timeout = timeout
        l11ll1ll1_opy_ = self.l1l11l1l1_opy_(port)
        if force:
            self._LOGGER.info(l1l1l1_opy_ (u"ࠢࡇࡱࡵࡧ࡮ࡴࡧࠡࡥࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲࠦࠨࣿ"))
            os.remove(l11ll1ll1_opy_)
        self.l11llll11_opy_ = goTenna.filelock.FileLock(l11ll1ll1_opy_)
        try:
            self.l11llll11_opy_.acquire(timeout=0)
        except goTenna.filelock.Timeout as l1l11llll_opy_:
            raise RuntimeError(l1l1l1_opy_ (u"ࠣࡅࡲࡹࡱࡪࠠ࡯ࡱࡷࠤࡦࡩࡱࡶ࡫ࡵࡩࠥࡲ࡯ࡤ࡭ࠣࡪࡴࡸࠠࡼࡿ࠽ࠤࢀࢃࠢऀ")
                               .format(port, l1l11llll_opy_))
        self.open()
        try:
            self.port.flushInput()
        except AttributeError:
            self.port.reset_input_buffer()
        self._1lll1lll_opy_ = _MODULE_LOGGER.getChild(self.__class__.__name__)
    def __del__(self):
        try:
            self.l11llll11_opy_.release()
        except AttributeError:
            pass
        self.close()
    def __enter__(self):
        l1l1l1_opy_ (u"ࠤࠥࠦࠥࡉ࡯࡯ࡶࡨࡼࡹࠦ࡭ࡢࡰࡤ࡫ࡪࡸࠠࡦࡰࡷࡶࡾࠦࡰࡰ࡫ࡱࡸ࠳ࠦࡄࡰࡧࡶࠤࡳࡵࡴࡩ࡫ࡱ࡫࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠱࠲ࡩ࡫ࡰࡳࡧࡦࡥࡹ࡫ࡤࠡ࠲࠱࠺࠳࠶ࠠࡕࡪ࡬ࡷࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡢࡰࡧࠤࡹ࡮ࡥࠡࡥࡲࡲࡹ࡫ࡸࡵࠢࡳࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡦࡸࡥࠡࡪࡨࡶࡪࠦࡦࡰࡴࠣࡦࡦࡩ࡫ࡸࡣࡵࡨࡸࠦࡣࡰ࡯ࡳࡥࡹ࡯ࡢࡪ࡮࡬ࡸࡾࠦ࡯࡯࡮ࡼ࠲ࠥࡍ࡯ࡕࡧࡱࡲࡦࡖࡃࡃࠢࡱࡳࡼࠦࡣࡰࡰࡱࡩࡨࡺࡳࠡࡹ࡫ࡩࡳࠦࡩࡵࠢ࡬ࡷࠥ࡯࡮ࡴࡶࡤࡲࡹ࡯ࡡࡵࡧࡧࠤࡦࡴࡤࠡࡵ࡫ࡳࡺࡲࡤࠡࡤࡨࠤࡩ࡯ࡳࡱࡱࡶࡩࡩࠦࡩࡧࠢࡷ࡬ࡪࠦࡤࡦࡸ࡬ࡧࡪࠦࡤࡪࡵࡦࡳࡳࡴࡥࡤࡶࡶ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤँ")
        return
    def __exit__(self, exc_type, l11ll1l11_opy_, l11lll11l_opy_):
        l1l1l1_opy_ (u"ࠥࠦࠧࠦࡃࡰࡰࡷࡩࡽࡺࠠ࡮ࡣࡱࡥ࡬࡫ࡲࠡࡧࡻ࡭ࡹࠦࡰࡰ࡫ࡱࡸ࠳ࠦࡄࡰࡧࡶࠤࡳࡵࡴࡩ࡫ࡱ࡫࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠱࠲ࡩ࡫ࡰࡳࡧࡦࡥࡹ࡫ࡤࠡ࠲࠱࠺࠳࠶ࠠࡕࡪ࡬ࡷࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡢࡰࡧࠤࡹ࡮ࡥࠡࡥࡲࡲࡹ࡫ࡸࡵࠢࡳࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡦࡸࡥࠡࡪࡨࡶࡪࠦࡦࡰࡴࠣࡦࡦࡩ࡫ࡸࡣࡵࡨࡸࠦࡣࡰ࡯ࡳࡥࡹ࡯ࡢࡪ࡮࡬ࡸࡾࠦ࡯࡯࡮ࡼ࠲ࠥࡍ࡯ࡕࡧࡱࡲࡦࡖࡃࡃࠢࡱࡳࡼࠦࡣࡰࡰࡱࡩࡨࡺࡳࠡࡹ࡫ࡩࡳࠦࡩࡵࠢ࡬ࡷࠥ࡯࡮ࡴࡶࡤࡲࡹ࡯ࡡࡵࡧࡧࠤࡦࡴࡤࠡࡵ࡫ࡳࡺࡲࡤࠡࡤࡨࠤࡩ࡯ࡳࡱࡱࡶࡩࡩࠦࡩࡧࠢࡷ࡬ࡪࠦࡤࡦࡸ࡬ࡧࡪࠦࡤࡪࡵࡦࡳࡳࡴࡥࡤࡶࡶ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤं")
        return False
    def open(self):
        l1l1l1_opy_ (u"ࠦࠧࠨࠠࡐࡲࡨࡲࠥࡺࡨࡦࠢࡶࡩࡷ࡯ࡡ࡭ࠢࡳࡳࡷࡺ࠮ࠣࠤࠥः")
        self.port.open()
    def close(self):
        l1l1l1_opy_ (u"ࠧࠨࠢࠡࡅ࡯ࡳࡸ࡫ࠠࡵࡪࡨࠤࡸ࡫ࡲࡪࡣ࡯ࠤࡵࡵࡲࡵ࠰ࠥࠦࠧऄ")
        self.port.close()
    def write(self, msg):
        l1l1l1_opy_ (u"ࠨࠢࠣࠢࡖࡩࡳࡪࠠࡢࠢࡰࡩࡸࡹࡡࡨࡧࠣࡸࡴࠦࡴࡩࡧࠣࡷࡪࡸࡩࡢ࡮ࠣࡴࡴࡸࡴ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨअ")
        if not msg.endswith(l1l1l1_opy_ (u"ࠧ࡝ࡰࠪआ")):
            msg += l1l1l1_opy_ (u"ࠨ࡞ࡱࠫइ")
        command = bytes(msg)
        self.port.write(command)
    def write_binary(self, msg):
        l1l1l1_opy_ (u"ࠤࠥࠦࠥ࡝ࡲࡪࡶࡨࠤࡦࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡸ࡫ࡷ࡬ࠥࡨࡩ࡯ࡣࡵࡽࠥ࡬ࡲࡢ࡯࡬ࡲ࡬ࠦࡴࡰࠢࡷ࡬ࡪࠦࡤࡦࡸ࡬ࡧࡪ࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢࡋࡥࡳࡪ࡬ࡦࡵࠣࡸ࡭࡫ࠠࠡࡤ࡬ࡲࡦࡸࡹࠡࡨࡵࡥࡲ࡯࡮ࡨࠢࡤࡲࡩࠦࡳࡦࡰࡧࡷࠥ࡯ࡴࠡࡶࡲࠤࡹ࡮ࡥࠡࡦࡨࡺ࡮ࡩࡥ࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡸࡺࡲࠡ࡯ࡶ࡫࠿ࠦࡔࡩࡧࠣࡱࡪࡹࡳࡢࡩࡨࠤࡹࡵࠠࡣࡧࠣࡷࡪࡴࡴࠡࡣࡶࠤࡧ࡯࡮ࡢࡴࡼࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣई")
        l11lllll1_opy_ = bytes(goTenna.binary_utils.l11l_opy_(msg))
        self.port.write(l11lllll1_opy_)
    def read(self, l1l1l1l1l_opy_, l1l11ll11_opy_=None, timeout_override=None):
        l1l1l1_opy_ (u"ࠥࠦࠧࠦࡒࡦࡣࡧࠤࡧࡿࡴࡦࡵࠣࡹࡳࡺࡩ࡭ࠢࡤࠤࡵࡧࡴࡵࡧࡵࡲࠥ࡯ࡳࠡ࡯ࡤࡸࡨ࡮ࡥࡥࠢࡲࡶࠥࡺࡨࡦࠢࡷ࡭ࡲ࡫࡯ࡶࡶࠣ࡭ࡸࠦࡨࡪࡶ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦ࡬ࡪࡵࡷ࡟ࡸࡺࡲ࡞ࠢࡪࡳࡴࡪ࡟ࡱࡣࡷࡸࡪࡸ࡮ࡴ࠼ࠣࡅࠥࡲࡩࡴࡶࠣࡳ࡫ࠦࡲࡦࡩࡨࡼࡵࡹ࠮ࠡࡇࡤࡧ࡭ࠦࡷࡪ࡮࡯ࠤࡧ࡫ࠠࡢࡲࡳࡰ࡮࡫ࡤࠡࡶࡲࠤࡲࡧࡴࡤࡪࠣࡥࠥࡽࡨࡰ࡮ࡨࠤࡱ࡯࡮ࡦ࠮ࠣ࡭ࡳࠦ࡯ࡳࡦࡨࡶ࠳ࠦࡔࡩࡧࡼࠤࡸ࡮࡯ࡶ࡮ࡧࠤࡳࡵࡴࠡࡥࡲࡲࡹࡧࡩ࡯ࠢࡨࡼࡵࡲࡩࡤ࡫ࡷࠤࡲࡧࡴࡤࡪࡨࡷࠥ࡬࡯ࡳࠢࠪࡠࡡࡴࠧ࠯ࠢࡗ࡬ࡪࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠡ࡫ࡶࠤࡨࡵ࡮ࡴ࡫ࡧࡩࡷ࡫ࡤࠡࡶࡲࠤࡸࡻࡣࡤࡧࡨࡨࠥ࡯ࡦࠡࡣ࡯ࡰࠥ࡭࡯ࡰࡦࡢࡴࡦࡺࡴࡦࡴࡱࡷࠥࡧࡲࡦࠢࡰࡥࡹࡩࡨࡦࡦ࠯ࠤ࡮ࡴࠠࡰࡴࡧࡩࡷ࠲ࠠࡣࡧࡩࡳࡷ࡫ࠠࡵࡪࡨࠤࡹ࡯࡭ࡦࡱࡸࡸࠥ࡫ࡸࡱ࡫ࡵࡩࡸࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭࡫ࡶࡸࡠࡹࡴࡳ࡟ࠣࡩࡷࡸ࡯ࡳࡡࡳࡥࡹࡺࡥࡳࡰࡶ࠾ࠥࡇࠠ࡭࡫ࡶࡸࠥࡵࡦࠡࡴࡨ࡫ࡪࡾࡰࡴ࠰ࠣࡉࡦࡩࡨࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡤࡴࡵࡲࡩࡦࡦࠣࡸࡴࠦ࡭ࡢࡶࡦ࡬ࠥࡧ࡬࡭ࠢ࡬ࡲࡨࡵ࡭ࡪࡰࡪࠤࡱ࡯࡮ࡦࡵ࠱ࠤࡎ࡬ࠠࡢࡰࡼࠤࡲࡧࡴࡤࡪࡨࡷࠥࡧ࡮ࡺࠢ࡬ࡲࡨࡵ࡭ࡪࡰࡪࠤࡱ࡯࡮ࡦ࠮ࠣࡸ࡭࡫ࠠࡳࡧࡤࡨࠥ࡯ࡳࠡࡥࡲࡲࡸ࡯ࡤࡦࡴࡨࡨࠥࡺ࡯ࠡࡪࡤࡺࡪࠦࡦࡢ࡫࡯ࡩࡩ࠲ࠠࡢࡰࡧࠤࡦࠦࡒࡦ࡯ࡲࡸࡪࡋࡲࡳࡱࡵࠤࡼ࡯࡬࡭ࠢࡥࡩࠥࡸࡡࡪࡵࡨࡨ࠳ࠦࡎࡰࡶࡨࠤࡹ࡮ࡡࡵࠢࡷ࡬࡮ࡹࠠ࡮ࡧࡷ࡬ࡴࡪࠠࡢࡷࡷࡳࡲࡧࡴࡪࡥࡤࡰࡱࡿࠠ࡭ࡱࡲ࡯ࡸࠦࡦࡰࡴࠣࡱࡪࡹࡳࡢࡩࡨࡷࠥ࡯࡮ࠡࡶ࡫ࡩࠥࡶࡡࡵࡶࡨࡶࡳࠦࠧ࠯ࠬࡈࡖࡗࡕࡒ࠻࠰࠭ࠫࠥࡧ࡮ࡥࠢࡦࡶࡪࡧࡴࡦࡵࠣ࠾ࡵࡿ࠺ࡤ࡮ࡤࡷࡸࡀࡠࡨࡱࡗࡩࡳࡴࡡ࠯ࡵࡷࡳࡷࡧࡧࡦ࠰ࡕࡩࡲࡵࡴࡦࡇࡵࡶࡴࡸࡠࠡ࡫ࡱࡷࡹࡧ࡮ࡤࡧࡶࠤࡹ࡮ࡡࡵࠢ࡫ࡥࡻ࡫ࠠࡸࡧ࡯ࡰ࠲ࡪࡥࡧ࡫ࡱࡩࡩࠦࡩ࡯ࡨࡲࡶࡲࡧࡴࡪࡱࡱࠤࡵࡧࡲࡴࡧࡧࠤ࡫ࡸ࡯࡮ࠢࡷ࡬ࡪࠦࡲࡦ࡯ࡲࡸࡪࠦࡥࡳࡴࡲࡶࠥࡳࡥࡴࡵࡤ࡫ࡪ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡨ࡯ࡳࡦࡺࠠࡵ࡫ࡰࡩࡴࡻࡴࡠࡱࡹࡩࡷࡸࡩࡥࡧ࠽ࠤࡆࠦࡴࡪ࡯ࡨࡳࡺࡺࠠࡵࡱࠣࡳࡻ࡫ࡲࡳ࡫ࡧࡩࠥࡺࡨࡦࠢࡲࡲࡪࠦࡤࡦࡨ࡬ࡲࡪࡪࠠࡢࡶࠣࡧࡴࡴࡳࡵࡴࡸࡧࡹ࡯࡯࡯ࠢࡺ࡭ࡹ࡮࠮ࠡࡅࡤࡲࠥࡨࡥࠡࡷࡶࡩ࡫ࡻ࡬ࠡ࡫ࡱࠤࡹ࡮ࡥࠡࡥࡤࡷࡪࠦ࡯ࡧࠢࡰࡩࡸࡹࡡࡨࡧࡶࠤࡹ࡮ࡡࡵࠢࡷࡥࡰ࡫ࠠ࡮ࡷࡦ࡬ࠥࡲ࡯࡯ࡩࡨࡶࠥࡺࡨࡢࡰࠣࡹࡸࡻࡡ࡭ࠢࡨࡺࡪࡴࠠࡪࡨࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲࠬࠡࡵࡸࡧ࡭ࠦࡡࡴࠢࡶࡩࡳࡪࡩ࡯ࡩࠣࡥࠥࡶࡲࡪࡸࡤࡸࡪࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡢࡰࡧࠤࡦࡽࡡࡪࡶ࡬ࡲ࡬ࠦࡡ࡯ࠢࡤࡧࡰࡴ࡯ࡸ࡮ࡨࡨ࡬࡫࡭ࡦࡰࡷ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡰࡲࡸࡪࡀࠠࡕࡪࡨࠤࡷ࡫ࡧࡦࡺࠣࡴࡦࡺࡴࡦࡴࡱࡷࠥࡶࡡࡴࡵࡨࡨࠥࡺ࡯ࠡࡶ࡫࡭ࡸࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠡࡵ࡫ࡳࡺࡲࡤࠡࡪࡤࡺࡪࠦࡥࡹࡲ࡯࡭ࡨ࡯ࡴࠡࡲࡵࡩ࡫࡯ࡸࠡࡣࡱࡨࠥࡹࡵࡧࡨ࡬ࡼࠥࡽࡩ࡭ࡦࡦࡥࡷࡪࡩ࡯ࡩ࠯ࠤࡧ࡫ࡣࡢࡷࡶࡩࠥࡶࡹࡵࡪࡲࡲࠬࡹࠠࡳࡧ࠱ࡱࡦࡺࡣࡩࠢࡺ࡭ࡱࡲࠠ࡯ࡱࡷࠤࡲࡧࡴࡤࡪ࠯ࠤࡪ࠴ࡧ࠯࠮ࠣࡸ࡭࡫ࠠࡱࡣࡷࡸࡪࡸ࡮ࠡࠤࡉ࡛ࠥ࡜ࡥࡳࡵ࡬ࡳࡳࠨࠠࡵࡱࠣࡸ࡭࡫ࠠࡴࡶࡵ࡭ࡳ࡭ࠠࠣࠢࡉ࡛ࠥ࡜ࡥࡳࡵ࡬ࡳࡳࠨ࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱࠤࡱ࡯ࡳࡵ࡝ࡶࡸࡷࡣ࠺ࠡࡎ࡬ࡷࡹࠦ࡯ࡧࠢ࡯࡭ࡳ࡫ࡳࠡ࡯ࡤࡸࡨ࡮ࡩ࡯ࡩࠣࡤࡥ࡭࡯ࡰࡦࡢࡴࡦࡺࡴࡦࡴࡱࡷࡥࡦࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥࠡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡦࡳࡳࡹࡴࡢࡰࡷࡷ࠳࡚ࡩ࡮ࡧࡲࡹࡹࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮࠻ࠢ࡬ࡪࠥࡴ࡯ࡵࠢࡤࡰࡱࠦࡧࡰࡱࡧࡣࡵࡧࡴࡵࡧࡵࡲࡸࠦࡡࡳࡧࠣࡱࡦࡺࡣࡩࡧࡧࠤࡼ࡮ࡥ࡯ࠢࡷ࡬ࡪࠦࡴࡪ࡯ࡨࡳࡺࡺࠠࡦࡺࡳ࡭ࡷ࡫ࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡦ࡯ࡳࡦࠢࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡧࡴࡴࡳࡵࡣࡱࡸࡸ࠴ࡒࡦ࡯ࡲࡸࡪࡋࡲࡳࡱࡵ࠾ࠥ࡯ࡦࠡࡣࡱࡽࠥࡵࡦࠡࡶ࡫ࡩࠥ࡫ࡲࡳࡱࡵࡣࡵࡧࡴࡵࡧࡵࡲࡸࠦ࡯ࡳࠢࡷ࡬ࡪࠦࡢࡶ࡫࡯ࡸࠥ࡯࡮ࠡࡧࡵࡶࡴࡸࠠࡱࡣࡷࡸࡪࡸ࡮ࠡࠢࡰࡥࡹࡩࡨࡦࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡸ࡭࡫ࠠࡢࡤࡲࡺࡪࠦࡴࡸࡱࠣࡳࡺࡺࡣࡰ࡯ࡨࡷࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡰࡲࡸࡪࡀࠠࡕࡪ࡬ࡷࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡪࡵࠣࡥࠥ࡭ࡥ࡯ࡧࡵࡥࡹࡵࡲࠡࡣࡱࡨࠥࡹࡨࡰࡷ࡯ࡨࠥࡨࡥࠡ࡫ࡷࡩࡷࡧࡴࡦࡦࠣࡸ࡭ࡸ࡯ࡶࡩ࡫ࠤࡺࡴࡴࡪ࡮ࠣ࡭ࡹࠦࡥࡪࡶ࡫ࡩࡷࠦࡥ࡯ࡦࡶࠤ࠭ࡼࡩࡢࠢࡖࡸࡴࡶࡉࡵࡧࡵࡥࡹ࡯࡯࡯ࠫࠣࡳࡷࠦࡲࡢ࡫ࡶࡩࡸࠦࡡ࡯ࠢࡨࡼࡨ࡫ࡰࡵ࡫ࡲࡲ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡱࡳࡹ࡫࠺ࠡࡄࡨࡧࡦࡻࡳࡦࠢࡷ࡬࡮ࡹࠠࡪࡵࠣࡱࡪࡧ࡮ࡵࠢࡷࡳࠥࡽ࡯ࡳ࡭ࠣࡻ࡮ࡺࡨࠡࡒࡼࡸ࡭ࡵ࡮࠳࠰࠺࠰ࠥࡺࡨࡦࠢࡵࡩࡹࡻࡲ࡯ࠢࡹࡥࡱࡻࡥࠡࡨࡵࡳࡲࠦࡴࡩ࡫ࡶࠤࡲ࡫ࡴࡩࡱࡧࠤ࡮ࡹࠠࡴࡧࡱࡸࠥࡧࡳࠡࡶ࡫ࡩࠥࡧࡲࡨࡷࡰࡩࡳࡺࠠࡵࡱࠣࡗࡹࡵࡰࡊࡶࡨࡶࡦࡺࡩࡰࡰࠫ࠭࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠ࡯ࡱࡷࠤࡩ࡫ࡡ࡭ࠢࡺ࡭ࡹ࡮ࠠࡵࡪ࡬ࡷ࠱ࠦࡵࡴࡧࠣ࠾ࡵࡿ࠺࡮ࡧࡷ࡬࠿ࡦࡰࡤࡤࡢࡧࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴ࠮ࡳࡧࡤࡨࡤࡨ࡬ࡰࡥ࡮࡭ࡳ࡭ࡠ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨउ")
        if None is l1l11ll11_opy_:
            l1l11ll11_opy_ = []
        l1l11111l_opy_ = list(map(re.compile, l1l1l1l1l_opy_))
        l1l1111ll_opy_ = list(map(re.compile, l1l11ll11_opy_))
        l11ll1l1l_opy_ = re.compile(l1l1l1_opy_ (u"ࠫ࠳࠰࠺ࡆࡔࡕࡓࡗࡀ࠮ࠫࠩऊ"))
        to_return = []
        lines = [six.b(l1l1l1_opy_ (u"ࠬ࠭ऋ"))]
        timeout = self.timeout
        if timeout_override:
            timeout = timeout_override
        l1l11l11l_opy_ = datetime.datetime.utcnow()
        while True:
            now = datetime.datetime.utcnow()
            if (now-l1l11l11l_opy_).seconds > timeout:
                self._1lll1lll_opy_.debug(l1l1l1_opy_ (u"࠭ࡲࡦࡣࡧࠤࡹ࡯࡭ࡦࡱࡸࡸ࠿ࠦࡻࡾࠩऌ").format(timeout))
                raise goTenna.constants.TimeoutException(l1l1l1_opy_ (u"ࠢࡳࡧࡤࡨࠧऍ"),
                                                         (now-l1l11l11l_opy_).seconds)
            l1l111lll_opy_ = self.port.inWaiting()
            read = self.port.read(l1l111lll_opy_)
            l1l11l1ll_opy_ = read.split(six.b(l1l1l1_opy_ (u"ࠨ࡞ࡱࠫऎ")))
            l11ll11l1_opy_ = [l1l111l1l_opy_+six.b(l1l1l1_opy_ (u"ࠩ࡟ࡲࠬए")) for l1l111l1l_opy_ in l1l11l1ll_opy_[:-1]] + [l1l11l1ll_opy_[-1]]
            l11ll111l_opy_ = [l for l in l11ll11l1_opy_ if l != l1l1l1_opy_ (u"ࠪࡠࡳ࠭ऐ")]
            if not lines[-1].endswith(six.b(l1l1l1_opy_ (u"ࠫࡡࡴࠧऑ"))):
                lines[-1] = lines[-1] + l11ll111l_opy_[0]
                lines.extend(l11ll111l_opy_[1:])
            else:
                lines.extend(l11ll111l_opy_)
            for line in lines[:-1]:
                if re.match(l11ll1l1l_opy_, line):
                    parts = line.split(l1l1l1_opy_ (u"ࠬࡀࠧऒ"))
                    code = 0
                    msg = l1l1l1_opy_ (u"࠭ࠧओ")
                    for idx, part in enumerate(parts):
                        if part == l1l1l1_opy_ (u"ࠧࡆࡔࡕࡓࡗ࠭औ"):
                            if idx == len(parts)-1:
                                raise goTenna.constants.RemoteError(goTenna.constants.ErrorCodes.UNKNOWN,
                                                                    l1l1l1_opy_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡧࡩࡻ࡯ࡣࡦࠢࡨࡶࡷࡵࡲࠨक"))
                            try:
                                code = goTenna.util.l1lll1ll_opy_(parts[idx+1:idx+2])
                            except ValueError:
                                code = goTenna.constants.ErrorCodes.UNKNOWN
                            if idx != len(parts)-2:
                                msg = parts[idx+2:idx+3]
                            raise goTenna.constants.RemoteError(code, msg)
                if any([re.match(l1l11ll1l_opy_, line) for l1l11ll1l_opy_ in l1l1111ll_opy_]):
                    raise goTenna.constants.RemoteError(goTenna.constants.ErrorCodes.UNKNOWN,
                                                        line)
                if re.match(l1l11111l_opy_[0], line):
                    to_return.append(line)
                    if len(l1l11111l_opy_) == 1:
                        l1l11lll1_opy_ = StopIteration()
                        setattr(l1l11lll1_opy_, l1l1l1_opy_ (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩख"), to_return) # pylint: disable=no-member
                        raise l1l11lll1_opy_
                    else:
                        l1l11111l_opy_ = l1l11111l_opy_[1:]
            lines = lines[-1:]
            yield
    def l1l111ll1_opy_(self, l1l1l1l1l_opy_, l1l11ll11_opy_=None,
                      timeout_override=None,
                      interstitial_sleeps=0.1):
        l1l1l1_opy_ (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡓࡧࡤࡨࠥ࡬ࡲࡰ࡯ࠣࡸ࡭࡫ࠠࡤࡱࡱࡲࡪࡩࡴࡦࡦࠣࡨࡪࡼࡩࡤࡧ࠱ࠤ࡜ࡵࡲ࡬ࡵࠣࡸ࡭࡫ࠠࡴࡣࡰࡩࠥࡧࡳࠡ࠼ࡳࡽ࠿ࡳࡥࡵࡪ࠽ࡤࡵࡩࡢࡠࡥࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲ࠳ࡸࡥࡢࡦࡣࠤࡧࡻࡴࠡ࡫ࡶࠤࡳࡵࡴࠡࡣࠣ࡫ࡪࡴࡥࡳࡣࡷࡳࡷ࠲ࠠࡪࡰࡶࡸࡪࡧࡤࠡࡤ࡯ࡳࡨࡱࡩ࡯ࡩࠣࡹࡳࡺࡩ࡭ࠢࡨ࡭ࡹ࡮ࡥࡳࠢࡤࠤ࡬ࡵ࡯ࡥࠢࡵࡩࡹࡻࡲ࡯ࠢࡲࡶࠥ࡫ࡸࡤࡧࡳࡸ࡮ࡵ࡮࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡱ࡯ࡳࡵ࡝ࡶࡸࡷࡣࠠࡨࡱࡲࡨࡤࡶࡡࡵࡶࡨࡶࡳࡹ࠺ࠡࡃࠣࡰ࡮ࡹࡴࠡࡱࡩࠤࡷ࡫ࡧࡦࡺࡨࡷࠥࡺ࡯ࠡࡦࡨࡪ࡮ࡴࡥࠡࡩࡲࡳࡩࠦࡲࡦࡵࡳࡳࡳࡹࡥࡴ࠰ࠣࡊࡴࡸࠠ࡮ࡱࡵࡩࠥ࡯࡮ࡧࡱࡵࡱࡦࡺࡩࡰࡰࠣࡷࡪ࡫ࠠ࠻࠼ࡳࡽ࠿ࡳࡥࡵࡪ࠽ࡤࡵࡩࡢࡠࡥࡲࡲࡪࡩࡴࡪࡱࡱ࠲ࡷ࡫ࡡࡥࠪࠬࡤࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦ࡬ࡪࡵࡷ࡟ࡸࡺࡲ࡞ࠢࡨࡶࡷࡵࡲࡠࡲࡤࡸࡹ࡫ࡲ࡯ࡵ࠽ࠤࡆࠦ࡬ࡪࡵࡷࠤࡴ࡬ࠠࡳࡧࡪࡩࡽ࡫ࡳࠡࡶࡲࠤࡩ࡫ࡦࡪࡰࡨࠤࡪࡸࡲࡰࡴࠣࡶࡪࡹࡰࡰࡰࡶࡩࡸ࠴ࠠࡇࡱࡵࠤࡲࡵࡲࡦࠢ࡬ࡪࡳࡵࡲ࡮ࡣࡷ࡭ࡴࡴࠠࡴࡧࡨࠤ࠿ࡀࡰࡺ࠼ࡰࡩࡹ࡮࠺ࡡࡲࡦࡦࡤࡩ࡯࡯ࡰࡨࡧࡹ࡯࡯࡯࠰ࡵࡩࡦࡪࠨࠪࡢࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤ࡫ࡲ࡯ࡢࡶࠣ࡭ࡳࡺࡥࡳࡵࡷ࡭ࡹ࡯ࡡ࡭ࡡࡶࡰࡪ࡫ࡰࡴ࠼ࠣࡅࠥࡴࡵ࡮ࡤࡨࡶࠥࡵࡦࠡࡵࡨࡧࡴࡴࡤࡴࠢࡷࡳࠥࡽࡡࡪࡶࠣ࡭ࡳࠦࡢࡦࡶࡺࡩࡪࡴࠠࡤࡣ࡯ࡰࡸࠦ࡯ࡧࠢ࠽࠾ࡵࡿ࠺࡮ࡧࡷ࡬࠿ࡦࡰࡤࡤࡢࡧࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴ࠮ࡳࡧࡤࡨ࠭࠯ࡠࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾࡙ࠥࡥࡦࠢ࠽࠾ࡵࡿ࠺࡮ࡧࡷ࡬࠿ࡦࡰࡤࡤࡢࡧࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴ࠮ࡳࡧࡤࡨ࠭࠯ࡠࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡦ࡯ࡳࡦ࠼ࠣࡗࡪ࡫ࠠ࠻ࡲࡼ࠾ࡲ࡫ࡴࡩ࠼ࡣࡴࡨࡨ࡟ࡤࡱࡱࡲࡪࡩࡴࡪࡱࡱ࠲ࡷ࡫ࡡࡥࠪࠬࡤࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤग")
        l1l1l1111_opy_ = self.read(l1l1l1l1l_opy_, l1l11ll11_opy_,
                             timeout_override)
        while True:
            try:
                next(l1l1l1111_opy_)
                time.sleep(interstitial_sleeps)
            except StopIteration as l1l11lll1_opy_:
                return l1l11lll1_opy_.l11lll111_opy_ # pylint: disable=no-member
    def l1l1l111l_opy_(self, timeout_override=None):
        l1l1l1_opy_ (u"ࠦࠧࠨࠊࠡࠢࠣࠤࠥࠦࠠࠡࡔࡨࡥࡩࠦࡢࡪࡰࡤࡶࡾࠦࡤࡢࡶࡤࠤ࡫ࡸ࡯࡮ࠢࡷ࡬ࡪࠦࡣࡰࡰࡱࡩࡨࡺࡥࡥࠢࡧࡩࡻ࡯ࡣࡦ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤ࡛ࠥ࡮࡭࡫࡮ࡩࠥࡀࡰࡺ࠼ࡰࡩࡹ࡮࠺ࡡࡲࡦࡦࡤࡩ࡯࡯ࡰࡨࡧࡹ࡯࡯࡯࠰ࡵࡩࡦࡪࡠ࠭ࠢࡷ࡬࡮ࡹࠠ࡮ࡧࡷ࡬ࡴࡪࠠࡥࡱࡨࡷࠥࡴ࡯ࡵࠢࡧࡳࠥ࡯ࡴࡴࠢࡲࡻࡳࠦࡲࡦ࡯ࡲࡸࡪࠦࡥࡳࡴࡲࡶࠥ࡮ࡡ࡯ࡦ࡯࡭ࡳ࡭ࠬࠡ࡫ࡱࡷࡹ࡫ࡡࡥࠢࡶ࡭ࡲࡶ࡬ࡺࠢࡵࡩࡦࡪࡩ࡯ࡩࠣࡨࡦࡺࡡࠡࡣࡱࡨࠥࡹࡥ࡯ࡦ࡬ࡲ࡬ࠦࡩࡵࠢࡸࡴࡸࡺࡲࡦࡣࡰ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࡕࡪ࡬ࡷࠥࡳࡥࡵࡪࡲࡨࠥࡹࡨࡰࡷ࡯ࡨࠥࡵ࡮࡭ࡻࠣࡦࡪࠦࡵࡴࡧࡧࠤࡼ࡮ࡥ࡯ࠢࡨࡼࡵ࡫ࡣࡵ࡫ࡱ࡫ࠥࡨࡩ࡯ࡣࡵࡽࠥࡪࡡࡵࡣ࠱ࠤࡎࡺࠠࡸ࡫࡯ࡰࠥࡩ࡯࡮ࡲ࡯ࡥ࡮ࡴࠠࡪࡨࠣࡻ࡭ࡧࡴࠡ࡫ࡷࠤࡷ࡫ࡡࡥࡵࠣࡨࡴ࡫ࡳࠡࡰࡲࡸࠥ࡬࡯࡭࡮ࡲࡻࠥࡺࡨࡦࠢࡥ࡭ࡳࡧࡲࡺࠢࡩࡳࡷࡳࡡࡵࡶ࡬ࡲ࡬࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡷ࡭ࡲ࡫࡯ࡶࡶࡢࡳࡻ࡫ࡲࡳ࡫ࡧࡩ࠿ࠦࡏࡱࡶ࡬ࡳࡳࡧ࡬࠯ࠢࡖࡴࡪࡩࡩࡧࡻࠣࡥࠥࡴࡵ࡮ࡤࡨࡶࠥࡵࡦࠡࡵࡨࡧࡴࡴࡤࡴࠢࡷࡳࠥࡹࡥࡵࠢࡷ࡬ࡪࠦࡴࡪ࡯ࡨࡳࡺࡺࠠࡵࡱ࠯ࠤࡴࡼࡥࡳࡴ࡬ࡨ࡮ࡴࡧࠡࡶ࡫ࡩࠥࡼࡡ࡭ࡷࡨࠤࡸ࡫ࡴࠡࡹ࡫ࡩࡳࠦࡴࡩ࡫ࡶࠤ࡮ࡴࡳࡵࡣࡱࡧࡪࠦࡷࡢࡵࠣࡧࡷ࡫ࡡࡵࡧࡧ࠲ࠥࡏࡦࠡࡐࡲࡲࡪࠦ࡯ࡳࠢࡱࡳࡹࠦࡰࡳࡧࡶࡩࡳࡺࠬࠡࡦࡲࠤࡳࡵࡴࡩ࡫ࡱ࡫࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡶࡼࡴࡪࠦࡴࡪ࡯ࡨࡳࡺࡺ࡟ࡰࡸࡨࡶࡷ࡯ࡤࡦ࠼ࠣࡪࡱࡵࡡࡵࠢࡲࡶࠥࡔ࡯࡯ࡧࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡡࡪࡵࡨࡷࠥ࡜ࡡ࡭ࡷࡨࡉࡷࡸ࡯ࡳ࠼ࠣࡍ࡫ࠦࡴࡩࡧࠣࡶࡪࡹࡰࡰࡰࡶࡩࠥ࡯ࡳࠡࡰࡲࡸࠥ࡯࡮ࠡࡶ࡫ࡩࠥࡶࡲࡰࡲࡨࡶࠥ࡬࡯ࡳ࡯ࡤࡸ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡤ࡭ࡸ࡫ࡳࠡࡕࡷࡳࡵࡏࡴࡦࡴࡤࡸ࡮ࡵ࡮࠻࡚ࠢ࡬ࡪࡴࠠࡵࡪࡨࠤࡷ࡫ࡡࡥࠢ࡬ࡷࠥࡹࡵࡤࡥࡨࡷࡸ࡬ࡵ࡭࡮ࡼࠤࡨࡵ࡮ࡤ࡮ࡸࡨࡪࡪ࠮ࠡࡖ࡫ࡩࠥࡦࡠࡳࡧࡷࡺࡦࡲࡠࡡࠢࡰࡩࡲࡨࡥࡳࠢࡲࡪࠥࡺࡨࡦࠢࡣࡤࡘࡺ࡯ࡱࡋࡷࡩࡷࡧࡴࡪࡱࡱࡤࡥࠦࡩ࡯ࡵࡷࡥࡳࡩࡥࠡࡹ࡬ࡰࡱࠦࡣࡰࡰࡷࡥ࡮ࡴࠠࡵࡪࡨࠤࡦࡸࡲࡢࡻࠣࡶࡪࡧࡤ࠭ࠢࡤࡷࠥࡨࡹࡵࡧࡶ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤघ")
        if timeout_override:
            timeout = timeout_override
        else:
            timeout = self.timeout
        l1l11l11l_opy_ = datetime.datetime.utcnow()
        def l1l111111_opy_():
            now = datetime.datetime.utcnow()
            if (now-l1l11l11l_opy_).total_seconds() > timeout:
                self._1lll1lll_opy_.debug(l1l1l1_opy_ (u"ࠬࡸࡥࡢࡦࡢࡦ࡮ࡴࡡࡳࡻࠣࡸ࡮ࡳࡥࡰࡷࡷ࠾ࠥࢁࡽࠨङ").format(timeout))
                raise goTenna.constants.TimeoutException(l1l1l1_opy_ (u"ࠨࡲࡦࡣࡧࡣࡧ࡯࡮ࡢࡴࡼࠦच"),
                                                         (now-l1l11l11l_opy_).seconds)
        while True:
            l1l111111_opy_()
            l1l111lll_opy_ = self.port.inWaiting()
            if l1l111lll_opy_ < 3:
                pass
            else:
                chars = self.port.read(3)
                if chars[:1] != six.b(l1l1l1_opy_ (u"ࠧࡿࠩछ")):
                    l1l111l11_opy_ = self.port.readline()
                    l11llll1l_opy_\
                        = goTenna.util.display_bytestring(chars + l1l111l11_opy_)
                    raise ValueError(l1l1l1_opy_ (u"ࠣࡄࡤࡨࠥࡨࡩ࡯ࡣࡵࡽࠥࡳࡥࡴࡵࡤ࡫ࡪ࠲ࠠࡴࡶࡤࡶࡹ࡫ࡤࠡࡹ࡬ࡸ࡭ࠦࡻࡾ࠼ࠣࡿࢂࠨज")
                                     .format(l11llll1l_opy_[:4],
                                             l11llll1l_opy_))
                size = struct.unpack(l1l1l1_opy_ (u"ࠩࠤࡌࠬझ"), chars[1:])[0]
                break
            yield
        payload = six.b(l1l1l1_opy_ (u"ࠪࠫञ"))
        while True:
            l1l111111_opy_()
            l1l111lll_opy_ = self.port.inWaiting()
            payload += self.port.read(min(l1l111lll_opy_, size-len(payload)))
            if len(payload) == size:
                break
            yield
        yield payload
    def read_binary_blocking(self, timeout_override=None, interstitial_sleeps=0.1):
        l1l1l1_opy_ (u"ࠦࠧࠨࠊࠡࠢࠣࠤࠥࠦࠠࠡࡔࡨࡥࡩࠦࡢࡪࡰࡤࡶࡾࠦࡤࡢࡶࡤࠤ࡫ࡸ࡯࡮ࠢࡷ࡬ࡪࠦࡣࡰࡰࡱࡩࡨࡺࡥࡥࠢࡧࡩࡻ࡯ࡣࡦ࠰࡛ࠣࡴࡸ࡫ࡴࠢࡷ࡬ࡪࠦࡳࡢ࡯ࡨࠤࡦࡹࠠ࠻ࡲࡼ࠾ࡲ࡫ࡴࡩ࠼ࡣࡴࡨࡨ࡟ࡤࡱࡱࡲࡪࡩࡴࡪࡱࡱ࠲ࡷ࡫ࡡࡥࡡࡥ࡭ࡳࡧࡲࡺࡢࠣࡦࡺࡺࠠࡪࡵࠣࡲࡴࡺࠠࡢࠢࡪࡩࡳ࡫ࡲࡢࡶࡲࡶ࠱ࠦࡩ࡯ࡵࡷࡩࡦࡪࠠࡣ࡮ࡲࡧࡰ࡯࡮ࡨࠢࡸࡲࡹ࡯࡬ࠡࡧ࡬ࡸ࡭࡫ࡲࠡࡶ࡫ࡩࠥࡼࡡ࡭ࡷࡨࠤ࡮ࡹࠠࡳࡧࡤࡨࠥࡵࡲࠡࡣࠣࡸ࡮ࡳࡥࡰࡷࡷࠤࡴࡩࡣࡶࡴࡶ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡧ࡮ࡲࡥࡹࠦࡴࡪ࡯ࡨࡳࡺࡺ࡟ࡰࡸࡨࡶࡷ࡯ࡤࡦ࠼ࠣࡅࠥࡴࡵ࡮ࡤࡨࡶࠥࡵࡦࠡࡵࡨࡧࡴࡴࡤࡴࠢࡷࡳࠥࡹࡥࡵࠢࡤࡷࠥࡺࡨࡦࠢࡷ࡭ࡲ࡫࡯ࡶࡶ࠯ࠤࡴࡼࡥࡳࡴ࡬ࡨ࡮ࡴࡧࠡࡶ࡫ࡩࠥࡹࡥࡵࡶ࡬ࡲ࡬ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡦࡦࠣࡻ࡭࡫࡮ࠡࡶ࡫࡭ࡸࠦࡩ࡯ࡵࡷࡥࡳࡩࡥࠡࡹࡤࡷࠥࡩࡲࡦࡣࡷࡩࡩࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡪࡰࡷࡩࡷࡹࡴࡪࡶ࡬ࡥࡱࡥࡳ࡭ࡧࡨࡴࡸࡀࠠࡂࠢࡱࡹࡲࡨࡥࡳࠢࡲࡪࠥࡹࡥࡤࡱࡱࡨࡸࠦࡴࡰࠢࡶࡰࡪ࡫ࡰࠡ࡫ࡱࠤࡧ࡫ࡴࡸࡧࡨࡲࠥ࡯ࡴࡦࡴࡤࡸ࡮ࡵ࡮ࡴࠢࡲࡪࠥࡺࡨࡦࠢࡸࡲࡩ࡫ࡲ࡭ࡻ࡬ࡲ࡬ࠦࡧࡦࡰࡨࡶࡦࡺ࡯ࡳ࠰ࠣࡍ࡫ࠦࡎࡰࡰࡨ࠰ࠥࡪ࡯ࠡࡰࡲࡸࠥࡹ࡬ࡦࡧࡳ࠲࡚ࠥࡨࡪࡵࠣࡱࡦࡿࠠࡤࡣࡸࡷࡪࠦࡵ࡯ࡦࡸࡩࠥࡸࡥࡴࡱࡸࡶࡨ࡫ࠠࡤࡱࡱࡷࡺࡳࡰࡵ࡫ࡲࡲ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡶࡼࡴࡪࠦࡩ࡯ࡶࡨࡶࡸࡺࡩࡵ࡫ࡤࡰࡤࡹ࡬ࡦࡧࡳࡷ࠿ࠦࡦ࡭ࡱࡤࡸࠥࡵࡲࠡࡐࡲࡲࡪࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡩࡹࡻࡲ࡯࠼ࠣࡗࡪ࡫ࠠ࠻ࡲࡼ࠾ࡲ࡫ࡴࡩ࠼ࡣࡴࡨࡨ࡟ࡤࡱࡱࡲࡪࡩࡴࡪࡱࡱ࠲ࡷ࡫ࡡࡥࡡࡥ࡭ࡳࡧࡲࡺࡢࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡡࡪࡵࡨࡷ࠿ࠦࡓࡦࡧࠣ࠾ࡵࡿ࠺࡮ࡧࡷ࡬࠿ࡦࡰࡤࡤࡢࡧࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴ࠮ࡳࡧࡤࡨࡤࡨࡩ࡯ࡣࡵࡽࡥࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥट")
        l1l1l1111_opy_ = self.l1l1l111l_opy_(timeout_override)
        for to_return in l1l1l1111_opy_:
            if interstitial_sleeps:
                time.sleep(interstitial_sleeps)
        return to_return
    @staticmethod
    def list_devices():
        l1l1l1_opy_ (u"ࠧࠨࠢࠡࡎ࡬ࡷࡹࠦࡣࡶࡴࡵࡩࡳࡺ࡬ࡺ࠯ࡦࡳࡳࡴࡥࡤࡶࡨࡨࠥ࡭࡯ࡕࡧࡱࡲࡦࠦࡐࡳࡱࠣࡨࡪࡼࡩࡤࡧࡶ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡨࡸࡺࡸ࡮ࠡ࡮࡬ࡷࡹࡡࡳࡵࡴࡠࠤࡕࡧࡴࡩࡵࠣࡸࡴࠦࡣࡰࡰࡱࡩࡨࡺࡥࡥࠢࡪࡳ࡙࡫࡮࡯ࡣࡶ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤठ")
        devices = serial.tools.list_ports.comports()
        to_return = []
        l1l1l11ll_opy_ = {l1l1l1_opy_ (u"࠭ࡇࡐࡖࡈࡒࡓࡇࠠ࠺࠲࠳ࠫड"): l1l1l1_opy_ (u"ࠧ࠺࠲࠳ࠫढ"),
                                  l1l1l1_opy_ (u"ࠨࡉࡒࡘࡊࡔࡎࡂࠢࡓࡖࡔ࠭ण"): l1l1l1_opy_ (u"ࠩࡳࡶࡴ࠭त"),
                                  l1l1l1_opy_ (u"࡚ࠪࡎࡘࡔࡖࡃࡏࠤࡈࡕࡍࠡࡒࡒࡖ࡙࠭थ"): None}
        for device in devices:
            if device.vid == 0x1fc9:
                if device.pid == 0x8181:
                    l11lll1ll_opy_ = l1l1l1_opy_ (u"ࠫࡌࡕࡔࡆࡐࡑࡅࠥࡖࡒࡐࠩद")
                    l11lll1l1_opy_ = True
                elif device.pid == 0x8182:
                    l11lll1ll_opy_ = l1l1l1_opy_ (u"ࠬࡍࡏࡕࡇࡑࡒࡆࠦ࠹࠱࠲ࠪध")
                    l11lll1l1_opy_ = True
                else:
                    l11lll1ll_opy_ = None
                    l11lll1l1_opy_ = False
                if l11lll1l1_opy_:
                    to_return.append(ListedDevice(l1l1l11ll_opy_.get(l11lll1ll_opy_, None),
                                                  device.serial_number,
                                                  device.device))
        return to_return
def list_devices():
    l1l1l1_opy_ (u"ࠨࠢࠣࠢࡆࡥࡱࡲࡳࠡ࠼ࡳࡽ࠿ࡳࡥࡵࡪ࠽ࡤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡶࡣࡣࡡࡦࡳࡳࡴࡥࡤࡶ࡬ࡳࡳ࠴ࡇࡰࡖࡨࡲࡳࡧࡐࡄࡄ࠱ࡰ࡮ࡹࡴࡠࡦࡨࡺ࡮ࡩࡥࡴࡢࠣࡪࡴࡸࠠࡤࡱࡰࡴࡦࡺࡩࡣ࡫࡯࡭ࡹࡿ࠮ࠋࠢࠣࠤࠥࠨࠢࠣन")
    return l1l11l111_opy_.list_devices()