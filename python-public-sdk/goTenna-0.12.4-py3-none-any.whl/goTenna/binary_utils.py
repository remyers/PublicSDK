# coding: utf8
import sys
l1l1ll_opy_ = sys.version_info [0] == 2
l1llll_opy_ = 2048
l11l1_opy_ = 7
def l1l1l1_opy_ (l1l1l_opy_):
    global l1ll11_opy_
    l1l111_opy_ = ord (l1l1l_opy_ [-1])
    l11_opy_ = l1l1l_opy_ [:-1]
    l111_opy_ = l1l111_opy_ % len (l11_opy_)
    ll_opy_ = l11_opy_ [:l111_opy_] + l11_opy_ [l111_opy_:]
    if l1l1ll_opy_:
        l1lll1_opy_ = unicode () .join ([unichr (ord (char) - l1llll_opy_ - (l1ll_opy_ + l1l111_opy_) % l11l1_opy_) for l1ll_opy_, char in enumerate (ll_opy_)])
    else:
        l1lll1_opy_ = str () .join ([chr (ord (char) - l1llll_opy_ - (l1ll_opy_ + l1l111_opy_) % l11l1_opy_) for l1ll_opy_, char in enumerate (ll_opy_)])
    return eval (l1lll1_opy_)
# Copyright (C) 2018 goTenna, Inc. This file is distributed as part of the
# goTenna USB SDK. See the associated license for more information.
# pylint: disable=line-too-long
l1l1l1_opy_ (u"ࠦࠧࠨࠊࠡࡤ࡬ࡲࡦࡸࡹࡠࡷࡷ࡭ࡱࡹࠠ࠮ࠢࡄࠤࡲࡵࡤࡶ࡮ࡨࠤࡨࡵ࡬࡭ࡧࡦࡸ࡮ࡴࡧࠡࡷࡶࡩ࡫ࡻ࡬ࠡࡨࡸࡲࡨࡺࡩࡰࡰࡶࠤࡦࡴࡤࠡࡥࡲࡲࡸࡺࡡ࡯ࡶࡶࠤ࡫ࡵࡲࠡࡤ࡬ࡲࡦࡸࡹࠡࡥࡲࡱࡲࡻ࡮ࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡹ࡬ࡸ࡭ࠦࡡࠡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࠍࠎࡈࡵࡰࡺࡴ࡬࡫࡭ࡺࠠ࠳࠲࠴࠻ࠥ࡭࡯ࡕࡧࡱࡲࡦࠦࡉ࡯ࡥ࠱ࠎࠧࠨࠢࠀ")
# pylint: enable=line-too-long
import binascii
import struct
import six
import goTenna.settings
import goTenna.util
l11ll_opy_ = six.b(l1l1l1_opy_ (u"ࠬࢄࠧࠁ"))
l1l1l1_opy_ (u"ࠨࠢࠣࠢࡗ࡬ࡪࠦ࡭ࡢࡩ࡬ࡧࠥࡩࡨࡢࡴࡤࡧࡹ࡫ࡲࠡࡶࡲࠤࡵࡸࡥࡱࡧࡱࡨࠥࡺ࡯ࠡࡤ࡬ࡲࡦࡸࡹࠡ࡯ࡨࡷࡸࡧࡧࡦࡵࠣࠦࠧࠨࠂ")
l1_opy_ = {
    l1l1l1_opy_ (u"ࠧࡦࡥ࡫ࡳࠬࠃ"): six.b(l1l1l1_opy_ (u"ࠨ࡞ࡻ࠴࠵࠭ࠄ")),
    l1l1l1_opy_ (u"ࠩࡶࡩࡹࡥࡧࡪࡦࠪࠅ"): six.b(l1l1l1_opy_ (u"ࠪࡠࡽ࠶࠱ࠨࠆ")),
    l1l1l1_opy_ (u"ࠫࡸ࡫ࡴࡠࡲࡸࡦࡱ࡯ࡣࡠ࡭ࡨࡽࠬࠇ"): six.b(l1l1l1_opy_ (u"ࠬࡢࡸ࠱࠴ࠪࠈ")),
    l1l1l1_opy_ (u"࠭ࡳࡦࡰࡧࡣࡲ࡫ࡳࡴࡣࡪࡩࠬࠉ"): six.b(l1l1l1_opy_ (u"ࠧ࡝ࡺ࠳࠷ࠬࠊ")),
    l1l1l1_opy_ (u"ࠨࡩࡨࡸࡤࡹࡹࡴࡡ࡬ࡲ࡫ࡵࠧࠋ"): six.b(l1l1l1_opy_ (u"ࠩ࡟ࡼ࠵࠺ࠧࠌ")),
    l1l1l1_opy_ (u"ࠪ࡫ࡪࡺ࡟ࡴࡶࡲࡶࡪࡪ࡟ࡪࡰࡩࡳࠬࠍ"): six.b(l1l1l1_opy_ (u"ࠫࡡࡾ࠰࠶ࠩࠎ")),
    l1l1l1_opy_ (u"ࠬ࡭ࡥࡵࡡࡩ࡭ࡷࡹࡴࡠࡵࡷࡳࡷ࡫ࡤࡠ࡯ࡨࡷࡸࡧࡧࡦࠩࠏ"): six.b(l1l1l1_opy_ (u"࠭࡜ࡹ࠲࠹ࠫࠐ")),
    l1l1l1_opy_ (u"ࠧࡥࡧ࡯ࡩࡹ࡫࡟ࡧ࡫ࡵࡷࡹࡥࡳࡵࡱࡵࡩࡩࡥ࡭ࡦࡵࡶࡥ࡬࡫ࠧࠑ"): six.b(l1l1l1_opy_ (u"ࠨ࡞ࡻ࠴࠼࠭ࠒ")),
    l1l1l1_opy_ (u"ࠩ࡬ࡲ࡮ࡺࡩࡢࡶࡨࡣࡳ࡫ࡷࡠࡨࡺࡣ࡮ࡳࡡࡨࡧࠪࠓ"): six.b(l1l1l1_opy_ (u"ࠪࡠࡽ࠶࠸ࠨࠔ")),
    l1l1l1_opy_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡥࡦࡸࡡ࡬ࡱࡦ࡭ࡥࠨࠕ"): six.b(l1l1l1_opy_ (u"ࠬࡢࡸ࠱࠻ࠪࠖ")),
    l1l1l1_opy_ (u"࠭ࡦࡪࡰࡤࡰ࡮ࢀࡥࡠࡨࡺࡣ࡮ࡳࡡࡨࡧࠪࠗ"): six.b(l1l1l1_opy_ (u"ࠧ࡝ࡺ࠳ࡥࠬ࠘")),
    l1l1l1_opy_ (u"ࠨࡴࡨࡷࡪࡺ࡟ࡨ࡫ࡧࠫ࠙"): six.b(l1l1l1_opy_ (u"ࠩ࡟ࡼ࠵ࡨࠧࠚ")),
    l1l1l1_opy_ (u"ࠪࡨ࡮ࡹࡣࡰࡰࡱࡩࡨࡺ࡟ࡣ࡮ࡸࡩࡹࡵ࡯ࡵࡪࠪࠛ"): six.b(l1l1l1_opy_ (u"ࠫࡡࡾ࠰ࡤࠩࠜ")),
    l1l1l1_opy_ (u"ࠬࡪࡥ࡭ࡧࡷࡩࡤ࡭ࡩࡥࠩࠝ"): six.b(l1l1l1_opy_ (u"࠭࡜ࡹ࠲ࡧࠫࠞ")),
    l1l1l1_opy_ (u"ࠧࡢࡰࡷࡩࡳࡴࡡࡠࡵࡺࡩࡪࡶࠧࠟ"): six.b(l1l1l1_opy_ (u"ࠨ࡞ࡻ࠴ࡪ࠭ࠠ")),
    l1l1l1_opy_ (u"ࠩࡳࡹࡱࡲ࡟ࡥࡧࡹ࡭ࡨ࡫࡟ࡢ࡮ࡨࡶࡹ࠭ࠡ"): six.b(l1l1l1_opy_ (u"ࠪࡠࡽ࠶ࡦࠨࠢ")),
    l1l1l1_opy_ (u"ࠫࡸ࡫ࡴࡠࡣࡳࡴࡤ࡯ࡤࠨࠣ"): six.b(l1l1l1_opy_ (u"ࠬࡢࡸ࠲࠲ࠪࠤ")),
    l1l1l1_opy_ (u"࠭ࡳࡦࡶࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡣࡲࡵࡤࡦࠩࠥ"): six.b(l1l1l1_opy_ (u"ࠧ࡝ࡺ࠴࠵ࠬࠦ")),
    l1l1l1_opy_ (u"ࠨࡩࡨࡸࡤࡨࡩ࡯ࡣࡵࡽࡤࡲ࡯ࡨࠩࠧ"): six.b(l1l1l1_opy_ (u"ࠩ࡟ࡼ࠶࠸ࠧࠨ")),
    l1l1l1_opy_ (u"ࠪࡧࡱ࡫ࡡࡳࡡࡤࡰࡱࡥ࡬ࡰࡩࠪࠩ"): six.b(l1l1l1_opy_ (u"ࠫࡡࡾ࠱࠴ࠩࠪ")),
    l1l1l1_opy_ (u"ࠬࡹࡥ࡯ࡦࡢࡴࡦࡩ࡫ࡦࡶࡶࠫࠫ"): six.b(l1l1l1_opy_ (u"࠭࡜ࡹ࠳࠷ࠫࠬ")),
    l1l1l1_opy_ (u"ࠧࡣ࡮ࡨࡣࡧ࡫ࡲࠨ࠭"): six.b(l1l1l1_opy_ (u"ࠨ࡞ࡻ࠵࠺࠭࠮")),
    l1l1l1_opy_ (u"ࠩࡶࡸࡷࡥࡤࡢࡶࡨࡣࡹ࡯࡭ࡦࠩ࠯"): six.b(l1l1l1_opy_ (u"ࠪࡠࡽ࠷࠶ࠨ࠰")),
    l1l1l1_opy_ (u"ࠫࡹࡸࡸࡠࡲࡲࡻࡪࡸࡳࡢࡸ࡬ࡲ࡬࠭࠱"): six.b(l1l1l1_opy_ (u"ࠬࡢࡸ࠲࠹ࠪ࠲")),
    l1l1l1_opy_ (u"࠭ࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦࡢࡪࡼࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ࠳"): six.b(l1l1l1_opy_ (u"ࠧ࡝ࡺ࠴࠼ࠬ࠴")),
    l1l1l1_opy_ (u"ࠨࡪࡤࡶࡩࡥࡲࡦࡵࡨࡸࠬ࠵"): six.b(l1l1l1_opy_ (u"ࠩ࡟ࡼ࠶࠿ࠧ࠶")),
    l1l1l1_opy_ (u"ࠪࡶࡪࡹࡥࡵࡡࡳࡹࡧࡲࡩࡤࡡ࡮ࡩࡾ࠭࠷"): six.b(l1l1l1_opy_ (u"ࠫࡡࡾ࠱ࡢࠩ࠸")),
    l1l1l1_opy_ (u"ࠬࡹࡥࡵࡡࡳࡶࡴࡶࡥࡳࡶࡼࠫ࠹"): six.b(l1l1l1_opy_ (u"࠭࡜ࡹ࠳ࡥࠫ࠺")),
    l1l1l1_opy_ (u"ࠧࡴࡧࡷࡣࡷࡻ࡮ࡵ࡫ࡰࡩࡤࡶࡲࡰࡲࡨࡶࡹࡿࠧ࠻"): six.b(l1l1l1_opy_ (u"ࠨ࡞ࡻ࠵ࡨ࠭࠼")),
    l1l1l1_opy_ (u"ࠩࡪࡩࡹࡥࡲࡶࡰࡷ࡭ࡲ࡫࡟ࡱࡴࡲࡴࡪࡸࡴࡺࠩ࠽"): six.b(l1l1l1_opy_ (u"ࠪࡠࡽ࠷ࡤࠨ࠾")),
    l1l1l1_opy_ (u"ࠫࡸࡺࡡࡳࡶࡢࡦࡦࡩ࡫ࡨࡴࡲࡹࡳࡪ࡟ࡧࡹࡢࡹࡵࡪࡡࡵࡧࠪ࠿"): six.b(l1l1l1_opy_ (u"ࠬࡢࡸ࠲ࡧࠪࡀ")),
    l1l1l1_opy_ (u"࠭ࡧࡦࡶࡢࡷࡹࡧࡴࡴࠩࡁ"): six.b(l1l1l1_opy_ (u"ࠧ࡝ࡺ࠴ࡪࠬࡂ")),
    l1l1l1_opy_ (u"ࠨࡴࡨࡷࡪࡺ࡟ࡴࡶࡤࡸࡸ࠭ࡃ"): six.b(l1l1l1_opy_ (u"ࠩ࡟ࡼ࠷࠶ࠧࡄ")),
    l1l1l1_opy_ (u"ࠪࡷࡪࡺ࡟ࡨࡧࡲࡣ࡫࡫࡮ࡤ࡫ࡱ࡫ࠬࡅ"): six.b(l1l1l1_opy_ (u"ࠫࡡࡾ࠲࠲ࠩࡆ")),
    l1l1l1_opy_ (u"ࠬ࡭ࡥࡵࡡࡪࡩࡴࡥࡦࡦࡰࡦ࡭ࡳ࡭ࠧࡇ"): six.b(l1l1l1_opy_ (u"࠭࡜ࡹ࠴࠵ࠫࡈ")),
    l1l1l1_opy_ (u"ࠧࡳࡵࡶ࡭ࠬࡉ"): six.b(l1l1l1_opy_ (u"ࠨ࡞ࡻ࠶࠸࠭ࡊ")),
    l1l1l1_opy_ (u"ࠩࡵࡷࡸ࡯࡟࡭࡫ࡶࡸࡪࡴࠧࡋ"): six.b(l1l1l1_opy_ (u"ࠪࡠࡽ࠸࠴ࠨࡌ")),
    l1l1l1_opy_ (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡵ࡫ࡲࡵࡻࠪࡍ"): six.b(l1l1l1_opy_ (u"ࠬࡢࡸ࠳࠷ࠪࡎ")),
    l1l1l1_opy_ (u"࠭ࡧࡦࡶࡢࡪࡦࡻ࡬ࡵࡡ࡬ࡲ࡫ࡵࠧࡏ"): six.b(l1l1l1_opy_ (u"ࠧ࡝ࡺ࠵࠺ࠬࡐ")),
    l1l1l1_opy_ (u"ࠨࡩࡨࡸࡤࡪࡤࡪࠩࡑ"): six.b(l1l1l1_opy_ (u"ࠩ࡟ࡼ࠷࠽ࠧࡒ")),
    l1l1l1_opy_ (u"ࠪࡷࡹࡵࡲࡦࡡࡨࡱࡪࡸࡧࡦࡰࡦࡽࠬࡓ"): six.b(l1l1l1_opy_ (u"ࠫࡡࡾ࠲ࡤࠩࡔ")),
}
def l1l_opy_(l1ll1l_opy_):
    l1l1l1_opy_ (u"ࠧࠨࠢࠡࡆࡨࡸࡪࡸ࡭ࡪࡰࡨࠤ࡮࡬ࠠࡢࠢࡥࡽࡹ࡫ࠠࡪࡵࠣࡥࠥࡔࡁࡌࠢࡲࡶࠥࡇࡃࡌࠌࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡪࡰࡷࠤࡨࡳࡤࡠࡤࡼࡸࡪࡀࠠࡂࠢࡥࡽࡹ࡫ࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶ࡬ࡲ࡬ࠦࡴࡩࡧࠣࡧࡴࡳ࡭ࡢࡰࡧࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲࡸࠦࡢࡰࡱ࡯࠾࡚ࠥࡲࡶࡧࠣ࡭࡫ࠦࡴࡩࡧࠣࡥࡷ࡭ࡵ࡮ࡧࡱࡸࠥ࡯ࡳࠡࡣࠣࡒࡆࡑ࠮ࠋࠌࠣࠤࠥࠦࡔࡩࡧࠣࡦࡾࡺࡥࠡ࡫ࡶࠤࡦࠦࡎࡂࡍࠣ࡭࡫ࠦࡢࡪࡶࠣ࠻ࠥ࡯ࡳࠡࡵࡨࡸ࠳ࠐࠠࠡࠢࠣࠦࠧࠨࡕ")
    return (l1ll1l_opy_ & 0x80) != 0
def l1l1_opy_(l1ll1l_opy_):
    l1l1l1_opy_ (u"ࠨࠢࠣࠢࡇࡩࡹ࡫ࡲ࡮࡫ࡱࡩࠥ࡯ࡦࠡࡣࠣࡦࡾࡺࡥࠡ࡫ࡶࠤࡦࡴࠠࡂࡅࡎࠤࡴࡸࠠࡏࡃࡎࠎࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢ࡬ࡲࡹࠦࡣ࡮ࡦࡢࡦࡾࡺࡥ࠻ࠢࡄࠤࡧࡿࡴࡦࠢࡵࡩࡵࡸࡥࡴࡧࡱࡸ࡮ࡴࡧࠡࡶ࡫ࡩࠥࡩ࡯࡮࡯ࡤࡲࡩࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴࡳࠡࡤࡲࡳࡱࡀࠠࡕࡴࡸࡩࠥ࡯ࡦࠡࡶ࡫ࡩࠥࡧࡲࡨࡷࡰࡩࡳࡺࠠࡪࡵࠣࡥࡳࠦࡁࡄࡍ࠱ࠎࠥࠦࠠࠡࠤࠥࠦࡖ")
    return not l1l_opy_(l1ll1l_opy_)
def l1l11_opy_(l1ll1l_opy_):
    l1l1l1_opy_ (u"ࠢࠣࠤࠣࡖࡪࡺࡵࡳࡰࠣࡸ࡭࡫ࠠࡤࡱࡰࡱࡦࡴࡤࠡࡹ࡬ࡸ࡭ࡵࡵࡵࠢࡷ࡬ࡪࠦࡁࡄࡍ࠲ࡒࡆࡑࠠࡣ࡫ࡷࡷࠥࠦࠢࠣࠤࡗ")
    return l1ll1l_opy_ & 0x3f
def l11l_opy_(text):
    l1l1l1_opy_ (u"ࠣࠤࠥࠤ࡜ࡸࡡࡱࠢࡤࠤࡵࡧࡹ࡭ࡱࡤࡨࠥ࡯࡮ࠡࡶ࡫ࡩࠥ࡫ࡸࡵࡴࡤࡷࠥࡸࡥࡲࡷ࡬ࡶࡪࡪࠠࡧࡱࡵࠤࡧ࡯࡮ࡢࡴࡼࠤࡨࡵ࡭࡮ࡷࡱ࡭ࡨࡧࡴࡪࡱࡱࠎࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡥࡽࡹ࡫ࡳ࡭࡫࡮ࡩࠥࡺࡥࡹࡶ࠽ࠤࡘࡵ࡭ࡦࡶ࡫࡭ࡳ࡭ࠠࡵࡪࡤࡸࠥࡲ࡯ࡰ࡭ࡶࠤࡱ࡯࡫ࡦࠢࡤࠤࡸ࡫ࡱࡶࡧࡱࡧࡪࠦࡡ࡯ࡦࠣࡻࡴࡴࠧࡵࠢࡨࡼࡵࡲ࡯ࡥࡧࠣࡻ࡭࡫࡮ࠡࡧࡹࡩࡳࡺࡵࡢ࡮࡯ࡽࠥࡹࡥ࡯ࡶࠣࡸࡴࠦࡴࡩࡧࠣࡨࡪࡼࡩࡤࡧࠍࠤࠥࠦࠠࠣࠤࠥࡘ")
    l1111_opy_ = goTenna.util.ensure_bytes(text)
    l11ll1_opy_ = l11ll_opy_ + struct.pack(l1l1l1_opy_ (u"ࠩࠤࡌ࡙ࠬ"), len(l1111_opy_)+2) + l1111_opy_
    l11ll1_opy_ += struct.pack(l1l1l1_opy_ (u"ࠪࠥࡍ࡚࠭"), binascii.crc_hqx(l11ll1_opy_, 0))
    return l11ll1_opy_
def l1l11l_opy_(sdk_key, gid, membership=None, l1lll_opy_=False):
    l1l1l1_opy_ (u"ࠦࠧࠨࠠࡑࡣࡦ࡯ࠥࡧࠠ࠻ࡲࡼ࠾ࡦࡺࡴࡳ࠼ࡣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡊࡆࡣࠤ࡮ࡴࡴࡰࠢࡤࠤࡧࡻࡦࡧࡧࡵࠤࡸࡻࡩࡵࡣࡥࡰࡪࠦࡦࡰࡴࠣࡹࡸ࡯࡮ࡨࠢࡺ࡭ࡹ࡮ࠠࡨ࡫ࡧࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥࡳࡥࡵࡪࡲࡨࡸࠐࠊࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡸࡺࡲࡪࡰࡪࠤࡸࡪ࡫ࡠ࡭ࡨࡽ࠿ࠦࡔࡩࡧࠣࡗࡉࡑࠠ࡬ࡧࡼࠤࡹ࡮ࡥࠡࡉࡌࡈࠥ࡯ࡳࠡࡣࡶࡷࡴࡩࡩࡢࡶࡨࡨࠥࡽࡩࡵࡪ࠱ࠤ࡜࡯࡬࡭ࠢࡥࡩࠥࡩࡨࡦࡥ࡮ࡩࡩࠦࡦࡰࡴࠣࡺࡦࡲࡩࡥ࡫ࡷࡽ࠳ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡊࡆࠣ࡫࡮ࡪ࠺ࠡࡖ࡫ࡩࠥࡍࡉࡅࠢࡷࡳࠥࡶࡡࡤ࡭ࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡮ࡧࡰࡦࡪࡸࡳࡩ࡫ࡳ࠾ࠥࡕࡰࡵ࡫ࡲࡲࡦࡲࠠ࡮ࡧࡰࡦࡪࡸࡳࡩ࡫ࡳࠤࡳࡻ࡭ࡣࡧࡵ࠲ࠥࡏࡦࠡࡰࡲࡸࠥࡶࡲࡦࡵࡨࡲࡹ࠲ࠠࡈࡋࡇࠤ࡮ࡹࠠࡢࡵࡶࡹࡲ࡫ࡤࠡࡶࡲࠤࡵࡸࡩࡷࡣࡷࡩ࠳ࠦࡉࡧࠢࡳࡶࡪࡹࡥ࡯ࡶ࠯ࠤࡌࡏࡄࠡ࡫ࡶࠤࡦࡹࡳࡶ࡯ࡨࡨࠥࡺ࡯ࠡࡤࡨࠤࡦࠦࡧࡳࡱࡸࡴࠥࡍࡉࡅ࠰ࠍࠤࠥࠦࠠ࠻ࡶࡼࡴࡪࠦ࡭ࡦ࡯ࡥࡩࡷࡹࡨࡪࡲ࠽ࠤࡓࡵ࡮ࡦࠢࡲࡶࠥ࡯࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡢࡰࡱ࡯ࠤࡸࡱࡩࡱࡡࡰࡩࡲࡨࡥࡳࡵ࡫࡭ࡵࡀࠠࡡࡢࡗࡶࡺ࡫ࡠࡡࠢ࡬ࡪࠥࡺࡨࡦࠢࡰࡩࡲࡨࡥࡳࡵ࡫࡭ࡵࠦࡳࡩࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡦࡪࠦࡳࡦࡰࡷࠤ࠭ࡧࡳࠡ࡫ࡱࠤࡼ࡮ࡥ࡯ࠢࡧࡩࡱ࡫ࡴࡪࡰࡪࠤࡦࠦࡇࡊࡆࠬ࠿ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡪࡶࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡦࡪࠦࡳࡦࡰࡷ࠲ࠏࠦࠠࠡࠢ࠽ࡶࡦ࡯ࡳࡦࡵࠣࡘࡾࡶࡥࡆࡴࡵࡳࡷࡀࠠࡪࡨࠣ࡫࡮ࡪࠠࡪࡵࠣࡲࡴࡺࠠࡵࡪࡨࠤࡵࡸ࡯ࡱࡧࡵࠤࡹࡿࡰࡦࠌࠣࠤࠥࠦ࠺ࡳࡣ࡬ࡷࡪࡹࠠࡗࡣ࡯ࡹࡪࡋࡲࡳࡱࡵ࠾ࠥ࡯ࡦࠡࡕࡇࡏࠥࡱࡥࡺࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡹࡥࡱ࡯ࡤࠋࠢࠣࠤࠥࡀࡲࡦࡶࡸࡶࡳࡹࠠࡣࡻࡷࡩࡸࡀࠊࠡࠢࠣࠤࠧࠨ࡛ࠢ")
    if not isinstance(gid, goTenna.settings.GID):
        raise TypeError(gid)
    magic = six.b(l1l1l1_opy_ (u"ࠬ࠷ࡶ࠲ࡦࡤ࠸࡯࠾࠳࠺࠵࠴࠴ࡧࡵࡨࡥࡨࡪࡱ࠼ࡰࡱ࠸࠸ࡲ࠻ࡹ࠼࠳ࡥࡳࡶ࡮ࡲ࠹࠷ࡴ࠲ࡹ࠴ࡺࡩࡳ࠱ࡦࡱࡶࠬ࡜"))
    checker = goTenna.encryption.sdk_token_valid(sdk_key)
    _, l1ll1_opy_ = checker(magic[::-1])
    if None is membership:
        membership = 0
    l11lll_opy_ = struct.pack(l1l1l1_opy_ (u"࠭ࠡࡃࡊࠪ࡝"), gid.gid_type, l1ll1_opy_)
    l111l_opy_ = struct.pack(l1l1l1_opy_ (u"ࠧࠢࡓࠪ࡞"), gid.gid_val)[2:]
    command = l11lll_opy_ + l111l_opy_
    if not l1lll_opy_:
        command += struct.pack(l1l1l1_opy_ (u"ࠨࠣࡅࠫ࡟"), membership)
    return command