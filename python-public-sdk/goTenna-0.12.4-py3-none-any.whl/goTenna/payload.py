# coding: utf8
# Copyright (C) 2018 goTenna, Inc. This file is distributed as part of the
# goTenna USB SDK. See the associated license for more information.
# pylint: disable=line-too-long
""" goTenna.payload: Classes defining message payloads

The classes defined here represent the payload part of messages. Some of the information contained in these payloads is required for routing, but the vast majority is user-specifiable and carries the content of the message.

The payload structure is made up of a base class, :py:class:`Payload`, which defines all the metadata common to each payload type; and subclasses for each different kind of payload. Each payload type defines the message types (from :py:attr:`goTenna.constants.LAYER8_MESSAGE_TYPES`) that associate with it, and its own serialization and deserialization routines that handle the data specific to that payload.

A special subclass, :py:class:`CustomPayload`, is provided to capture anything that cannot be parsed into one of the other subclasses of :py:class:`Payload`. If parsing fails for any reason, the message is represented as containing a :py:class:`CustomPayload` through which the raw contents of the payload, as byteslike, are accessible.
"""
# pylint: enable=line-too-long

import logging
import struct
import copy

import six

import goTenna.constants
from goTenna.tlv import payload_tlv
from goTenna.tlv import message_tlv
import goTenna.settings

_MODULE_LOGGER = logging.getLogger(__name__)

class Payload(object):
    # pylint: disable=line-too-long
    """ A base class representing a message payload. Should not be instantiated directly; instead, should be built with one of the factory functions. Primarily exists to feed to the initializer or factory methods of :py:class:`Message`.

    The ``Payload`` type largely exists to be subclassed by specific kinds of payloads that know their message types and contents. To subclass ``Payload``, a child must

    - Override :py:meth:`serialize` with a method that returns bytes representing the payload-specific parts of the payload: for instance, :py:meth:`TextPayload.serialize` returns the serialized bytes of its :py:class:`goTenna.tlv.payload_tlv.TextTLV`.
    - Override :py:meth:`deserialize` with a method that takes a list of TLVs, which will be the non-common parts of the payload received on the network.
    - Have a property :py:attr:`payload_type` returning the appropriate member of :py:obj:`goTenna.constants.LAYER8_MESSAGE_TYPE` for the subclass. This is used when serializing messages to determine what message type should be encoded in the message.
    - Have a class attribute ``MESSAGE_TYPES`` that is a tuple containing message types the class responds to. This should be a member of :py:class:`goTenna.constants.LAYER8_MESSAGE_TYPES`.  This is used when parsing received messages to select which subclass of :py:class:`Payload` should be built.

    Once these methods and attributes are defined, the class will work with :py:meth:`deserialize` and :py:meth:`serialize` and be automatically deserialized from incoming messages if the message's type matches one of the elements of ``MESSAGE_TYPE``. If an exception is raised during deserialization, ``Payload`` will fall back to creating a :py:class:`CustomPayload` that interprets the payload as bytes.

    In general, it is not necessary to define custom payloads. The SDK comes with a number of ``Payload`` subclasses tailored to various different kinds of data, from locations to text to pings. The :py:class:`CustomPayload` fallback can also be used as a container of bytes that are later parsed by the application.

    The field containing the sender of the message is automatically updated by the driver when a payload is sent, unless it has previously been set via :py:meth:`Payload.set_sender`. To explicitly set the sender of a payload to something other than the private GID configured in the driver, call :py:meth:`Payload.set_sender` before sending the payload. If the sender is set when the payload is sent, and the driver is configured as a  gateway, the sender is assumed to be external.
    """
    # pylint: enable=line-too-long
    _LOGGER = _MODULE_LOGGER.getChild('Payload')

    @property
    def counter(self):
        """ The counter used to disambiguate identical messages """
        return self._counter

    @property
    def sender(self):
        """ Read-only property for accessing the message sender.

        :returns goTenna.settings.GID: The sender
        """
        return self._sender

    @property
    def time_sent(self):
        # pylint: disable=line-too-long
        """ Return the time the payload was sent

        :returns datetime.datetime: The time. If the datetime is naive, it should be assumed to be in UTC.
        """
        # pylint: enable=line-too-long
        return self._time_sent

    @property
    def valid(self):
        # pylint: disable=line-too-long
        """ Property to check if all the common data is properly set and the payload is ready for transmission."""
        # pylint: enable=line-too-long
        return all([prop is not None for prop in [self.sender,
                                                  self.time_sent,
                                                  self.counter,
                                                  self.sender_initials]])\
                and type(self) is not Payload

    @property
    def encrypted(self):
        """ Whether the payload is or should be encrypted """
        return self._encrypt

    @property
    def encryption_counter(self):
        """ The cryptographic encryption_counter used for the payload """
        return self._encryption_counter

    def __eq__(self, other):
        return isinstance(other, Payload)\
            and self.sender == other.sender \
            and self.time_sent == other.time_sent \
            and self.counter == other.counter \
            and self.sender_initials == other.sender_initials

    def __ne__(self, other):
        return not self.__eq__(other)

    def _print_contents(self):
        """ Helper for subclass reprs """
        return 'sender={}, time_sent={}, counter={}, sender_initials={}'\
            .format(self.sender, self.time_sent,
                    self.counter, self.sender_initials)

    def __repr__(self):
        return '<{}: {}>'.format(self.__class__.__name__, self._print_contents())

    def __init__(self):
        # pylint: disable=line-too-long
        """ Build the payload.

        This class should not be instantiated directly, and will never be seen when a message is received. Instead, one of the child classes of :py:class:`Payload` should be used when sending, and will be received.
        """
        # pylint: enable=line-too-long
        # The default values of the common data
        self._sender = None
        self._counter = None
        self._sender_initials = None
        self._time_sent = None
        self._encrypt = False
        self._encrypt_hook = None
        self._encryption_counter = 0

    def set_encryption(self, should_encrypt, encryption_counter=0, encrypt_hook=None):
        # pylint: disable=line-too-long
        """ Configure whether or not the palyoad should be encrypted

        :param bool should_encrypt: Whether or not the payload should be encrypted. If True (or truthy), ``encrypt_hook`` should be specified.
        :param int encryption_counter: A encryption_counter to use for the encryption, if encryption is desired. This should fit in 16 bytes and should be different for every subsequent message between a specific pair of GIDs.
        :param callable encrypt_hook: A function to call to encrypt the contents of the payload. The hook is given the payload metadata. The form is
            .. function:: encrypt_hook(sender_gid, time_sent, encryption_counter, plaintext)
                :param goTenna.settings.GID sender_gid: The sender of the message
                :param datetime.datetime time_sent: The time the message was sent
                :param int encryption_counter: The payload encryption_counter, a 16-bit counter that changes with every meant-to-be-unique message sent from a specific sender to a specific destination
                :param byteslike plaintext: The message content to encrypt
        """
        # pylint: enable=line-too-long
        self._encrypt_hook = encrypt_hook
        self._encrypt = bool(should_encrypt)
        self._encryption_counter = encryption_counter

    def set_sender(self, sender):
        # pylint: disable=line-too-long
        """ Set the sender of the payload.

        :param sender: The sender. If ``None``, reset and make the payload invalid.
        :type sender: None or goTenna.settings.GID
        :returns: The object this method was called on, to allow chaining

        The GID must be private. It may have a gateway set.
        """
        # pylint: enable=line-too-long
        if sender is not None and not isinstance(sender, goTenna.settings.GID):
            raise TypeError("invalid sender for Payload: should be None or GID, not {}"
                            .format(type(sender)))
        if sender.gid_type != goTenna.settings.GID.PRIVATE:
            raise ValueError("invalid sender for Payload: only private GIDs can originate messages")
        self._sender = sender
        # return ourselves to allow method chaining
        return self

    def set_counter(self, counter):
        # pylint: disable=line-too-long
        """ Set the deduplication counter of the payload.

        :param sender: The counter. If ``None``, reset and make the payload invalid. Should be in [0, 255].
        :type sender: None or int
        :returns: The object this method was called on, to allow chaining
        """
        # pylint: enable=line-too-long
        if counter is None:
            self._counter = None
        else:
            try:
                c = int(counter)
            except ValueError:
                raise TypeError("invalid counter for Payload: must be integral, not {}"
                                .format(type(counter)))
            if c < 0 or c > 255:
                raise ValueError("invalid counter for Payload: must be between 0 and 255, not {}"
                                 .format(c))
            self._counter = c
        # return ourselves to allow method chaining
        return self

    def set_sender_initials(self, sender_initials):
        # pylint: disable=line-too-long
        """ Set the sender initials of the payload.

        :param sender_initials: The sender initials. If ``None``, reset and make the payload invalid. Should be <= 4 bytes when encoded as UTF-8.
        :type sender_initials: None or ``str``.
        :returns: The object this method was called on, to allow chaining

        """
        # pylint: enable=line-too-long
        if sender_initials is None:
            self._sender_initials = None
        else:
            try:
                encoded = goTenna.util.s2b(sender_initials)
            except Exception:
                raise TypeError("invalid sender_initials for Payload: must be"
                                " str,is {}"
                                .format(type(sender_initials)))
            if len(encoded) > 8:
                raise ValueError("invalid sender_initials for Payload: "
                                 "must be less than 9 bytes encoded, "
                                 "but {} is {} bytes"
                                 .format(sender_initials, len(encoded)))
            self._sender_initials = sender_initials
        # return ourselves to allow method chaining
        return self

    def set_time_sent(self, time_sent):
        # pylint: disable=line-too-long
        """ Set the time the payload was sent.

        :param time_sent: The time. If this is an aware :py:class:`datetime.datetime`, it will be converted to UTC. If it is a naive :py:class:`datetime.datetime`, an `int` representing a Posix timestamp, or a :py:class:`time.struct_time` or similar tuple it is assumed to already be in UTC.
        :type time_sent: None or datetime.datetime or int or time.struct_time

        :returns: The object this method was called on, to allow chaining
        """
        # pylint: enable=line-too-long
        if None is time_sent:
            self._time_sent = None
        else:
            self._time_sent = goTenna.util.time_from_various(time_sent)
        # return ourselves to allow method chaining
        return self

    @property
    def sender_initials(self):
        """ Accessor sender initials

        :return str: The initials
        """
        return self._sender_initials

    def serialize(self):
        # pylint: disable=line-too-long
        """ The base method for subclasses to serialize themselves

        Payload subclasses should override this to return a bytestream containing their specific content. This method should not be called otherwise.
        """
        # pylint: enable=line-too-long
        raise NotImplementedError()

    def _build_encryption_header(self):
        if self._sender.via_gateway:
            sender = self._sender.via_gateway
        else:
            sender = self._sender
        return payload_tlv.EncryptionInfoTLV(sender, self._time_sent,
                                             self._encrypt,
                                             self._encryption_counter,
                                             self._counter)

    def to_tlv(self, with_external_dest=None):
        """ Serialize the payload to a TLV-based bytestream. """
        # The payload always has encryption info even if it's plaintext
        encryption = self._build_encryption_header()
        payload_tlvs = []
        # Allow CustomPayload to not specify a message type
        if self._sender.via_gateway:
            payload_tlvs.append(payload_tlv.ExternalOriginTLV(self._sender.gid_val))
        if with_external_dest:
            payload_tlvs.append(payload_tlv.ExternalDestinationTLV(with_external_dest.gid_val))
        if self.payload_type:
            payload_tlvs.append(payload_tlv.MessageTypeTLV(self.payload_type))
        if self.sender_initials:
            payload_tlvs.append(payload_tlv.SenderInitialsTLV(self.sender_initials))

        return message_tlv.MessagePayloadTLV(encryption, payload_tlvs,
                                             self.serialize(),
                                             encrypt_hook=self._encrypt_hook)

    @property
    def hash_id(self):
        # pylint: disable=line-too-long
        """ Return the hash used to associate this payload with its ACK.

        This uses a special hash function duplicated in the firmware (which actually creates the ack message) and other SDKs.
        """
        # pylint: enable=line-too-long
        encryption = self._build_encryption_header()
        # We hash only the payload part of the encryption TLV
        to_hash = encryption.to_bytes()[2:]
        return goTenna.util.firmware_hash16(to_hash)

    @classmethod
    def from_tlv(cls, tlv):
        """ Parse the information present in a MessagePayloadTLV to a payload.

        :param goTenna.tlv.message_tlv.MessagePayloadTLV: The TLV to build from.
        """
        # First, sweep the TLVs for data to send to the base initializer
        kwargs = {
            'sender_initials': None
        }
        if not tlv.encryption:
            raise ValueError("Payload must have metadata before serialization")
        message_type = None
        specific_tlvs = []
        external_origin = None
        external_destination = None
        for section in tlv.payload_tlvs:
            if isinstance(section, payload_tlv.SenderInitialsTLV):
                kwargs['sender_initials'] = section.contents
            elif isinstance(section, payload_tlv.MessageTypeTLV):
                message_type = section.msgtype
            elif isinstance(section, payload_tlv.ExternalOriginTLV):
                external_origin = section.origin
            elif isinstance(section, payload_tlv.ExternalDestinationTLV):
                external_destination = section.destination
            else:
                specific_tlvs.append(section)
        subclasses = _get_all_subclasses(cls)
        try:
            if None is message_type:
                raise KeyError('no message type found in payload')
            for sc in subclasses:
                if message_type in sc.MESSAGE_TYPE:
                    obj = sc.deserialize(specific_tlvs)
                    break
            else:
                raise KeyError('no match for message type {}'
                               .format(message_type))
        except Exception: # pylint: disable=broad-except
            Payload._LOGGER.exception("Failed to deserialize payload, falling back to custom")
            # Any failure to parse a class or missing type gets a custom payload
            # Reserialize the data not in the common tlvs
            specific_data = six.b('')
            for t in specific_tlvs:
                if t != None:
                    specific_data += t.to_bytes()
            if tlv.payload_bytes:
                specific_data += tlv.payload_bytes
            obj = CustomPayload(specific_data)
        if external_origin:
            obj.set_sender(goTenna.settings.GID(external_origin,
                                                goTenna.settings.GID.PRIVATE,
                                                via_gateway=tlv.encryption.sender))
        else:
            obj.set_sender(tlv.encryption.sender)
        obj.set_time_sent(tlv.encryption.time)
        obj.set_counter(tlv.encryption.message_id)
        obj.set_sender_initials(kwargs.get('sender_initials', None))
        obj.set_encryption(tlv.encryption.encrypted, tlv.encryption.counter)
        if external_destination:
            setattr(obj, 'external_destination', external_destination)
        return obj

    @property
    def payload_type(self):
        """ Get the payload type.

        """
        raise NotImplementedError()

    @classmethod
    def deserialize(cls, tlvs):
        """ Deserialize a payload from the payload-specific TLVs received on the network. """
        raise NotImplementedError()

class CustomPayload(Payload):
    """ A payload that does not parse its input. """

    MESSAGE_TYPE = tuple()

    def __eq__(self, other):
        return isinstance(other, CustomPayload)\
            and self.contents == other.contents\
            and Payload.__eq__(self, other)

    def __repr__(self):
        return '<{}: contents={}, {}>'\
            .format(self.__class__.__name__,
                    goTenna.util.display_bytestring(self.contents)
                    if self.contents else None,
                    Payload._print_contents(self))

    @classmethod
    def deserialize(cls, payload_bytes):
        """ Deserialize a CustomPayload from the payload-specific TLVs. """
        cls(payload_bytes)

    @property
    def contents(self):
        """ The contents of the payload.

        :returns bytes: The contents, as bytes.
        """
        return self._contents

    def __init__(self, contents):
        # pylint: disable=line-too-long
        """ Build a CustomPayload.

        :param byteslike content: The content of the payload, as a byteslike.

        This class is intended for use if the types of message provided by this SDK are too restrictive. In that case, this payload allows the use of byteslike messages while still preserving required routing data.
        """
        # pylint: enable=line-too-long
        Payload.__init__(self)
        if contents:
            try:
                struct.pack('1s', contents[:1])
            except struct.error:
                raise TypeError('contents should be byteslike, is {}'
                                .format(type(contents)))
        else:
            contents = six.b('')
        self._contents = contents

    def serialize(self):
        return self.contents

    @property
    def payload_type(self):
        """ Get the payload type.

        """
        return None

class TextPayload(Payload):
    """ Payload containing only text.
    """

    MESSAGE_TYPE = (goTenna.constants.LAYER8_MESSAGE_TYPES.TEXT_ONLY,)

    @property
    def payload_type(self):
        return goTenna.constants.LAYER8_MESSAGE_TYPES.TEXT_ONLY

    def __eq__(self, other):
        return isinstance(other, TextPayload)\
            and other.message == self.message\
            and Payload.__eq__(self, other)

    def __repr__(self):
        return '<{}: message={}, {}>'.format(self.__class__.__name__,
                                             self.message,
                                             Payload._print_contents(self))

    @classmethod
    def deserialize(cls, tlvs):
        """ Deserialize a TextPayload from the payload-specific TLVs. """
        for section in tlvs:
            if isinstance(section, payload_tlv.TextTLV):
                return cls(section.contents)
        raise ValueError("No TextTLV found in payload")

    def __init__(self, message):
        # pylint: disable=line-too-long
        """ Build a TextPayload.

        This builds a TextPayload directly.

        :param str message: The message to send.

        """
        # pylint: enable=line-too-long
        Payload.__init__(self)
        if not isinstance(message, (str, goTenna.util.UnicodeType)):
            raise TypeError('text must be a string or unicode type, is {}'
                            .format(type(message)))
        self._message = message
        self._type = self.MESSAGE_TYPE[0]

    @property
    def message(self):
        """ The payload's message """
        return self._message

    def serialize(self):
        return payload_tlv.TextTLV(self._message).to_bytes()

class LocationPayload(Payload):
    """ Payload containing location and perhaps also text.
    """

    MESSAGE_TYPE = (goTenna.constants.LAYER8_MESSAGE_TYPES.LOCATION_ONLY,
                    goTenna.constants.LAYER8_MESSAGE_TYPES.TEXT_AND_LOCATION)

    @property
    def payload_type(self):
        return self._type

    def __eq__(self, other):
        return isinstance(other, LocationPayload)\
            and self.map_id == other.map_id\
            and self.name == other.name \
            and self.position == other.position \
            and self.time == other.time \
            and self.loc_type == other.loc_type \
            and self.text == other.text \
            and self.accuracy == other.accuracy \
            and Payload.__eq__(self, other)

    def __repr__(self):
        return '<{}: id={}, name={}, position={}, time={}, type={}, accuracy={}, {}{}>'\
            .format(self.__class__.__name__,
                    self.map_id, self.name, self.position,
                    self.time, self.loc_type,
                    self.accuracy,
                    'text={}, '.format(self.text) if self.text else '',
                    self._print_contents())

    def __init__(self, loc_id, loc_name, loc_latlong, loc_time, loc_type,
                 accuracy, text):
        # pylint: disable=line-too-long
        """ Build a LocationPayload.

        Location payloads encapsulate
        - A numeric ID used for correlating updates to persistent positions
        - A human readable name
        - The location, as a (latitude, longitude) pair
        - The time the location was captured or is relevant for
        - The type of location
        - Optionally, the accuracy of the location
        - Optionally, a text component

        :param int loc_id: The location ID.
        :param str loc_name: The human readable name. Should be <32 bytes encoded.
        :param tuple(float, float) loc_latlong: The position of the location.
        :param datetime.datetime loc_time: A time that the position is relevant for.
        :param goTenna.constants.LOCATION_TYPES loc_type: The location type
        :param accuracy: An integer number of meters between 0 and 65535 inclusive representing the accuracy of the location measurement
        :type accuracy: int or None
        :param text: Text to send along with the message
        :type text: str or None
        """
        # pylint: enable=line-too-long
        Payload.__init__(self)
        self._id = goTenna.tlv.payload_tlv.MapIDTLV(loc_id)
        self._name = goTenna.tlv.payload_tlv.LocationNameTLV(loc_name)
        self._long = goTenna.tlv.payload_tlv.LocationLongitudeTLV(loc_latlong[1])
        self._lat = goTenna.tlv.payload_tlv.LocationLatitudeTLV(loc_latlong[0])
        self._loc_time = goTenna.tlv.payload_tlv.LocationGPSTimestampTLV(loc_time)
        self._loc_type = goTenna.tlv.payload_tlv.LocationTypeTLV(loc_type)
        if None is not accuracy:
            self._accuracy = goTenna.tlv.payload_tlv.LocationAccuracyTLV(accuracy)
        else:
            self._accuracy = None
        if None is not text:
            self._text = goTenna.tlv.payload_tlv.TextTLV(text)
            self._type = goTenna.constants.LAYER8_MESSAGE_TYPES.TEXT_AND_LOCATION
        else:
            self._text = None
            self._type = goTenna.constants.LAYER8_MESSAGE_TYPES.LOCATION_ONLY

    @property
    def map_id(self):
        """ The map ID associated with the location.

        :returns int: The ID
        """
        return self._id.map_id

    @property
    def accuracy(self):
        """ The accuracy associated with the location, in meters

        :returns int or None: The accuracy, if available
        """
        if self._accuracy: # pylint: disable=no-else-return
            return self._accuracy.accuracy
        else:
            return None

    @property
    def name(self):
        """ The name associated with the location

        :returns str: The name
        """
        return self._name.name

    @property
    def position(self):
        """ The actual position, as a (latitude, longitude) pair.

        :returns tuple(float, float): The latitude and longitude
        """
        return (self._lat.latitude, self._long.longitude)

    @property
    def time(self):
        """ The time associated with the location.

        :returns datetime.datetime: The time, in UTC.
        """
        return self._loc_time.timestamp

    @property
    def text(self):
        """ The text associated with the message, if there is any.

        :returns str: The text
        """
        if not self._text:  # pylint: disable=no-else-return
            return None
        else:
            return self._text.contents

    @property
    def loc_type(self):
        """ The type of location.

        :returns str: A value of :py:attr:`goTenna.constants.LOCATION_TYPES`
        """
        return self._loc_type.location_type

    @classmethod
    def deserialize(cls, tlvs):
        """ Deserialize the Location payload from a list of TLVs.

        :param list[goTenna.tlv.basic_tlv.TLV] A list of the TLVs in the message

        :returns LocationPayload: The initialized payload.
        """
        kwargs = {'text': None,
                  'accuracy': None}
        position = [None, None]
        inner_tlvs = tlvs
        for tlv in tlvs:
            if isinstance(tlv, goTenna.tlv.payload_tlv.LocationDataTLV):
                inner_tlvs = tlv.contents
            elif isinstance(tlv, goTenna.tlv.payload_tlv.TextTLV):
                kwargs['text'] = tlv.contents

        for contained in inner_tlvs:
            if isinstance(contained, goTenna.tlv.payload_tlv.MapIDTLV):
                kwargs['loc_id'] = contained.map_id
            elif isinstance(contained, goTenna.tlv.payload_tlv.LocationNameTLV):
                kwargs['loc_name'] = contained.name
            elif isinstance(contained, goTenna.tlv.payload_tlv.LocationGPSTimestampTLV):
                kwargs['loc_time'] = contained.timestamp
            elif isinstance(contained, goTenna.tlv.payload_tlv.LocationTypeTLV):
                kwargs['loc_type'] = contained.location_type
            elif isinstance(contained, goTenna.tlv.payload_tlv.LocationLatitudeTLV):
                position[0] = contained.latitude
            elif isinstance(contained, goTenna.tlv.payload_tlv.LocationLongitudeTLV):
                position[1] = contained.longitude
            elif isinstance(contained, goTenna.tlv.payload_tlv.LocationAccuracyTLV):
                kwargs['accuracy'] = contained.accuracy
        kwargs['loc_latlong'] = tuple(position)
        return cls(**kwargs)

    def serialize(self):
        contained = [self._id,
                     self._name,
                     self._loc_time,
                     self._loc_type,
                     self._long,
                     self._lat]
        if self.accuracy:
            contained.append(self._accuracy)
        payload = goTenna.tlv.payload_tlv.LocationDataTLV(contained)\
                                         .to_bytes()
        if self._text:
            payload += self._text.to_bytes()
        return payload


class LocationRequestPayload(Payload):
    """ Payload containing a location request and perhaps also text.
    """
    MESSAGE_TYPE = (goTenna.constants.LAYER8_MESSAGE_TYPES.LOCATION_REQUEST_ONLY,
                    goTenna.constants.LAYER8_MESSAGE_TYPES.LOCATION_REQUEST_AND_TEXT)

    @property
    def payload_type(self):
        return self._type

    def __eq__(self, other):
        return isinstance(other, LocationRequestPayload)\
            and self.request_gid == other.request_gid\
            and self.text == other.text\
            and Payload.__eq__(self, other)

    def __repr__(self):
        return '<{}: request_gid={}, {}{}>'\
            .format(self.__class__.__name__,
                    self.request_gid,
                    'text={}, '.format(self.text) if self.text else '',
                    self._print_contents())

    @property
    def request_gid(self):
        return self._request_gid.gid

    @property
    def text(self):
        if self._text: return self._text.contents
        else: return None

    @classmethod
    def deserialize(cls, tlvs):
        """ Deserialize a location request from a list of TLVs.

        :param list[goTenna.tlv.basic_tlv.TLV] tlvs: The TLVs

        :returns LocationRequestPayload: The initialized payload
        """
        rq = None
        text = None
        for contained in tlvs:
            if isinstance(contained, goTenna.tlv.payload_tlv.RequestGIDTLV):
                rq = contained.gid
            elif isinstance(contained, goTenna.tlv.payload_tlv.TextTLV):
                text = contained.contents
        return cls(rq, text)

    def __init__(self, request_gid, text):
        # pylint: disable=line-too-long
        """ Build a LocationRequest.

        :param goTenna.settings.GID request_gid: The request gid
        :param str text: An optional message to send along with the request. If no message is desired, set to ``None``.
        """
        # pylint: enable=line-too-long
        Payload.__init__(self)
        self._request_gid = goTenna.tlv.payload_tlv.RequestGIDTLV(request_gid)
        if text:
            self._text = goTenna.tlv.payload_tlv.TextTLV(text)
            self._type = goTenna.constants.LAYER8_MESSAGE_TYPES.LOCATION_REQUEST_AND_TEXT
        else:
            self._text = None
            self._type = goTenna.constants.LAYER8_MESSAGE_TYPES.LOCATION_REQUEST_ONLY

    def serialize(self):
        payload = self._request_gid.to_bytes()
        if self._text:
            payload += self._text.to_bytes()
        return payload

class GroupGIDPayload(Payload):
    """ Payload containing a group invitation with a group GID and member index.
    """
    MESSAGE_TYPE = (goTenna.constants.LAYER8_MESSAGE_TYPES.SET_GROUP_GID)

    _LOGGER = _MODULE_LOGGER.getChild('GroupGIDPayload')

    def __eq__(self, other):
        return isinstance(other, GroupGIDPayload)\
            and self.group == other.group\
            and Payload.__eq__(self, other)

    def __repr__(self):
        return '<{}: group={}, {}>'.format(self.__class__.__name__,
                                           self.group,
                                           self._print_contents())

    @property
    def payload_type(self):
        return goTenna.constants.LAYER8_MESSAGE_TYPES.SET_GROUP_GID

    @classmethod
    def deserialize(cls, tlvs):
        """ Deserialize a GroupGIDPayload from a list of TLVs

        :param list[goTenna.tlv.basic_tlv.TLV] tlvs: The TLVs.
        :return GroupGIDPayload: The initialized payload
        """
        gid = None
        members = []
        secret = None
        for contained in tlvs:
            if isinstance(contained, goTenna.tlv.payload_tlv.GroupGIDTLV):
                gid = contained.gid
            elif isinstance(contained, goTenna.tlv.payload_tlv.GroupSharedSecretTLV):
                secret = contained.secret
            elif isinstance(contained, goTenna.tlv.payload_tlv.GroupMemberListTLV):
                members = contained.members
        # The creator of the group is pulled from the origination address
        members = members
        return cls(goTenna.settings.Group(gid, members, secret))

    def __init__(self, group):
        # pylint: disable=line-too-long
        """ Build a GroupGIDPayload.

        The GroupGIDPayload is used as a group invitation, to specify the other members and the shared GID to a new participant. It contains the same information as found in a :py:class:`goTenna.settings.Group` object and therefore requires one to initialize.

        :param goTenna.settings.Group group: The group to pack into the payload.

        .. note ::
           Because internal mechanisms require modification of the Group object, the argument is copied.

        """
        # pylint: enable=line-too-long
        Payload.__init__(self)
        if not isinstance(group, goTenna.settings.Group):
            raise TypeError('group should be goTenna.settings.Group, is {}'
                            .format(type(group)))
        self._group = copy.copy(group)

    def set_sender(self, sender):
        """ GroupGIDPayload override to ensure the sender is in the group.

        :param goTenna.settings.GID sender: The sender of the message
        """
        old_sender = self._sender
        Payload.set_sender(self, sender)
        if not old_sender and sender not in self._group.members:
            # But if it is _not_, this is being added to a message being
            # _received_, and is the owner of the group
            self._group._members = [sender] + self._group.members
        return self

    def serialize(self):
        gtlv = goTenna.tlv.payload_tlv.GroupGIDTLV(self.group.gid)
        mltlv = goTenna.tlv.payload_tlv.GroupMemberListTLV(self.group.members[1:])
        stlv = goTenna.tlv.payload_tlv.GroupSharedSecretTLV(self.group.shared_secret)
        return gtlv.to_bytes() + mltlv.to_bytes() + stlv.to_bytes()

    @property
    def group(self):
        """ The group associated with the payload. """
        return self._group

class PingPayload(Payload):
    # pylint: disable=line-too-long
    """ Payload for a simple ping.

    This payload does not carry any information beyond its existence; it is meant to serve as a lightweight way to see if a given destination is on the network. Though it can be used however the caller desires, the most frequent use is as a minimal payload for a private message, where the presence or absence of an acknowledgement in return indicates whether the recipient is on the network.
    """
    # pylint: enable=line-too-long
    MESSAGE_TYPE = (goTenna.constants.LAYER8_MESSAGE_TYPES.PING_TEXT_ONLY)

    @property
    def payload_type(self):
        return self.MESSAGE_TYPE[0]

    @classmethod
    def deserialize(cls, tlvs):
        """ Deserialize a Ping from a list of TLVs

        :param list[goTenna.tlv.basic_tlv.TLV] tlvs: The TLVs
        :returns goTenna.PingPayload: The initialized payload
        """
        # We dont care what message this is aside from the message type
        return cls()

    def __init__(self):
        # pylint: disable=line-too-long
        """ Build a ping payload.
        """
        # pylint: enable=line-too-long
        Payload.__init__(self)

    def serialize(self):
        return goTenna.tlv.payload_tlv.TextTLV('P').to_bytes()

    def __eq__(self, other):
        return isinstance(other, PingPayload) and Payload.__eq__(self, other)

    def __repr__(self):
        return '<{}: {}>'.format(self.__class__.__name__,
                                 self._print_contents())

class PerimeterPayload(Payload):
    # pylint: disable=line-too-long
    """ Payload containing perimeter and optionally text data

    A perimeter encloses an area on a map. It contains a list of points (as (latitude, longitude) pairs), a title, a color, an ID, and optionally a message.
    """
    # pylint: enable=line-too-long
    MESSAGE_TYPE = (goTenna.constants.LAYER8_MESSAGE_TYPES.TEXT_AND_MAP_PERIMETER,
                    goTenna.constants.LAYER8_MESSAGE_TYPES.PERIMETER_ONLY)

    @property
    def payload_type(self):
        return self._payload_type

    @classmethod
    def deserialize(cls, tlvs):
        """ Build a PerimeterPayload from a list of TLVs.

        :param list[goTenna.tlv.basic_tlv.TLV] tlvs: The TLVs
        :returns PerimeterPayload: The initialized payload
        """
        kwargs = {'text': None,
                  'color': (0, 0, 0, 0)}
        inner_tlvs = tlvs
        for tlv in tlvs:
            if isinstance(tlv, goTenna.tlv.payload_tlv.PerimeterDataTLV):
                inner_tlvs = tlv.contents
            elif isinstance(tlv, payload_tlv.TextTLV):
                kwargs['text'] = tlv.contents

        for section in inner_tlvs:
            if isinstance(section, goTenna.tlv.payload_tlv.MapIDTLV):
                kwargs['map_id'] = section.map_id
            elif isinstance(section, goTenna.tlv.payload_tlv.PerimeterTitleTLV):
                kwargs['title'] = section.contents
            elif isinstance(section, goTenna.tlv.payload_tlv.PerimeterColorTLV):
                kwargs['color'] = section.color_tuple
            elif isinstance(section, goTenna.tlv.payload_tlv.PerimeterPointsTLV):
                kwargs['points'] = section.points
            elif isinstance(section, goTenna.tlv.payload_tlv.TextTLV):
                kwargs['text'] = section.contents
        return cls(**kwargs)

    def __init__(self, map_id, title, color, points, text):
        # pylint: disable=line-too-long
        """ Build a PerimeterPayload

        :param int map_id: A unique ID for the Perimeter object.
        :param str title: A short title to display for the Perimeter object.
        :param color: A color to specify for the Perimeter. The color should be a 4-tuple of (red, green, blue, alpha) channels that should either be ``int`` in [0, 255] or ``float`` in (0.0, 1.0) (where a higher value represents more intensity in the channel). For deserialization purposes, an int consisting of values backed as bytes in the order (alpha, red, green, blue) is also accepted.

        .. note ::

          The color is transmitted on the network with 8 bits per pixel, even if it is specified as a float. Thus, the :py:attr:`PerimeterPayload.color` accessor always returns a tuple of ints, even if this object was created locally with floats.


        :param points: The points making up the perimeter, as ``list(tuple(float, float))`` where the ``tuple`` elements are latitude and longitude, respectively. There may be up to 16 points in a perimeter.
        :param text: A message to send with the perimeter. This may be ``None``, in which case no message will be sent. If not ``None``, must be a stringlike that is less than 32 bytes long when encoded as UTF8.
        """
        # pylint: enable=line-too-long
        Payload.__init__(self)
        self._map_id = goTenna.tlv.payload_tlv.MapIDTLV(map_id)
        self._title = goTenna.tlv.payload_tlv.PerimeterTitleTLV(title)
        self._color = goTenna.tlv.payload_tlv.PerimeterColorTLV(color_tuple=color)
        self._points = goTenna.tlv.payload_tlv.PerimeterPointsTLV(points)
        if text:
            self._text = goTenna.tlv.payload_tlv.TextTLV(text)
            self._payload_type\
                = goTenna.constants.LAYER8_MESSAGE_TYPES.TEXT_AND_MAP_PERIMETER
        else:
            self._payload_type\
                = goTenna.constants.LAYER8_MESSAGE_TYPES.PERIMETER_ONLY
            self._text = None

    def serialize(self):
        contents_tlvs = [self._map_id, self._title, self._color, self._points]
        container = goTenna.tlv.payload_tlv.PerimeterDataTLV(contents_tlvs)
        payload_bytes = container.to_bytes()
        if self._text:
            payload_bytes += self._text.to_bytes()
        return payload_bytes

    def __eq__(self, other):
        return isinstance(other, PerimeterPayload)\
            and self.map_id == other.map_id\
            and self.color == other.color\
            and self.title == other.title\
            and self.points == other.points\
            and self.text == other.text\
            and Payload.__eq__(self, other)

    def __repr__(self):
        return '<{}: id={}, title={}, points={}, color={}{}, {}>'\
            .format(self.__class__.__name__, self.map_id, self.title,
                    self.points, self.color,
                    ', text={}'.format(self.text) if self.text else '',
                    self._print_contents())

    @property
    def map_id(self):
        """ The ID of the perimeter object. """
        return self._map_id.map_id

    @property
    def color(self):
        # pylint: disable=line-too-long
        """ The perimeter color.

        This is a ``tuple(int, int, int, int)``, where each element is in [0, 255] indicating the intensity of (in order) the red, green, blue, and alpha channels of the color. The color is presented as ints rather than floats to reflect the encoding; because this is how it is serialized, it cannot retain more than 8 bits per channel during transmission over the network, even if specified as floats.
        """
        # pylint: enable=line-too-long
        def converter(chan):
            if isinstance(chan, float):
                return int(chan*255.0)
            else:
                return chan
        return tuple(converter(c) for c in self._color.color_tuple)

    @property
    def title(self):
        """ The perimeter title. ``str``. """
        return self._title.contents

    @property
    def points(self):
        """ The points making up the perimeter. ``list(tuple(lat, long))``."""
        return self._points.points

    @property
    def text(self):
        # pylint: disable=line-too-long
        """ The message specified with the perimeter, if it exists. Otherwise ``None``.
        """
        # pylint: enable=line-too-long
        if not self._text:
            return None
        else:
            return self._text.contents

class RoutePayload(Payload):
    # pylint: disable=line-too-long
    """ Payload containing a route and optionally text data

    Routes have very similar data to perimeters, but differ in their semantics. They represent a path on a map rather than the border of an area.
    """
    # pylint: enable=line-too-long
    MESSAGE_TYPE = (goTenna.constants.LAYER8_MESSAGE_TYPES.TEXT_AND_MAP_ROUTE,
                    goTenna.constants.LAYER8_MESSAGE_TYPES.MAP_ROUTE_ONLY)

    @property
    def payload_type(self):
        return self._payload_type

    @classmethod
    def deserialize(cls, tlvs):
        """ Build a RoutePayload from a list of TLVs.

        :param list[goTenna.tlv.basic_tlv.TLV] tlvs: The TLVs
        :returns RoutePayload: The initialized payload
        """
        kwargs = {'text': None,
                  'color': (0, 0, 0, 0)}
        inner_tlvs = tlvs
        for tlv in tlvs:
            if isinstance(tlv, goTenna.tlv.payload_tlv.RouteDataTLV):
                inner_tlvs = tlv.contents
            elif isinstance(tlv, payload_tlv.TextTLV):
                kwargs['text'] = tlv.contents
            elif isinstance(tlv, payload_tlv.MessageTypeTLV):
                Payload._LOGGER.info("route has type {}".format(tlv.msgtype))

        for section in inner_tlvs:
            if isinstance(section, goTenna.tlv.payload_tlv.MapIDTLV):
                kwargs['map_id'] = section.map_id
            elif isinstance(section, goTenna.tlv.payload_tlv.RouteTitleTLV):
                kwargs['title'] = section.contents
            elif isinstance(section, goTenna.tlv.payload_tlv.RouteColorTLV):
                kwargs['color'] = section.color_tuple
            elif isinstance(section, goTenna.tlv.payload_tlv.RoutePointsTLV):
                kwargs['points'] = section.points
            elif isinstance(section, goTenna.tlv.payload_tlv.TextTLV):
                kwargs['text'] = section.contents
        return cls(**kwargs)

    def __init__(self, map_id, title, color, points, text):
        # pylint: disable=line-too-long
        """ Build a RoutePayload

        :param int map_id: A unique ID for the Route object.
        :param str title: A short title to display for the Route object.
        :param color: A color to specify for the Route. The color should be a 4-tuple of (red, green, blue, alpha) channels that should either be ``int`` in [0, 255] or ``float`` in (0.0, 1.0) (where a higher value represents more intensity in the channel). For deserialization purposes, an int consisting of values backed as bytes in the order (alpha, red, green, blue) is also accepted.

        .. note ::

          The color is transmitted on the network with 8 bits per pixel, even if it is specified as a float. Thus, the :py:attr:`RoutePayload.color` accessor always returns a tuple of ints, even if this object was created locally with floats.


        :param points: The points making up the route, as ``list(tuple(float, float))`` where the ``tuple`` elements are latitude and longitude, respectively. There may be up to 16 points in a route.
        :param text: A message to send with the route. This may be ``None``, in which case no message will be sent. If not ``None``, must be a stringlike that is less than 32 bytes long when encoded as UTF8.
        """
        # pylint: enable=line-too-long
        Payload.__init__(self)
        self._map_id = goTenna.tlv.payload_tlv.MapIDTLV(map_id)
        self._title = goTenna.tlv.payload_tlv.RouteTitleTLV(title)
        self._color = goTenna.tlv.payload_tlv.RouteColorTLV(color_tuple=color)
        self._points = goTenna.tlv.payload_tlv.RoutePointsTLV(points)
        if text:
            self._text = goTenna.tlv.payload_tlv.TextTLV(text)
            self._payload_type\
                = goTenna.constants.LAYER8_MESSAGE_TYPES.TEXT_AND_MAP_ROUTE
        else:
            self._payload_type\
                = goTenna.constants.LAYER8_MESSAGE_TYPES.MAP_ROUTE_ONLY
            self._text = None

    def serialize(self):
        contents_tlvs = [self._map_id, self._title, self._color, self._points]
        container = goTenna.tlv.payload_tlv.RouteDataTLV(contents_tlvs)
        payload_bytes = container.to_bytes()
        if self._text:
            payload_bytes += self._text.to_bytes()
        return payload_bytes

    def __eq__(self, other):
        return isinstance(other, RoutePayload)\
            and self.map_id == other.map_id\
            and self.color == other.color\
            and self.title == other.title\
            and self.points == other.points\
            and self.text == other.text\
            and Payload.__eq__(self, other)

    def __repr__(self):
        return '<{}: id={}, title={}, points={}, color={}{}, {}>'\
            .format(self.__class__.__name__, self.map_id, self.title,
                    self.points, self.color,
                    ', text={}'.format(self.text) if self.text else '',
                    self._print_contents())

    @property
    def map_id(self):
        """ The ID of the route object. """
        return self._map_id.map_id

    @property
    def color(self):
        # pylint: disable=line-too-long
        """ The route color.

        This is a ``tuple(int, int, int, int)``, where each element is in [0, 255] indicating the intensity of (in order) the red, green, blue, and alpha channels of the color. The color is presented as ints rather than floats to reflect the encoding; because this is how it is serialized, it cannot retain more than 8 bits per channel during transmission over the network, even if specified as floats.
        """
        # pylint: enable=line-too-long
        def converter(chan):
            if isinstance(chan, float):
                return int(chan*255.0)
            else:
                return chan
        return tuple(converter(c) for c in self._color.color_tuple)

    @property
    def title(self):
        """ The route title. ``str``. """
        return self._title.contents

    @property
    def points(self):
        """ The points making up the route. ``list(tuple(lat, long))``."""
        return self._points.points

    @property
    def text(self):
        # pylint: disable=line-too-long
        """ The message specified with the route, if it exists. Otherwise ``None``.
        """
        # pylint: enable=line-too-long
        if not self._text:
            return None
        else:
            return self._text.contents


class CirclePayload(Payload):
    """ Payload containing a circle and optionally text data """
    MESSAGE_TYPE = (goTenna.constants.LAYER8_MESSAGE_TYPES.TEXT_AND_CIRCLE,
                    goTenna.constants.LAYER8_MESSAGE_TYPES.CIRCLE_ONLY)

    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and self.map_id == other.map_id\
            and self.title == other.title\
            and self.color == other.color\
            and self.center == other.center\
            and self.radius == other.radius\
            and self.text == other.text\
            and Payload.__eq__(self, other)

    def __repr__(self):
        return '<{}: title={}, center={}, radius={}, id={}, color={}{}, {}>'\
            .format(self.__class__.__name__,
                    self.center, self.title,
                    self.radius, self.map_id, self.color,
                    ', text={}'.format(self.text) if self.text else '',
                    self._print_contents())
    @property
    def payload_type(self):
        return self._payload_type

    @classmethod
    def deserialize(cls, tlvs):
        """ Build a CirclePayload from a list of TLVs

        :param list[goTenna.tlv.basic_tlv.TLV] tlvs: The list of TLVs
        :return CirclePayload: The initialized payload
        """
        kwargs = {'text': None,
                  'color': (0, 0, 0, 0)}
        inner_tlvs = tlvs
        for tlv in tlvs:
            if isinstance(tlv, goTenna.tlv.payload_tlv.CircleDataTLV):
                inner_tlvs = tlv.contents
            elif isinstance(tlv, payload_tlv.TextTLV):
                kwargs['text'] = tlv.contents

        for section in inner_tlvs:
            if isinstance(section, goTenna.tlv.payload_tlv.MapIDTLV):
                kwargs['map_id'] = section.map_id
            elif isinstance(section, goTenna.tlv.payload_tlv.CircleTitleTLV):
                kwargs['title'] = section.contents
            elif isinstance(section, goTenna.tlv.payload_tlv.CircleColorTLV):
                kwargs['color'] = section.color_tuple
            elif isinstance(section, goTenna.tlv.payload_tlv.CircleCenterTLV):
                kwargs['center'] = section.position
            elif isinstance(section, goTenna.tlv.payload_tlv.CircleRadiusTLV):
                kwargs['radius'] = section.radius
            elif isinstance(section, goTenna.tlv.payload_tlv.TextTLV):
                kwargs['text'] = section.contents
        return cls(**kwargs)

    def __init__(self, map_id, title, center, radius, color, text,
                 *args, **kwargs):
        # pylint: disable=line-too-long
        """ Build a CirclePayload.

        :param int map_id: The ID for the circle.
        :param str title: The short title for the circle. This should be <32 bytes when encoded.
        :param tuple(float, float) center: The center of the circle, as a ``tuple`` of ``(latitude, longitude)``.
        :param float radius: The radius of the circle.
        :param color: A color to specify for the circle. The color should be a 4-tuple of (red, green, blue, alpha) channels that should either be ``int`` in [0, 255] or ``float`` in (0.0, 1.0) (where a higher value represents more intensity in the channel). For deserialization purposes, an int consisting of values backed as bytes in the order (alpha, red, green, blue) is also accepted.

        .. note ::

          The color is transmitted on the network with 8 bits per pixel, even if it is specified as a float. Thus, the :py:attr:`CirclePayload.color` accessor always returns a tuple of ints, even if this object was created locally with floats.


        :param str text: A message that should go along with the circle. This is not mandatory. If ``None``, no message will be sent.
        """
        # pylint: enable=line-too-long
        Payload.__init__(self)
        self._map_id = goTenna.tlv.payload_tlv.MapIDTLV(map_id)
        self._title = goTenna.tlv.payload_tlv.CircleTitleTLV(title)
        try:
            latitude = center[0]
            longitude = center[1]
        except (AttributeError, TypeError):
            raise TypeError("center should be a tuple(latitude, longitude), is {}"
                            .format(type(center)))
        self._center = goTenna.tlv.payload_tlv.CircleCenterTLV(latitude, longitude)
        self._radius = goTenna.tlv.payload_tlv.CircleRadiusTLV(radius)
        self._color = goTenna.tlv.payload_tlv.CircleColorTLV(color_tuple=color)
        if text:
            self._text = goTenna.tlv.payload_tlv.TextTLV(text)
            self._payload_type\
                = goTenna.constants.LAYER8_MESSAGE_TYPES.TEXT_AND_CIRCLE
        else:
            self._text = None
            self._payload_type\
                = goTenna.constants.LAYER8_MESSAGE_TYPES.CIRCLE_ONLY

    def serialize(self):
        sections = [self._map_id, self._title, self._center, self._radius,
                    self._color]
        container = goTenna.tlv.payload_tlv.CircleDataTLV(sections)
        payload_bytes = container.to_bytes()
        if self._text:
            payload_bytes += self._text.to_bytes()
        return payload_bytes

    @property
    def map_id(self):
        """ The map ID for the circle """
        return self._map_id.map_id

    @property
    def title(self):
        """ The title of the circle """
        return self._title.contents

    @property
    def center(self):
        """ The center of the circle, as a ``tuple(float, float)``"""
        return self._center.position

    @property
    def radius(self):
        """ The radius of the circle, in meters """
        return self._radius.radius

    @property
    def color(self):
        # pylint: disable=line-too-long
        """ The color of the circle, as a ``tuple(int, int, int int)`` describing the red, blue, green, and alpha channels. 0 is no intensity, 255 is most intense."""
        # pylint: enable=line-too-long
        return self._color.color_tuple

    @property
    def text(self):
        """ The text that came with the circle, or None. """
        if self._text:
            return self._text.contents
        else:
            return None

class SquarePayload(Payload):
    # pylint: disable=line-too-long
    """ Payload containing a square and optionally text data.

    The Square is named as such for legacy reasons; it is actually a rectangle.

    The Square is defined by three points, held internally as a list of (latitude, longitude) tuples.

    The first two points define a line that defines one edge of the rectangle (the width). The distance between the third point and the width determines the length of the side of the rectangle normal to the width (the depth), and its position determines on which side of the width the rectangle extends.
    """
    # pylint: enable=line-too-long
    MESSAGE_TYPE = (goTenna.constants.LAYER8_MESSAGE_TYPES.TEXT_AND_SQUARE,
                    goTenna.constants.LAYER8_MESSAGE_TYPES.SQUARE_ONLY)

    @property
    def payload_type(self):
        return self._payload_type

    @classmethod
    def deserialize(cls, tlvs):
        """ Deserialize a SquarePayload from the payload-specific TLVs. """
        kwargs = {'text': None,
                  'color': (0, 0, 0, 0),
                  'corners': [None, None, None]}
        inner_tlvs = tlvs
        for tlv in tlvs:
            if isinstance(tlv, goTenna.tlv.payload_tlv.SquareDataTLV):
                inner_tlvs = tlv.contents
            elif isinstance(tlv, payload_tlv.TextTLV):
                kwargs['text'] = tlv.contents

        for section in inner_tlvs:
            if isinstance(section, goTenna.tlv.payload_tlv.MapIDTLV):
                kwargs['map_id'] = section.map_id
            elif isinstance(section, goTenna.tlv.payload_tlv.SquareTitleTLV):
                kwargs['title'] = section.contents
            elif isinstance(section, goTenna.tlv.payload_tlv.SquareColorTLV):
                kwargs['color'] = section.color_tuple
            elif isinstance(section, goTenna.tlv.payload_tlv.SquareCornerOneTLV):
                kwargs['corners'][0] = section.position
            elif isinstance(section, goTenna.tlv.payload_tlv.SquareCornerTwoTLV):
                kwargs['corners'][1] = section.position
            elif isinstance(section, goTenna.tlv.payload_tlv.SquareDepthTLV):
                kwargs['corners'][2] = section.position
            elif isinstance(section, goTenna.tlv.payload_tlv.TextTLV):
                kwargs['text'] = section.contents
        return cls(**kwargs)

    def __init__(self, map_id, title, corners, color, text):
        # pylint: disable=line-too-long
        """ Build the square.

        :param int map_id: A unique ID for this shape.
        :param str title: A short title for the object.
        :param list(tuple(float, float)) corners: The three points that make up the square, as a length-3 iterable of (latitude, longitude) tuples.
        :param color: A color to specify for the square. The color should be a 4-tuple of (red, green, blue, alpha) channels that should either be ``int`` in [0, 255] or ``float`` in (0.0, 1.0) (where a higher value represents more intensity in the channel). For deserialization purposes, an int consisting of values backed as bytes in the order (alpha, red, green, blue) is also accepted.

        .. note ::

          The color is transmitted on the network with 8 bits per pixel, even if it is specified as a float. Thus, the :py:attr:`SquarePayload.color` accessor always returns a tuple of ints, even if this object was created locally with floats.


        :param str text: A message that should go along with the square. This is not mandatory. If ``None``, no message will be sent.
        """
        # pylint: enable=line-too-long
        Payload.__init__(self)
        self._map_id = goTenna.tlv.payload_tlv.MapIDTLV(map_id)
        self._title = goTenna.tlv.payload_tlv.SquareTitleTLV(title)
        if len(corners) != 3:
            raise ValueError("squares (rectangles) are specified with three points, have {}"
                             .format(len(corners)))
        self._corners = (goTenna.tlv.payload_tlv.SquareCornerOneTLV(*corners[0]),
                         goTenna.tlv.payload_tlv.SquareCornerTwoTLV(*corners[1]),
                         goTenna.tlv.payload_tlv.SquareDepthTLV(*corners[2]))
        self._color = goTenna.tlv.payload_tlv.SquareColorTLV(color_tuple=color)
        if text:
            self._text = goTenna.tlv.payload_tlv.TextTLV(text)
            self._payload_type = goTenna.constants.LAYER8_MESSAGE_TYPES.TEXT_AND_SQUARE
        else:
            self._text = None
            self._payload_type = goTenna.constants.LAYER8_MESSAGE_TYPES.SQUARE_ONLY

    def serialize(self):
        contents = [self._map_id, self._title, self._color]\
                   + list(self._corners)
        payload = goTenna.tlv.payload_tlv.SquareDataTLV(contents)
        payload_bytes = payload.to_bytes()
        if self._text:
            payload_bytes += self._text.to_bytes()
        return payload_bytes

    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and self.title == other.title\
            and self.map_id == other.map_id\
            and self.corners == other.corners\
            and self.color == other.color\
            and self.text == other.text\
            and Payload.__eq__(self, other)

    def __repr__(self):
        return '<{}: title={}, corners={}, id={}, color={}{}, {}>'\
            .format(self.__class__.__name__, self.title, self.corners,
                    self.map_id, self.color,
                    ', text={}'.format(self.text) if self.text else '',
                    self._print_contents())

    @property
    def title(self):
        """ The title of the square """
        return self._title.title

    @property
    def map_id(self):
        """ The ID of the square """
        return self._map_id.map_id

    @property
    def corners(self):
        """ The three corners defining the shape """
        return [c.position for c in self._corners]

    @property
    def color(self):
        """ The color, as a tuple(float, float, float, float)

        The tuple elements are the (r,g,b,a) channels in [0, 255].
        """
        return self._color.color_tuple

    @property
    def text(self):
        """ The text associated with the square, if any"""
        if self._text:
            return self._text.contents
        else:
            return None

class FrequencySlotPayload(Payload):
    """ A payload communicating RF configuration information. """
    MESSAGE_TYPE = (goTenna.constants.LAYER8_MESSAGE_TYPES.FREQUENCY_SLOT,
                    goTenna.constants.LAYER8_MESSAGE_TYPES.FREQUENCY_SLOT_AND_TEXT)

    @property
    def payload_type(self):
        return self.MESSAGE_TYPE[0]

    @property
    def rf_settings(self):
        """ The :py:class:`goTenna.settings.RFSettings` object associated with the payload.

        .. note ::
          Because this payload is only capable of sending the channel mask, not the bitrate, the :py:class:`goTenna.settings.RFSettings` object may not be identical to the one specified when the class was initialized. The payload defaults to selecting the maximum throughput (fastest) datarate for the specified mask.
        """
        return self._rf_settings

    @property
    def slot_id(self):
        """ The slot id (a byteslike) associated with the payload. """
        return self._slot_id.id_bytes

    @property
    def name(self):
        """ The name (a ``str``) associated with the payload. """
        return self._name.name

    @property
    def callsign(self):
        """ The callsign (a ``str``) associated with the payload. """
        return self._callsign.callsign

    @property
    def text(self):
        """ The text (``str`` or None) that might have been sent along with the payload."""
        if self._text:
            return self._text.contents
        else:
            return None

    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and self.rf_settings == other.rf_settings\
            and self.slot_id == other.slot_id\
            and self.name == other.name\
            and self.callsign == other.callsign

    def __repr__(self):
        return '<{}: name={}, slot_id={}, callsign={}, rf_settings={}{}>'\
            .format(self.__class__.__name__,
                    self.name, self.slot_id, self.callsign, self.rf_settings,
                    ', text={}'.format(self.text) if self.text else '')

    @classmethod
    def deserialize(cls, tlvs):
        """ Build a FrequencySlotPayload from a list of TLVs

        :param list[goTenna.tlv.basic_tlv.TLV] tlvs: The list of TLVs
        :returns FrequencySlotPayload: The initialized payload
        """
        kwargs = {'rf_settings': goTenna.settings.RFSettings(),
                  'text': None}
        inner_tlvs = []
        for top_tlv in tlvs:
            if isinstance(top_tlv, goTenna.tlv.payload_tlv.FrequencySlotDataTLV):
                inner_tlvs = top_tlv.contents
            elif isinstance(top_tlv, goTenna.tlv.payload_tlv.TextTLV):
                kwargs['text'] = top_tlv.contents
        for section in inner_tlvs:
            if isinstance(section, goTenna.tlv.payload_tlv.FrequencySlotIDTLV):
                kwargs['slot_id'] = section.id_bytes
            elif isinstance(section, goTenna.tlv.payload_tlv.FrequencySlotNameTLV):
                kwargs['name'] = section.name
            elif isinstance(section, goTenna.tlv.payload_tlv.FrequencySlotCallSignTLV):
                kwargs['callsign'] = section.callsign
            elif isinstance(section, goTenna.tlv.payload_tlv.FrequencySlotMaxPowerTLV):
                kwargs['rf_settings'].power_enum = section.power
            elif isinstance(section, goTenna.tlv.payload_tlv.FrequencySlotFrequencyListTLV):
                kwargs['rf_settings'].control_freqs = section.control_freqs
                kwargs['rf_settings'].data_freqs = section.data_freqs
            elif isinstance(section, goTenna.tlv.payload_tlv.FrequencySlotDataBandwidthTLV):
                kwargs['rf_settings'].bandwidth = section.bandwidth
            elif isinstance(section, goTenna.tlv.payload_tlv.TextTLV):
                kwargs['text'] = section.contents
        return cls(**kwargs)

    def __init__(self, rf_settings, name, callsign, slot_id, text):
        # pylint: disable=line-too-long
        """ Build a FrequencySlotPayload.

        This payload is intended to share a complete frequency slot setup over the goTenna network.

        :param goTenna.settings.RFSettings rf_settings: A valid :py:class:`goTenna.settings.RFSettings` object to define the frequencies, transmit power, and channel mask the device should communicate on. This is the same object required to initialize a device.

        .. note ::
          Only the channel mask is communicated over the network. The data rate is assumed to be the highest-throughput (fastest) data rate allowed by the mask. For this reason, the :py:class:`goTenna.settings.RFSettings` object is copied and modified to have this datarate when it is passed in to this initializer.

        :param str name: A human-readable name for the frequency slot. This should be less than 32 bytes when encoded as UTF-8.
        :param str callsign: A human-readable short callsign for the frequency slot. This should be less than 32 bytes when encoded as UTF-8.
        :param byteslike slot_id: An ID for the frequency slots. This should be a byteslike, 36 bytes or less long. This is intended to allow the use of UUIDs.
        :param str text: A message to send along with the frequency slots. This may be empty or None if there is no message to send.
        """
        # pylint: enable=line-too-long
        Payload.__init__(self)
        self._name = goTenna.tlv.payload_tlv.FrequencySlotNameTLV(name)
        self._slot_id = goTenna.tlv.payload_tlv.FrequencySlotIDTLV(slot_id)
        self._callsign = goTenna.tlv.payload_tlv.FrequencySlotCallSignTLV(callsign)
        self._text = goTenna.tlv.payload_tlv.TextTLV(text) if text else None
        if not isinstance(rf_settings, goTenna.settings.RFSettings):
            raise TypeError('rf_settings must be an instance of goTenna.settings.RFSettings, is {}'
                            .format(type(rf_settings)))
        if not rf_settings.valid:
            raise ValueError("rf_settings must be valid")
        self._rf_settings = copy.copy(rf_settings)

    def serialize(self):
        ptlv = goTenna.tlv.payload_tlv
        data = six.b('')
        if self._text:
            data += self._text.to_bytes()
        payload_tlvs = [self._name, self._slot_id, self._callsign,
                        ptlv.FrequencySlotDataBandwidthTLV(self.rf_settings.bandwidth),
                        ptlv.FrequencySlotMaxPowerTLV(self.rf_settings.power_enum),
                        ptlv.FrequencySlotFrequencyListTLV(self.rf_settings.control_freqs,
                                                           self.rf_settings.data_freqs)]
        return data + ptlv.FrequencySlotDataTLV(payload_tlvs).to_bytes()

class GatewayAdvertisementPayload(Payload):
    # pylint: disable=line-too-long
    """  A payload advertising a gateway and what external nodes are available.

    This payload can be used to advertise as a gateway with certain external GIDs available. Contacts specified in the payload should be sent as destinations with ``via_gateway`` set to the origin of this payload.

    The list of nodes in this payload is not exhaustive; it is only a list of the numbers the gateway has chosen to advertise. Messages may arrive from the gateway with an origin that was not listed here.

    The text sent along with each node should be human-readable and safe to display.

    The advertised GIDs may have their ``via_gateway`` set, and may not; if they do not, it will be set as the sender (or sender's ``via_gateway``, if present) set in the payload.
    """
    # pylint: enable=line-too-long

    MESSAGE_TYPE = (goTenna.constants.LAYER8_MESSAGE_TYPES.GATEWAY_ADVERTISEMENT,)

    @property
    def payload_type(self):
        return self.MESSAGE_TYPE[0]

    @property
    def advertised_nodes(self):
        return [(an.gid, an.description) for an in self._advertised_nodes]

    def __init__(self, advertised_nodes):
        """ Build the GatewayAdvertisementPayload.

        :param advertised_nodes: A list of ``tuple[int, str]`` describing the node's  ID and a short human readable description.

        :raises TypeError: If ``advertised_nodes`` is not a list of ``tuple[int,str]``
        :raises ValueError: If the total length of the encoded payload is too long, or if a node ID is invalid (negative or cannot fit into 8 bytes)
        """
        Payload.__init__(self)
        self._advertised_nodes\
            = [goTenna.tlv.payload_tlv.AdvertisedExternalAddressTLV(*an)
               for an in advertised_nodes]

    def set_sender(self, sender):
        """ Override of set_sender for GatewayAdvertisementPayload that sets the gateway for its advertised nodes"""
        if sender.via_gateway:
            gateway = sender.via_gateway
        else:
            gateway = sender
        for an in self._advertised_nodes:
            an.gid._via_gateway = gateway
        return Payload.set_sender(self, sender)

    def serialize(self):
        return six.b('').join([an.to_bytes() for an in self._advertised_nodes])

    @classmethod
    def deserialize(cls, tlvs):
        """ Deserialize a GatewayAdvertisementPayload from the payload-specific TLVs. """
        nodes = []
        for t in tlvs:
            if not isinstance(t,
                              goTenna.tlv.payload_tlv.AdvertisedExternalAddressTLV):
                raise ValueError("unexpected tlv type {}".format(type(t)))
            nodes.append((t.gid, t.description))
        return cls(nodes)

    def __eq__(self, other):
        return isinstance(other, GatewayAdvertisementPayload)\
            and Payload.__eq__(self, other)\
            and self.advertised_nodes == other.advertised_nodes

    def __repr__(self):
        return '<{}: advertised nodes={}>'.format(self.__class__.__name__,
                                                  self.advertised_nodes)

class BinaryPayload(Payload):
    # pylint: disable=line-too-long
    """  A payload with binary data.

    This payload can be used to send binary data.

    """
    # pylint: enable=line-too-long

    MESSAGE_TYPE = (goTenna.constants.LAYER8_MESSAGE_TYPES.BINARY_ONLY,)

    @property
    def payload_type(self):
        return self.MESSAGE_TYPE[0]

    def __init__(self, binary_data):
        """ Build the BinaryPayload.

        :param binary_data: A binary data.

        :raises ValueError: If the total length of the encoded payload is too long
        """
        Payload.__init__(self)
        self._binary_data = binary_data

    def serialize(self):
        contents_tlvs = self._binary_data
        container = goTenna.tlv.payload_tlv.BinaryTLV(contents_tlvs)
        payload_bytes = container.to_bytes()
        return payload_bytes

    @classmethod
    def deserialize(cls, tlvs):
        """ Deserialize a BinaryPayload from the payload-specific TLVs. """
        for section in tlvs:
            if isinstance(section, payload_tlv.BinaryTLV):
                return cls(section.binary)
        raise ValueError("No BinaryTLV found in payload")

    def __eq__(self, other):
        return isinstance(other, BinaryPayload)\
            and Payload.__eq__(self, other)\
            and self._binary_data == other._binary_data

    def __repr__(self):
        return '<{}: binary={}, {}>'\
            .format(self.__class__.__name__,
                    goTenna.util.display_bytestring(self._binary_data)
                    if self._binary_data else None,
                    Payload._print_contents(self))                                                  

class KeyExchangeBase(Payload):
    # pylint: disable=line-too-long
    """ A payload handling the key exchange mechanism across the goTenna network

    This payload is used internally by the SDK to exchange public keys with other nodes of the goTenna network. Users of the SDK do not need to use it.

    The key exchange protocol is a two-way handshake, with a request and response.

    When a node Alice wants to send an encrypted message to a node Bob whose public key it does not have, Alice sends Bob a :py:class:`KeyRequestPayload`. This request message includes Alice's public key.

    When a Bob receives the :py:class:`KeyRequestPayload`, it loads the public key data contained in the payload and stores it as the Alice's public key. Bob then sends a :py:class:`KeyResponsePayload` containing its public key back to Alice. When Alice receives Bob's :py:class:`KeyResponsePayload`, it stores Bob's public key. When Alice receives the :py:class:`KeyResponsePayload`, key exchange is complete. Alice and Bob each use Diffie-Helman key exchange to generate a shared secret used as key material for encrypted messages going forward.
    """
    # pylint: enable=line-too-long

    MESSAGE_TYPE = ()

    def __init__(self, kind, key_bytes):
        # pylint: disable=line-too-long
        """ Build a KeyExchangePayload.

        :param goTenna.constants.LAYER8_MESSAGE_TYPE kind: The kind of the message. Should be either :py:attr:`goTenna.constants.LAYER8_MESSAGE_TYPES.MESH_PUBLIC_KEY_REQUEST` or :py:attr:`goTenna.constants.LAYER8_MESSAGE_TYPES.MESH_PUBLIC_KEY_RESPONSE`.
        :param byteslike key_bytes: The compressed public key, generated with :py:meth:`goTenna.encryption.pubkey_from_compressed`

        :returns KeyExchangePayload: The initialized payload
        """
        # pylint: enable=line-too-long
        if kind not in self.MESSAGE_TYPE:
            raise ValueError("kind must be one of MESH_PUBLIC_KEY_REQUEST or MESH_PUBLIC_KEY_RESPONSE, is {}"
                             .format(kind))
        try:
            _ = struct.pack('1s', key_bytes[:1])
        except struct.error:
            raise KeyError('key_bytes must be a byteslike, is {}'
                           .format(type(key_bytes)))
        self._key_bytes = key_bytes
        Payload.__init__(self)

    @property
    def key_bytes(self):
        return self._key_bytes

    @classmethod
    def deserialize(cls, tlvs):
        """ Deserialize a KeyExchangeBase from the payload-specific TLVs. """
        for tlv in tlvs:
            if isinstance(tlv, goTenna.tlv.payload_tlv.PublicKeyDataTLV):
                return cls(tlv.key_bytes)
        raise ValueError("No PublicKeyDataTLV in payload!")

    def serialize(self):
        return goTenna.tlv.payload_tlv.PublicKeyDataTLV(self.key_bytes).to_bytes()

    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and self.key_bytes == other.key_bytes\
            and self.payload_type == other.payload_type\
            and Payload.__eq__(self, other)

    def __repr__(self):
        return '<{}: key_bytes={}, {}>'.format(self.__class__.__name__,
                                               self.key_bytes,
                                               self._print_contents())

class KeyRequestPayload(KeyExchangeBase):
    """ The payload type for a key exchange request.

    See :py:class:`KeyExchangeBase` for more.
    """
    MESSAGE_TYPE = (goTenna.constants.LAYER8_MESSAGE_TYPES.MESH_PUBLIC_KEY_REQUEST,)

    @property
    def payload_type(self):
        return self.MESSAGE_TYPE[0]

    def __init__(self, key_bytes):
        """ Build a KeyRequestPayload.

        :param byteslike key_bytes: The public key.
        """
        KeyExchangeBase.__init__(self, self.payload_type, key_bytes)


class KeyResponsePayload(KeyExchangeBase):
    """ The payload type for a key exchange response.

    See :py:class:`KeyExchangeBase` for more.
    """
    MESSAGE_TYPE = (goTenna.constants.LAYER8_MESSAGE_TYPES.MESH_PUBLIC_KEY_RESPONSE,)

    @property
    def payload_type(self):
        return self.MESSAGE_TYPE[0]

    def __init__(self, key_bytes):
        """ Build a KeyResponsePayload.

        :param byteslike key_bytes: The public key.
        """
        KeyExchangeBase.__init__(self, self.payload_type, key_bytes)

def _get_all_subclasses(cls):
    all_subclasses = []
    for subclass in cls.__subclasses__():
        if subclass != KeyExchangeBase:
            all_subclasses.append(subclass)
        all_subclasses.extend(_get_all_subclasses(subclass))
    return all_subclasses
