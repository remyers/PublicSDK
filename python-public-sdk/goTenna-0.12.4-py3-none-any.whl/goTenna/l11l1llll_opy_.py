# coding: utf8
import sys
l1l1ll_opy_ = sys.version_info [0] == 2
l1llll_opy_ = 2048
l11l1_opy_ = 7
def l1l1l1_opy_ (l1l1l_opy_):
    global l1ll11_opy_
    l1l111_opy_ = ord (l1l1l_opy_ [-1])
    l11_opy_ = l1l1l_opy_ [:-1]
    l111_opy_ = l1l111_opy_ % len (l11_opy_)
    ll_opy_ = l11_opy_ [:l111_opy_] + l11_opy_ [l111_opy_:]
    if l1l1ll_opy_:
        l1lll1_opy_ = unicode () .join ([unichr (ord (char) - l1llll_opy_ - (l1ll_opy_ + l1l111_opy_) % l11l1_opy_) for l1ll_opy_, char in enumerate (ll_opy_)])
    else:
        l1lll1_opy_ = str () .join ([chr (ord (char) - l1llll_opy_ - (l1ll_opy_ + l1l111_opy_) % l11l1_opy_) for l1ll_opy_, char in enumerate (ll_opy_)])
    return eval (l1lll1_opy_)
# Copyright (C) 2018 goTenna, Inc. This file is distributed as part of the
# goTenna USB SDK. See the associated license for more information.
# pylint: disable=line-too-long
l1l1l1_opy_ (u"ࠦࠧࠨࠠࡎࡧࡷ࡬ࡴࡪࡳࠡࡣࡱࡨࠥࡩ࡯࡯ࡵࡷࡥࡳࡺࡳࠡࡨࡲࡶࠥࡩࡲࡢࡨࡷ࡭ࡳ࡭ࠠࡣ࡫ࡱࡥࡷࡿࠠࡧ࡫ࡵࡱࡼࡧࡲࡦࠢࡸࡴࡩࡧࡴࡦࠢࡳࡥࡨࡱࡥࡵࡵ࠱ࠎࠏ࡚ࡨࡪࡵࠣࡱࡴࡪࡵ࡭ࡧࠣࡸࡾࡶࡩࡤࡣ࡯ࡰࡾࠦࡳࡩࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡦࡪࠦࡵࡴࡧࡧࠤࡧࡿࠠࡂࡒࡌࠤࡨࡵ࡮ࡴࡷࡰࡩࡷࡹ࠻ࠡࡶ࡫ࡩࠥࡀࡰࡺ࠼ࡰࡩࡹ࡮࠺ࡡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡳࡶࡴ࠴ࡐࡳࡱ࠱ࡪࡱࡧࡳࡩࡡࡧࡩࡻ࡯ࡣࡦࡢࠣࡱࡪࡺࡨࡰࡦࠣ࡭ࡸࠦࡡࠡ࡯ࡸࡧ࡭ࠦ࡭ࡰࡴࡨࠤࡺࡹࡥࡳࠢࡩࡶ࡮࡫࡮ࡥ࡮ࡼࠤࡼࡧࡹࠡࡶࡲࠤ࡮ࡴࡴࡦࡴࡤࡧࡹࠦࡷࡪࡶ࡫ࠤࡹ࡮ࡩࡴࠢࡦࡳࡩ࡫࠮ࠋࠤࠥࠦ৿")
# pylint: enable=line-too-long
import struct
import math
import os
import six
import goTenna.binary_utils
class l1l11ll111_opy_(object):
    l1l1l1_opy_ (u"ࠧࠨࠢࠡࡃࡱࠤࡴࡨࡪࡦࡥࡷࠤ࡫ࡵࡲࠡࡥࡤࡰࡨࡻ࡬ࡢࡶ࡬ࡲ࡬ࠦࡢࡺࡶࡨࡥࡷࡸࡡࡺࡵࠣࡥࡳࡪࠠࡩࡱ࡯ࡨ࡮ࡴࡧࠡࡵࡷࡥࡹ࡫ࠠࡳࡧ࡯ࡥࡹ࡫ࡤࠡࡶࡲࠤ࡫࡯ࡲ࡮ࡹࡤࡶࡪࠦࡵࡱࡦࡤࡸࡪࡹ࠮ࠋࠌࠣࠤࠥࠦࡔࡩࡧࠣࡲࡴࡸ࡭ࡢ࡮ࠣࡹࡸࡧࡧࡦࠢࡳࡥࡹࡺࡥࡳࡰࠣ࡭ࡸࠦࡴࡰࠢࡦࡶࡪࡧࡴࡦࠢࡤࡲࠥ࡯࡮ࡴࡶࡤࡲࡨ࡫ࠠࡰࡨࠣࡊ࡮ࡸ࡭ࡸࡣࡵࡩࡈࡵ࡮ࡷࡧࡵࡸࡪࡸࠠࡸ࡫ࡷ࡬ࠥࡧࠠࡱࡣࡷ࡬ࠥࡺ࡯ࠡࡣࠣࡪ࡮ࡲࡥࠡࡱࡵࠤ࡫࡯࡬ࡦ࠯࡯࡭ࡰ࡫ࠠࡰࡤ࡭ࡩࡨࡺࠬࠡࡣࡱࡨࠥࡺࡨࡦࡰࠣࡹࡸ࡫ࠠࡪࡶࠣࡥࡸࠦࡡ࡯ࠢ࡬ࡸࡪࡸࡡࡵࡱࡵࠤࡾ࡯ࡥ࡭ࡦ࡬ࡲ࡬ࠦࠨࡱࡣࡦ࡯ࡪࡺࠠࡵࡱࠣࡷࡪࡴࡤ࠭ࠢࡷ࡭ࡲ࡫࡯ࡶࡶࠬࠤࡹࡻࡰ࡭ࡧࡶ࠲ࠥࡎ࡯ࡸࡧࡹࡩࡷ࠲ࠠࡵࡪࡨࠤࡴࡺࡨࡦࡴࠣࡱࡪࡺࡨࡰࡦࡶࠤࡦࡴࡤࠡࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷࠥࡵࡦࠡࡣࡱࠤ࡮ࡴࡳࡵࡣࡱࡧࡪࠦࡣࡢࡰࠣࡦࡪࠦࡵࡴࡧࡧࠤࡹࡵࠠࡪࡰࡷࡩࡷࡧࡣࡵࠢࡶࡸࡦࡺࡥ࡭ࡧࡶࡷࡱࡿࠠࡸ࡫ࡷ࡬ࠥࡺࡨࡦࠢ࡯ࡳࡦࡪࡥࡥࠢࡧࡥࡹࡧ࠮ࠋࠌࠣࠤࠥࠦࡔࡩࡧࠣࡤࡵࡧࡣ࡬ࡧࡷࡣࡹࡵ࡟ࡴࡧࡱࡨࡥࠦࡥ࡭ࡧࡰࡩࡳࡺࠠࡪࡵࠣࡷࡺ࡯ࡴࡢࡤ࡯ࡩࠥ࡬࡯ࡳࠢࡶࡩࡳࡪࡩ࡯ࡩࠣࡨ࡮ࡸࡥࡤࡶ࡯ࡽࠥࡺ࡯ࠡ࠼ࡳࡽ࠿ࡳࡥࡵࡪ࠽ࡤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡶࡣࡣࡡࡦࡳࡳࡴࡥࡤࡶ࡬ࡳࡳ࠴ࡇࡰࡶࡨࡲࡳࡧࡐࡄࡄ࠱ࡻࡷ࡯ࡴࡦࡡࡥ࡭ࡳࡧࡲࡺࡢ࠱ࠎࠥࠦࠠࠡࡖ࡫ࡩࠥࡦࡴࡪ࡯ࡨࡳࡺࡺࡠࠡࡧ࡯ࡩࡲ࡫࡮ࡵࠢ࡬ࡷࠥࡹࡵࡪࡶࡤࡦࡱ࡫ࠠࡧࡱࡵࠤࡸࡶࡥࡤ࡫ࡩࡽ࡮ࡴࡧࠡࡣࠣࡤࡹ࡯࡭ࡦࡱࡸࡸࡤࡵࡶࡦࡴࡵ࡭ࡩ࡫ࡠࠡ࡫ࡱࠤ࠿ࡶࡹ࠻࡯ࡨࡸ࡭ࡀࡠࡨࡱࡗࡩࡳࡴࡡ࠯ࡲࡦࡦࡤࡩ࡯࡯ࡰࡨࡧࡹ࡯࡯࡯࠰ࡊࡳࡹ࡫࡮࡯ࡣࡓࡇࡇ࠴ࡲࡦࡣࡧࡣࡧ࡯࡮ࡢࡴࡼࡣࡧࡲ࡯ࡤ࡭࡬ࡲ࡬ࡦ࠮ࠋࠢࠣࠤࠥࠨࠢࠣ਀")
    _CHUNK_SIZE = 250
    l1l1l1_opy_ (u"ࠨࠢࠣࡖ࡫ࡩࠥࡹࡩࡻࡧࠣࡳ࡫ࠦࡡࠡࡥ࡫ࡹࡳࡱ࠮ࠡࡈ࡯ࡳࡦࡺࠠࡣࡧࡦࡥࡺࡹࡥࠡࡹࡨࠤࡼࡧ࡮ࡵࠢࡤࠤࡨ࡫ࡩ࡭࡫ࡱ࡫ࠥࡪࡩࡷ࡫ࡶ࡭ࡴࡴࠠࡳࡣࡷ࡬ࡪࡸࠠࡵࡪࡤࡲࠥࡧࠠࡴࡶࡤࡲࡩࡧࡲࡥࠢࡩࡰࡴࡵࡲࡦࡦࠣ࡭ࡳࡺࠠࡥ࡫ࡹ࡭ࡸ࡯࡯࡯࠰ࠥࠦࠧਁ")
    _11ll1ll11_opy_ = six.int2byte(0x00)
    _11lll11l1_opy_ = six.int2byte(0x01)
    _11lll11ll_opy_ = six.int2byte(0x02)
    _11lll111l_opy_ = six.int2byte(0x03)
    _11lll1ll1_opy_ = six.int2byte(0xff)
    @staticmethod
    def l1l1llllll_opy_(path, version_major, version_minor):
        l1l1l1_opy_ (u"ࠢࠣࠤࠣࡅࠥ࡬ࡡࡤࡶࡲࡶࡾࠦࡦࡰࡴࠣࡦࡺ࡯࡬ࡥ࡫ࡱ࡫ࠥࡧ࡮ࠡ࡫ࡱࡷࡹࡧ࡮ࡤࡧࠣࡪࡷࡵ࡭ࠡࡣࠣࡴࡦࡺࡨࠡ࡫ࡱࡷࡹ࡫ࡡࡥࠢࡲࡪࠥࡧ࡮ࠡࡱࡳࡩࡳࠦࡦࡪ࡮ࡨ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤਂ")
        with open(path, l1l1l1_opy_ (u"ࠨࡴࡥࠫਃ")) as fromfile:
            return l1l11ll111_opy_(fromfile, version_major, version_minor)
    def __init__(self, l11ll11l11_opy_, version_major, version_minor):
        l1l1l1_opy_ (u"ࠤࠥࠦࠥࡉࡲࡦࡣࡷࡩࠥࡧ࡮ࠡ࡫ࡱࡷࡹࡧ࡮ࡤࡧࠣࡪࡷࡵ࡭ࠡࡣࡱࠤࡴࡶࡥ࡯ࠢࡩ࡭ࡱ࡫࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡊ࡮ࡲࡥࠡࡨ࡬ࡰࡪࡲࡩ࡬ࡧ࠽ࠤ࡙࡮ࡥࠡࡨ࡬ࡰࡪࠦࡴࡰࠢࡵࡩࡦࡪࠠࡧࡴࡲࡱ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡪࡰࡷࠤࡻ࡫ࡲࡴ࡫ࡲࡲࡤࡳࡡ࡫ࡱࡵ࠾࡚ࠥࡨࡦࠢࡰࡥ࡯ࡵࡲࠡࡸࡨࡶࡸ࡯࡯࡯ࠢࡲࡪࠥࡺࡨࡦࠢࡩ࡭ࡷࡳࡷࡢࡴࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥ࡯࡮ࡵࠢࡹࡩࡷࡹࡩࡰࡰࡢࡱ࡮ࡴ࡯ࡳ࠼ࠣࡘ࡭࡫ࠠ࡮࡫ࡱࡳࡷࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡰࡨࠣࡸ࡭࡫ࠠࡧ࡫ࡵࡱࡼࡧࡲࡦࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨ਄")
        data = l11ll11l11_opy_.read()
        #: The name associated with this firmware file
        self.name = os.path.basename(l11ll11l11_opy_.name)
        #: The major version of the firmware file
        self.version_major = version_major
        #: The minor version of the firmware file
        self.version_minor = version_minor
        #: The l11ll11l1l_opy_ l11ll1l111_opy_
        self.l11ll1l1l1_opy_ = self._11ll1llll_opy_(len(data))
        #: The data l1l1ll1111_opy_
        self.l11lll1l1l_opy_\
            = [self._11lll1111_opy_(l11ll1l11l_opy_) # l11ll1111l_opy_ a l11ll1l111_opy_ from a chunk
               for l11ll1l11l_opy_ # l11llll1l1_opy_ a list built from
               in [data[i:i+self._CHUNK_SIZE] # Data l11ll11ll1_opy_ into l11ll111ll_opy_
                   for i in range(0, len(data), self._CHUNK_SIZE)]]
        self.l11ll1l1ll_opy_ = self._11lll1lll_opy_(version_major,
                                                        version_minor)
        self.l11ll1lll1_opy_ = self._11llll11l_opy_()
        self.generator = self._11lll1l11_opy_()
    @property
    def l11ll1ll1l_opy_(self):
        l1l1l1_opy_ (u"ࠥࠦࠧࠦࡒࡦࡣࡧ࠱ࡴࡴ࡬ࡺࠢࡳࡶࡴࡶࡥࡳࡶࡼࠤ࡫ࡵࡲࠡࡦࡨࡸࡪࡸ࡭ࡪࡰ࡬ࡲ࡬ࠦࡴࡩࡧࠣࡲࡺࡳࡢࡦࡴࠣࡳ࡫ࠦࡰࡢࡥ࡮ࡩࡹࡹࠠࡵࡪࡨࠤࡺࡶࡤࡢࡶࡨࠤࡲࡻࡳࡵࠢࡶࡩࡳࡪ࠮ࠡࡥࡤࡰࡱ࡯࡮ࡨࠢ࡯ࡩࡳ࠮ࠩࠡࡱࡱࠤࡦࡴࠠࡪࡰࡶࡸࡦࡴࡣࡦࠢࡲࡪࠥࡺࡨࡪࡵࠣࡳࡧࡰࡥࡤࡶࠣࡶࡪࡲࡩࡦࡵࠣࡳࡳࠦࡴࡩ࡫ࡶࠤࡲ࡫ࡴࡩࡱࡧ࠲ࠧࠨࠢਅ")
        return len(self.l11lll1l1l_opy_) + 2 # init, finalize, reset
    def __len__(self):
        return self.l11ll1ll1l_opy_
    def _11lll1l11_opy_(self):
        l1l1l1_opy_ (u"ࠦࠧࠨࠠࡉࡧ࡯ࡴࡪࡸࠠ࡮ࡧࡷ࡬ࡴࡪࠠࡧࡱࡵࠤࡹ࡮ࡥࠡ࡫ࡷࡩࡷࡧࡴࡰࡴࠣࡴࡷࡵࡴࡰࡥࡲࡰࠥ࠳ࠠࡸࡧࠣ࡮ࡺࡹࡴࠡࡥࡵࡩࡦࡺࡥࠡࡣࠣ࡫ࡪࡴࡥࡳࡣࡷࡳࡷࠦࡷࡪࡶ࡫ࠤࡹ࡮ࡩࡴࠢࡰࡩࡹ࡮࡯ࡥࠢࡤࡲࡩࠦࡲࡦࡶࡸࡶࡳࠦࡴࡩࡧࠣࡶࡪࡹࡵ࡭ࡶࡶࠤࡴ࡬ࠠࡤࡣ࡯ࡰ࡮ࡴࡧࠡࡰࡨࡼࡹ࠮ࠩࠡࡱࡱࠤ࡮ࡺࠬࠡࡵࡲࠤࡼ࡫ࠠࡤࡣࡱࠤࡧ࡫ࠠࡢࡰࠣ࡭ࡹ࡫ࡲࡢࡶࡲࡶࠥࡽࡩࡵࡪࡲࡹࡹࠦࡨࡢࡸ࡬ࡲ࡬ࠦࡴࡰࠢࡧࡳࠥࡹ࡯࡮ࡧࡷ࡬࡮ࡴࡧࠡࡣࡶࠤ࡬ࡧࡵࡤࡪࡨࠤࡦࡹࠠ࡮ࡣ࡬ࡲࡹࡧࡩ࡯ࠢࡲࡹࡷࠦ࡯ࡸࡰࠣࡩࡽࡶ࡬ࡪࡥ࡬ࡸࠥࡹࡴࡢࡶࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣਆ")
        yield self.l11ll1l1l1_opy_
        for l11ll1l111_opy_ in self.l11lll1l1l_opy_:
            yield l11ll1l111_opy_
        yield self.l11ll1l1ll_opy_
        #yield self.l11ll1lll1_opy_
    def __iter__(self):
        l1l1l1_opy_ (u"ࠧࠨࠢࠡࡋࡷࡩࡷࡧࡴࡰࡴࠣࡴࡷࡵࡴࡰࡥࡲࡰ࠿ࠦࡩࡥࡧࡱࡸ࡮ࡺࡹࠡࡨࡸࡲࡨࡺࡩࡰࡰࠣࠦࠧࠨਇ")
        return self
    def __next__(self):
        return next(self.generator)
    def next(self):
        l1l1l1_opy_ (u"ࠨࠢࠣࠢࡌࡸࡪࡸࡡࡵࡱࡵࠤࡵࡸ࡯ࡵࡱࡦࡳࡱࡀ࡚ࠠ࡫ࡨࡰࡩࠦࡴࡩࡧࠣࡲࡪࡾࡴࠡࡲࡤࡧࡰ࡫ࡴࠡࡶࡲࠤࡧ࡫ࠠࡴࡧࡱࡸࠧࠨࠢਈ")
        return self.__next__()
    @staticmethod
    def _11ll1llll_opy_(l11ll11lll_opy_):
        l1l1l1_opy_ (u"ࠢࠣࠤࠣࡆࡺ࡯࡬ࡥࠢࡷ࡬ࡪࠦࡩ࡯࡫ࡷ࡭ࡦࡲࡩࡻࡣࡷ࡭ࡴࡴࠠࡱࡣࡦ࡯ࡪࡺࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢ࡬ࡲࡹࠦࡤࡢࡶࡤࡣࡱ࡫࡮ࡨࡶ࡫࠾࡚ࠥࡨࡦࠢ࡯ࡩࡳ࡭ࡴࡩࠢࡲࡪࠥࡺࡨࡦࠢࡥ࡭ࡳࡧࡲࡺࠢࡩ࡭ࡱ࡫ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡩࡹࡻࡲ࡯ࡵࠣࡸࡺࡶ࡬ࡦ࡝ࡶࡸࡷ࠲ࠠࡪࡰࡷࡡ࠿ࠦࡁࠡࡤ࡬ࡲࡦࡸࡹࠡࡵࡷࡶ࡮ࡴࡧࠡࡥࡲࡱࡵࡸࡩࡴ࡫ࡱ࡫ࠥࡧࠠࡧࡱࡵࡱࡦࡺࡴࡦࡦࠣࡴࡦࡩ࡫ࡦࡶࠣࡪࡴࡸࠠࡵࡴࡤࡲࡸࡳࡩࡴࡵ࡬ࡳࡳࠦࡴࡰࠢࡤࠤࡷ࡫࡭ࡰࡶࡨࠤࡩ࡫ࡶࡪࡥࡨࠤ࠭࡫࡬ࡦ࡯ࡨࡲࡹࠦ࠰ࠪࠢࡤࡲࡩࠦࡴࡩࡧࠣࡥࡵࡶࡲࡰࡲࡵ࡭ࡦࡺࡥࠡࡶ࡬ࡱࡪࡵࡵࡵࠢࡩࡳࡷࠦࡴࡩࡧࠣࡶࡪࡹࡰࡰࡰࡶࡩࠥ࠮ࡥ࡭ࡧࡰࡩࡳࡺࠠ࠲ࠫࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢਉ")
        chunks = math.ceil(float(l11ll11lll_opy_)/float(l1l11ll111_opy_._CHUNK_SIZE))
        payload = goTenna.binary_utils.l1_opy_[l1l1l1_opy_ (u"ࠨ࡫ࡱ࡭ࡹ࡯ࡡࡵࡧࡢࡲࡪࡽ࡟ࡧࡹࡢ࡭ࡲࡧࡧࡦࠩਊ")]\
                  + struct.pack(l1l1l1_opy_ (u"ࠩࠤࡍࠬ਋"), chunks)\
                  + struct.pack(l1l1l1_opy_ (u"ࠪࠥࡎ࠭਌"), l11ll11lll_opy_)
        return (payload, False, 30)
    @staticmethod
    def _11lll1111_opy_(data):
        l1l1l1_opy_ (u"ࠦࠧࠨࠠࡃࡷ࡬ࡰࡩࠦࡡࠡࡤ࡬ࡲࡦࡸࡹࠡࡦࡤࡸࡦࠦࡰࡢࡥ࡮ࡩࡹࠦࡩ࡯ࡥ࡯ࡹࡩ࡯࡮ࡨࠢࡷ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡀࡰࡺ࠼ࡤࡸࡹࡸ࠺ࡡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡩ࡭ࡷࡳࡷࡢࡴࡨࡣࡺࡶࡤࡢࡶࡨ࠲ࡋ࡯ࡲ࡮ࡹࡤࡶࡪࡉ࡯࡯ࡸࡨࡶࡹ࡫ࡲ࠯ࡡࡆࡌ࡚ࡔࡋࡠࡕࡌ࡞ࡊࡦࠠࡣࡻࡷࡩࡸࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡩ࡯ࡲࡸࡸ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡ࡫ࡱࡸࠥࡶࡡࡤ࡭ࡨࡸࡤ࡯࡮ࡥࡧࡻ࠾࡚ࠥࡨࡦࠢ࡬ࡲࡩ࡫ࡸࠡࡱࡩࠤࡹ࡮ࡥࠡࡲࡤࡧࡰ࡫ࡴࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡸࡷࠦࡤࡢࡶࡤ࠾ࠥࡇࠠࡴࡶࡵ࡭ࡳ࡭ࠠࡤࡱࡱࡸࡦ࡯࡮ࡪࡰࡪࠤࡹ࡮ࡥࠡࡥࡲࡲࡹ࡫࡮ࡵࡵࠣࡳ࡫ࠦࡡࠡࡨ࡬ࡶࡲࡽࡡࡳࡧࠣࡦ࡮ࡴࡡࡳࡻࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲࡸࠦࡴࡶࡲ࡯ࡩࡠࡹࡴࡳ࠮ࠣ࡭ࡳࡺ࡝࠻ࠢࡄࠤࡧ࡯࡮ࡢࡴࡼࠤࡸࡺࡲࡪࡰࡪࠤࡨࡵ࡭ࡱࡴ࡬ࡷ࡮ࡴࡧࠡࡣࠣࡪࡴࡸ࡭ࡢࡶࡷࡩࡩࠦࡰࡢࡥ࡮ࡩࡹࠦࡦࡰࡴࠣࡸࡷࡧ࡮ࡴ࡯࡬ࡷࡸ࡯࡯࡯ࠢࡷࡳࠥࡧࠠࡳࡧࡰࡳࡹ࡫ࠠࡥࡧࡹ࡭ࡨ࡫ࠠࠩࡧ࡯ࡩࡲ࡫࡮ࡵࠢ࠳࠭ࠥࡧ࡮ࡥࠢࡷ࡬ࡪࠦࡡࡱࡲࡵࡳࡵࡸࡩࡢࡶࡨࠤࡹ࡯࡭ࡦࡱࡸࡸࠥ࡬࡯ࡳࠢࡷ࡬ࡪࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡࠪࡨࡰࡪࡳࡥ࡯ࡶࠣ࠵࠮ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ਍")
        l11ll111l1_opy_ = min(len(data), l1l11ll111_opy_._CHUNK_SIZE)
        l11llll111_opy_ = data[:l11ll111l1_opy_]
        payload = goTenna.binary_utils.l1_opy_[l1l1l1_opy_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡧࡹࡢ࡭ࡲࡧࡧࡦࠩ਎")]\
                  + l11llll111_opy_
        return (payload, False, 10)
    @staticmethod
    def _11lll1lll_opy_(major, minor):
        l1l1l1_opy_ (u"ࠨࠢࠣࠢࡅࡹ࡮ࡲࡤࠡࡣࠣࡴࡦࡩ࡫ࡦࡶࠣࡶࡪࡷࡵࡦࡵࡷ࡭ࡳ࡭ࠠࡧ࡫ࡵࡱࡼࡧࡲࡦࠢࡹࡩࡷ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤ࡮ࡴࡴࠡ࡯ࡤ࡮ࡴࡸ࠺ࠡࡖ࡫ࡩࠥࡳࡡ࡫ࡱࡵࠤࡻ࡫ࡲࡴ࡫ࡲࡲࠥࡵࡦࠡࡶ࡫ࡩࠥ࡬ࡩࡳ࡯ࡺࡥࡷ࡫ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡ࡫ࡱࡸࠥࡳࡩ࡯ࡱࡵ࠾࡚ࠥࡨࡦࠢࡰ࡭ࡳࡵࡲࠡࡸࡨࡶࡸ࡯࡯࡯ࠢࡲࡪࠥࡺࡨࡦࠢࡩ࡭ࡷࡳࡷࡢࡴࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡦࡶࡸࡶࡳࡹࠠࡵࡷࡳࡰࡪࡡࡳࡵࡴ࠯ࠤ࡮ࡴࡴ࡞࠼ࠣࡅࠥࡨࡩ࡯ࡣࡵࡽࠥࡹࡴࡳ࡫ࡱ࡫ࠥࡩ࡯࡮ࡲࡵ࡭ࡸ࡯࡮ࡨࠢࡤࠤ࡫ࡵࡲ࡮ࡣࡷࡸࡪࡪࠠࡱࡣࡦ࡯ࡪࡺࠠࡧࡱࡵࠤࡹࡸࡡ࡯ࡵࡰ࡭ࡸࡹࡩࡰࡰࠣࡸࡴࠦࡡࠡࡴࡨࡱࡴࡺࡥࠡࡦࡨࡺ࡮ࡩࡥࠡࠪࡨࡰࡪࡳࡥ࡯ࡶࠣ࠴࠮ࠦࡡ࡯ࡦࠣࡸ࡭࡫ࠠࡢࡲࡳࡶࡴࡶࡲࡪࡣࡷࡩࠥࡺࡩ࡮ࡧࡲࡹࡹࠦࡦࡰࡴࠣࡸ࡭࡫ࠠࡳࡧࡶࡴࡴࡴࡳࡦࠢࠫࡩࡱ࡫࡭ࡦࡰࡷࠤ࠶࠯࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧਏ")
        payload = goTenna.binary_utils.l1_opy_[l1l1l1_opy_ (u"ࠧࡧ࡫ࡱࡥࡱ࡯ࡺࡦࡡࡩࡻࡤ࡯࡭ࡢࡩࡨࠫਐ")]\
                  + l1l11ll111_opy_._11lll1ll1_opy_\
                  + struct.pack(l1l1l1_opy_ (u"ࠨࡄࠪ਑"), major)\
                  + struct.pack(l1l1l1_opy_ (u"ࠩࡅࠫ਒"), minor)
        return (payload, True, 30)
    @staticmethod
    def _11llll11l_opy_():
        l1l1l1_opy_ (u"ࠥࠦࠧࠦࡂࡶ࡫࡯ࡨࠥࡧࠠࡱࡣࡦ࡯ࡪࡺࠠࡳࡧࡴࡹࡪࡹࡴࡪࡰࡪࠤࡷ࡫ࡢࡰࡱࡷࠤ࡮ࡴࡴࡰࠢࡷ࡬ࡪࠦ࡮ࡦࡹࠣࡪ࡮ࡸ࡭ࡸࡣࡵࡩ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡩࡹࡻࡲ࡯ࡵࠣࡸࡺࡶ࡬ࡦ࡝ࡶࡸࡷ࠲ࠠࡪࡰࡷࡡ࠿ࠦࡁࠡࡤ࡬ࡲࡦࡸࡹࠡࡵࡷࡶ࡮ࡴࡧࠡࡥࡲࡱࡵࡸࡩࡴ࡫ࡱ࡫ࠥࡧࠠࡧࡱࡵࡱࡦࡺࡴࡦࡦࠣࡴࡦࡩ࡫ࡦࡶࠣࡪࡴࡸࠠࡵࡴࡤࡲࡸࡳࡩࡴࡵ࡬ࡳࡳࠦࡴࡰࠢࡤࠤࡷ࡫࡭ࡰࡶࡨࠤࡩ࡫ࡶࡪࡥࡨࠤ࠭࡫࡬ࡦ࡯ࡨࡲࡹࠦ࠰ࠪࠢࡤࡲࡩࠦࡴࡩࡧࠣࡥࡵࡶࡲࡰࡲࡵ࡭ࡦࡺࡥࠡࡶ࡬ࡱࡪࡵࡵࡵࠢࡩࡳࡷࠦࡴࡩࡧࠣࡶࡪࡹࡰࡰࡰࡶࡩࠥ࠮ࡥ࡭ࡧࡰࡩࡳࡺࠠ࠲ࠫࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢਓ")
        payload = goTenna.binary_utils.l1_opy_[l1l1l1_opy_ (u"ࠫ࡫࡯࡮ࡢ࡮࡬ࡾࡪࡥࡦࡸࡡ࡬ࡱࡦ࡭ࡥࠨਔ")]\
                  + l1l11ll111_opy_._11lll111l_opy_\
                  + six.int2byte(0) + six.int2byte(0)
        return (payload, True, 30)