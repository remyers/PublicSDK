# coding: utf8
import sys
l1l1ll_opy_ = sys.version_info [0] == 2
l1llll_opy_ = 2048
l11l1_opy_ = 7
def l1l1l1_opy_ (l1l1l_opy_):
    global l1ll11_opy_
    l1l111_opy_ = ord (l1l1l_opy_ [-1])
    l11_opy_ = l1l1l_opy_ [:-1]
    l111_opy_ = l1l111_opy_ % len (l11_opy_)
    ll_opy_ = l11_opy_ [:l111_opy_] + l11_opy_ [l111_opy_:]
    if l1l1ll_opy_:
        l1lll1_opy_ = unicode () .join ([unichr (ord (char) - l1llll_opy_ - (l1ll_opy_ + l1l111_opy_) % l11l1_opy_) for l1ll_opy_, char in enumerate (ll_opy_)])
    else:
        l1lll1_opy_ = str () .join ([chr (ord (char) - l1llll_opy_ - (l1ll_opy_ + l1l111_opy_) % l11l1_opy_) for l1ll_opy_, char in enumerate (ll_opy_)])
    return eval (l1lll1_opy_)
# Copyright (C) 2018 goTenna, Inc. This file is distributed as part of the
# goTenna USB SDK. See the associated license for more information.
# pylint: disable=line-too-long
l1l1l1_opy_ (u"ࠢࠣࠤࠣࡑࡴࡪࡵ࡭ࡧࠣࡩࡳࡩࡲࡺࡲࡷ࡭ࡴࡴ࠺ࠡࡈࡸࡲࡨࡺࡩࡰࡰࡶࠤ࡫ࡵࡲࠡࡧࡱࡧࡷࡿࡰࡵ࡫ࡱ࡫ࠥ࡭࡯ࡕࡧࡱࡲࡦࠦ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠋࠌࡗ࡬ࡪࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࡴࠢ࡫ࡩࡷ࡫ࠠࡳࡧࡴࡹ࡮ࡸࡥࠡࡶ࡫ࡩࠥࡀࡰࡺ࠼ࡰࡳࡩࡀࡠࡤࡴࡼࡴࡹࡵࡧࡳࡣࡳ࡬ࡾࡦࠠ࡮ࡱࡧࡹࡱ࡫ࠬࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠤࡴࡴࠠࡑࡻࡓ࡭࠳ࠦࡔࡩࡧࡼࠤࡪࡴࡣࡢࡲࡶࡹࡱࡧࡴࡦࠢ࡮ࡩࡾࠦ࡬ࡰࡣࡧ࡭ࡳ࡭ࠠࡢࡰࡧࠤࡸࡺ࡯ࡳࡣࡪࡩ࠱ࠦࡳࡩࡣࡵࡩࡩࠦࡳࡦࡥࡵࡩࡹࠦࡧࡦࡰࡨࡶࡦࡺࡩࡰࡰ࠯ࠤࡦࡴࡤࠡࡣࡦࡸࡺࡧ࡬ࠡࡤࡼࡸࡪࡹࡴࡳ࡫ࡱ࡫ࠥ࡫࡮ࡤࡴࡼࡴࡹ࡯࡯࡯࠰ࠍࠦࠧࠨर")
# pylint: enable=line-too-long
import collections
import itertools
import struct
import os
import base64
import cryptography.hazmat.backends as backends
import cryptography.hazmat.backends.openssl.ec as l1111111l_opy_
import cryptography.hazmat.primitives.asymmetric.ec as ec
import cryptography.hazmat.primitives.serialization as serialization
import cryptography.hazmat.primitives.hmac as hmac
import cryptography.hazmat.primitives.hashes as hashes
import cryptography.utils
import six
import goTenna
l11l1111l_opy_ = collections.namedtuple(l1l1l1_opy_ (u"ࠨࡍࡨࡽࡕࡧࡩࡳࠩऱ"), [l1l1l1_opy_ (u"ࠩࡳࡶ࡮ࡼࡡࡵࡧࠪल"), l1l1l1_opy_ (u"ࠪࡴࡺࡨ࡬ࡪࡥࠪळ")])
_11l111l1_opy_ = 32
_1llll1lll_opy_ = 28
_1ll1lll1l_opy_ = six.b(l1l1l1_opy_ (u"ࠫࠬऴ")).join([six.int2byte(i)
                           for i in range(_1llll1lll_opy_)])
_1lll111ll_opy_ = hashes.SHA256
def l1llll11ll_opy_(l111111ll_opy_):
    l1l1l1_opy_ (u"ࠧࠨࠢࠡࡎࡲࡥࡩࠦࡡࠡࡲࡸࡦࡱ࡯ࡣࠡ࡭ࡨࡽࠥ࡬ࡲࡰ࡯ࠣ࡭ࡹࡹࠠࡤࡱࡰࡴࡷ࡫ࡳࡴࡧࡧࠤ࡫ࡵࡲ࡮࠮ࠣࡹࡸࡻࡡ࡭࡮ࡼࠤ࡫ࡸ࡯࡮ࠢࡷ࡬ࡪࠦࡧࡰࡖࡨࡲࡳࡧࠠ࡯ࡧࡷࡻࡴࡸ࡫࠯ࠌࠍࠤࠥࠦࠠࡕࡪ࡬ࡷࠥࡻࡳࡦࡵࠣࡸ࡭࡫ࠠࡄࡧࡵࡸ࡮ࡩ࡯࡮ࠢࡖࡉࡈࠦࡣࡰ࡯ࡳࡶࡪࡹࡳࡪࡱࡱࠤࡲ࡫ࡴࡩࡱࡧࠤࡦࡹࠠࡴࡲࡨࡧ࡮࡬ࡩࡦࡦࠣ࡭ࡳࠦࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡷࡪࡩࡧ࠯ࡱࡵ࡫࠴ࡹࡥࡤ࠳࠰ࡺ࠷࠴ࡰࡥࡨࠣࡷࡪࡩࡴࡪࡱࡱࠤ࠷࠴࠳࠯࠶࠱ࠎࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡥࡽࡹ࡫ࡳࠡࡥࡲࡱࡵࡸࡥࡴࡵࡨࡨ࠿ࠦࡔࡩࡧࠣࡦࡾࡺࡥࡴࠢࡲࡪࠥࡺࡨࡦࠢࡦࡳࡲࡶࡲࡦࡵࡶࡩࡩࠦࡰࡰ࡫ࡱࡸࠥࡵ࡮ࠡࡥࡸࡶࡻ࡫ࠠࡔࡇࡆࡔ࠸࠾࠴ࡓ࠳࠱ࠎࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥࡴ࡙ࠢࡥࡱࡻࡥࡆࡴࡵࡳࡷࡀࠠࡊࡨࠣࡸ࡭࡫ࠠ࡬ࡧࡼࠤ࡫ࡵࡲ࡮ࡣࡷࠤ࡮ࡹࠠࡸࡴࡲࡲ࡬ࠦ࡯ࡳࠢࡧࡳࡪࡹࠠ࡯ࡱࡷࠤࡷ࡫ࡰࡳࡧࡶࡩࡳࡺࠠࡢࠢࡹࡥࡱ࡯ࡤࠡࡲࡲ࡭ࡳࡺࠠࡰࡰࠣࡗࡊࡉࡐ࠴࠺࠷ࡖ࠶࠴ࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲࡸࠦࡣࡳࡻࡳࡸࡴ࡭ࡲࡢࡲ࡫ࡽ࠳࡮ࡡࡻ࡯ࡤࡸ࠳ࡶࡲࡪ࡯࡬ࡸ࡮ࡼࡥࡴ࠰ࡤࡷࡾࡳ࡭ࡦࡶࡵ࡭ࡨ࠴ࡥࡤ࠰ࡈࡰࡱ࡯ࡰࡵ࡫ࡦࡇࡺࡸࡶࡦࡒࡸࡦࡱ࡯ࡣࡌࡧࡼ࠾࡚ࠥࡨࡦࠢࡧࡩࡸ࡫ࡲࡪࡣ࡯࡭ࡿ࡫ࡤࠡࡲࡸࡦࡱ࡯ࡣࠡ࡭ࡨࡽ࠳ࠐࠠࠡࠢࠣࠦࠧࠨव")
    l1111l111_opy_ = backends.default_backend()._elliptic_curve_to_nid(ec.SECP384R1())
    l111ll111_opy_ = backends.default_backend()._lib.EC_KEY_new_by_curve_name(l1111l111_opy_)
    l111ll111_opy_ = backends.default_backend()._ffi.gc(l111ll111_opy_, backends.default_backend()._lib.EC_KEY_free)
    group = backends.default_backend()._lib.EC_KEY_get0_group(l111ll111_opy_)
    l1lll1ll1l_opy_ = cryptography.utils.int_from_bytes(l111111ll_opy_[:1], l1l1l1_opy_ (u"࠭ࡢࡪࡩࠪश"))
    x = cryptography.utils.int_from_bytes(l111111ll_opy_[1:], l1l1l1_opy_ (u"ࠧࡣ࡫ࡪࠫष"))
    l11111l1l_opy_ = backends.default_backend()._lib.EC_POINT_new(group)
    l11111l1l_opy_ = backends.default_backend()._ffi.gc(l11111l1l_opy_, backends.default_backend()._lib.EC_POINT_free)
    with backends.default_backend()._tmp_bn_ctx() as l1lllll111_opy_:
        l1lll1l1l1_opy_ = backends.default_backend()._lib.BN_CTX_get(l1lllll111_opy_)
        l1lll1l1l1_opy_ = backends.default_backend()._int_to_bn(x, l1lll1l1l1_opy_)
        res = backends.default_backend()._lib.EC_POINT_set_compressed_coordinates_GFp(group,
                                                                                      l11111l1l_opy_,
                                                                                      l1lll1l1l1_opy_,
                                                                                      l1lll1ll1l_opy_ - 2,
                                                                                      l1lllll111_opy_)
        if res != 1:
            raise ValueError(l1l1l1_opy_ (u"ࠣࡕࡨࡸࠥࡩ࡯࡮ࡲࡵࡩࡸࡹࡥࡥࠢࡦࡳࡴࡸࡤࡴࠢࡩࡥ࡮ࡲࡥࡥࠤस"))
        res = backends.default_backend()._lib.EC_KEY_set_public_key(l111ll111_opy_, l11111l1l_opy_)
        if res != 1:
            raise ValueError(l1l1l1_opy_ (u"ࠤࡖࡩࡹࠦࡰࡶࡤ࡯࡭ࡨࠦ࡫ࡦࡻࠣࡪࡦ࡯࡬ࡦࡦࠥह"))
    l1ll1l1l1l_opy_ = backends.default_backend()._ec_cdata_to_evp_pkey(l111ll111_opy_)
    return l1111111l_opy_._EllipticCurvePublicKey(backends.default_backend(), l111ll111_opy_, l1ll1l1l1l_opy_)
def l111llll1_opy_(l1llll1l11_opy_):
    l1l1l1_opy_ (u"ࠥࠦࠧࠦࡓࡦࡴ࡬ࡥࡱ࡯ࡺࡦࠢࡤࠤࡵࡻࡢ࡭࡫ࡦࠤࡰ࡫ࡹࠡࡶࡲࠤ࡮ࡺࡳࠡࡥࡲࡱࡵࡸࡥࡴࡵࡨࡨࠥ࡬࡯ࡳ࡯ࠣࡪࡴࡸࠠࡴࡧࡱࡨ࡮ࡴࡧࠡࡱࡱࠤࡹ࡮ࡥࠡࡩࡲࡘࡪࡴ࡮ࡢࠢࡱࡩࡹࡽ࡯ࡳ࡭࠱ࠎࠏࠦࠠࠡࠢࡗ࡬࡮ࡹࠠࡶࡵࡨࡷࠥࡺࡨࡦࠢࡆࡩࡷࡺࡩࡤࡱࡰࠤࡘࡋࡃࠡࡥࡲࡱࡵࡸࡥࡴࡵ࡬ࡳࡳࠦ࡭ࡦࡶ࡫ࡳࡩࠦࡡࡴࠢࡶࡴࡪࡩࡩࡧ࡫ࡨࡨࠥ࡯࡮ࠡࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡹࡥࡤࡩ࠱ࡳࡷ࡭࠯ࡴࡧࡦ࠵࠲ࡼ࠲࠯ࡲࡧࡪࠥࡹࡥࡤࡶ࡬ࡳࡳࠦ࠲࠯࠵࠱࠷࠱ࠦࡷࡩࡧࡵࡩࠥࡶ࡯ࡪࡰࡷࠤࡨࡵ࡭ࡱࡴࡨࡷࡸ࡯࡯࡯ࠢ࡬ࡷࠥࡨࡥࡪࡰࡪࠤࡺࡹࡥࡥ࠰ࠍࠎࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡥࡵࡽࡵࡺ࡯ࡨࡴࡤࡴ࡭ࡿ࠮ࡩࡣࡽࡱࡦࡺ࠮ࡱࡴ࡬ࡱ࡮ࡺࡩࡷࡧࡶ࠲ࡦࡹࡹ࡮࡯ࡨࡸࡷ࡯ࡣ࠯ࡧࡦ࠲ࡊࡲ࡬ࡪࡲࡷ࡭ࡨࡉࡵࡳࡸࡨࡔࡺࡨ࡬ࡪࡥࡎࡩࡾࠦࡰࡶࡤ࡮ࡩࡾࡀࠠࡕࡪࡨࠤࡵࡻࡢ࡭࡫ࡦࠤࡰ࡫ࡹࠡࡶࡲࠤࡸ࡫ࡲࡪࡣ࡯࡭ࡿ࡫࠮ࠋࠢࠣࠤࠥࠨࠢࠣऺ")
    l11111l11_opy_ = l1llll1l11_opy_.public_numbers()
    prefix = six.int2byte(3) if l11111l11_opy_.y % 2 else six.int2byte(2)
    return prefix + cryptography.utils.int_to_bytes(l11111l11_opy_.x,
                                                    (ec.SECP384R1().key_size + 7)//8)
def l1ll1llll1_opy_():
    l1l1l1_opy_ (u"ࠦࠧࠨࠠࡈࡧࡱࡩࡷࡧࡴࡦࠢࡤࠤࡰ࡫ࡹࡱࡣ࡬ࡶࠥ࡬࡯ࡳࠢࡸࡷࡪࠦࡷࡪࡶ࡫ࠤࡹ࡮ࡥࠡࡴࡨࡷࡹࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡥ࡯ࡥࡵࡽࡵࡺࡩࡰࡰࠣࡷࡾࡹࡴࡦ࡯࠱ࠎࠏࠦࠠࠡࠢࡄࠤࡰ࡫ࡹࡱࡣ࡬ࡶࠥ࡯ࡳࠡࡣࡱࠤ࡮ࡴࡳࡵࡣࡱࡧࡪࠦ࡯ࡧࠢ࠽ࡴࡾࡀࡣ࡭ࡣࡶࡷ࠿ࡦࡋࡦࡻࡓࡥ࡮ࡸࡠࠡࡥࡲࡲࡹࡧࡩ࡯࡫ࡱ࡫ࠥࡧࠠࡱࡴ࡬ࡺࡦࡺࡥࠡࡣࡱࡨࠥࡶࡵࡣ࡮࡬ࡧࠥࡱࡥࡺ࠰ࠍࠤࠥࠦࠠࠣࠤࠥऻ")
    private = ec.generate_private_key(ec.SECP384R1(), backends.default_backend())
    public = private.public_key()
    return l11l1111l_opy_(private, public)
def l111l1ll1_opy_(l1llll1l11_opy_):
    l1l1l1_opy_ (u"ࠧࠨࠢࠡࡕࡨࡶ࡮ࡧ࡬ࡪࡼࡨࠤࡦࠦࡰࡶࡤ࡯࡭ࡨࠦ࡫ࡦࡻࠣࡸࡴࠦࡡࠡࡤࡤࡷࡪ࠼࠴ࠡࡵࡷࡶ࡮ࡴࡧࠡࡨࡲࡶࠥࡲ࡯࡯ࡩ࠰ࡸࡪࡸ࡭ࠡࡵࡷࡳࡷࡧࡧࡦ࠰ࠍࠎࠥࠦࠠࠡࡖ࡫࡭ࡸࠦࡳࡩࡱࡸࡰࡩࠦࡢࡦࠢࡸࡷࡪࡪࠠࡵࡱࠣࡷࡪࡸࡩࡢ࡮࡬ࡾࡪࠦࡡࠡࡲࡸࡦࡱ࡯ࡣࠡ࡭ࡨࡽࠥ࡬࡯ࡳࠢࡺ࡬࡮ࡩࡨࠡࡶ࡫ࡩࠥࡶࡲࡪࡸࡤࡸࡪࠦ࡫ࡦࡻࠣ࡭ࡸࠦ࡮ࡰࡶࠣ࡯ࡳࡵࡷ࡯ࠢࡩࡳࡷࠦ࡬ࡰࡰࡪࠤࡹ࡫ࡲ࡮ࠢࡶࡸࡴࡸࡡࡨࡧ࠱ࠤ࡙ࡵࠠࡴࡧࡵ࡭ࡦࡲࡩࡻࡧࠣࡥࠥࡶࡵࡣ࡮࡬ࡧࠥࡱࡥࡺࠢࡩࡳࡷࠦࡴࡳࡣࡱࡷࡲ࡯ࡳࡴ࡫ࡲࡲࠥࡵ࡮ࠡࡶ࡫ࡩࠥ࡭࡯ࡕࡧࡱࡲࡦࠦ࡮ࡦࡶࡺࡳࡷࡱࠬࠡࡵࡨࡩࠥࡀࡰࡺ࠼ࡰࡩࡹ࡮࠺ࡡࡲࡸࡦࡰ࡫ࡹࡠࡣࡶࡣࡨࡵ࡭ࡱࡴࡨࡷࡸ࡫ࡤࡡ࠰ࠣࡘࡴࠦࡳࡦࡴ࡬ࡥࡱ࡯ࡺࡦࠢࡤࠤ࡫ࡻ࡬࡭ࠢ࡮ࡩࡾࡶࡡࡪࡴࠣࠬ࡫ࡵࡲࠡࡹ࡫࡭ࡨ࡮ࠠࡵࡪࡨࠤࡵࡸࡩࡷࡣࡷࡩࠥࡱࡥࡺࠢ࡬ࡷࠥࡧ࡬ࡴࡱࠣ࡯ࡳࡵࡷ࡯ࠫࠣࡪࡴࡸࠠ࡭ࡱࡱ࡫ࠥࡺࡥࡳ࡯ࠣࡷࡹࡵࡲࡢࡩࡨ࠰ࠥࡹࡥࡦࠢ࠽ࡴࡾࡀ࡭ࡦࡶ࡫࠾ࡥࡹࡥࡳ࡫ࡤࡰ࡮ࢀࡥࡠ࡭ࡨࡽࡵࡧࡩࡳࡢ࠱ࠎࠏࠦࠠࠡࠢࡗ࡬ࡪࠦ࡫ࡦࡻࠣ࡭ࡸࠦࡳࡢࡸࡨࡨࠥ࡯࡮ࠡࡷࡵࡰࡸࡧࡦࡦࠢࡥࡥࡸ࡫࠶࠵࠯ࡨࡲࡨࡵࡤࡦࡦࠣࡤࡥࡊࡅࡓࡢࡣࠤ࡫ࡵࡲ࡮ࡣࡷ࠲ࠏࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡷࡿࡰࡵࡱࡪࡶࡦࡶࡨࡺ࠰࡫ࡥࡿࡳࡡࡵ࠰ࡳࡶ࡮ࡳࡩࡵ࡫ࡹࡩࡸ࠴ࡡࡴࡻࡰࡱࡪࡺࡲࡪࡥ࠱ࡩࡨ࠴ࡅ࡭࡮࡬ࡴࡹ࡯ࡣࡄࡷࡵࡺࡪࡖࡵࡣ࡮࡬ࡧࡐ࡫ࡹ࠻ࠢࡗ࡬ࡪࠦ࡬ࡰࡣࡧࡩࡩࠦࡰࡶࡤ࡯࡭ࡨࠦ࡫ࡦࡻ࠱ࠎࠥࠦࠠࠡ࠼ࡵࡩࡹࡻࡲ࡯ࡵࠣࡷࡹࡸ࠺ࠡࡖ࡫ࡩࠥࡹࡥࡳ࡫ࡤࡰ࡮ࢀࡥࡥࠢࡳࡹࡧࡲࡩࡤࠢ࡮ࡩࡾࠐࠠࠡࠢࠣࠦࠧࠨ़")
    l1lll1lll1_opy_ = l1llll1l11_opy_.public_bytes(serialization.Encoding.DER,
                                       serialization.PublicFormat.SubjectPublicKeyInfo)
    return goTenna.util.b2s(base64.urlsafe_b64encode(l1lll1lll1_opy_))
def l111111l1_opy_(l1llll111l_opy_):
    l1l1l1_opy_ (u"ࠨࠢࠣࠢࡇࡩࡸ࡫ࡲࡪࡣ࡯࡭ࡿ࡫ࠠࡢࠢࡳࡹࡧࡲࡩࡤࠢ࡮ࡩࡾࠦࡦࡳࡱࡰࠤࡦࠦࡢࡢࡵࡨ࠺࠹ࠦࡳࡵࡴ࡬ࡲ࡬ࠦࡩ࡯ࠢ࡯ࡳࡳ࡭࠭ࡵࡧࡵࡱࠥࡹࡴࡰࡴࡤ࡫ࡪ࠴ࠊࠋࠢࠣࠤ࡚ࠥࡨࡪࡵࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡦࡪࠦࡵࡴࡧࡧࠤࡹࡵࠠࡥࡧࡶࡩࡷࡧ࡬ࡪࡼࡨࠤࡦࠦࡰࡶࡤ࡯࡭ࡨࠦ࡫ࡦࡻࠣࡪࡴࡸࠠࡸࡪ࡬ࡧ࡭ࠦࡴࡩࡧࠣࡴࡷ࡯ࡶࡢࡶࡨࠤࡰ࡫ࡹࠡ࡫ࡶࠤࡳࡵࡴࠡ࡭ࡱࡳࡼࡴࠠࡧࡴࡲࡱࠥࡲ࡯࡯ࡩࠣࡸࡪࡸ࡭ࠡࡵࡷࡳࡷࡧࡧࡦ࠰ࠣࡘࡴࠦࡤࡦࡵࡨࡶ࡮ࡧ࡬ࡪࡼࡨࠤࡦࠦࡰࡶࡤ࡯࡭ࡨࠦ࡫ࡦࡻࠣࡪࡷࡵ࡭ࠡࡶࡵࡥࡳࡹ࡭ࡪࡵࡶ࡭ࡴࡴࠠࡰࡰࠣࡸ࡭࡫ࠠࡨࡱࡗࡩࡳࡴࡡࠡࡰࡨࡸࡼࡵࡲ࡬ࠢࡶࡩࡪࠦ࠺ࡱࡻ࠽ࡱࡪࡺࡨ࠻ࡢࡳࡹࡧࡱࡥࡺࡡࡩࡶࡴࡳ࡟ࡤࡱࡰࡴࡷ࡫ࡳࡴࡧࡧࡤ࠳ࠦࡔࡰࠢࡧࡩࡸ࡫ࡲࡪࡣ࡯࡭ࡿ࡫ࠠࡢࠢࡩࡹࡱࡲࠠ࡬ࡧࡼࡴࡦ࡯ࡲࠡࠪࡩࡳࡷࠦࡷࡩ࡫ࡦ࡬ࠥࡺࡨࡦࠢࡳࡶ࡮ࡼࡡࡵࡧࠣ࡯ࡪࡿࠠࡪࡵࠣࡥࡱࡹ࡯ࠡ࡭ࡱࡳࡼࡴࠩࠡࡨࡵࡳࡲࠦ࡬ࡰࡰࡪࠤࡹ࡫ࡲ࡮ࠢࡶࡸࡴࡸࡡࡨࡧ࠯ࠤࡸ࡫ࡥࠡ࠼ࡳࡽ࠿ࡳࡥࡵࡪ࠽ࡤࡩ࡫ࡳࡦࡴ࡬ࡥࡱ࡯ࡺࡦࡡ࡮ࡩࡾࡶࡡࡪࡴࡣ࠲ࠏࠐࠠࠡࠢࠣࡘ࡭࡫ࠠ࡬ࡧࡼࠤ࡮ࡹࠠ࡭ࡱࡤࡨࡪࡪࠠࡧࡴࡲࡱࠥࡻࡲ࡭ࡵࡤࡪࡪࠦࡢࡢࡵࡨ࠺࠹ࠦࡥ࡯ࡥࡲࡨࡪࡪࠠࡡࡢࡇࡉࡗࡦࡠࠡࡨࡲࡶࡲࡧࡴ࠯ࠌࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡴࡶࡵࠤࡧ࠼࠴ࡴࡶࡵ࡭ࡳ࡭࠺ࠡࡖ࡫ࡩࠥࡹࡥࡳ࡫ࡤࡰ࡮ࢀࡥࡥࠢࡳࡹࡧࡲࡩࡤࠢ࡮ࡩࡾ࠲ࠠࡪࡰࠣࡹࡷࡲࡳࡢࡨࡨࠤࡧࡧࡳࡦ࠸࠷࠱ࡪࡴࡣࡰࡦࡨࡨࠥࡊࡅࡓࠢࡩࡳࡷࡳࡡࡵ࠰ࠍࠤࠥࠦࠠ࠻ࡴࡨࡸࡺࡸ࡮ࡴࠢࡦࡶࡾࡶࡴࡰࡩࡵࡥࡵ࡮ࡹ࠯ࡪࡤࡾࡲࡧࡴ࠯ࡲࡵ࡭ࡲ࡯ࡴࡪࡸࡨࡷ࠳ࡧࡳࡺ࡯ࡰࡩࡹࡸࡩࡤ࠰ࡨࡧ࠳ࡋ࡬࡭࡫ࡳࡸ࡮ࡩࡃࡶࡴࡹࡩࡕࡻࡢ࡭࡫ࡦࡏࡪࡿ࠺ࠡࡖ࡫ࡩࠥࡲ࡯ࡢࡦࡨࡨࠥࡶࡵࡣ࡮࡬ࡧࠥࡱࡥࡺ࠰ࠍࠤࠥࠦࠠࠣࠤࠥऽ")
    l1lll1lll1_opy_ = base64.urlsafe_b64decode(goTenna.util.s2b(l1llll111l_opy_))
    return serialization.load_der_public_key(l1lll1lll1_opy_, backends.default_backend())
def l1lll1l1ll_opy_(l1lll11111_opy_):
    l1l1l1_opy_ (u"ࠢࠣࠤࠣࡗࡪࡸࡩࡢ࡮࡬ࡾࡪࠦࡡࠡ࡭ࡨࡽࡵࡧࡩࡳࠢࡷࡳࠥࡧࠠࡶࡴ࡯ࡷࡦ࡬ࡥࠡࡤࡤࡷࡪ࠼࠴ࠡࡵࡷࡶ࡮ࡴࡧࠡࡨࡲࡶࠥࡲ࡯࡯ࡩ࠰ࡸࡪࡸ࡭ࠡࡵࡷࡳࡷࡧࡧࡦ࠰ࠍࠎࠥࠦࠠࠡࡖ࡫࡭ࡸࠦࡳࡩࡱࡸࡰࡩࠦࡢࡦࠢࡸࡷࡪࡪࠠࡵࡱࠣࡷࡪࡸࡩࡢ࡮࡬ࡾࡪࠦࡡࠡ࡭ࡨࡽࡵࡧࡩࡳࠢࠫࡪࡴࡸࠠࡸࡪ࡬ࡧ࡭ࠦࡢࡰࡶ࡫ࠤࡵࡻࡢ࡭࡫ࡦࠤࡦࡴࡤࠡࡲࡵ࡭ࡻࡧࡴࡦࠢ࡮ࡩࡾࡹࠠࡢࡴࡨࠤࡰࡴ࡯ࡸࡰࠬࠤ࡫ࡵࡲࠡ࡮ࡲࡲ࡬ࠦࡴࡦࡴࡰࠤࡸࡺ࡯ࡳࡣࡪࡩ࠳ࠦࡔࡰࠢࡶࡩࡷ࡯ࡡ࡭࡫ࡽࡩࠥࡧࠠࡱࡷࡥࡰ࡮ࡩࠠ࡬ࡧࡼࠤ࡫ࡵࡲࠡࡶࡵࡥࡳࡹ࡭ࡪࡵࡶ࡭ࡴࡴࠠࡰࡰࠣࡸ࡭࡫ࠠࡨࡱࡗࡩࡳࡴࡡࠡࡰࡨࡸࡼࡵࡲ࡬࠮ࠣࡷࡪ࡫ࠠ࠻ࡲࡼ࠾ࡲ࡫ࡴࡩ࠼ࡣࡴࡺࡨ࡫ࡦࡻࡢࡥࡸࡥࡣࡰ࡯ࡳࡶࡪࡹࡳࡦࡦࡣ࠲࡚ࠥ࡯ࠡࡵࡨࡶ࡮ࡧ࡬ࡪࡼࡨࠤࡦࠦࡰࡶࡤ࡯࡭ࡨࠦ࡫ࡦࡻࠣࠬ࡫ࡵࡲࠡࡹ࡫࡭ࡨ࡮ࠠࡵࡪࡨࠤࡵࡸࡩࡷࡣࡷࡩࠥࡱࡥࡺࠢ࡬ࡷࠥࡴ࡯ࡵࠢ࡮ࡲࡴࡽ࡮࠭ࠢࡩࡳࡷࠦࡩ࡯ࡵࡷࡥࡳࡩࡥࠡࡱࡱࡩࠥࡸࡥࡤࡧ࡬ࡺࡪࡪࠠࡧࡴࡲࡱࠥࡺࡨࡦࠢࡪࡳ࡙࡫࡮࡯ࡣࠣࡲࡪࡺࡷࡰࡴ࡮࠭ࠥࡹࡥࡦࠢ࠽ࡴࡾࡀ࡭ࡦࡶ࡫࠾ࡥࡹࡥࡳ࡫ࡤࡰ࡮ࢀࡥࡠࡲࡸࡦࡰ࡫ࡹࡡ࠰ࠍࠎࠥࠦࠠࠡࡖ࡫࡭ࡸࠦࡩࡴࠢࡤࡧࡨࡵ࡭ࡱ࡮࡬ࡷ࡭࡫ࡤࠡࡤࡼࠤࡸࡧࡶࡪࡰࡪࠤࡹ࡮ࡥࠡࡲࡵ࡭ࡻࡧࡴࡦࠢ࡮ࡩࡾࠦࡩ࡯ࠢࡸࡶࡱࡹࡡࡧࡧࠣࡦࡦࡹࡥ࠷࠶࠰ࡩࡳࡩ࡯ࡥࡧࡧࠤࡥࡦࡄࡆࡔࡣࡤࠥ࡬࡯ࡳ࡯ࡤࡸ࠳ࠐࠊࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡐ࡫ࡹࡑࡣ࡬ࡶࠥࡱࡥࡺࡲࡤ࡭ࡷࡀࠠࡕࡪࡨࠤࡰ࡫ࡹࡱࡣ࡬ࡶࠥࡺ࡯ࠡࡵࡤࡺࡪ࠴ࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲࡸࠦࡳࡵࡴ࠽ࠤ࡙࡮ࡥࠡࡵࡨࡶ࡮ࡧ࡬ࡪࡼࡨࡨࠥࡱࡥࡺࡲࡤ࡭ࡷ࠲ࠠࡪࡰࠣࡹࡷࡲࡳࡢࡨࡨࠤࡧࡧࡳࡦ࠸࠷࠱ࡪࡴࡣࡰࡦࡨࡨࠥࡦࡠࡅࡇࡕࡤࡥࠦࡥ࡯ࡥࡲࡨ࡮ࡴࡧ࠯ࠌࠣࠤࠥࠦࠢࠣࠤा")
    l1llllll1l_opy_ = l1lll11111_opy_.private.private_bytes(serialization.Encoding.DER,
                                             serialization.PrivateFormat.PKCS8,
                                             serialization.NoEncryption())
    return goTenna.util.b2s(base64.urlsafe_b64encode(l1llllll1l_opy_))
def l111l11ll_opy_(l1llll111l_opy_):
    l1l1l1_opy_ (u"ࠣࠤࠥࠤࡑࡵࡡࡥࠢࡤࠤࡰ࡫ࡹࡱࡣ࡬ࡶࠥ࡬ࡲࡰ࡯ࠣࡥࠥࡨࡡࡴࡧ࠹࠸࠲࡫࡮ࡤࡱࡧࡩࡩࠦࡳࡵࡴ࡬ࡲ࡬࠲ࠠࡦ࠰ࡪ࠲ࠥ࡬ࡲࡰ࡯ࠣࡰࡴࡴࡧࠡࡶࡨࡶࡲࠦࡳࡵࡱࡵࡥ࡬࡫࠮ࠋࠌࠣࠤࠥࠦࡔࡩ࡫ࡶࠤࡸ࡮࡯ࡶ࡮ࡧࠤࡧ࡫ࠠࡶࡵࡨࡨࠥࡺ࡯ࠡࡦࡨࡷࡪࡸࡩࡢ࡮࡬ࡾࡪࠦࡡࠡ࡭ࡨࡽࡵࡧࡩࡳࠢࡩࡳࡷࠦࡷࡩ࡫ࡦ࡬ࠥࡨ࡯ࡵࡪࠣࡴࡺࡨ࡬ࡪࡥࠣࡥࡳࡪࠠࡱࡴ࡬ࡺࡦࡺࡥࠡ࡭ࡨࡽࡸࠦࡡࡳࡧࠣ࡯ࡳࡵࡷ࡯ࠢࡩࡶࡴࡳࠠ࡭ࡱࡱ࡫ࠥࡺࡥࡳ࡯ࠣࡷࡹࡵࡲࡢࡩࡨ࠲࡚ࠥ࡯ࠡࡦࡨࡷࡪࡸࡩࡢ࡮࡬ࡾࡪࠦࡡࠡࡲࡸࡦࡱ࡯ࡣࠡ࡭ࡨࡽࠥ࡬ࡲࡰ࡯ࠣࡥࠥࡺࡲࡢࡰࡶࡱ࡮ࡹࡳࡪࡱࡱࠤࡴࡴࠠࡵࡪࡨࠤ࡬ࡵࡔࡦࡰࡱࡥࠥࡴࡥࡵࡹࡲࡶࡰ࠲ࠠࡴࡧࡨࠤ࠿ࡶࡹ࠻࡯ࡨࡸ࡭ࡀࡠࡱࡷࡥ࡯ࡪࡿ࡟ࡧࡴࡲࡱࡤࡩ࡯࡮ࡲࡵࡩࡸࡹࡥࡥࡢ࠱ࠤ࡙ࡵࠠࡥࡧࡶࡩࡷ࡯ࡡ࡭࡫ࡽࡩࠥࡧࠠࡱࡷࡥࡰ࡮ࡩࠠ࡬ࡧࡼࠤ࠭࡬࡯ࡳࠢࡺ࡬࡮ࡩࡨࠡࡶ࡫ࡩࠥࡶࡲࡪࡸࡤࡸࡪࠦ࡫ࡦࡻࠣ࡭ࡸࠦ࡮ࡰࡶࠣ࡯ࡳࡵࡷ࡯࠮ࠣࡪࡴࡸࠠࡪࡰࡶࡸࡦࡴࡣࡦࠢࡲࡲࡪࠦࡲࡦࡥࡨ࡭ࡻ࡫ࡤࠡࡨࡵࡳࡲࠦࡴࡩࡧࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤࠤࡳ࡫ࡴࡸࡱࡵ࡯࠮ࠦࡳࡦࡧࠣ࠾ࡵࡿ࠺࡮ࡧࡷ࡬࠿ࡦࡤࡦࡵࡨࡶ࡮ࡧ࡬ࡪࡼࡨࡣࡵࡻࡢ࡬ࡧࡼࡤ࠳ࠐࠊࠡࠢࠣࠤ࡙࡮ࡥࠡ࡭ࡨࡽࠥ࡯ࡳࠡ࡮ࡲࡥࡩ࡫ࡤࠡࡣࡶࠤࡦࠦࡰࡳ࡫ࡹࡥࡹ࡫ࠠ࡬ࡧࡼࠤ࡫ࡸ࡯࡮ࠢࡸࡶࡱࡹࡡࡧࡧࠣࡦࡦࡹࡥ࠷࠶࠰ࡩࡳࡩ࡯ࡥࡧࡧࠤࡥࡦࡄࡆࡔࡣࡤࠥ࡬࡯ࡳ࡯ࡤࡸࠥࡧ࡮ࡥࠢࡷ࡬ࡪࠦࡰࡶࡤ࡯࡭ࡨࠦ࡫ࡦࡻࠣࡸ࡭࡫࡮ࠡࡥࡲࡱࡵࡻࡴࡦࡦ࠱ࠎࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡸࡷࠦࡢ࠷࠶ࡶࡸࡷ࡯࡮ࡨ࠼ࠣࡘ࡭࡫ࠠࡴࡧࡵ࡭ࡦࡲࡩࡻࡧࡧࠤࡰ࡫ࡹࡱࡣ࡬ࡶ࠱ࠦࡩ࡯ࠢࡸࡶࡱࡹࡡࡧࡧࠣࡦࡦࡹࡥ࠷࠶࠰ࡩࡳࡩ࡯ࡥࡧࡧࠤࡥࡦࡄࡆࡔࡣࡤࠥ࡫࡮ࡤࡱࡧ࡭ࡳ࡭࠮ࠋࠢࠣࠤࠥࡀࡲࡦࡶࡸࡶࡳࡹࠠࡌࡧࡼࡔࡦ࡯ࡲ࠻ࠢࡗ࡬ࡪࠦ࡬ࡰࡣࡧࡩࡩࠦ࡫ࡦࡻࡳࡥ࡮ࡸ࠮ࠋࠢࠣࠤࠥࠨࠢࠣि")
    bytestring = base64.urlsafe_b64decode(goTenna.util.s2b(l1llll111l_opy_))
    l1llllllll_opy_ = serialization.load_der_private_key(bytestring,
                                                 None,
                                                 backends.default_backend())
    return l11l1111l_opy_(private=l1llllllll_opy_, public=l1llllllll_opy_.public_key())
def l11111111_opy_(l1111ll1l_opy_, l1111l1ll_opy_):
    l1l1l1_opy_ (u"ࠤࠥࠦࠥࡍࡥ࡯ࡧࡵࡥࡹ࡫ࠠࡢࠢࡶ࡬ࡦࡸࡥࡥࠢࡶࡩࡨࡸࡥࡵࠢࡩࡶࡴࡳࠠࡵࡪࡨࠤࡱࡵࡣࡢ࡮ࠣࡥࡳࡪࠠࡧࡱࡵࡩ࡮࡭࡮ࠡ࡭ࡨࡽࡸ࠴ࠊࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡑࡥࡺࡒࡤ࡭ࡷࠦ࡬ࡰࡥࡤࡰࡤࡱࡥࡺࡲࡤ࡭ࡷࡀࠠࡕࡪࡨࠤࡱࡵࡣࡢ࡮ࠣ࡯ࡪࡿࡰࡢ࡫ࡵࠤ࠭ࡶࡲࡪࡸࡤࡸࡪࠦࡡ࡯ࡦࠣࡴࡺࡨ࡬ࡪࡥࠬࠎࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡥࡵࡽࡵࡺ࡯ࡨࡴࡤࡴ࡭ࡿ࠮ࡩࡣࡽࡱࡦࡺ࠮ࡱࡴ࡬ࡱ࡮ࡺࡩࡷࡧࡶ࠲ࡦࡹࡹ࡮࡯ࡨࡸࡷ࡯ࡣ࠯ࡧࡦ࠲ࡊࡲ࡬ࡪࡲࡷ࡭ࡨࡉࡵࡳࡸࡨࡔࡺࡨ࡬ࡪࡥࡎࡩࡾࠦࡦࡰࡴࡨ࡭࡬ࡴ࡟ࡱࡷࡥ࡯ࡪࡿ࠺ࠡࡖ࡫ࡩࠥࡶࡵࡣ࡮࡬ࡧࠥࡱࡥࡺࠢࡩࡳࡷࠦࡴࡩࡧࠣࡳࡹ࡮ࡥࡳࠢࡨࡲࡩࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱࡷࠥࡨࡹࡵࡧࡶ࠾࡚ࠥࡨࡦࠢࡶ࡬ࡦࡸࡥࡥࠢࡶࡩࡨࡸࡥࡵࠢࡤࡷࠥࡧࠠࡣࡻࡷࡩࡸࡺࡲࡪࡰࡪࠎࠥࠦࠠࠡࠤࠥࠦी")
    return l1111ll1l_opy_.private.exchange(ec.ECDH(), l1111l1ll_opy_)
def l11l1l111_opy_(l111ll1ll_opy_, l111l1l1l_opy_):
    l1l1l1_opy_ (u"ࠥࠦࠧࠦࡇࡦࡰࡨࡶࡦࡺࡥࠡࡶ࡫ࡩࠥ࠭ࡰࡶࡤ࡯࡭ࡨࠦ࡫ࡦࡻࠪࠤࡻࡧ࡬ࡶࡧࠣࡪࡴࡸࠠࡢࠢࡪࡶࡴࡻࡰࠡࡷࡶࡩࡩࠦࡦࡰࡴࠣࡩࡳࡩࡲࡺࡲࡷ࡭ࡴࡴࠊࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡨࡹࡵࡧࡶࠤ࡬ࡸ࡯ࡶࡲࡢࡷ࡭ࡧࡲࡦࡦࡢࡷࡪࡩࡲࡦࡶ࠽ࠤ࡙࡮ࡥࠡࡩࡵࡳࡺࡶࠧࡴࠢࡶ࡬ࡦࡸࡥࡥࠢࡶࡩࡨࡸࡥࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡩ࡯ࡶࠣ࡫ࡷࡵࡵࡱࡡࡪ࡭ࡩࡥࡶࡢ࡮࠽ࠤ࡙࡮ࡥࠡࡸࡤࡰࡺ࡫ࠠࡰࡨࠣࡸ࡭࡫ࠠࡨࡴࡲࡹࡵ࠭ࡳࠡࡉࡌࡈࠏࠦࠠࠡࠢࠥࠦࠧु")
    l1llll1l1l_opy_ = hmac.HMAC(l111ll1ll_opy_, _1lll111ll_opy_(), backends.default_backend())
    l1llll1l1l_opy_.update(cryptography.utils.int_to_bytes(l111l1l1l_opy_, 8))
    return l1llll1l1l_opy_.finalize()
def _111ll1l1_opy_(chunk, l1111l1l1_opy_, l11111ll1_opy_,
                 l111l1l11_opy_, counter, l1111l11l_opy_):
    l1l1l1_opy_ (u"ࠦࠧࠨࠠࡄࡴࡼࡴࡹࠦࡡࠡࡵ࡬ࡲ࡬ࡲࡥࠡࡥ࡫ࡹࡳࡱࠠࡰࡨࠣࡨࡦࡺࡡ࠯ࠌࠍࠤࠥࠦࠠࡕࡪ࡬ࡷࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠊࠡࠢࠣࠤ࠲ࠦࡇࡦࡰࡨࡶࡦࡺࡥࡴࠢࡷ࡬ࡪࠦࡡࡱࡲࡵࡳࡵࡸࡩࡢࡶࡨࠤࡸࡿ࡭࡮ࡧࡷࡶ࡮ࡩࠠ࡬ࡧࡼࠤ࡫ࡵࡲࠡࡶ࡫ࡩࠥࡱࡥࡺࠢࡰࡥࡹ࡫ࡲࡪࡣ࡯࠰ࠥ࡯࡮ࡤ࡮ࡸࡨ࡮ࡴࡧࠡࡵࡸࡦࡨࡵࡵ࡯ࡶࡨࡶࠏࠦࠠࠡࠢ࠰ࠤࡽࡵࡲࡴࠢࡷ࡬ࡪࠦࡩ࡯ࡲࡸࡸࠥࡽࡩࡵࡪࠣࡸ࡭࡫ࠠࡴࡻࡰࡱࡪࡺࡲࡪࡥࠣ࡯ࡪࡿࠊࠡࠢࠣࠤ࠲ࠦࡲࡦࡶࡸࡶࡳࡹࠠࡵࡪࡨࠤࡷ࡫ࡳࡶ࡮ࡷࠤࡴ࡬ࠠࡵࡪࡨࠤࡽࡵࡲࠋࠌࠣࠤࠥࠦࡔࡩ࡫ࡶࠤࡼ࡯࡬࡭ࠢࡨࡲࡨࡸࡹࡱࡶࠣࡴࡱࡧࡩ࡯ࡶࡨࡼࡹࠦࡡ࡯ࡦࠣࡨࡪࡩࡲࡺࡲࡷࠤࡨ࡯ࡰࡩࡧࡵࡸࡪࡾࡴ࠯ࠢࡣࡤࡸࡻࡢࡤࡱࡸࡲࡹ࡫ࡲࡡࡢࠣࡷ࡭ࡵࡵ࡭ࡦࠣ࡭ࡳࡩࡲࡦࡣࡶࡩࠥࡽࡩࡵࡪࠣࡩࡻ࡫ࡲࡺࠢࡦ࡬ࡺࡴ࡫ࠡࡣࡶࡷࡴࡩࡩࡢࡶࡨࡨࠥࡽࡩࡵࡪࠣࡸ࡭࡫ࠠࡴࡣࡰࡩࠥࡺࡥࡹࡶ࠯ࠤࡸࡺࡡࡳࡶ࡬ࡲ࡬ࠦࡡࡵࠢࡷ࡬ࡪࠦࡶࡢ࡮ࡸࡩࠥࡵࡦࠡࡢࡣࡧࡴࡻ࡮ࡵࡧࡵࡤࡥ࠴ࠊࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡨࡹࡵࡧࡶࠤࡨ࡮ࡵ࡯࡭࠽ࠤ࡙࡮ࡥࠡࡥ࡫ࡹࡳࡱࠠࡵࡱࠣࡧࡷࡿࡰࡵ࠰ࠣࡗ࡭ࡵࡵ࡭ࡦࠣࡦࡪࠦࡴࡩࡧࠣ࠾ࡵࡿ࠺ࡢࡶࡷࡶ࠿ࡦ࡟ࡔ࡛ࡐࡑࡊ࡚ࡒࡊࡅࡢࡏࡊ࡟࡟ࡔࡋ࡝ࡉࡥࠦ࡬ࡰࡰࡪ࠲ࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡥࡽࡹ࡫ࡳࠡࡵ࡫ࡥࡷ࡫ࡤࡠࡵࡨࡧࡷ࡫ࡴࡠࡤࡼࡸࡪࡹ࠺ࠡࡖ࡫ࡩࠥࡹࡨࡢࡴࡨࡨࠥࡹࡥࡤࡴࡨࡸࠥࡻࡳࡦࡦࠣࡥࡸࠦࡰࡢࡴࡷࠤࡴ࡬ࠠࡵࡪࡨࠤࡰ࡫ࡹࠡ࡯ࡤࡸࡪࡸࡩࡢ࡮࠱ࠎࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡ࡫ࡱࡸࠥࡹࡥ࡯ࡦࡨࡶࡤ࡭ࡩࡥࡡࡹࡥࡱࡀࠠࡕࡪࡨࠤࡻࡧ࡬ࡶࡧࠣࡴࡦࡸࡴࠡࡱࡩࠤࡹ࡮ࡥࠡࡵࡨࡲࡩ࡫ࡲࠡࡉࡌࡈ࠳ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡦࡾࡺࡥࡴࠢࡶࡩࡳࡪࡥࡳࡡࡳࡹࡧࡱࡥࡺࡡࡥࡽࡹ࡫ࡳ࠻ࠢࡗ࡬ࡪࠦࡣࡰ࡯ࡳࡶࡪࡹࡳࡦࡦࠣࡷࡪࡴࡤࡦࡴࠣࡴࡺࡨ࡬ࡪࡥࠣ࡯ࡪࡿ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥ࡯࡮ࡵࠢࡦࡳࡺࡴࡴࡦࡴ࠽ࠤ࡙࡮ࡥࠡࡥࡲࡹࡳࡺࡥࡳࠢࡩࡳࡷࠦࡴࡩࡧࠣࡱࡪࡹࡳࡢࡩࡨ࠲ࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢ࡬ࡲࡹࠦࡳࡶࡤࡦࡳࡺࡴࡴࡦࡴ࠽ࠤ࡙࡮ࡥࠡࡥࡲࡹࡳࡺࡥࡳࠢࡩࡳࡷࠦࡴࡩࡧࠣࡧ࡭ࡻ࡮࡬࠰ࠍࠎࠥࠦࠠࠡ࠼ࡵࡩࡹࡻࡲ࡯ࡵࠣࡦࡾࡺࡥࡴ࠼ࠣࡇࡷࡿࡰࡵࡧࡧࠤࡧࡿࡴࡦࡵ࠱ࠎࠥࠦࠠࠡࠤࠥࠦू")
    if len(chunk) != _11l111l1_opy_:
        raise ValueError(l1l1l1_opy_ (u"ࠧࡉࡨࡶࡰ࡮ࠤࡲࡻࡳࡵࠢࡥࡩࠥࢁࡽࠡ࡮ࡲࡲ࡬࠲ࠠࡪࡵࠣࡿࢂࠨृ")
                         .format(_11l111l1_opy_, len(chunk)))
    l111l_opy_ = cryptography.utils.int_to_bytes(l11111ll1_opy_, 8)
    l11l111ll_opy_ = cryptography.utils.int_to_bytes(counter, 2)
    l11l11l1l_opy_ = cryptography.utils.int_to_bytes(l1111l11l_opy_, 2)
    l1llll11l1_opy_ = (l1111l1l1_opy_ + l111l_opy_ + l111l1l11_opy_
               + l11l111ll_opy_ + l11l11l1l_opy_ + _1ll1lll1l_opy_)
    l1llll1l1l_opy_ = hmac.HMAC(l1111l1l1_opy_, _1lll111ll_opy_(), backends.default_backend())
    l1llll1l1l_opy_.update(l1llll11l1_opy_)
    l11111lll_opy_ = l1llll1l1l_opy_.finalize()
    l1111llll_opy_ = cryptography.utils.int_from_bytes(l11111lll_opy_, l1l1l1_opy_ (u"࠭ࡢࡪࡩࠪॄ"))
    l11l1l11l_opy_ = cryptography.utils.int_from_bytes(chunk, l1l1l1_opy_ (u"ࠧࡣ࡫ࡪࠫॅ"))
    l1ll1ll1ll_opy_ = l1111llll_opy_ ^ l11l1l11l_opy_
    return cryptography.utils.int_to_bytes(l1ll1ll1ll_opy_, _1lll111ll_opy_.digest_size)
def _11l11111_opy_(l1ll1l111l_opy_, l1111l1l1_opy_,
                 l1111lll1_opy_, l1lll11l1l_opy_, counter):
    l1l1l1_opy_ (u"ࠣࠤࠥࠤࡊࡴࡣࡳࡻࡳࡸࠥࡵࡲࠡࡦࡨࡧࡷࡿࡰࡵࠢࡤࠤࡸ࡫ࡱࡶࡧࡱࡧࡪࠦ࡯ࡧࠢࡥࡽࡹ࡫ࡳ࠯ࠌࠍࠤࠥࠦࠠࡕࡪ࡬ࡷࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡪࡵࠣࡸ࡭࡫ࠠࡨࡧࡱࡩࡷࡧ࡬ࡪࡼࡨࡨࠥࡻ࡮ࡥࡧࡵࡴ࡮ࡴ࡮ࡪࡰࡪࠤࡴ࡬ࠠࡵࡪࡨࠤ࡬ࡵࡔࡦࡰࡱࡥࠥࡩࡩࡱࡪࡨࡶࠥࡹࡣࡩࡧࡰࡩ࠳ࠦࡗࡩࡧࡱࠤ࡬࡯ࡶࡦࡰࠣࡥࠥࡶࡲࡰࡲࡨࡶࠥࡹࡨࡢࡴࡨࡨࠥࡹࡥࡤࡴࡨࡸ࠱ࠦ࡬ࡰࡥࡤࡰࠥࡱࡥࡺࠢࡰࡥࡹ࡫ࡲࡪࡣ࡯࠰ࠥࡧࡤࡥࡴࡨࡷࡸ࡫ࡳ࠭ࠢࡤࡲࡩࠦࡣࡰࡷࡱࡸࡪࡸࠠࡪࡶࠣࡻ࡮ࡲ࡬ࠡࡦࡨࡧࡷࡿࡰࡵࠢࡦ࡭ࡵ࡮ࡥࡳࡶࡨࡼࡹࠦ࡯ࡳࠢࡨࡲࡨࡸࡹࡱࡶࠣࡴࡱࡧࡩ࡯ࡶࡨࡼࡹࠦࠨࡵࡪࡨࠤ࡫ࡻ࡮ࡥࡣࡰࡩࡳࡺࡡ࡭ࠢࡲࡴࡪࡸࡡࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡺࡲࡶ࡮ࡴࡧࠡࡣࠣࡦࡾࡺࡥࡴࡶࡵࡩࡦࡳࠠࡸ࡫ࡷ࡬ࠥࡧࠠ࡬ࡧࡼ࠰ࠥࡹ࡯ࠡࡣࡶࠤࡱࡵ࡮ࡨࠢࡤࡷࠥࡺࡨࡦࠢ࡮ࡩࡾࠦࡩࡴࠢࡷ࡬ࡪࠦࡳࡢ࡯ࡨࠤࡾࡵࡵࠡࡧࡱࡨࠥࡻࡰࠡࡨ࡯࡭ࡵࡶࡩ࡯ࡩࠣࡦࡪࡺࡷࡦࡧࡱࠤࡨ࡯ࡰࡩࡧࡵࡸࡪࡾࡴࠡࡣࡱࡨࠥࡶ࡬ࡢ࡫ࡱࡸࡪࡾࡴࠪ࠰ࠍࠎࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡤࡼࡸࡪࡹ࡬ࡪ࡭ࡨࠤࡧࡿࡴࡦࡵࡢࡸࡴࡥࡣࡳࡻࡳࡸ࠿ࠦࡔࡩࡧࠣࡦࡾࡺࡥࡴࠢࡷࡳࠥࡧࡰࡱ࡮ࡼࠤࡹ࡮ࡥࠡࡱࡳࡩࡷࡧࡴࡪࡱࡱࡷࠥࡺ࡯ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡨࡹࡵࡧࡶࡰ࡮ࡱࡥࠡࡵ࡫ࡥࡷ࡫ࡤࡠࡵࡨࡧࡷ࡫ࡴࡠࡤࡼࡸࡪࡹ࠺ࠡࡖ࡫ࡩࠥࡨࡹࡵࡧࡶࠤࡴ࡬ࠠࡵࡪࡨࠤࡸ࡮ࡡࡳࡧࡧࠤࡸ࡫ࡣࡳࡧࡷࠤ࡬࡫࡮ࡦࡴࡤࡸࡪࡪࠠࡣࡻࠣࡸ࡭࡫ࠠ࡭ࡱࡦࡥࡱࠦࡰࡳ࡫ࡹࡥࡹ࡫ࠠ࡬ࡧࡼࠤࡦࡴࡤࠡࡶ࡫ࡩࠥࡸࡥ࡮ࡱࡷࡩࠥࡶࡵࡣ࡮࡬ࡧࠥࡱࡥࡺࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡧࡰࡖࡨࡲࡳࡧ࠮ࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡍࡉࠦࡳࡦࡰࡧࡩࡷࡥࡧࡪࡦ࠽ࠤ࡙࡮ࡥࠡࡵࡨࡲࡩ࡫ࡲࠡࡉࡌࡈࠥࡼࡡ࡭ࡷࡨࠤ࠭ࡧࡳࠡࡣࡱࠤ࡮ࡴࡴࠪࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡣࡳࡻࡳࡸࡴ࡭ࡲࡢࡲ࡫ࡽ࠳࡮ࡡࡻ࡯ࡤࡸ࠳ࡶࡲࡪ࡯࡬ࡸ࡮ࡼࡥࡴ࠰ࡤࡷࡾࡳ࡭ࡦࡶࡵ࡭ࡨ࠴ࡥࡤ࠰ࡈࡰࡱ࡯ࡰࡵ࡫ࡦࡇࡺࡸࡶࡦࡒࡸࡦࡱ࡯ࡣࡌࡧࡼࠤࡸ࡫࡮ࡥࡧࡵࡣࡵࡻࡢ࡬ࡧࡼ࠾࡚ࠥࡨࡦࠢࡳࡹࡧࡲࡩࡤࠢ࡮ࡩࡾࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡳࡦࡰࡧࡩࡷࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣ࡭ࡳࡺࠠࡤࡱࡸࡲࡹ࡫ࡲ࠻ࠢࡗ࡬ࡪࠦࡧ࡭ࡱࡥࡥࡱࠦࡣࡰࡷࡱࡸࡪࡸࠬࠡࡹ࡫࡭ࡨ࡮ࠠࡪࡵࠣࡹࡸ࡫ࡤࠡࡣࡶࠤࡹ࡮ࡥࠡࡵࡷࡥࡷࡺࡩ࡯ࡩࠣࡴࡴ࡯࡮ࡵࠢࡩࡳࡷࠦࡴࡩࡧࠣࡌࡒࡇࡃࠡࡥࡲࡹࡳࡺࡥࡳ࠮ࠣࡸࡴࠦࡤࡰࠢࡶࡸࡦࡸࡴࠡࡶ࡫ࡩࠥࡨ࡬ࡰࡥ࡮ࠤࡨ࡯ࡰࡩࡧࡵࠤࡼ࡯ࡴࡩࠌࠣࠤࠥࠦࠢࠣࠤॆ")
    def l1111l11l_opy_(l1lll111l1_opy_):
        sc = l1lll111l1_opy_
        while True:
            yield sc
            sc += 1
            if sc > 65535:
                sc = 0
    chunks = goTenna.util.l1ll1lll1_opy_(goTenna.util.l1111l1l_opy_(l1ll1l111l_opy_,
                                                    _11l111l1_opy_,
                                                    six.b(l1l1l1_opy_ (u"ࠩ࠳ࠫे"))[0]),
                               l1111l11l_opy_(counter))
    gid_val = l1111lll1_opy_.gid_val
    l1lll1l111_opy_ = itertools.chain.from_iterable([
        _111ll1l1_opy_(goTenna.util.l1ll1111l_opy_(chunk[0]),
                     l1111l1l1_opy_, gid_val,
                     l1lll11l1l_opy_, counter, chunk[1])
        for chunk in chunks])
    content = list(l1lll1l111_opy_)[:len(l1ll1l111l_opy_)]
    return  goTenna.util.l1ll1111l_opy_(content)
def l11l11ll1_opy_(l1lll1ll11_opy_, shared_secret, l1111ll11_opy_,
                  l111lll1l_opy_, l1ll1lll11_opy_):
    l1l1l1_opy_ (u"ࠥࠦࠧࠦࡅ࡯ࡥࡵࡽࡵࡺࠠࡢࠢࡥࡽࡹ࡫ࡳࡵࡴ࡬ࡲ࡬ࠦࡦࡰࡴࠣࡸࡷࡧ࡮ࡴ࡯࡬ࡷࡸ࡯࡯࡯࠰ࠍࠎࠥࠦࠠࠡࡖ࡫࡭ࡸࠦࡥ࡯ࡥࡵࡽࡵࡺࡩࡰࡰࠣࡹࡸ࡫ࡳࠡࡶ࡫ࡩࠥࡲ࡯ࡤࡣ࡯ࠤࡵࡻࡢ࡭࡫ࡦࠤࡰ࡫ࡹ࠭ࠢ࡯ࡳࡨࡧ࡬ࠡࡉࡌࡈ࠱ࠦࡳࡩࡣࡵࡩࡩࠦࡳࡦࡥࡵࡩࡹࠦࠨࡦ࡫ࡷ࡬ࡪࡸࠠࡢࠢࡪࡶࡴࡻࡰࠡࡵ࡫ࡥࡷ࡫ࡤࠡࡵࡨࡧࡷ࡫ࡴࠡࡱࡵࠤࡦࠦࡶࡢ࡮ࡸࡩࠥࡪࡥࡳ࡫ࡹࡩࡩࠦࡦࡳࡱࡰࠤࡰ࡫ࡹࠡࡧࡻࡧ࡭ࡧ࡮ࡨࡧࠣࡦࡪࡺࡷࡦࡧࡱࠤࡹࡽ࡯ࠡࡇࡆࠤࡰ࡫ࡹࡴࠫ࠯ࠤࡦࡴࡤࠡ࡯ࡨࡷࡸࡧࡧࡦࠢࡦࡳࡺࡴࡴࡦࡴࠣࡸࡴࠦࡥ࡯ࡥࡵࡽࡵࡺࠠࡵࡪࡨࠤࡲ࡫ࡳࡴࡣࡪࡩ࠳ࠐࠊࠡࠢࠣࠤࡌ࡯ࡶࡦࡰࠣࡱࡾࡥࡰࡶࡤ࡮ࡩࡾ࠲ࠠ࡮ࡻࡢ࡫࡮ࡪࠬࠡࡵ࡫ࡥࡷ࡫ࡤࡠࡵࡨࡧࡷ࡫ࡴ࠭ࠢࡤࡲࡩࠦ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡤࡱࡸࡲࡹ࡫ࡲࠡ࠼ࡳࡽ࠿ࡳࡥࡵࡪ࠽ࡤࡪࡴࡣࡳࡻࡳࡸࡤࡨࡹࡵࡧࡶࡤࠥࡧ࡮ࡥࠢ࠽ࡴࡾࡀ࡭ࡦࡶ࡫࠾ࡥࡪࡥࡤࡴࡼࡴࡹࡥࡢࡺࡶࡨࡷࡥࠦࡡࡳࡧࠣࡩࡦࡩࡨࠡࡱࡷ࡬ࡪࡸࡳࠡࡦࡸࡥࡱࡹࠬࠡࡵࡲࠤࡹ࡮ࡥࠡࡨࡲࡰࡱࡵࡷࡪࡰࡪࠤࡸࡴࡩࡱࡲࡨࡸࠥࡹࡨࡰࡷ࡯ࡨࠥ࡮࡯࡭ࡦ࠽ࠎࠏࠦࠠࠡࠢ࠱࠲ࠥࡩ࡯ࡥࡧ࠰ࡦࡱࡵࡣ࡬࠼࠽ࠤࡵࡿࡴࡩࡱࡱࠎࠥࠦࠠࠡࠢࠣࡱࡪࡹࡳࡢࡩࡨࠤࡂࠦࠢࡉࡧ࡯ࡰࡴ࠲ࠠࡸࡱࡵࡰࡩࠧࠢࠋࠢࠣࠤࠥࠦࠠࡦࡰࡦࡶࡾࡶࡴࡦࡦࠣࡁࠥ࡫࡮ࡤࡴࡼࡴࡹࡥࡢࡺࡶࡨࡷ࠭ࡳࡥࡴࡵࡤ࡫ࡪ࠲ࠠࡴࡪࡤࡶࡪࡪ࡟ࡴࡧࡦࡶࡪࡺࠬࠡ࡯ࡼࡣ࡬࡯ࡤ࠭ࠢࡰࡽࡤࡶࡵࡣ࡭ࡨࡽ࠱ࠦ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡤࡱࡸࡲࡹ࡫ࡲࠪࠌࠣࠤࠥࠦࠠࠡࡦࡨࡧࡷࡿࡰࡵࡧࡧࠤࡂࠦࡤࡦࡥࡵࡽࡵࡺ࡟ࡣࡻࡷࡩࡸ࠮ࡥ࡯ࡥࡵࡽࡵࡺࡥࡥ࠮ࠣࡷ࡭ࡧࡲࡦࡦࡢࡷࡪࡩࡲࡦࡶ࠯ࠤࡲࡿ࡟ࡨ࡫ࡧ࠰ࠥࡳࡹࡠࡲࡸࡦࡰ࡫ࡹ࠭ࠢࡰࡩࡸࡹࡡࡨࡧࡢࡧࡴࡻ࡮ࡵࡧࡵ࠭ࠏࠦࠠࠡࠢࠣࠤࡦࡹࡳࡦࡴࡷࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡃ࠽ࠡࡦࡨࡧࡷࡿࡰࡵࡧࡧࠤࠨࠦࡐࡢࡵࡶࡩࡸࠐࠊࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡨࡹࡵࡧࡶࠤࡵࡲࡡࡪࡰࡷࡩࡽࡺ࠺ࠡࡖ࡫ࡩࠥࡶ࡬ࡢ࡫ࡱࡸࡪࡾࡴࠡࡶࡲࠤࡪࡴࡣࡳࡻࡳࡸ࠳ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡦࡾࡺࡥࡴࠢࡶ࡬ࡦࡸࡥࡥࡡࡶࡩࡨࡸࡥࡵ࠼ࠣࡘ࡭࡫ࠠࡴࡪࡤࡶࡪࡪࠠࡴࡧࡦࡶࡪࡺࠊࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡋࡇࠤࡲࡿ࡟ࡨ࡫ࡧ࠾࡚ࠥࡨࡦࠢ࡯ࡳࡨࡧ࡬ࠡࡉࡌࡈࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡥࡽࡹ࡫ࡳࠡ࡯ࡼࡣࡵࡻࡢ࡬ࡧࡼ࠾࡚ࠥࡨࡦࠢ࡯ࡳࡨࡧ࡬ࠡࡲࡸࡦࡱ࡯ࡣࠡ࡭ࡨࡽࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢ࡬ࡲࡹࠦ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡤࡱࡸࡲࡹ࡫ࡲ࠻ࠢࡗ࡬ࡪࠦࡥ࡯ࡥࡵࡽࡵࡺࡩࡰࡰࡢࡧࡴࡻ࡮ࡵࡧࡵࠤࡺࡹࡥࡥࠢࡩࡳࡷࠦࡴࡩ࡫ࡶࠤࡲ࡫ࡳࡴࡣࡪࡩ࠳ࠐࠠࠡࠢࠣࠦࠧࠨै")
    return _11l11111_opy_(l1lll1ll11_opy_, shared_secret, l1111ll11_opy_, l111lll1l_opy_,
                        l1ll1lll11_opy_)
def l111l111l_opy_(l1lll11l11_opy_, shared_secret, l111lll11_opy_,
                  l1llllll11_opy_, l1ll1lll11_opy_):
    l1l1l1_opy_ (u"ࠦࠧࠨࠠࡅࡧࡦࡶࡾࡶࡴࠡࡣࠣࡦࡾࡺࡥࡴࡶࡵ࡭ࡳ࡭ࠠࡧࡴࡲࡱࠥࡺࡲࡢࡰࡶࡱ࡮ࡹࡳࡪࡱࡱ࠲ࠏࠐࠠࠡࠢࠣࡘ࡭࡯ࡳࠡࡦࡨࡧࡷࡿࡰࡵ࡫ࡲࡲࠥࡻࡳࡦࡵࠣࡸ࡭࡫ࠠࡳࡧࡰࡳࡹ࡫ࠠࡱࡷࡥࡰ࡮ࡩࠠ࡬ࡧࡼ࠰ࠥࡸࡥ࡮ࡱࡷࡩࠥࡍࡉࡅ࠮ࠣࡷ࡭ࡧࡲࡦࡦࠣࡷࡪࡩࡲࡦࡶࠣࠬࡪ࡯ࡴࡩࡧࡵࠤࡦࠦࡧࡳࡱࡸࡴࠥࡹࡨࡢࡴࡨࡨࠥࡹࡥࡤࡴࡨࡸࠥࡵࡲࠡࡣࠣࡺࡦࡲࡵࡦࠢࡧࡩࡷ࡯ࡶࡦࡦࠣࡪࡷࡵ࡭ࠡ࡭ࡨࡽࠥ࡫ࡸࡤࡪࡤࡲ࡬࡫ࠠࡣࡧࡷࡻࡪ࡫࡮ࠡࡶࡺࡳࠥࡋࡃࠡ࡭ࡨࡽࡸ࠯ࠬࠡࡣࡱࡨࠥࡳࡥࡴࡵࡤ࡫ࡪࠦࡣࡰࡷࡱࡸࡪࡸࠠࡵࡱࠣࡩࡳࡩࡲࡺࡲࡷࠤࡹ࡮ࡥࠡ࡯ࡨࡷࡸࡧࡧࡦ࠰ࠍࠎࠥࠦࠠࠡࠢࡊ࡭ࡻ࡫࡮ࠡ࡯ࡼࡣࡵࡻࡢ࡬ࡧࡼ࠰ࠥࡳࡹࡠࡩ࡬ࡨ࠱ࠦࡳࡩࡣࡵࡩࡩࡥࡳࡦࡥࡵࡩࡹ࠲ࠠࡢࡰࡧࠤࡲ࡫ࡳࡴࡣࡪࡩࡤࡩ࡯ࡶࡰࡷࡩࡷࠦ࠺ࡱࡻ࠽ࡱࡪࡺࡨ࠻ࡢࡨࡲࡨࡸࡹࡱࡶࡢࡦࡾࡺࡥࡴࡢࠣࡥࡳࡪࠠ࠻ࡲࡼ࠾ࡲ࡫ࡴࡩ࠼ࡣࡨࡪࡩࡲࡺࡲࡷࡣࡧࡿࡴࡦࡵࡣࠤࡦࡸࡥࠡࡧࡤࡧ࡭ࠦ࡯ࡵࡪࡨࡶࡸࠦࡤࡶࡣ࡯ࡷ࠱ࠦࡳࡰࠢࡷ࡬ࡪࠦࡦࡰ࡮࡯ࡳࡼ࡯࡮ࡨࠢࡶࡲ࡮ࡶࡰࡦࡶࠣࡷ࡭ࡵࡵ࡭ࡦࠣ࡬ࡴࡲࡤ࠻ࠌࠍࠤࠥࠦࠠࠡ࠰࠱ࠤࡨࡵࡤࡦ࠯ࡥࡰࡴࡩ࡫࠻࠼ࠣࡴࡾࡺࡨࡰࡰࠍࠤࠥࠦࠠࠡࠢࠣࡱࡪࡹࡳࡢࡩࡨࠤࡂࠦࠢࡉࡧ࡯ࡰࡴ࠲ࠠࡸࡱࡵࡰࡩࠧࠢࠋࠢࠣࠤࠥࠦࠠࠡࡧࡱࡧࡷࡿࡰࡵࡧࡧࠤࡂࠦࡥ࡯ࡥࡵࡽࡵࡺ࡟ࡣࡻࡷࡩࡸ࠮࡭ࡦࡵࡶࡥ࡬࡫ࠬࠡࡵ࡫ࡥࡷ࡫ࡤࡠࡵࡨࡧࡷ࡫ࡴ࠭ࠢࡰࡽࡤ࡭ࡩࡥ࠮ࠣࡱࡾࡥࡰࡶࡤ࡮ࡩࡾ࠲ࠠ࡮ࡧࡶࡷࡦ࡭ࡥࡠࡥࡲࡹࡳࡺࡥࡳࠫࠍࠤࠥࠦࠠࠡࠢࠣࡨࡪࡩࡲࡺࡲࡷࡩࡩࠦ࠽ࠡࡦࡨࡧࡷࡿࡰࡵࡡࡥࡽࡹ࡫ࡳࠩࡧࡱࡧࡷࡿࡰࡵࡧࡧ࠰ࠥࡹࡨࡢࡴࡨࡨࡤࡹࡥࡤࡴࡨࡸ࠱ࠦ࡭ࡺࡡࡪ࡭ࡩ࠲ࠠ࡮ࡻࡢࡴࡺࡨ࡫ࡦࡻ࠯ࠤࡲ࡫ࡳࡴࡣࡪࡩࡤࡩ࡯ࡶࡰࡷࡩࡷ࠯ࠊࠡࠢࠣࠤࠥࠦࠠࡢࡵࡶࡩࡷࡺࠠ࡮ࡧࡶࡷࡦ࡭ࡥࠡ࠿ࡀࠤࡩ࡫ࡣࡳࡻࡳࡸࡪࡪࠠࠤࠢࡓࡥࡸࡹࡥࡴࠌࠍࠎࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡤࡼࡸࡪࡹࠠࡱ࡮ࡤ࡭ࡳࡺࡥࡹࡶ࠽ࠤ࡙࡮ࡥࠡࡲ࡯ࡥ࡮ࡴࡴࡦࡺࡷࠤࡹࡵࠠࡦࡰࡦࡶࡾࡶࡴ࠯ࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡢࡺࡶࡨࡷࠥࡹࡨࡢࡴࡨࡨࡤࡹࡥࡤࡴࡨࡸ࠿ࠦࡔࡩࡧࠣࡷ࡭ࡧࡲࡦࡦࠣࡷࡪࡩࡲࡦࡶࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡨࡱࡗࡩࡳࡴࡡ࠯ࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡎࡊࠠ࡮ࡻࡢ࡫࡮ࡪ࠺ࠡࡖ࡫ࡩࠥࡸࡥ࡮ࡱࡷࡩࠥࡍࡉࡅࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡢࡺࡶࡨࡷࠥࡳࡹࡠࡲࡸࡦࡰ࡫ࡹ࠻ࠢࡗ࡬ࡪࠦࡲࡦ࡯ࡲࡸࡪࠦࡰࡶࡤ࡯࡭ࡨࠦ࡫ࡦࡻࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡪࡰࡷࠤࡲ࡫ࡳࡴࡣࡪࡩࡤࡩ࡯ࡶࡰࡷࡩࡷࡀࠠࡕࡪࡨࠤࡪࡴࡣࡳࡻࡳࡸ࡮ࡵ࡮ࠡࡷࡶࡩࡩࠦࡦࡰࡴࠣࡸ࡭࡯ࡳࠡ࡯ࡨࡷࡸࡧࡧࡦ࠰ࠍࠤࠥࠦࠠࠣࠤࠥॉ")
    return _11l11111_opy_(l1lll11l11_opy_, shared_secret, l111lll11_opy_, l1llllll11_opy_,
                        l1ll1lll11_opy_)
def sdk_token_valid(sdk_token):
    #
    #
    #
    #
    def _1lllll1ll_opy_(magic):
        try:
            l1lllll1l1_opy_ = goTenna.util.ensure_bytes(sdk_token)
            l1lll1l11l_opy_ = base64.urlsafe_b64decode(l1lllll1l1_opy_)
            if len(l1lll1l11l_opy_) != 48:
                raise ValueError
            l1lll1llll_opy_ = cryptography.utils.int_from_bytes(l1lll1l11l_opy_, l1l1l1_opy_ (u"ࠬࡨࡩࡨࠩॊ"))
        except Exception: # pylint: disable=broad-except
            return None
        l1llll1ll1_opy_ = cryptography.utils.int_from_bytes(magic, l1l1l1_opy_ (u"࠭ࡢࡪࡩࠪो"))
        l1ll1l1l11_opy_ = l1lll1llll_opy_ ^ l1llll1ll1_opy_
        l1ll1ll11l_opy_ = cryptography.utils.int_to_bytes(l1ll1l1l11_opy_, 48)
        level = l1ll1ll11l_opy_[20:24]
        l1ll1_opy_ = int(l1ll1ll11l_opy_[24:28], 16)
        if level == six.b(l1l1l1_opy_ (u"ࠧ࠸࠻࠺࠼ࠬौ")):
            return (goTenna.constants.SDKLevels.SUPER, l1ll1_opy_)
        elif level == six.b(l1l1l1_opy_ (u"ࠨ࠵ࡨ࠻࠺्࠭")):
            return (goTenna.constants.SDKLevels.NORMAL, l1ll1_opy_)
        else:
            return None
    _1ll1l11l1_opy_ = six.b(l1l1l1_opy_ (u"ࠩ࠴ࡺ࠶ࡪࡡ࠵࡬࠻࠷࠾࠹࠱࠱ࡤࡲ࡬ࡩ࡬ࡧ࡮࠹࡭ࡵ࠼࠼࡯࠸ࡶ࠹࠷ࡩࡷࡳ࡫࡯࠶࠻ࡸ࠶ࡶ࠱ࡷࡦࡷ࠵ࡪ࡮ࡳࠩॎ"))
    if _1lllll1ll_opy_(_1ll1l11l1_opy_[::-1]) is None:
        raise ValueError(l1l1l1_opy_ (u"ࠥࡆࡦࡪࠠࡔࡆࡎࠤࡰ࡫ࡹࠡࡽࢀࠦॏ").format(sdk_token))
    return _1lllll1ll_opy_
class l1ll1ll1l1_opy_(object):
    l1l1l1_opy_ (u"ࠦࠧࠨࠠࡔࡶࡤࡸࡪ࡬ࡵ࡭ࠢࡶࡸࡴࡸࡡࡨࡧࠣࡥࡳࡪࠠࡤࡱࡱࡸࡪࡾࡴࠡࡪࡤࡲࡩࡲࡩ࡯ࡩࠣࡪࡴࡸࠠ࡮ࡧࡶࡷࡦ࡭ࡥࠡࡧࡱࡧࡷࡿࡰࡵ࡫ࡲࡲ࠳ࠐࠊࠡࠢࠣࠤ࡙࡮ࡥࠡࡧࡱࡧࡷࡿࡰࡵ࡫ࡲࡲࠥࡳࡡ࡯ࡣࡪࡩࡷࠦࡨࡰ࡮ࡧࡷࠥࡱ࡮ࡰࡹ࡯ࡩࡩ࡭ࡥࠡࡱࡩࠤࡹ࡮ࡥࠡ࡮ࡲࡧࡦࡲࠠࡨ࡫ࡧࠤࡦࡴࡤࠡࡧࡱࡧࡷࡿࡴࡱ࡫ࡲࡲ࠲ࡸࡥ࡭ࡧࡹࡥࡳࡺࠠࡱࡣࡵࡸࡸࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡳࡵࡱࡵࡩࡩࠦࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࠢࡌࡸࠥࡪࡥࡵࡧࡵࡱ࡮ࡴࡥࡴࠢࡺ࡬ࡪࡺࡨࡦࡴࠣ࡯ࡪࡿࠠࡦࡺࡦ࡬ࡦࡴࡧࡦࠢࡰࡹࡸࡺࠠࡣࡧࠣࡨࡴࡴࡥ࠭ࠢ࡬ࡷࠥࡺࡨࡦࠢࡳࡰࡦࡩࡥࠡࡶࡲࠤࡱࡵࡡࡥࠢ࡮ࡩࡾࡹࠠࡪࡰࡷࡳ࠱ࠦࡡ࡯ࡦࠣࡴࡷࡵࡶࡪࡦࡨࡷࠥ࡫࡮ࡤࡴࡼࡴࡹ࡯࡯࡯ࠢࡤࡲࡩࠦࡤࡦࡥࡵࡽࡵࡺࡩࡰࡰࠣ࡬ࡴࡵ࡫ࡴࠢࡩࡳࡷࠦ࡭ࡦࡵࡶࡥ࡬࡫ࡳ࠯ࠌࠣࠤࠥࠦࠢࠣࠤॐ")
    l111l1lll_opy_ = 128
    def __init__(self, storage, gid):
        l1l1l1_opy_ (u"ࠧࠨࠢࠡࡄࡸ࡭ࡱࡪࠠࡵࡪࡨࠤࡪࡴࡣࡳࡻࡳࡸ࡮ࡵ࡮ࠡ࡯ࡤࡲࡦ࡭ࡥࡳ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡳࡵࡱࡵࡥ࡬࡫࠮ࡔࡶࡲࡶࡦ࡭ࡥࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡷࡹࡵࡲࡢࡩࡨ࠾ࠥࡇ࡮ࠡ࡫ࡱ࡭ࡹ࡯ࡡ࡭࡫ࡽࡩࡩࠦࡳࡵࡱࡵࡥ࡬࡫ࠠࡪࡰࡷࡩࡷ࡬ࡡࡤࡧ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡌࡈࠥ࡭ࡩࡥ࠼ࠣࡘ࡭࡫ࠠ࡭ࡱࡦࡥࡱࠦࡇࡊࡆ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣ॑")
        self._storage = storage
        self._gid = gid
        self._storage.load(self._gid)
        if not self._storage.local_key:
            self._1lll11lll_opy_ = l1ll1llll1_opy_()
            self._storage.local_key = l1lll1l1ll_opy_(self._1lll11lll_opy_)
            self._storage.store()
        else:
            self._1lll11lll_opy_ = l111l11ll_opy_(self._storage.local_key)
    @property
    def l1ll1l1lll_opy_(self):
        l1l1l1_opy_ (u"ࠨࠢࠣࠢࡊࡩࡹࠦࡴࡩࡧࠣࡰࡴࡩࡡ࡭ࠢࡳࡹࡧࡲࡩࡤࠢ࡮ࡩࡾࠦࡩ࡯ࠢࡦࡳࡲࡶࡲࡦࡵࡶࡩࡩࠦࡦࡰࡴࡰࠤ࡫ࡵࡲࠡࡵࡨࡲࡩ࡯࡮ࡨࠢࡹ࡭ࡦࠦࡴࡩࡧࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤࠤࡳ࡫ࡴࡸࡱࡵ࡯࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤ॒ࠥ")
        return l111llll1_opy_(self._1lll11lll_opy_.public)
    def l111l11l1_opy_(self, l1lllll1l_opy_):
        l1l1l1_opy_ (u"ࠢࠣࠤࠣࡇ࡭࡫ࡣ࡬ࠢࡺ࡬ࡪࡺࡨࡦࡴࠣ࡯ࡪࡿࠠࡦࡺࡦ࡬ࡦࡴࡧࡦࠢ࡬ࡷࠥࡴࡥࡦࡦࡨࡨࠥ࡬࡯ࡳࠢࡷ࡬ࡪࠦࡤࡦࡵࡷ࡭ࡳࡧࡴࡪࡱࡱ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡨࡱࡗࡩࡳࡴࡡ࠯ࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡎࡊࠠࡥࡧࡶࡸ࠿ࠦࡁࠡࡲࡵ࡭ࡻࡧࡴࡦࠢࡊࡍࡉࠦࡴࡰࠢࡦ࡬ࡪࡩ࡫࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲࡸࠦࡢࡰࡱ࡯࠾ࠥࡦࡠࡕࡴࡸࡩࡥࡦࠠࡪࡨࠣ࡯ࡪࡿࠠࡦࡺࡦ࡬ࡦࡴࡧࡦࠢࡰࡹࡸࡺࠠࡣࡧࠣࡨࡴࡴࡥ࠼ࠢࡣࡤࡋࡧ࡬ࡴࡧࡣࡤࠥࡵࡴࡩࡧࡵࡻ࡮ࡹࡥ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨ॓")
        return l1lllll1l_opy_ not in self._storage.link_pubkeys
    def add_group(self, group):
        l1l1l1_opy_ (u"ࠣࠤࠥࠤࡆࡪࡤࠡࡣࠣ࡫ࡷࡵࡵࡱࠢࡷࡳࠥࡶࡥࡳࡵ࡬ࡷࡹ࡫࡮ࡵࠢࡶࡸࡴࡸࡡࡨࡧ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࡉࡧࠢࡤࠤ࡬ࡸ࡯ࡶࡲࠣࡻ࡮ࡺࡨࠡࡶ࡫ࡩࠥࡹࡡ࡮ࡧࠣࡋࡎࡊࠠࡪࡵࠣࡥࡱࡸࡥࡢࡦࡼࠤࡵࡸࡥࡴࡧࡱࡸ࠱ࠦࡩࡵࠢࡺ࡭ࡱࡲࠠࡣࡧࠣࡳࡻ࡫ࡲࡸࡴ࡬ࡸࡹ࡫࡮ࠡࡹ࡬ࡸ࡭ࠦࡴࡩ࡫ࡶࠤ࡬ࡸ࡯ࡶࡲ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡧࡰࡖࡨࡲࡳࡧ࠮ࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡶࡴࡻࡰࠡࡩࡵࡳࡺࡶ࠺ࠡࡖ࡫ࡩࠥ࡭ࡲࡰࡷࡳࠤࡹࡵࠠࡢࡦࡧ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤ॔")
        self._storage.groups[group.gid] = group
        self._storage.store()
    def remove_group(self, group):
        l1l1l1_opy_ (u"ࠤࠥࠦࠥࡘࡥ࡮ࡱࡹࡩࠥࡧࠠࡨࡴࡲࡹࡵࠦࡦࡳࡱࡰࠤࡵ࡫ࡲࡴ࡫ࡶࡸࡪࡴࡴࠡࡵࡷࡳࡷࡧࡧࡦ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡏࡦࠡࡶ࡫ࡩࠥ࡭ࡲࡰࡷࡳࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࠠࡵࡪࡨࠤࡵ࡫ࡲࡴ࡫ࡶࡸࡪࡴࡴࠡࡵࡷࡳࡷࡧࡧࡦ࠮ࠣࡸ࡭࡯ࡳࠡ࡫ࡱࡺࡴࡩࡡࡵ࡫ࡲࡲࠥࡪ࡯ࡦࡵࠣࡲࡴࡺࡨࡪࡰࡪ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡨࡱࡗࡩࡳࡴࡡ࠯ࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡷࡵࡵࡱࠢࡪࡶࡴࡻࡰ࠻ࠢࡗ࡬ࡪࠦࡧࡳࡱࡸࡴࠥࡺ࡯ࠡࡣࡧࡨ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥॕ")
        if group.gid in self._storage.groups:
            del self._storage.groups[group.gid]
            self._storage.store()
    def l1ll1l1ll1_opy_(self, l11l11lll_opy_, l1lll1lll1_opy_):
        l1l1l1_opy_ (u"ࠥࠦࠧࠦࡁࡥࡦࠣࡥࠥࡵ࡮ࡦ࠯ࡷࡳ࠲ࡵ࡮ࡦࠢ࡯࡭ࡳࡱࠠࡵࡱࠣࡴࡪࡸࡳࡪࡵࡷࡩࡳࡺࠠࡴࡶࡲࡶࡦ࡭ࡥ࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤࡎ࡬ࠠࡵࡪࡨࠤࡴࡺࡨࡦࡴࠣࡋࡎࡊࠠࡪࡵࠣࡥࡱࡸࡥࡢࡦࡼࠤ࡮ࡴࠠࡵࡪࡨࠤࡱ࡯࡮࡬ࡵ࠯ࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡨࡥࠡࡱࡹࡩࡷࡽࡲࡪࡶࡷࡩࡳࠦࡷࡪࡶ࡫ࠤࡹ࡮ࡥࠡࡰࡨࡻࠥࡶࡵࡣ࡮࡬ࡧࠥࡱࡥࡺ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡌࡈࠥࡵࡴࡩࡧࡵࡣ࡬࡯ࡤ࠻ࠢࡗ࡬ࡪࠦࡇࡊࡆࠣࡳ࡫ࠦࡴࡩࡧࠣࡳࡹ࡮ࡥࡳࠢࡶ࡭ࡩ࡫ࠠࡰࡨࠣࡸ࡭࡫ࠠ࡭࡫ࡱ࡯࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡣࡻࡷࡩࡸࠦࡰࡶࡤ࡮ࡩࡾࡀࠠࡕࡪࡨࠤࡨࡵ࡭ࡱࡴࡨࡷࡸ࡫ࡤࠡࡴࡨࡱࡴࡺࡥࠡࡲࡸࡦࡱ࡯ࡣࠡ࡭ࡨࡽࠥࡨࡹࡵࡧࡶ࠰ࠥࡧࡳࠡࡴࡨࡧࡪ࡯ࡶࡦࡦࠣࡪࡷࡵ࡭ࠡࡶ࡫ࡩࠥ࡭࡯ࡕࡧࡱࡲࡦࠦ࡮ࡦࡶࡺࡳࡷࡱࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦॖ")
        l111lllll_opy_ = l1llll11ll_opy_(l1lll1lll1_opy_)
        self._storage.link_pubkeys[l11l11lll_opy_] = l111l1ll1_opy_(l111lllll_opy_)
        self._storage.store()
    def l11l11l11_opy_(self, l11l11lll_opy_):
        l1l1l1_opy_ (u"ࠦࠧࠨࠠࡓࡧࡰࡳࡻ࡫ࠠࡢࠢࡲࡲࡪ࠳ࡴࡰ࠯ࡲࡲࡪࠦ࡬ࡪࡰ࡮ࠤ࡫ࡸ࡯࡮ࠢࡳࡩࡷࡹࡩࡴࡶࡨࡲࡹࠦࡳࡵࡱࡵࡥ࡬࡫࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣࡍ࡫ࠦࡴࡩࡧࠣࡳࡹ࡮ࡥࡳࠢࡊࡍࡉࠦࡩࡴࠢࡱࡳࡹࠦ࡫࡯ࡱࡺࡲ࠱ࠦࡴࡩ࡫ࡶࠤ࡮ࡴࡶࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡦࡲࡩࡸࠦ࡮ࡰࡶ࡫࡭ࡳ࡭࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡊࡆࠣࡳࡹ࡮ࡥࡳࡡࡪ࡭ࡩࡀࠠࡕࡪࡨࠤࡌࡏࡄࠡࡶࡲࠤࡷ࡫࡭ࡰࡸࡨ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤॗ")
        if l11l11lll_opy_ in self._storage.link_pubkeys:
            del self._storage.link_pubkeys[l11l11lll_opy_]
            self._storage.store()
    def next_encryption_counter(self, l1lllll1l_opy_):
        l1l1l1_opy_ (u"ࠧࠨࠢࠡࡉࡨࡲࡪࡸࡡࡵࡧࠣࡥࠥ࡫࡮ࡤࡴࡼࡴࡹ࡯࡯࡯ࡡࡦࡳࡺࡴࡴࡦࡴࠣࡪࡴࡸࠠࡢࠢࡱࡩࡼࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡵࡱࠣࡤࡥࡪࡥࡴࡶࡣࡤ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌࡏࡄࠡࡦࡨࡷࡹࡀࠠࡂࠢࡊࡍࡉࠦࡴࡰࠢࡪࡩࡳ࡫ࡲࡢࡶࡨࠤࡦࠦࡥ࡯ࡥࡵࡽࡵࡺࡩࡰࡰࡢࡧࡴࡻ࡮ࡵࡧࡵࠤ࡫ࡵࡲ࠯ࠢࡌࡪࠥࡴ࡯ࠡࡧࡱࡧࡷࡿࡰࡵ࡫ࡲࡲࡤࡩ࡯ࡶࡰࡷࡩࡷࠦࡨࡢࡵࠣࡦࡪ࡫࡮ࠡࡲࡵࡩࡻ࡯࡯ࡶࡵ࡯ࡽࠥ࡭ࡥ࡯ࡧࡵࡥࡹ࡫ࡤࠡࡨࡲࡶࠥࡺࡨࡪࡵࠣࡨࡪࡹࡴࡪࡰࡤࡸ࡮ࡵ࡮࠭ࠢࡤࠤࡳ࡫ࡷࠡࡴࡤࡲࡩࡵ࡭ࠡࡸࡤࡰࡺ࡫ࠠࡸ࡫࡯ࡰࠥࡨࡥࠡࡩࡨࡲࡪࡸࡡࡵࡧࡧ࠿ࠥࡺࡨࡦࡴࡨࡥ࡫ࡺࡥࡳ࠮ࠣࡸ࡭࡫ࠠࡦࡰࡦࡶࡾࡶࡴࡪࡱࡱࡣࡨࡵࡵ࡯ࡶࡨࡶࠥࡽࡩ࡭࡮ࠣ࡭ࡳࡩࡲࡦࡣࡶࡩࠥࡳ࡯ࡥࠢ࠹࠹࠺࠹࠵࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲࡸࠦࡩ࡯ࡶ࠽ࠤ࡙࡮ࡥࠡࡧࡱࡧࡷࡿࡰࡵ࡫ࡲࡲࡤࡩ࡯ࡶࡰࡷࡩࡷࠦࡴࡰࠢࡸࡷࡪࠦࡦࡰࡴࠣࡸ࡭࡫ࠠ࡮ࡧࡶࡷࡦ࡭ࡥ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨक़")
        if l1lllll1l_opy_ not in self._storage.encryption_counters:
            self._storage.encryption_counters[l1lllll1l_opy_]\
                = [struct.unpack(l1l1l1_opy_ (u"࠭ࠡࡉࠩख़"), os.urandom(2))[0]]
        else:
            l111l1111_opy_ = self._storage.encryption_counters[l1lllll1l_opy_][-1]
            self._storage.encryption_counters[l1lllll1l_opy_]\
                         .append((l111l1111_opy_ + 1) % 65536)
        l1ll1ll111_opy_ = len(self._storage.encryption_counters[l1lllll1l_opy_])
        if l1ll1ll111_opy_ > self.l111l1lll_opy_:
            l1ll1lllll_opy_ = int(l1ll1ll111_opy_/2)
            self._storage.encryption_counters[l1lllll1l_opy_]\
                = self._storage.encryption_counters[l1lllll1l_opy_][l1ll1lllll_opy_:]
        self._storage.store()
        return self._storage.encryption_counters[l1lllll1l_opy_][-1]
    def _1llll1111_opy_(self, group_gid):
        for l111ll11l_opy_, l1lll1111l_opy_ in self._storage.groups.items():
            if l111ll11l_opy_ == group_gid:
                return l1lll1111l_opy_.shared_secret
        raise KeyError(l1l1l1_opy_ (u"ࠢࡏࡱࠣ࡫ࡷࡵࡵࡱࠢ࡮ࡲࡴࡽ࡮ࠡࡨࡲࡶࠥࡍࡉࡅࠢࡾࢁࠧग़").format(group_gid))
    def _1ll1l11ll_opy_(self, l1lllll1l_opy_):
        l1llll1l11_opy_ = l111111l1_opy_(self._storage.link_pubkeys[l1lllll1l_opy_])
        return l11111111_opy_(self._1lll11lll_opy_, l1llll1l11_opy_)
    def _1lllll11l_opy_(self, l1lllll1l_opy_, sender):
        if l1lllll1l_opy_.gid_type == goTenna.settings.GID.GROUP:
            shared_secret = self._1llll1111_opy_(l1lllll1l_opy_)
            l1lllllll1_opy_ = l11l1l111_opy_(shared_secret, l1lllll1l_opy_.gid_val)
            gid = sender
        elif l1lllll1l_opy_.gid_type == goTenna.settings.GID.PRIVATE:
            if l1lllll1l_opy_ == self._gid:
                shared_secret = self._1ll1l11ll_opy_(sender)
                l1lllllll1_opy_ = l111llll1_opy_(l111111l1_opy_(self._storage.link_pubkeys[sender]))
                gid = sender
            else:
                shared_secret = self._1ll1l11ll_opy_(l1lllll1l_opy_)
                l1lllllll1_opy_ = l111llll1_opy_(self._1lll11lll_opy_.public)
                gid = self._gid
        else:
            raise ValueError(l1l1l1_opy_ (u"ࠣࡏࡨࡷࡸࡧࡧࡦࡵࠣࡳࡹ࡮ࡥࡳࠢࡷ࡬ࡦࡴࠠࡱࡴ࡬ࡺࡦࡺࡥࡴࠢࡲࡶࠥ࡭ࡲࡰࡷࡳࡷࠥࡩࡡ࡯ࡰࡲࡸࠥࡨࡥࠡࡧࡱࡧࡷࡿࡰࡵࡧࡧࠦज़"))
        return (shared_secret, l1lllllll1_opy_, gid)
    def encryption_hook(self, l1lllll1l_opy_, sender, time_sent, encryption_counter,
                        l1lll1ll11_opy_):
        l1l1l1_opy_ (u"ࠤࠥࠦࠥࡇ࡮ࠡࡧࡱࡧࡷࡿࡰࡵ࡫ࡲࡲࠥ࡮࡯ࡰ࡭ࠣࡷࡺ࡯ࡴࡢࡤ࡯ࡩࠥ࡬࡯ࡳࠢࡩࡩࡪࡪࡩ࡯ࡩࠣࡸࡴࠦ࠺ࡱࡻ࠽ࡱࡪࡺࡨ࠻ࡢࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡱࡪࡹࡳࡢࡩࡨ࠲ࡒ࡫ࡳࡴࡣࡪࡩ࠳ࡥ࡟ࡪࡰ࡬ࡸࡤࡥࡠ࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࡙࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡼ࡯࡬࡭ࠢ࡯ࡳࡴࡱࠠࡶࡲࠣࡸ࡭࡫ࠠࡥࡧࡶࡸ࡮ࡴࡡࡵ࡫ࡲࡲࠥࡧ࡮ࡥࠢࡶࡩࡳࡪࡥࡳࠢࡷࡳࠥࡸࡥࡵࡴ࡬ࡩࡻ࡫ࠠࡱࡧࡨࡶࠥࡶࡵࡣ࡮࡬ࡧࠥࡱࡥࡺࡵࠣࡥࡳࡪࠠࡴࡪࡤࡶࡪࡪࠠࡴࡧࡦࡶࡪࡺࡳࠡࡨࡵࡳࡲࠦࡳࡵࡱࡵࡥ࡬࡫࠮ࠡࡋࡩࠤࡪ࡯ࡴࡩࡧࡵࠤࡴ࡬ࠠࡥࡧࡶࡸ࡮ࡴࡡࡵ࡫ࡲࡲࠥࡵࡲࠡࡵࡨࡲࡩ࡫ࡲࠡࡥࡤࡲࡳࡵࡴࠡࡤࡨࠤ࡮ࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡤ࠭ࠢ࡬ࡸࠥࡽࡩ࡭࡮ࠣࡶࡦ࡯ࡳࡦࠢ࠽ࡴࡾࡀࡣ࡭ࡣࡶࡷ࠿ࡦࡋࡦࡻࡈࡶࡷࡵࡲࡡ࠰ࠣࡘ࡭࡯ࡳࠡ࡯ࡨࡥࡳࡹࠠࡵࡪࡤࡸࠥࡺࡨࡪࡵࠣࡪࡺࡴࡣࡵ࡫ࡲࡲࠥࡹࡨࡰࡷ࡯ࡨࠥࡵ࡮࡭ࡻࠣࡦࡪࠦࡵࡴࡧࡧࠤࡼ࡮ࡥ࡯ࠢࡷ࡬ࡪࠦࡣࡢ࡮࡯ࡩࡷࠦࡩࡴࠢࡶࡹࡷ࡫ࠠࡵࡪࡨࡶࡪࠦࡩࡴࠢࡤࠤࡸࡺ࡯ࡳࡧࡧࠤࡵࡻࡢ࡭࡫ࡦࠤࡰ࡫ࡹࠡࡱࡵࠤࡸ࡮ࡡࡳࡧࡧࠤࡸ࡫ࡣࡳࡧࡷࠤ࡫ࡵࡲࠡࡶ࡫ࡩࠥࡪࡥࡴࡶ࡬ࡲࡦࡺࡩࡰࡰࠣ࠱ࠥ࡯ࡴࠡࡦࡲࡩࡸࠦ࡮ࡰࡶࠣ࡬ࡦࡴࡤ࡭ࡧࠣ࡯ࡪࡿࠠࡦࡺࡦ࡬ࡦࡴࡧࡦ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤ࡚ࠥࡨࡦࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨ࡮ࡥࡤ࡭ࡶࠤࡧࡵࡴࡩࠢࡧࡩࡸࡺࡩ࡯ࡣࡷ࡭ࡴࡴࠠࡢࡰࡧࠤࡸ࡫࡮ࡥࡧࡵࠤ࡫ࡵࡲࠡࡶ࡫ࡩࠥࡲ࡯ࡤࡣ࡯ࠤࡌࡏࡄ࠭ࠢࡶࡳࠥ࡯ࡴࠡࡥࡤࡲࠥࡨࡥࠡࡷࡶࡩࡩࠦࡴࡰࠢࡵࡩ࠲࡫࡮ࡤࡴࡼࡴࡹࠦࡡࠡࡴࡨࡧࡪ࡯ࡶࡦࡦࠣࡱࡪࡹࡳࡢࡩࡨࠤ࡮࡬ࠠ࡯ࡧࡦࡩࡸࡹࡡࡳࡻ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡳࡣ࡬ࡷࡪࡹࠠࡌࡧࡼࡉࡷࡸ࡯ࡳ࠼ࠣࡍ࡫ࠦࡴࡩࡧࠣࡤࡥࡪࡥࡴࡶࡣࡤࠥࡵࡲࠡࡢࡣࡷࡪࡴࡤࡦࡴࡣࡤࠥࡪ࡯ࠡࡰࡲࡸࠥ࡮ࡡࡷࡧࠣ࡯ࡪࡿࠠ࡮ࡣࡷࡩࡷ࡯ࡡ࡭ࠢࡶࡸࡴࡸࡥࡥ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢड़")
        shared_secret, l1lllllll1_opy_, gid = self._1lllll11l_opy_(l1lllll1l_opy_, sender)
        return l11l11ll1_opy_(l1lll1ll11_opy_, shared_secret, gid, l1lllllll1_opy_,
                             encryption_counter)
    def l1lll11ll1_opy_(self, l1lllll1l_opy_, sender, time_sent, encryption_counter,
                        l1lll11l11_opy_):
        l1l1l1_opy_ (u"ࠥࠦࠧࠦࡁࠡࡦࡨࡧࡷࡿࡰࡵ࡫ࡲࡲࠥ࡮࡯ࡰ࡭ࠣࡷࡺ࡯ࡴࡢࡤ࡯ࡩࠥ࡬࡯ࡳࠢࡩࡩࡪࡪࡩ࡯ࡩࠣࡸࡴࠦ࠺ࡱࡻ࠽ࡱࡪࡺࡨ࠻ࡢࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡱࡪࡹࡳࡢࡩࡨ࠲࡫ࡸ࡯࡮ࡡࡧࡩࡻ࡯ࡣࡦࡡࡵࡩࡸࡶ࡯࡯ࡵࡨࡤ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡࡖ࡫࡭ࡸࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠡ࡮ࡲࡳࡰࡹࠠࡶࡲࠣࡸ࡭࡫ࠠࡥࡧࡶࡸ࡮ࡴࡡࡵ࡫ࡲࡲࠥࡧ࡮ࡥࠢࡶࡩࡳࡪࡥࡳࠢࡷࡳࠥࡸࡥࡵࡴ࡬ࡩࡻ࡫ࠠࡱࡧࡨࡶࠥࡶࡵࡣ࡮࡬ࡧࠥࡱࡥࡺࡵࠣࡥࡳࡪࠠࡴࡪࡤࡶࡪࡪࠠࡴࡧࡦࡶࡪࡺࡳࠡࡨࡵࡳࡲࠦࡳࡵࡱࡵࡥ࡬࡫࠮ࠡࡋࡩࠤࡪ࡯ࡴࡩࡧࡵࠤࡴ࡬ࠠࡥࡧࡶࡸ࡮ࡴࡡࡵ࡫ࡲࡲࠥࡵࡲࠡࡵࡨࡲࡩ࡫ࡲࠡࡥࡤࡲࡳࡵࡴࠡࡤࡨࠤ࡮ࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡤ࠭ࠢ࡬ࡸࠥࡽࡩ࡭࡮ࠣࡶࡦ࡯ࡳࡦࠢ࠽ࡴࡾࡀࡣ࡭ࡣࡶࡷ࠿ࡦ࡫ࡦࡻࡈࡶࡷࡵࡲࡡ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡢ࡫ࡶࡩࡸࠦࡋࡦࡻࡈࡶࡷࡵࡲ࠻ࠢࡌࡪࠥࡺࡨࡦࠢࡣࡤࡩ࡫ࡳࡵࡢࡣࠤࡴࡸࠠࡡࡢࡶࡩࡳࡪࡥࡳࡢࡣࠤࡩࡵࠠ࡯ࡱࡷࠤ࡭ࡧࡶࡦࠢ࡮ࡩࡾࠦ࡭ࡢࡶࡨࡶ࡮ࡧ࡬ࠡࡵࡷࡳࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨढ़")
        shared_secret, l1lllllll1_opy_, gid = self._1lllll11l_opy_(l1lllll1l_opy_, sender)
        return l111l111l_opy_(l1lll11l11_opy_, shared_secret, gid, l1lllllll1_opy_,
                             encryption_counter)