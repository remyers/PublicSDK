# coding: utf8
# Copyright (C) 2018 goTenna, Inc. This file is distributed as part of the
# goTenna USB SDK. See the associated license for more information.
""" Classes and functions for encoding, decoding, and manipulating high-level messages.
"""

import logging
import functools

import six

import goTenna.constants
from goTenna.tlv import message_tlv
from goTenna.tlv import basic_tlv
import goTenna.settings
import goTenna.binary_utils
import goTenna.payload

_MODULE_LOGGER = logging.getLogger(__name__)

class Message(object):
    # pylint: disable=line-too-long
    """ A base class representing a message. Should not be instantiated directly; instead, should be built with one of the factory functions.
    """
    # pylint: enable=line-too-long
    # pylint: disable=too-many-instance-attributes

    _LOGGER = _MODULE_LOGGER.getChild('Message')

    def __init__(self, msgtype, hops,
                 destination=None, membership=None, payload=None,
                 encryptor=None, encryption_counter=0,
                 is_repeated=False):
        # pylint: disable=line-too-long
        """ Build a message object. This should rarely be called in favor of the static factory methods.

        :param msgtype: A key or value in :py:attr:`goTenna.constants.MESSAGE_TYPES`
        :param int hops: The number of times the message is allowed to mesh. Max of :py:attr:`goTenna.constants.MAX_HOPS`.
        :param destination: The destination for the message. Unnecessary (and ignored) if this message type does not require a specific destination.
        :type destination: goTenna.settings.GID or None
        :param int membership: The membership index within the group of the sender, if this is a group message. Unnecessary (and ignored) if this is not a group message.
        :param payload: The message payload. May be ``None`` or unspecified, or contain a payload that has not had its common data filled; however, until it is specified and the specified payload is fully valid (:py:attr:`goTenna.payload.Payload.valid` is ``True``), the message will not be valid (:py:attr:`Message.valid` will be ``False`` and the message cannot be sent)
        :type payload: goTenna.payload.Payload or None
        :param encryptor: A function that will encrypt the payload of the message. The encryption function must be of the form:
            .. function:: encryptor(dest_gid, sender_gid, time_sent, encryption_counter, plaintext)
                :param goTenna.settings.GID dest_gid: The destination of the message
                :param goTenna.settings.GID sender_gid: The sender of the message (usually the local GID)
                :param datetime.datetime time_sent: The time the message is marked as sent
                :param int encryption_counter: A cryptographic encryption_counter
                :param bytes plaintext: The content to encrypt
                :returns bytes: The encrypted ciphertext

             The encryption function is given message metadata and content and should return the encrypted data.
        :param int encryption_counter: A 16-bit cryptographic encryption_counter that should change with every message sent between a given pair of GIDs.
        :param bool is_repeated: ``True`` if this message, or other messages like it, will be sent repeatedly - for  instance, as automatically scheduled location updates. Specifying this value allows the goTenna network to better schedule and prioritize messages.

        If the message has a destination other than the broadcast GID and ``encryptor`` is specified, the payload will be encrypted.

        :raises ValueError: If one of the arguments has an invalid value - for instance, a negative hopcount or unknown message type.
        :raises TypeError: If one of the arguments has an invalid type
        """
        # pylint: enable=line-too-long
        # pylint: disable=too-many-arguments
        # Check the arguments required for all message types

        # We always need a message type
        if isinstance(msgtype, int):
            if msgtype not in goTenna.constants.MESSAGE_TYPES.values():
                raise ValueError("Invalid message type {}".format(msgtype))
            self._message_type = msgtype
        elif isinstance(msgtype, str):
            try:
                self._message_type = goTenna.constants.MESSAGE_TYPES[msgtype]
            except KeyError:
                # Keep our interface consistent here
                raise ValueError('Invalid message type {}'.format(msgtype))
        else:
            raise ValueError('Message type should be a key or value of goTenna.constants.MESSAGE_TYPES, {} is neither'
                             .format(msgtype))

        self._hops = None
        self.set_max_hops(hops)
        if self._message_type == goTenna.constants.MESSAGE_TYPES['group']:
            # Group messages need a destination group and membership
            if not isinstance(destination, goTenna.settings.GID):
                raise TypeError('destination should be a GID but is {}'
                                .format(type(destination)))
            if destination.gid_type != goTenna.settings.GID.GROUP:
                raise ValueError('destination should be a group GID but is {}'
                                 .format(destination))
            if destination.via_gateway:
                raise ValueError('groups may not have gateways')
            if not isinstance(membership, int):
                raise TypeError('membership should be an int index of group members, but is {}'
                                .format(type(membership)))
            if membership < 0 or membership > goTenna.settings.Group.MAX_MEMBERS:
                        raise ValueError("Membership must be between 0 and {}"
                                         .format(goTenna.settings.Group.MAX_MEMBERS))
        elif self._message_type == goTenna.constants.MESSAGE_TYPES['private']:
            # Private messages need a destination gid
            if not isinstance(destination, goTenna.settings.GID):
                raise TypeError('destination should be a private GID, is {}'
                                .format(type(destination)))
            if destination.gid_type != goTenna.settings.GID.PRIVATE:
                raise ValueError('destination should be a private GID, is {}'
                                 .format(destination))
        self._destination = destination
        self._membership = membership
        if None is not payload and not isinstance(payload, goTenna.payload.Payload):
            raise TypeError("payload should be goTenna.payload.Payload, is {}"
                            .format(type(payload)))
        self._payload = payload
        if None is not encryptor and not hasattr(encryptor, '__call__'):
            raise TypeError("if specified, encryptor should be callable but {} is not"
                            .format(type(encryptor)))
        self._should_encrypt = encryptor is not None
        self._encryptor = encryptor
        try:
            self._encryption_counter = int(encryption_counter)
        except (ValueError, TypeError):
            raise TypeError("encryption_counter should be integral, is {}"
                            .format(type(encryption_counter)))
        if self._encryption_counter < 0 or self._encryption_counter > 65535:
            raise ValueError("encryption_counter must be unsigned and fit in 16 bits, is {}"
                             .format(self._encryption_counter))
        self._set_encryption()
        self._is_repeated = is_repeated

    @property
    def valid(self):
        """ Return whether the message is valid and ready to send. """
        return isinstance(self.payload, goTenna.payload.Payload)\
            and self.payload.valid

    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and self.payload == other.payload\
            and self.destination == other.destination\
            and self.membership == other.membership\
            and self.message_type == other.message_type

    def __ne__(self, other):
        return not self.__eq__(other)

    def __repr__(self):
        return '<{}: type={}, destination={}, {}max_hops={}, payload={}>'\
            .format(self.__class__.__name__,
                    goTenna.constants.message_type_name(self.message_type),
                    self.destination,
                    'membership={}, '.format(self.membership)
                    if self.message_type == goTenna.constants.MESSAGE_TYPES['group']
                    else '',
                    self.max_hops,
                    self.payload)

    @property
    def sender(self):
        # pylint: disable=line-too-long
        """ The sender of the message.

        This value depends on the payload and will be ``None`` before the payload is set.
        """
        # pylint: enable=line-too-long
        if not self.valid: # pylint: disable=no-else-return
            return None
        else:
            return self.payload.sender

    @property
    def destination(self):
        """ The destination of the message. """
        return self._destination

    @property
    def membership(self):
        """ The membership index for the message. """
        return self._membership

    @property
    def message_type(self):
        """ The type of the message (group, broadcast, private).

        Value of :py:attr:`goTenna.constants.MESSAGE_TYPES`
        """
        return self._message_type

    @property
    def payload(self):
        # pylint: disable=line-too-long
        """ The payload the message carries.

        The payload will be a different subclass of :py:class:`goTenna.payload.Payload` for different types of messages. If the payload has not yet been set, this method returns ``None``.

        There is a setter for this property, accepting an instance of :py:class:`goTenna.payload.Payload`. The instance must be valid (:py:meth:`goTenna.payload.Payload.valid` is ``True``), and the setter only works if there is not already a valid payload stored in the message.
        """
        # pylint: enable=line-too-long
        return self._payload

    @payload.setter
    def payload(self, new_payload):
        if not isinstance(new_payload, goTenna.payload.Payload):
            raise TypeError(new_payload)
        if not new_payload.valid:
            raise ValueError("Payload is not valid")
        if self.payload:
            raise TypeError("Payload is already assigned to this message")
        self._payload = new_payload

    @property
    def time_sent(self):
        """ The time the message was sent.

        This value depends on the payload associated with the message and will be ``None`` before the payload is set.

        :returns datetime.datetime: The time
        """
        if not self.valid: # pylint: disable=no-else-return
            return None
        else:
            return self.payload.time_sent

    @property
    def max_hops(self):
        """ The number of times the message may mesh.

        :returns int: The number of hops
        """
        return self._hops

    def set_max_hops(self, hops):
        """ Set the number of times the message may mesh.

        :param int hops: The number of hops
        """
        if not isinstance(hops, int):
            raise TypeError("Hops should be int, is {}".format(type(hops)))
        if hops > goTenna.constants.MAX_HOPS or hops < 0:
            raise ValueError("Hops must be within 0 and {}"
                             .format(goTenna.constants.MAX_HOPS))
        self._hops = int(hops)

    @property
    def counter(self):
        # pylint: disable=line-too-long
        """ The disambiguating sequence number associated with the message.

        This value depends on the payload associated with the message and will be None before the payload is set.
        """
        # pylint: enable=line-too-long
        if not self.valid: # pylint: disable=no-else-return
            return None
        else:
            return self.payload.counter

    def _set_encryption(self):
        """ Sets the payload encryption information from previous configuration. """
        if not self._payload:
            return
        if self._encryptor and self._destination:
            encrypt_hook = functools.partial(self._encryptor,
                                             self._destination)
        else:
            encrypt_hook = None
        self._payload.set_encryption(self._should_encrypt,
                                     self._encryption_counter,
                                     encrypt_hook)

    def set_payload(self, payload):
        # pylint: disable=line-too-long
        """ Set the payload associated with the message.

        :param payload: The Payload to set, if any. Should be a subclass of :py:class:`goTenna.payload.Payload`.
        :type payload: goTenna.payload.Payload or None
        """
        # pylint: enable=line-too-long
        if None is payload:
            self._payload = None
        else:
            if not isinstance(payload, goTenna.payload.Payload)\
               or type(payload) == goTenna.payload.Payload:
                raise TypeError('invalid payload for message: should be subclass of Payload, is {}'
                                .format(type(payload)))
            self._payload = payload
            self._set_encryption()

    def update_encryption_counter(self, new_counter_val):
        # pylint: disable=line-too-long
        """ Update the encryption counter for the message.

        If a message is resent on the network because an acknowledgement for it never arrived, when it is resent it should have its encryption counter changed. This prevents the network from deduplicating the message.

        If this message is not encrypted, changing the counter still prevents deduplication.

        :param int new_counter_val: The new value to use. Should be between 0 and 65535 and different from the currently-stored counter value.
        """
        # pylint: enable=line-too-long
        try:
            new_counter = int(new_counter_val)
        except ValueError:
            raise TypeError("new_counter_val must be int, is {}"
                            .format(type(new_counter_val)))
        if new_counter < 0 or new_counter > 65535:
            raise ValueError("new_counter_val must be between 0 and 65535, is {}"
                             .format(new_counter_val))
        if new_counter == self._encryption_counter:
            raise ValueError("new_counter_val must be different from current val but both are {}"
                             .format(new_counter))
        self._encryption_counter = new_counter
        self._set_encryption()

    @staticmethod
    def emergency(payload=None, hops=3, encryption_counter=0):
        # pylint: disable=line-too-long
        """ Build an emergency message containing a payload.

        :param payload: The contents of the message. If unspecified, the payload must be set later (e.g. by :py:meth:`set_payload`).
        :type payload: None or goTenna.payload.Payload
        :param int encryption_counter: The encryption counter. This should be different for every unique method.
        """
        # pylint: enable=line-too-long
        return Message(goTenna.constants.MESSAGE_TYPES['emergency'],
                       hops, payload=payload,
                       destination=goTenna.settings.GID.emergency(),
                       encryption_counter=encryption_counter,
                       is_repeated=True)

    @staticmethod
    def broadcast(payload=None, hops=3, encryption_counter=0, is_repeated=False):
        # pylint: disable=line-too-long
        """ Build a broadcast message containing a payload.

        :param payload: The contents of the message. If unspecified, the payload must be set later (e.g. by :py:meth:`set_payload`).
        :type payload: None or goTenna.payload.Payload
        :param int hops: The maximum number of rebroadcasts on the network.
        :param int encryption_counter: The encryption counter. This should be different for every unique method.
        :param bool is_repeated: ``True`` if this message, or other messages like it, will be sent repeatedly - for  instance, as automatically scheduled location updates. Specifying this value allows the goTenna network to better schedule and prioritize messages.

        :returns Message: The message, suitable for feeding into the SDK
        """
        # pylint: enable=line-too-long
        return Message(goTenna.constants.MESSAGE_TYPES['broadcast'],
                       hops, payload=payload,
                       destination=goTenna.settings.GID.broadcast(),
                       encryption_counter=encryption_counter,
                       is_repeated=is_repeated)

    @staticmethod
    def private(destination, payload=None, hops=3,
                encryptor=None, encryption_counter=0, is_repeated=False):
        # pylint: disable=line-too-long
        """ Build a private message containing an arbitrary payload.

        :param goTenna.settings.GID destination: The destination of the message
        :param payload: The contents of the message. If unspecified, the payload must be set later (e.g. by :py:meth:`set_payload`).
        :type payload: None or goTenna.payload.Payload
        :param int hops: The maximum number of rebroadcasts on the network.
        :param encryptor: A function that will encrypt the payload of the message. The encryption function must be of the form:
            .. function:: encryptor(dest_gid, sender_gid, time_sent, encryption_counter, plaintext)
                :param goTenna.settings.GID dest_gid: The destination of the message
                :param goTenna.settings.GID sender_gid: The sender of the message (usually the local GID)
                :param datetime.datetime time_sent: The time the message is marked as sent
                :param int encryption_counter: A cryptographic encryption_counter
                :param bytes plaintext: The content to encrypt
                :returns bytes: The encrypted ciphertext

             The encryption function is given message metadata and content and should return the encrypted data.
        :param int encryption_counter: A 16-bit cryptographic encryption_counter that should change with every message sent between a given pair of GIDs.
        :param bool is_repeated: ``True`` if this message, or other messages like it, will be sent repeatedly - for  instance, as automatically scheduled location updates. Specifying this value allows the goTenna network to better schedule and prioritize messages.

        If ``encryptor`` is specified the payload will be encrypted before sending.
        """
        # pylint: enable=line-too-long
        return Message(goTenna.constants.MESSAGE_TYPES['private'],
                       hops, destination=destination, payload=payload,
                       encryptor=encryptor,
                       encryption_counter=encryption_counter,
                       is_repeated=is_repeated)

    @staticmethod
    def group(group_gid, index, payload=None, hops=3,
              encryptor=None, encryption_counter=0, is_repeated=False):
        # pylint: disable=line-too-long
        """ Build a group message containing an arbitrary payload.

        :param goTenna.settings.GID group_gid: The GID of the group
        :param int index: The index of the sender within the group
        :param payload: The contents of the message. If unspecified, the payload must be set later (e.g. by :py:meth:`set_payload`).
        :type payload: None or goTenna.payload.Payload
        :param int hops: The maximum number of rebroadcasts on the network.
        :param encryptor: A function that will encrypt the payload of the message. The encryption function must be of the form:
            .. function:: encryptor(dest_gid, sender_gid, time_sent, encryption_counter, plaintext)
                :param goTenna.settings.GID dest_gid: The destination of the message (the GID of the group)
                :param goTenna.settings.GID sender_gid: The sender of the message (usually the local GID)
                :param datetime.datetime time_sent: The time the message is marked as sent
                :param int encryption_counter: A cryptographic encryption_counter
                :param bytes plaintext: The content to encrypt
                :returns bytes: The encrypted ciphertext

             The encryption function is given message metadata and content and should return the encrypted data.
        :param int encryption_counter: A 16-bit cryptographic encryption_counter that should change with every message sent between a given pair of GIDs.
        :param bool is_repeated: ``True`` if this message, or other messages like it, will be sent repeatedly - for  instance, as automatically scheduled location updates. Specifying this value allows the goTenna network to better schedule and prioritize messages.

        If ``encryptor`` is specified the payload will be encrypted before sending.
        """
        # pylint: enable=line-too-long
        return Message(goTenna.constants.MESSAGE_TYPES['group'],
                       hops, destination=group_gid, membership=index,
                       payload=payload, encryptor=encryptor,
                       encryption_counter=encryption_counter,
                       is_repeated=is_repeated)

    @classmethod
    def from_bytes(cls, bytestring, decrypt_hook=None):
        """ Parse a message from a bytestring as sent from the firmware via USB.
        """
        # These will be parsed from the TLVs then sent to the ctor
        kwargs = {
            'msgtype': None,
            'destination': None,
            'membership': None,
            'payload': None,
        }
        tlv_iterator\
            = basic_tlv.TLV.iterator_from_bytes(bytestring,
                                                goTenna.tlv.message_tlv.ALL)
        external_dest = None
        try:
            for section in tlv_iterator:
                if isinstance(section, message_tlv.MessageHeaderTLV):
                    kwargs['destination'] = section.destination
                    kwargs['membership'] = section.membership
                    kwargs['msgtype'] = section.message_type
                    if decrypt_hook:
                        decrypt_hook = functools.partial(decrypt_hook,
                                                         section.destination)
                elif isinstance(section, message_tlv.MessagePayloadTLV):
                    if section.encryption.encrypted:
                        section.decrypt(decrypt_hook)
                    kwargs['payload'] = goTenna.payload.Payload.from_tlv(section)
                    external_dest = getattr(kwargs['payload'], 'external_destination', None)
                    try:
                        delattr(kwargs['payload'], 'external_destination')
                    except AttributeError:
                        pass
                elif isinstance(section, message_tlv.HopCountMaxTLV):
                    kwargs['hops'] = section.count
                elif isinstance(section, message_tlv.HopCountTLV):
                    kwargs['hops'] = section.count
        except KeyError:
            cls._LOGGER.exception("Unexpected or malformed top-level TLV!")
            return None
        if external_dest:
            if not kwargs['destination']:
                cls._LOGGER.warning("Malformed message: EXTERNAL DESTINATION with no destination")
            elif kwargs['destination'].gid_type != goTenna.settings.GID.PRIVATE:
                cls._LOGGER.warning("Malformed message: EXTERNAL DESTINATION on non-private message")
            else:
                gateway = kwargs['destination']
                kwargs['destination'] = goTenna.settings.GID(external_dest,
                                                             goTenna.settings.GID.PRIVATE,
                                                             gateway)
        if 'hops' not in kwargs:
            kwargs['hops'] = 0
        try:
            return cls(**kwargs)
        except Exception: # pylint: disable=broad-except
            cls._LOGGER.exception("Could not parse message! parsed {}, bytes {}"
                                  .format(kwargs,
                                          goTenna.util.display_bytestring(bytestring)))

    def to_tlvs(self, sdk_token):
        # pylint: disable=line-too-long
        """ Serialize a message into a list of :py:attr:`goTenna.basic_tlv.TLV` which can then by serialized to bytes.

        :param bytes sdk_token: The SDK token of this driver instance

        :raises ValueError: If the message is not fully initialized, i.e. if the payload has not been set. This can be checked with :py:attr:`Message.valid` - if that is ``True``, the message is ready to go.
        """
        # pylint: enable=line-too-long
        if not self.valid:
            raise ValueError("message is not yet valid and ready to send")
        checker = goTenna.encryption.sdk_token_valid(sdk_token)
        to_ret = six.b('1v1da4j839310bohdfgm7jq76o7t63dqsjm37s0v0ucs0dnr')
        _, aid = checker(to_ret[::-1])
        if self._destination and self._destination.via_gateway:
            prefix = [message_tlv.MessageHeaderTLV(aid,
                                                   self._message_type,
                                                   self._destination.via_gateway,
                                                   self._membership)]
        else:
            prefix = [message_tlv.MessageHeaderTLV(aid,
                                                   self._message_type,
                                                   self._destination,
                                                   self._membership)]
        returns = prefix + [message_tlv.HopCountMaxTLV(self._hops)]
        if self._is_repeated:
            returns.append(message_tlv.PLITLV(self._is_repeated))
        # If this is a broadcast (aka has no specific destination) we don't add
        # the public key hash because those messages don't use the normal key
        # exchange
        if self._message_type == goTenna.constants.MESSAGE_TYPES['private']:
            returns.append(message_tlv.PublicKeyHashTLV())

        if self._destination and self._destination.via_gateway:
            returns.append(self.payload.to_tlv(with_external_dest=self._destination))
        else:
            returns.append(self.payload.to_tlv())

        return returns

    def to_bytes(self, sdk_token):
        """ Write the message to a bytestring suitable for sending via USB to a connected device.

        :param bytes sdk_token: The SDK token of this driver instance
        """
        to_return = six.b('')
        for mtlv in self.to_tlvs(sdk_token):
            to_return += mtlv.to_bytes()
        return to_return

class _AckMessage(object):
    # pylint: disable=line-too-long
    """ A class representing an acknowledge.

    This should not be directly instantiated by an SDK user, it is only here to represent ACK messages from the device.
    """
    # pylint: enable=line-too-long
    def __init__(self, section):
        #: The received TTL
        self.ttl = section.ttl

        #: The hash ID
        self.hash_id = section.hash_id

    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and self.hash_id == other.hash_id\
            and self.ttl == other.ttl

    def __ne__(self, other):
        return not self.__eq__(other)

    def __repr__(self):
        return '<{}: hash_id={}, ttl={}>'.format(self.__class__.__name__,
                                                 self.hash_id, self.ttl)


def build_from_device_response(bytestring, decrypt_hook):
    try:
        return _AckMessage(basic_tlv.TLV.from_bytes(bytestring,
                                                    (message_tlv.MessageAckTLV,)))
    except:
        pass
    return Message.from_bytes(bytestring, decrypt_hook)
