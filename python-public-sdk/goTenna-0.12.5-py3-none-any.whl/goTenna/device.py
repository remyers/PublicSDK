# coding: utf8
import sys
ll_opy_ = sys.version_info [0] == 2
l1llll_opy_ = 2048
l11l1_opy_ = 7
def l1l11l_opy_ (l1l111_opy_):
    global l1_opy_
    l11ll1_opy_ = ord (l1l111_opy_ [-1])
    l1l1l1_opy_ = l1l111_opy_ [:-1]
    l11ll_opy_ = l11ll1_opy_ % len (l1l1l1_opy_)
    l1ll_opy_ = l1l1l1_opy_ [:l11ll_opy_] + l1l1l1_opy_ [l11ll_opy_:]
    if ll_opy_:
        l1l11_opy_ = unicode () .join ([unichr (ord (char) - l1llll_opy_ - (l1l1_opy_ + l11ll1_opy_) % l11l1_opy_) for l1l1_opy_, char in enumerate (l1ll_opy_)])
    else:
        l1l11_opy_ = str () .join ([chr (ord (char) - l1llll_opy_ - (l1l1_opy_ + l11ll1_opy_) % l11l1_opy_) for l1l1_opy_, char in enumerate (l1ll_opy_)])
    return eval (l1l11_opy_)
# Copyright (C) 2018 goTenna, Inc. This file is distributed as part of the
# goTenna USB SDK. See the associated license for more information.
# pylint: disable=line-too-long
l1l11l_opy_ (u"ࠦࠧࠨࠠࡥࡧࡹ࡭ࡨ࡫ࠠ࠮ࠢࡄࠤࡲࡵࡤࡶ࡮ࡨࠤ࡫ࡵࡲࠡ࡫ࡱࡸࡪࡸࡡࡤࡶ࡬ࡲ࡬ࠦࡷࡪࡶ࡫ࠤࡦࠦࡧࡰࡖࡨࡲࡳࡧࠠࡥࡧࡹ࡭ࡨ࡫ࠊࠋࡖ࡫࡭ࡸࠦ࡭ࡰࡦࡸࡰࡪࠦࡰࡳࡱࡹ࡭ࡩ࡫ࡳࠡࡶ࡫ࡩࠥࡖࡲࡰࠢࡤࡲࡩࠦࡇ࠺࠲࠳ࠤࡨࡲࡡࡴࡵࡨࡷ࠱ࠦࡩ࡯ࡵࡷࡥࡳࡩࡥࡴࠢࡲࡪࠥࡽࡨࡪࡥ࡫ࠤࡷ࡫ࡰࡳࡧࡶࡩࡳࡺࠠࡢࠢࡶ࡭ࡳ࡭࡬ࡦࠢࡦࡳࡳࡴࡥࡤࡶࡨࡨࠥ࡭࡯ࡕࡧࡱࡲࡦࠦࡐࡳࡱࠣࡳࡷࠦ࠹࠱࠲࠱ࠤ࡙࡮ࡩࡴࠢࡦࡰࡦࡹࡳࠡ࡫ࡶࠤࡩ࡫ࡳࡪࡩࡱࡩࡩࠦࡴࡰࠢ࡬ࡲࡹ࡫ࡲࡢࡥࡷࠤࡼ࡯ࡴࡩࠢࡷ࡬ࡪࠦ࡯ࡵࡪࡨࡶࠥࡹࡵࡣ࡯ࡲࡨࡺࡲࡥࡴࠢࡲࡪࠥࡺࡨࡦࠢࡪࡳ࡙࡫࡮࡯ࡣࠣࡅࡕࡏ࠮ࠋࠤࠥࠦफ़")
# pylint: enable=line-too-long
import datetime
import time
import struct
import logging
import collections
import binascii
import goTenna.settings
import goTenna.constants
import goTenna.l11l1ll1l_opy_
import goTenna.message
from goTenna.tlv import l1l1l11111_opy_
_MODULE_LOGGER = logging.getLogger(__name__)
class l1l1111111_opy_(object):
    l1l11l_opy_ (u"ࠧࠨࠢࠡࡃࠣࡧࡱࡧࡳࡴࠢࡰࡳࡩ࡫࡬ࡪࡰࡪࠤࡦࠦࡳࡪࡰࡪࡰࡪࠦࡣࡰࡰࡱࡩࡨࡺࡥࡥࠢࡪࡳ࡙࡫࡮࡯ࡣࠣࡨࡪࡼࡩࡤࡧ࠱ࠎࠏࠦࠠࠡࠢࡗ࡬࡮ࡹࠠࡪࡵࠣ࡭ࡳࡺࡥ࡯ࡦࡨࡨࠥࡧࡳࠡࡣࠣࡦࡦࡹࡥࠡࡥ࡯ࡥࡸࡹࠠࡧࡱࡵࠤࡹ࡮ࡥࠡ࠼ࡳࡽ࠿ࡩ࡬ࡢࡵࡶ࠾ࡥࡖࡲࡰࡢࠣࡥࡳࡪࠠ࠻ࡲࡼ࠾ࡨࡲࡡࡴࡵ࠽ࡤࡌ࠿࠰࠱ࡢࠣࡧࡱࡧࡳࡴࡧࡶࠤࡴࡴ࡬ࡺ࠽ࠣ࡭ࡹࠦࡳࡩࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡦࡪࠦࡤࡪࡴࡨࡧࡹࡲࡹࠡ࡫ࡱࡷࡹࡧ࡮ࡵ࡫ࡤࡸࡪࡪ࠮ࠋࠌࠣࠤࠥࠦࡃࡩ࡫࡯ࡨࡷ࡫࡮ࠡࡱࡩࠤࡹ࡮ࡩࡴࠢࡦࡰࡦࡹࡳࠡࡵ࡫ࡳࡺࡲࡤࠡࡱࡱࡰࡾࠦࡢࡦࠢࡸࡷࡪࡪࠠࡪࡨࠣࡽࡴࡻࠠࡸࡣࡱࡸࠥࡺ࡯ࠡࡦ࡬ࡶࡪࡩࡴ࡭ࡻࠣࡱࡦࡴࡡࡨࡧࠣࡥࠥࡩ࡯࡯ࡰࡨࡧࡹ࡯࡯࡯࠮ࠣࡥࡳࡪࠠࡢࡸࡲ࡭ࡩࠦࡴࡩࡧࠣࡹࡸ࡫ࠠࡰࡨࠣࡅࡕࡏ࠭ࡪࡰࡷࡩࡷࡴࡡ࡭ࠢࡷ࡬ࡷ࡫ࡡࡥࡵ࠱ࠤࡋࡵࡲࠡ࡯ࡲࡷࡹࠦࡵࡴࡧࡶࠤࡴ࡬ࠠࡵࡪ࡬ࡷࠥࡇࡐࡊ࠮ࠣࡧࡴࡳ࡭ࡶࡰ࡬ࡧࡦࡺࡩ࡯ࡩࠣࡻ࡮ࡺࡨࠡࡣࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤࠤࡩ࡫ࡶࡪࡥࡨࠤࡹ࡮ࡲࡰࡷࡪ࡬ࠥࡀࡰࡺ࠼ࡦࡰࡦࡹࡳ࠻ࡢࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡨࡷ࡯ࡶࡦࡴ࠱ࡈࡷ࡯ࡶࡦࡴࡣࠤ࡮ࡹࠠࡳࡧࡦࡳࡲࡳࡥ࡯ࡦࡨࡨ࠳ࠐࠊࠡࠢࠣࠤ࡙࡮ࡥࠡ࡫ࡱࡸࡪࡴࡤࡦࡦࠣࡹࡸࡧࡧࡦࠢࡳࡥࡹࡺࡥࡳࡰࠣࡪࡴࡸࠠࡵࡪࡨࠤࡨ࡮ࡩ࡭ࡦࡵࡩࡳࠦ࡯ࡧࠢࡷ࡬࡮ࡹࠠࡤ࡮ࡤࡷࡸࠦࡩࡴࠢࡷࡳࠥࡩࡲࡦࡣࡷࡩࠥ࡯ࡴࠡࡣࡱࡨࠥࡩ࡯࡮࡯ࡸࡲ࡮ࡩࡡࡵࡧࠣࡻ࡮ࡺࡨࠡࡣࡱࠤࡦࡲࡲࡦࡣࡧࡽ࠲ࡩ࡯࡯ࡰࡨࡧࡹ࡫ࡤࠡࡩࡲࡘࡪࡴ࡮ࡢࠢࡧࡩࡻ࡯ࡣࡦ࠰ࠍࠎࠥࠦࠠࠡࡃ࡯ࡰࠥࡳࡥࡵࡪࡲࡨࡸࠦ࡯ࡧࠢࡷ࡬࡮ࡹࠠࡤ࡮ࡤࡷࡸࠦࡲࡢ࡫ࡶࡩࠥࡧࠠ࠻ࡲࡼ࠾ࡨࡲࡡࡴࡵ࠽ࡤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡩ࡯࡯ࡵࡷࡥࡳࡺࡳ࠯ࡖ࡬ࡱࡪࡵࡵࡵࡇࡻࡧࡪࡶࡴࡪࡱࡱࡤࠥ࡯ࡦࠡࡥࡲࡱࡲࡻ࡮ࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡹ࡬ࡸ࡭ࠦࡴࡩࡧࠣࡧࡴࡴ࡮ࡦࡥࡷࡩࡩࠦࡤࡦࡸ࡬ࡧࡪࠦࡴࡪ࡯ࡨࡷࠥࡵࡵࡵ࠮ࠣࡥࡳࡪࠠࡢࠢࡣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡨࡵ࡮ࡴࡶࡤࡲࡹࡹ࠮ࡓࡧࡰࡳࡹ࡫ࡅࡳࡴࡲࡶࡥࠦࡥࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡪࠥࡺࡨࡦࠢࡵࡩࡲࡵࡴࡦࠢࡧࡩࡻ࡯ࡣࡦࠢࡨࡲࡨࡵࡵ࡯ࡶࡨࡶࡸࠦࡡ࡯ࠢࡨࡶࡷࡵࡲࠡࡹ࡫࡭ࡱ࡫ࠠࡦࡺࡨࡧࡺࡺࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡤࡱࡰࡱࡦࡴࡤ࠯ࠌࠍࠤࠥࠦࠠࡂ࡮࡯ࠤࡲ࡫ࡴࡩࡱࡧࡷࠥࡵࡦࠡࡶ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥࡨ࡬ࡰࡥ࡮ࠤࡼ࡮ࡥ࡯ࠢࡺࡥ࡮ࡺࡩ࡯ࡩࠣࡪࡴࡸࠠࡢࠢࡧࡩࡻ࡯ࡣࡦࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࠏࠦࠠࠡࠢࠥࠦࠧय़")
    def __init__(self, gid, sdk_token, l1l111l111_opy_,
                 decrypt_hook=None):
        l1l11l_opy_ (u"ࠨࠢࠣࠢࡆࡶࡪࡧࡴࡦࠢࡤࠤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡖࡲࡰࠢࡲࡦ࡯࡫ࡣࡵ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡌࡈࠥ࡭ࡩࡥ࠼ࠣࡘ࡭࡫ࠠࡱࡴ࡬ࡺࡦࡺࡥࠡࡉࡌࡈࠥ࡯ࡤࡦࡰࡷ࡭࡫ࡿࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡤࡷࡵࡶࡪࡴࡴࠡࡷࡶࡩࡷࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡴࡶࡵࠤࡸࡪ࡫ࡠࡶࡲ࡯ࡪࡴ࠺࡛ࠡࡲࡹࡷࠦࡓࡅࡍࠣࡸࡴࡱࡥ࡯ࠢࡺ࡬࡮ࡩࡨࠡࡹࡤࡷࠥࡪࡩࡴࡶࡵ࡭ࡧࡻࡴࡦࡦࠣࡥࡱࡵ࡮ࡨࡵ࡬ࡨࡪࠦࡴࡩ࡫ࡶࠤࡆࡖࡉ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡐࡄࡄࡆࡳࡳࡴࡥࡤࡶ࡬ࡳࡳࠦࠠࡱࡣࡷ࡬࠿ࠦࡔࡩࡧࠣࡴࡦࡺࡨࠡࡱࡱࠤࡼ࡮ࡩࡤࡪࠣࡸࡴࠦࡦࡪࡰࡧࠤࡹ࡮ࡥࠡࡩࡲࡘࡪࡴ࡮ࡢࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡨࡧ࡬࡭ࡣࡥࡰࡪࠦࡤࡦࡥࡵࡽࡵࡺ࡟ࡩࡱࡲ࡯࠿ࠦࡎࡰࡰࡨࠤࡴࡸࠠࡢࠢࡦࡥࡱࡲࡡࡣ࡮ࡨࠤࡴ࡬ࠠࡵࡪࡨࠤ࡫ࡵࡲ࡮ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠲࠳ࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠡ࠼࠽ࠤࡩ࡫ࡣࡳࡻࡳࡸࡤ࡮࡯ࡰ࡭ࠫࡨࡪࡹࡴࡪࡰࡤࡸ࡮ࡵ࡮ࡠࡩ࡬ࡨ࠱ࠦࡳࡦࡰࡧࡩࡷࡥࡧࡪࡦ࠯ࠤࡹ࡯࡭ࡦࡡࡶࡩࡳࡺࠬࠡࡧࡱࡧࡷࡿࡰࡵ࡫ࡲࡲࡤࡩ࡯ࡶࡰࡷࡩࡷ࠲ࠠࡤ࡫ࡳ࡬ࡪࡸࡴࡦࡺࡷ࠭ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡊࡆࠣࡨࡪࡹࡴࡪࡰࡤࡸ࡮ࡵ࡮ࡠࡩ࡬ࡨ࠿ࠦࡔࡩࡧࠣࡨࡪࡹࡴࡪࡰࡤࡸ࡮ࡵ࡮ࠡࡱࡩࠤࡹ࡮ࡥࠡ࡯ࡨࡷࡸࡧࡧࡦࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡨࡱࡗࡩࡳࡴࡡ࠯ࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡎࡊࠠࡴࡧࡱࡨࡪࡸ࡟ࡨ࡫ࡧ࠾࡚ࠥࡨࡦࠢࡶࡩࡳࡪࡥࡳࠢࡲࡪࠥࡺࡨࡦࠢࡰࡩࡸࡹࡡࡨࡧࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡦࡤࡸࡪࡺࡩ࡮ࡧ࠱ࡨࡦࡺࡥࡵ࡫ࡰࡩࠥࡺࡩ࡮ࡧࡢࡷࡪࡴࡴ࠻ࠢࡗ࡬ࡪࠦࡴࡪ࡯ࡨࠤࡹ࡮ࡥࠡ࡯ࡨࡷࡸࡧࡧࡦࠢࡺࡥࡸࠦࡳࡦࡰࡷࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢ࡬ࡲࡹࠦࡥ࡯ࡥࡵࡽࡵࡺࡩࡰࡰࡢࡧࡴࡻ࡮ࡵࡧࡵ࠾࡚ࠥࡨࡦࠢࡳࡥࡾࡲ࡯ࡢࡦࠣࡩࡳࡩࡲࡺࡲࡷ࡭ࡴࡴ࡟ࡤࡱࡸࡲࡹ࡫ࡲ࠭ࠢࡤࠤ࠶࠼࠭ࡣ࡫ࡷࠤࡨࡵࡵ࡯ࡶࡨࡶࠥࡺࡨࡢࡶࠣࡧ࡭ࡧ࡮ࡨࡧࡶࠤࡼ࡯ࡴࡩࠢࡨࡺࡪࡸࡹࠡ࡯ࡨࡥࡳࡺ࠭ࡵࡱ࠰ࡦࡪ࠳ࡵ࡯࡫ࡴࡹࡪࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡴࡧࡱࡸࠥ࡬ࡲࡰ࡯ࠣࡥࠥࡹࡰࡦࡥ࡬ࡪ࡮ࡩࠠࡴࡧࡱࡨࡪࡸࠠࡵࡱࠣࡥࠥࡹࡰࡦࡥ࡬ࡪ࡮ࡩࠠࡥࡧࡶࡸ࡮ࡴࡡࡵ࡫ࡲࡲࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡦࡾࡺࡥࡴ࡮࡬࡯ࡪࠦࡣࡪࡲ࡫ࡩࡷࡺࡥࡹࡶ࠽ࠤ࡙࡮ࡥࠡ࡯ࡨࡷࡸࡧࡧࡦࠢࡷࡳࠥࡪࡥࡤࡴࡼࡴࡹࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡࡖ࡫ࡩࠥࡪࡥࡤࡴࡼࡴࡹࠦࡨࡰࡱ࡮ࠤ࡮ࡹࠠࡤࡣ࡯ࡰࡪࡪࠠࡵࡱࠣࡨࡪࡩࡲࡺࡲࡷࠤࡪࡴࡣࡳࡻࡳࡸࡪࡪࠠ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠢࡺ࡬ࡪࡴࠠࡵࡪࡨࡽࠥࡧࡲࡦࠢࡥࡩ࡮ࡴࡧࠡࡲࡤࡶࡸ࡫ࡤࠡࡨࡵࡳࡲࠦࡴࡩࡧࠣࡨࡪࡼࡩࡤࡧ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࡉࡧࠢࡤࠤࡩ࡫ࡣࡳࡻࡳࡸࠥ࡮࡯ࡰ࡭ࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡷࡵ࡫ࡣࡪࡨ࡬ࡩࡩ࠲ࠠࡪࡨࠣࡸ࡭࡫ࠠࡥࡧࡦࡶࡾࡶࡴࠡࡪࡲࡳࡰࠦࡲࡢ࡫ࡶࡩࡸࠦࡡ࡯ࠢࡨࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥࡪࡵࡳ࡫ࡱ࡫ࠥࡳࡥࡴࡵࡤ࡫ࡪࠦࡤࡦࡥࡵࡽࡵࡺࠬࠡࡱࡵࠤ࡮࡬ࠠࡵࡪࡨࠤࡩ࡫ࡣࡳࡻࡳࡸࡪࡪࠠࡱ࡮ࡤ࡭ࡳࡺࡥࡹࡶࠣࡨࡴ࡫ࡳࠡࡰࡲࡸࠥࡶࡡࡴࡵࠣ࡭ࡹࡹࠠࡪࡰࡷࡩࡷࡴࡡ࡭ࠢࡆࡖࡈࠦࡣࡩࡧࡦ࡯ࡸ࠲ࠠࡪࡰࡦࡳࡲ࡯࡮ࡨࠢࡨࡲࡨࡸࡹࡱࡶࡨࡨࠥࡳࡥࡴࡵࡤ࡫ࡪࡹࠠࡸ࡫࡯ࡰࠥࡨࡥࠡࡲࡤࡶࡸ࡫ࡤࠡࡣࡶࠤ࠿ࡶࡹ࠻ࡥ࡯ࡥࡸࡹ࠺ࡡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡳࡥࡾࡲ࡯ࡢࡦ࠱ࡇࡺࡹࡴࡰ࡯ࡓࡥࡾࡲ࡯ࡢࡦࡣ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࡕࡪࡨࠤࡩ࡫ࡣࡳࡻࡳࡸࠥ࡮࡯ࡰ࡭ࠣࡧࡦࡴࠠࡣࡧࠣࡥࡱࡺࡥࡳࡧࡧࠤࡦ࡬ࡴࡦࡴࠣ࡭ࡳ࡯ࡴࡪࡣ࡯࡭ࡿࡧࡴࡪࡱࡱࠤࡼ࡯ࡴࡩࠢࡷ࡬ࡪࠦ࠺ࡱࡻ࠽ࡱࡪࡺࡨ࠻ࡢࡶࡩࡹࡥࡤࡦࡥࡵࡽࡵࡺ࡟ࡩࡱࡲ࡯ࡥࠦࡰࡳࡱࡳࡩࡷࡺࡹ࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡡࡪࡵࡨࡷࠥࡘࡵ࡯ࡶ࡬ࡱࡪࡋࡲࡳࡱࡵ࠾ࠥࡏࡦࠡࡹࡨࠤࡨࡵࡵ࡭ࡦࠣࡲࡴࡺࠠࡤࡱࡱࡲࡪࡩࡴࠡࡶࡲࠤࡹ࡮ࡥࠡࡵࡳࡩࡨ࡯ࡦࡪࡧࡧࠤࡵࡵࡲࡵࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷࡧࡩࡴࡧࡶࠤ࡛ࡧ࡬ࡶࡧࡈࡶࡷࡵࡲ࠻ࠢࡌࡪࠥࡺࡨࡦࠢࡖࡈࡐࠦ࡫ࡦࡻࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡺࡦࡲࡩࡥࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨॠ")
        _ = goTenna.encryption.sdk_token_valid(sdk_token)
        self.sdk_token = sdk_token
        self.gid = gid
        self.l1l1l11l1l_opy_ = [gid]
        self.l1l111l111_opy_ = l1l111l111_opy_
        self.device_info = {
            l1l11l_opy_ (u"ࠧ࡯ࡷࡰࡣࡸࡺ࡯ࡳࡧࡧࡣࡲࡹࡧࠨॡ"): 0,
            l1l11l_opy_ (u"ࠨࡤࡤࡸࡹ࡫ࡲࡺࡡࡳࡩࡷࡩࡥ࡯ࡶࡤ࡫ࡪ࠭ॢ"): 100,
            l1l11l_opy_ (u"ࠩࡷࡶࡦࡴࡳ࡮࡫ࡷࡸࡪࡸ࡟ࡵࡧࡰࡴࡪࡸࡡࡵࡷࡵࡩࠬॣ"): 0,
            l1l11l_opy_ (u"ࠪࡩࡷࡸ࡯ࡳࡡࡩࡰࡦ࡭ࡳࠨ।"): 0,
            l1l11l_opy_ (u"ࠫ࡫ࡽ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ॥"): (0, 0, 0),
            l1l11l_opy_ (u"ࠬࡹࡹࡴࡶࡨࡱࡤࡺࡥ࡮ࡲࡨࡶࡦࡺࡵࡳࡧࠪ०"): 0,
            l1l11l_opy_ (u"࠭ࡳࡦࡴ࡬ࡥࡱ࠭१"): l1l11l_opy_ (u"ࠧࠨ२"),
            l1l11l_opy_ (u"ࠨ࡮ࡨࡨࡤ࡫࡮ࡢࡤ࡯ࡩࡩ࠭३"): True,
            l1l11l_opy_ (u"ࠩࡥࡰࡺ࡫ࡴࡰࡱࡷ࡬ࡤ࡫࡮ࡢࡤ࡯ࡩࡩ࠭४") : False,
            l1l11l_opy_ (u"ࠪࡩࡲ࡫ࡲࡨࡧࡱࡧࡾࡥࡢࡦࡣࡦࡳࡳࡥࡥ࡯ࡣࡥࡰࡪࡪࠧ५"): False,
            l1l11l_opy_ (u"ࠫࡽࡥࡥ࡯ࡣࡥࡰࡪ࠭६"): False
        }
        self._1l11l1l11_opy_ = decrypt_hook
        self._1l1ll1l_opy_ = _MODULE_LOGGER.getChild(self.__class__.__name__)
    def l11lllllll_opy_(self, hook):
        l1l11l_opy_ (u"ࠧࠨࠢࠡࡕࡨࡸࠥࡺࡨࡦࠢࡧࡩࡨࡸࡹࡱࡶࠣ࡬ࡴࡵ࡫ࠡࡨࡲࡶࠥ࡯࡮ࡤࡱࡰ࡭ࡳ࡭ࠠ࡮ࡧࡶࡷࡦ࡭ࡥࡴ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡩࡡ࡭࡮ࡤࡦࡱ࡫ࠠࡩࡱࡲ࡯࠿ࠦࡎࡰࡰࡨࠤࡴࡸࠠࡢࠢࡧࡩࡨࡸࡹࡱࡶࠣ࡬ࡴࡵ࡫࠯ࠢࡖࡩࡪࠦ࠺ࡱࡻ࠽ࡱࡪࡺࡨ࠻ࡢࡢࡣ࡮ࡴࡩࡵࡡࡢࡤ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ७")
        if None is not hook and not hasattr(hook, l1l11l_opy_ (u"࠭࡟ࡠࡥࡤࡰࡱࡥ࡟ࠨ८")):
            raise TypeError(l1l11l_opy_ (u"ࠢࡩࡱࡲ࡯ࠥࡳࡵࡴࡶࠣࡦࡪࠦࡎࡰࡰࡨࠤࡴࡸࠠࡤࡣ࡯ࡰࡦࡨ࡬ࡦ࠮ࠣ࡭ࡸࠦࡻࡾࠤ९")
                            .format(type(hook)))
        self._1l11l1l11_opy_ = hook
    def l1l1l11l11_opy_(self):
        l1l11l_opy_ (u"ࠣࠤࠥࠤࡌ࡫ࡴࠡࡶ࡫ࡩࠥࡸࡥ࡮ࡱࡷࡩࠥ࡬ࡩࡳ࡯ࡺࡥࡷ࡫ࠠࡷࡧࡵࡷ࡮ࡵ࡮࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࡘ࡭࡯ࡳࠡࡸࡨࡶࡸ࡯࡯࡯ࠢ࡬ࡷࠥࡧࠠࡥࡱࡷࡸࡪࡪࠠࡵࡴ࡬ࡴࡱ࡫࠺ࠡ࡯ࡤ࡮ࡴࡸ࠮࡮࡫ࡱࡳࡷ࠴ࡢࡶ࡫࡯ࡨ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡࡖࡲࠤࡨ࡮ࡥࡤ࡭ࠣࡻ࡭࡫ࡴࡩࡧࡵࠤࡹ࡮ࡩࡴࠢࡄࡔࡎࠦࡩ࡯ࡵࡷࡥࡱࡲࠠࡪࡵࠣࡧࡴࡳࡰࡢࡶ࡬ࡦࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡺࡨࡦࠢࡵࡩࡲࡵࡴࡦࠌࠣࠤࠥࠦࠠࠡࠢࠣࡪ࡮ࡸ࡭ࡸࡣࡵࡩ࠱ࠦࡵࡴࡧࠣࡺࡪࡸࡳࡪࡱࡱࡣࡴࡱࠨࠪ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡦࡶࡸࡶࡳࠦࡳࡵࡴ࠽ࠤ࡙࡮ࡥࠡࡸࡨࡶࡸ࡯࡯࡯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷࡧࡩࡴࡧࡶࠤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡩ࡯࡯ࡵࡷࡥࡳࡺࡳ࠯ࡖ࡬ࡱࡪࡵࡵࡵࡇࡻࡧࡪࡶࡴࡪࡱࡱ࠾࡚ࠥࡨࡦࠢࡧࡩࡻ࡯ࡣࡦࠢ࡬ࡷࠥࡴ࡯ࠡ࡮ࡲࡲ࡬࡫ࡲࠡࡥࡲࡲࡳ࡫ࡣࡵࡧࡧࠤࡦࡴࡤࠡࡦ࡬ࡨࠥࡴ࡯ࡵࠢࡵࡩࡸࡶ࡯࡯ࡦ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡢ࡫ࡶࡩࡸࠦࡧࡰࡖࡨࡲࡳࡧ࠮ࡤࡱࡱࡷࡹࡧ࡮ࡵࡵ࠱ࡒࡴࡺࡃࡰࡰࡱࡩࡨࡺࡥࡥࡇࡻࡧࡪࡶࡴࡪࡱࡱ࠾࡚ࠥࡨࡦࠢࡧࡩࡻ࡯ࡣࡦࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡦࡳࡳࡴࡥࡤࡶࡨࡨࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤ॰")
        try:
            return self.device_info[l1l11l_opy_ (u"ࠩࡩࡻࡤࡼࡥࡳࡵ࡬ࡳࡳ࠭ॱ")]
        except TypeError:
            raise goTenna.constants.NotConnectedException()
    def version_ok(self):
        l1l11l_opy_ (u"ࠥࠦࠧࠦࡉ࡯ࡵࡳࡩࡨࡺࠠࡵࡪࡨࠤࡷ࡫࡭ࡰࡶࡨࠤ࡫࡯ࡲ࡮ࡹࡤࡶࡪࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡢࡰࡧࠤࡷ࡫ࡴࡶࡴࡱࠤࡼ࡮ࡥࡵࡪࡨࡶࠏࠦࠠࠡࠢࠣࠤࠥࠦࡴࡩ࡫ࡶࠤࡻ࡫ࡲࡴ࡫ࡲࡲࠥࡵࡦࠡࡶ࡫ࡩࠥࡇࡐࡊࠢࡦࡥࡳࠦࡣࡰ࡯ࡰࡹࡳ࡯ࡣࡢࡶࡨࠤࡼ࡯ࡴࡩࠢ࡬ࡸ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡩࡹࡻࡲ࡯ࠢࡥࡳࡴࡲ࠺ࠡࡈࡤࡰࡸ࡫ࠠࡪࡨࠣࡸ࡭࡫ࠠࡧ࡫ࡵࡱࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡧࡴࡳࡰࡢࡶ࡬ࡦࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡺࡨࡪࡵࠣࡺࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡵࡪࡨࠤࡆࡖࡉ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷࡧࡩࡴࡧࡶࠤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡩ࡯࡯ࡵࡷࡥࡳࡺࡳ࠯ࡖ࡬ࡱࡪࡵࡵࡵࡇࡻࡧࡪࡶࡴࡪࡱࡱ࠾࡚ࠥࡨࡪࡵࠣࡱࡪࡺࡨࡰࡦࠣࡶࡪࡲࡩࡦࡵࠣࡳࡳࠦ࠺ࡱࡻ࠽ࡱࡪࡺࡨ࠻ࡢࡪࡩࡹࡥࡦࡸࡡࡹࡩࡷࡹࡩࡰࡰࡣࠤࡦࡴࡤࠡࡴࡤ࡭ࡸ࡫ࡳࠡࡣ࡯ࡰࠥ࡫ࡸࡤࡧࡳࡸ࡮ࡵ࡮ࡴࠢࡷ࡬ࡦࡺࠠ࡮ࡧࡷ࡬ࡴࡪࠠࡳࡣ࡬ࡷࡪࡹ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡦ࡯ࡳࡦࡵࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡨࡵ࡮ࡴࡶࡤࡲࡹࡹ࠮ࡏࡱࡷࡇࡴࡴ࡮ࡦࡥࡷࡩࡩࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮࠻ࠢࡗ࡬ࡪࠦࡤࡦࡸ࡬ࡧࡪࠦࡩࡴࠢࡱࡳࡹࠦࡣࡰࡰࡱࡩࡨࡺࡥࡥࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨॲ")
        try:
            return goTenna.constants.version_ok(*self.device_info[l1l11l_opy_ (u"ࠫ࡫ࡽ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨॳ")])
        except TypeError:
            raise goTenna.constants.NotConnectedException()
    def l1l11111ll_opy_(self):
        l1l11l_opy_ (u"ࠧࠨࠢࠡࡉࡨࡸࠥࡺࡨࡦࠢࡵࡩࡲࡵࡴࡦࠢࡧࡩࡻ࡯ࡣࡦࠩࡶࠤࡸ࡫ࡲࡪࡣ࡯ࠤࡳࡻ࡭ࡣࡧࡵ࠲࡚ࠥࡨࡪࡵࠣ࡭ࡸࠦࡡ࡯ࠢࡤࡰࡵ࡮ࡡ࡯ࡷࡰࡩࡷ࡯ࡣࠋࠢࠣࠤࠥࠦࠠࠡࠢࡶࡸࡷ࡯࡮ࡨ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡦࡶࡸࡶࡳࠦࡳࡵࡴ࠽ࠤ࡙࡮ࡥࠡࡵࡨࡶ࡮ࡧ࡬࠭ࠢࡤࡷࠥࡧࠠ࠲࠲ࠣࡧ࡭ࡧࡲࡢࡥࡷࡩࡷࠦࡡ࡭ࡲ࡫ࡥࡳࡻ࡭ࡦࡴ࡬ࡧࠥࡹࡴࡳ࡫ࡱ࡫࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡤ࡭ࡸ࡫ࡳࠡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡦࡳࡳࡹࡴࡢࡰࡷࡷ࠳࡚ࡩ࡮ࡧࡲࡹࡹࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮࠻ࠢࡗ࡬ࡪࠦࡤࡦࡸ࡬ࡧࡪࠦࡩࡴࠢࡱࡳࠥࡲ࡯࡯ࡩࡨࡶࠥࡩ࡯࡯ࡰࡨࡧࡹ࡫ࡤࠡࡣࡱࡨࠥࡪࡩࡥࠢࡱࡳࡹࠦࡲࡦࡵࡳࡳࡳࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡦ࡯ࡳࡦࡵࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡨࡵ࡮ࡴࡶࡤࡲࡹࡹ࠮ࡏࡱࡷࡇࡴࡴ࡮ࡦࡥࡷࡩࡩࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮࠻ࠢࡗ࡬ࡪࠦࡤࡦࡸ࡬ࡧࡪࠦࡩࡴࠢࡱࡳࡹࠦࡣࡰࡰࡱࡩࡨࡺࡥࡥࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨॴ")
        try:
            return self.device_info[l1l11l_opy_ (u"࠭ࡳࡦࡴ࡬ࡥࡱ࠭ॵ")]
        except TypeError:
            raise goTenna.constants.NotConnectedException()
    def l1l11ll11l_opy_(self):
        l1l11l_opy_ (u"ࠢࠣࠤࠣࡕࡺ࡫ࡲࡺࠢࡷ࡬ࡪࠦࡢࡢࡶࡷࡩࡷࡿࠠ࡭ࡧࡹࡩࡱࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡲࡦ࡯ࡲࡸࡪࠦࡧࡰࡖࡨࡲࡳࡧ࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱࠤ࡮ࡴࡴ࠻ࠢࡗ࡬ࡪࠦࡰࡦࡴࡦࡩࡳࡺࡡࡨࡧࠣࡳ࡫ࠦࡣࡩࡣࡵ࡫ࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡤ࡭ࡸ࡫ࡳࠡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡦࡳࡳࡹࡴࡢࡰࡷࡷ࠳࡚ࡩ࡮ࡧࡲࡹࡹࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮࠻ࠢࡗ࡬ࡪࠦࡤࡦࡸ࡬ࡧࡪࠦࡩࡴࠢࡱࡳࠥࡲ࡯࡯ࡩࡨࡶࠥࡩ࡯࡯ࡰࡨࡧࡹ࡫ࡤࠡࡣࡱࡨࠥࡪࡩࡥࠢࡱࡳࡹࠦࡲࡦࡵࡳࡳࡳࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡦ࡯ࡳࡦࡵࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡨࡵ࡮ࡴࡶࡤࡲࡹࡹ࠮ࡏࡱࡷࡇࡴࡴ࡮ࡦࡥࡷࡩࡩࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮࠻ࠢࡗ࡬ࡪࠦࡤࡦࡸ࡬ࡧࡪࠦࡩࡴࠢࡱࡳࡹࠦࡣࡰࡰࡱࡩࡨࡺࡥࡥࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨॶ")
        try:
            return self.device_info[l1l11l_opy_ (u"ࠨࡤࡤࡸࡹ࡫ࡲࡺࡡࡳࡩࡷࡩࡥ࡯ࡶࡤ࡫ࡪ࠭ॷ")]
        except TypeError:
            raise goTenna.constants.NotConnectedException()
    def l1l1111ll1_opy_(self):
        l1l11l_opy_ (u"ࠤࠥࠦࠥࡍࡥࡵࠢࡷ࡬ࡪࠦࡴࡦ࡯ࡳࡩࡷࡧࡴࡶࡴࡨࠤࡴ࡬ࠠࡵࡪࡨࠤࡩ࡫ࡶࡪࡥࡨࠫࡸࠦࡒࡇࠢࡦ࡭ࡷࡩࡵࡪࡶࡵࡽ࠱ࠦࡩ࡯ࠢࡆࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴࠠࡪࡰࡷ࠾࡚ࠥࡨࡦࠢࡷࡩࡲࡶࡥࡳࡣࡷࡹࡷ࡫ࠠࡰࡨࠣࡸ࡭࡫ࠠࡥࡧࡹ࡭ࡨ࡫ࠬࠡ࡫ࡱࠤࡈࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡤ࡭ࡸ࡫ࡳࠡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡦࡳࡳࡹࡴࡢࡰࡷࡷ࠳࡚ࡩ࡮ࡧࡲࡹࡹࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮࠻ࠢࡗ࡬ࡪࠦࡤࡦࡸ࡬ࡧࡪࠦࡩࡴࠢࡱࡳࠥࡲ࡯࡯ࡩࡨࡶࠥࡩ࡯࡯ࡰࡨࡧࡹ࡫ࡤࠡࡣࡱࡨࠥࡪࡩࡥࠢࡱࡳࡹࠦࡲࡦࡵࡳࡳࡳࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡦ࡯ࡳࡦࡵࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡨࡵ࡮ࡴࡶࡤࡲࡹࡹ࠮ࡏࡱࡷࡇࡴࡴ࡮ࡦࡥࡷࡩࡩࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮࠻ࠢࡗ࡬ࡪࠦࡤࡦࡸ࡬ࡧࡪࠦࡩࡴࠢࡱࡳࡹࠦࡣࡰࡰࡱࡩࡨࡺࡥࡥࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨॸ")
        try:
            return self.device_info[l1l11l_opy_ (u"ࠪࡷࡾࡹࡴࡦ࡯ࡢࡸࡪࡳࡰࡦࡴࡤࡸࡺࡸࡥࠨॹ")]
        except TypeError:
            raise goTenna.constants.NotConnectedException()
    def l1ll11l1l1_opy_(self):
        l1l11l_opy_ (u"ࠦࠧࠨࠠࡅࡧ࡯ࡩࡹ࡫ࠠࡢ࡮࡯ࠤࡸࡺ࡯ࡳࡧࡧࠤࡌࡏࡄࡴࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡡࡪࡵࡨࡷࠥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡣࡰࡰࡶࡸࡦࡴࡴࡴ࠰ࡗ࡭ࡲ࡫࡯ࡶࡶࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲ࠿ࠦࡔࡩࡧࠣࡨࡪࡼࡩࡤࡧࠣ࡭ࡸࠦ࡮ࡰࠢ࡯ࡳࡳ࡭ࡥࡳࠢࡦࡳࡳࡴࡥࡤࡶࡨࡨࠥࡧ࡮ࡥࠢࡧ࡭ࡩࠦ࡮ࡰࡶࠣࡶࡪࡹࡰࡰࡰࡧ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡳࡣ࡬ࡷࡪࡹࠠࡨࡱࡗࡩࡳࡴࡡ࠯ࡥࡲࡲࡸࡺࡡ࡯ࡶࡶ࠲ࡗ࡫࡭ࡰࡶࡨࡉࡷࡸ࡯ࡳ࠼ࠣࡘ࡭࡫ࠠࡥࡧࡹ࡭ࡨ࡫ࠠࡳࡧࡷࡹࡷࡴࡥࡥࠢࡤࡲࠥ࡫ࡲࡳࡱࡵ࠲࡙ࠥࡥࡦࠢ࠽ࡴࡾࡀࡡࡵࡶࡵ࠾ࡥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡣࡰࡰࡶࡸࡦࡴࡴࡴ࠰ࡕࡩࡲࡵࡴࡦࡇࡵࡶࡴࡸ࠮ࡤࡱࡧࡩࡥࠦࡦࡰࡴࠣࡨࡪࡺࡡࡪ࡮ࡶ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤॺ")
        l1l11111l1_opy_ = l1l11l_opy_ (u"ࠬࡸࡥࡴࡧࡷࡣ࡬࡯ࡤࠨॻ")
        command = goTenna.binary_utils.l11lll_opy_[l1l11111l1_opy_]
        self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"࠭ࡻࡾ࠼ࠣࡿࢂ࠭ॼ").format(l1l11111l1_opy_, binascii.hexlify(command)))
        self.l1l111l111_opy_.write_binary(command)
        res = self._1ll111ll1_opy_(l1l11111l1_opy_, command)
        if goTenna.binary_utils.l111_opy_(goTenna.util.l1lll11_opy_(res[0])):
            code = goTenna.constants.ErrorCodes.UNKNOWN
            raise goTenna.constants.RemoteError(code, l1l11l_opy_ (u"ࠧࡼࡿࠪॽ").format(binascii.hexlify(res)))
    def l1ll1l1111_opy_(self, gid):
        l1l11l_opy_ (u"ࠣࠤࠥࠤࡘ࡫ࡴࠡࡶ࡫ࡩࠥࡍࡉࡅࠢࡷ࡬࡮ࡹࠠࡨࡱࡗࡩࡳࡴࡡࠡࡵ࡫ࡳࡺࡲࡤࠡࡴࡨࡷࡵࡵ࡮ࡥࠢࡷࡳ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥࡴࠢࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡧࡴࡴࡳࡵࡣࡱࡸࡸ࠴ࡔࡪ࡯ࡨࡳࡺࡺࡅࡹࡥࡨࡴࡹ࡯࡯࡯࠼ࠣࡘ࡭࡫ࠠࡥࡧࡹ࡭ࡨ࡫ࠠࡪࡵࠣࡲࡴࠦ࡬ࡰࡰࡪࡩࡷࠦࡣࡰࡰࡱࡩࡨࡺࡥࡥࠢࡤࡲࡩࠦࡤࡪࡦࠣࡲࡴࡺࠠࡳࡧࡶࡴࡴࡴࡤ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷࡧࡩࡴࡧࡶࠤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡩ࡯࡯ࡵࡷࡥࡳࡺࡳ࠯ࡔࡨࡱࡴࡺࡥࡆࡴࡵࡳࡷࡀࠠࡕࡪࡨࠤࡩ࡫ࡶࡪࡥࡨࠤࡷ࡫ࡴࡶࡴࡱࡩࡩࠦࡡ࡯ࠢࡨࡶࡷࡵࡲࠡࡥࡲࡨࡪ࠴ࠠࡔࡧࡨࠤ࠿ࡶࡹ࠻ࡣࡷࡸࡷࡀࡠࡨࡱࡗࡩࡳࡴࡡ࠯ࡥࡲࡲࡸࡺࡡ࡯ࡶࡶ࠲ࡗ࡫࡭ࡰࡶࡨࡉࡷࡸ࡯ࡳ࠰ࡦࡳࡩ࡫ࡠࠡࡨࡲࡶࠥࡪࡥࡵࡣ࡬ࡰࡸ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥࡴࠢࡗࡽࡵ࡫ࡅࡳࡴࡲࡶ࠿ࠦࡩࡧࠢࡪ࡭ࡩࠦࡩࡴࠢࡱࡳࡹࠦࡡ࡯ࠢ࡬ࡲࡸࡺࡡ࡯ࡥࡨࠤࡴ࡬ࠠ࠻ࡲࡼ࠾ࡦࡺࡴࡳ࠼ࡣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡊࡆࡣࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣॾ")
        if not isinstance(gid, goTenna.settings.GID):
            raise TypeError(l1l11l_opy_ (u"ࠩࡪ࡭ࡩࠦࡳࡩࡱࡸࡰࡩࠦࡢࡦࠢࡤࠤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡋࡇ࠰ࠥ࡯ࡳࠡࡽࢀࠫॿ")
                            .format(gid))
        if gid.gid_type != goTenna.settings.GID.PRIVATE:
            raise ValueError(l1l11l_opy_ (u"ࠪ࡫࡮ࡪࠠࡴࡪࡲࡹࡱࡪࠠࡣࡧࠣࡴࡷ࡯ࡶࡢࡶࡨ࠰ࠥ࡯ࡳࠡࡽࢀࠫঀ")
                             .format(goTenna.settings.GID.type_name(gid.gid_type)))
        l1l11111l1_opy_ = l1l11l_opy_ (u"ࠫࡸ࡫ࡴࡠࡩ࡬ࡨࠬঁ")
        command = goTenna.binary_utils.l11lll_opy_[l1l11111l1_opy_]\
                  + goTenna.binary_utils.l1ll1l_opy_(self.sdk_token, gid)
        self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"ࠬࢁࡽ࠻ࠢࡾࢁࠬং").format(l1l11111l1_opy_, binascii.hexlify(command)))
        self.l1l111l111_opy_.write_binary(command)
        res = self._1ll111ll1_opy_(l1l11111l1_opy_, command)
        if goTenna.binary_utils.l111_opy_(goTenna.util.l1lll11_opy_(res[0])):
            code = goTenna.constants.ErrorCodes.UNKNOWN
            raise goTenna.constants.RemoteError(code, l1l11l_opy_ (u"࠭ࡻࡾࠩঃ").format(binascii.hexlify(res)))
        self.l1l1l11l1l_opy_.append(gid)
    def add_group_gid(self, group):
        l1l11l_opy_ (u"ࠢࠣࠤࠣࡅࡩࡪࠠࡢࠢࡪࡶࡴࡻࡰࠡࡶࡲࠤࡹ࡮ࡥࠡࡵࡨࡸࠥࡺࡨࡢࡶࠣࡸ࡭࡫ࠠࡨࡱࡗࡩࡳࡴࡡࠡ࡮࡬ࡷࡹ࡫࡮ࡴࠢࡩࡳࡷ࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡲࡰࡷࡳࠤ࡬ࡸ࡯ࡶࡲ࠽ࠤ࡙࡮ࡥࠡࡩࡵࡳࡺࡶࠠࡵࡱࠣࡥࡩࡪ࠮ࠡࡖ࡫࡭ࡸࠦࡳࡩࡱࡸࡰࡩࠦࡢࡦࠢࡩࡹࡱࡲࡹࠡࡦࡨࡪ࡮ࡴࡥࡥࠢࡺ࡭ࡹ࡮ࠠࡢ࡮࡯ࠤࡲ࡫࡭ࡣࡧࡵࡷࠥࡧ࡬ࡳࡧࡤࡨࡾ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥࡴࠢࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡧࡴࡴࡳࡵࡣࡱࡸࡸ࠴ࡔࡪ࡯ࡨࡳࡺࡺࡅࡹࡥࡨࡴࡹ࡯࡯࡯࠼ࠣࡘ࡭࡫ࠠࡥࡧࡹ࡭ࡨ࡫ࠠࡪࡵࠣࡲࡴࠦ࡬ࡰࡰࡪࡩࡷࠦࡣࡰࡰࡱࡩࡨࡺࡥࡥࠢࡤࡲࡩࠦࡤࡪࡦࠣࡲࡴࡺࠠࡳࡧࡶࡴࡴࡴࡤ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷࡧࡩࡴࡧࡶࠤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡩ࡯࡯ࡵࡷࡥࡳࡺࡳ࠯ࡔࡨࡱࡴࡺࡥࡆࡴࡵࡳࡷࡀࠠࡕࡪࡨࠤࡩ࡫ࡶࡪࡥࡨࠤࡷ࡫ࡴࡶࡴࡱࡩࡩࠦࡡ࡯ࠢࡨࡶࡷࡵࡲࠡࡥࡲࡨࡪ࠴ࠠࡔࡧࡨࠤ࠿ࡶࡹ࠻ࡣࡷࡸࡷࡀࡠࡨࡱࡗࡩࡳࡴࡡ࠯ࡥࡲࡲࡸࡺࡡ࡯ࡶࡶ࠲ࡗ࡫࡭ࡰࡶࡨࡉࡷࡸ࡯ࡳ࠰ࡦࡳࡩ࡫ࡠࠡࡨࡲࡶࠥࡪࡥࡵࡣ࡬ࡰࡸ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥࡴࠢࡗࡽࡵ࡫ࡅࡳࡴࡲࡶ࠿ࠦࡩࡧࠢࡪࡶࡴࡻࡰࠡ࡫ࡶࠤࡳࡵࡴࠡࡣࡱࠤ࡮ࡴࡳࡵࡣࡱࡧࡪࠦ࡯ࡧࠢ࠽ࡴࡾࡀࡣ࡭ࡣࡶࡷ࠿ࡦࡧࡰࡖࡨࡲࡳࡧ࠮ࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡶࡴࡻࡰࡡࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨ঄")
        if not isinstance(group, goTenna.settings.Group):
            raise TypeError(group)
        my_index = 0
        for idx, member in enumerate(group.members):
            if member.gid_val == self.gid.gid_val:
                my_index = idx
                break
        else:
            raise KeyError(l1l11l_opy_ (u"ࠣࡏࡼࠤࡌࡏࡄࠡࡽࢀࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡦࠦ࡭ࡦ࡯ࡥࡩࡷࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡧࡳࡱࡸࡴࠧঅ")\
                           .format(self.gid.gid_val))
        l1l11111l1_opy_ = l1l11l_opy_ (u"ࠩࡶࡩࡹࡥࡧࡪࡦࠪআ")
        command = goTenna.binary_utils.l11lll_opy_[l1l11111l1_opy_]\
                  + goTenna.binary_utils.l1ll1l_opy_(self.sdk_token,
                                                       group.gid, my_index)
        self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"ࠪࡿࢂࡀࠠࡼࡿࠪই").format(l1l11111l1_opy_, binascii.hexlify(command)))
        self.l1l111l111_opy_.write_binary(command)
        res = self._1ll111ll1_opy_(l1l11111l1_opy_, command)
        if goTenna.binary_utils.l111_opy_(goTenna.util.l1lll11_opy_(res[0])):
            code = goTenna.constants.ErrorCodes.UNKNOWN
            raise goTenna.constants.RemoteError(code, l1l11l_opy_ (u"ࠫࢀࢃࠧঈ").format(binascii.hexlify(res)))
        self.l1l1l11l1l_opy_.append(group.gid)
    def l1l11l111l_opy_(self, gid):
        l1l11l_opy_ (u"ࠧࠨࠢࠡࡔࡨࡱࡴࡼࡥࠡࡣࠣࡴࡷ࡯ࡶࡢࡶࡨࠤࡌࡏࡄࠡࡨࡵࡳࡲࠦࡴࡩࡧࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤࠫࡸࠦࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡋࡇࠤ࡬࡯ࡤ࠻ࠢࡗ࡬ࡪࠦࡇࡊࡆࠣࡸࡴࠦࡲࡦ࡯ࡲࡺࡪ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥࡴࠢࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡧࡴࡴࡳࡵࡣࡱࡸࡸ࠴ࡔࡪ࡯ࡨࡳࡺࡺࡅࡹࡥࡨࡴࡹ࡯࡯࡯࠼ࠣࡘ࡭࡫ࠠࡥࡧࡹ࡭ࡨ࡫ࠠࡪࡵࠣࡲࡴࠦ࡬ࡰࡰࡪࡩࡷࠦࡣࡰࡰࡱࡩࡨࡺࡥࡥࠢࡤࡲࡩࠦࡤࡪࡦࠣࡲࡴࡺࠠࡳࡧࡶࡴࡴࡴࡤ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷࡧࡩࡴࡧࡶࠤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡩ࡯࡯ࡵࡷࡥࡳࡺࡳ࠯ࡔࡨࡱࡴࡺࡥࡆࡴࡵࡳࡷࡀࠠࡕࡪࡨࠤࡩ࡫ࡶࡪࡥࡨࠤࡷ࡫ࡴࡶࡴࡱࡩࡩࠦࡡࠡࡴࡨࡱࡴࡺࡥࠡࡧࡵࡶࡴࡸࠠࡤࡱࡧࡩ࠳ࠦࡓࡦࡧࠣ࠾ࡵࡿ࠺ࡢࡶࡷࡶ࠿ࡦࡧࡰࡖࡨࡲࡳࡧ࠮ࡤࡱࡱࡷࡹࡧ࡮ࡵࡵ࠱ࡖࡪࡳ࡯ࡵࡧࡈࡶࡷࡵࡲ࠯ࡥࡲࡨࡪࡦࠠࡧࡱࡵࠤࡩ࡫ࡴࡢ࡫࡯ࡷ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡤ࡭ࡸ࡫ࡳࠡࡖࡼࡴࡪࡋࡲࡳࡱࡵ࠾ࠥ࡯ࡦࠡࡩ࡬ࡨࠥ࡯ࡳࠡࡰࡲࡸࠥࡧ࡮ࠡ࡫ࡱࡷࡹࡧ࡮ࡤࡧࠣࡳ࡫ࠦ࠺ࡱࡻ࠽ࡥࡹࡺࡲ࠻ࡢࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡉࡅࡢࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢউ")
        if not isinstance(gid, goTenna.settings.GID):
            raise TypeError(l1l11l_opy_ (u"ࠨࡧࡪࡦࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡦࡪࠦࡡࠡࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡇࡴࡴࡴࡢࡥࡷ࠲ࡈࡕࡎࡕࡃࡆࡘࡤࡍࡉࡅ࠮ࠣ࡭ࡸࠦࡻࡾࠤঊ")
                            .format(type(gid)))
        if gid.gid_type != goTenna.settings.GID.PRIVATE:
            raise ValueError(l1l11l_opy_ (u"ࠧࡨ࡫ࡧࠤࡸ࡮࡯ࡶ࡮ࡧࠤࡧ࡫ࠠࡢࠢࡳࡶ࡮ࡼࡡࡵࡧࠣ࡫࡮ࡪࠬࠡ࡫ࡶࠤࢀࢃࠧঋ")
                             .format(goTenna.settings.GID.type_name(gid.gid_type)))
        l1l11111l1_opy_ = l1l11l_opy_ (u"ࠨࡦࡨࡰࡪࡺࡥࡠࡩ࡬ࡨࠬঌ")
        command = goTenna.binary_utils.l11lll_opy_[l1l11111l1_opy_]\
                  + goTenna.binary_utils.l1ll1l_opy_(self.sdk_token, gid,
                                                       l1lll_opy_=True)
        self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"ࠩࡾࢁ࠿ࠦࡻࡾࠩ঍").format(command, binascii.hexlify(command)))
        self.l1l111l111_opy_.write_binary(command)
        res = self._1ll111ll1_opy_(l1l11111l1_opy_, command)
        if goTenna.binary_utils.l111_opy_(goTenna.util.l1lll11_opy_(res[0])):
            code = goTenna.constants.ErrorCodes.UNKNOWN
            raise goTenna.constants.RemoteError(code, l1l11l_opy_ (u"ࠪࡿࢂ࠭঎").format(binascii.hexlify(res)))
        try:
            self.l1l1l11l1l_opy_.remove(gid)
        except ValueError:
            self._1l1ll1l_opy_.warning(l1l11l_opy_ (u"ࠦࡵࡸࡩࡷࡣࡷࡩࠥ࡭ࡩࡥࠢࡾࢁࠥࡴ࡯ࡵࠢ࡮ࡲࡴࡽ࡮ࠣএ").format(gid))
    def remove_group_gid(self, group):
        l1l11l_opy_ (u"ࠧࠨࠢࠡࡔࡨࡱࡴࡼࡥࠡࡶ࡫ࡩࠥ࡭ࡲࡰࡷࡳࠤࡌࡏࡄࠡࡨࡵࡳࡲࠦࡴࡩࡧࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡧࡰࡖࡨࡲࡳࡧ࠮ࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡶࡴࡻࡰࠡࡩࡵࡳࡺࡶ࠺ࠡࡖ࡫ࡩࠥ࡭ࡲࡰࡷࡳࠤࡹࡵࠠࡳࡧࡰࡳࡻ࡫ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥࡴࠢࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡧࡴࡴࡳࡵࡣࡱࡸࡸ࠴ࡔࡪ࡯ࡨࡳࡺࡺࡅࡹࡥࡨࡴࡹ࡯࡯࡯࠼ࠣࡘ࡭࡫ࠠࡥࡧࡹ࡭ࡨ࡫ࠠࡪࡵࠣࡲࡴࠦ࡬ࡰࡰࡪࡩࡷࠦࡣࡰࡰࡱࡩࡨࡺࡥࡥࠢࡤࡲࡩࠦࡤࡪࡦࠣࡲࡴࡺࠠࡳࡧࡶࡴࡴࡴࡤ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷࡧࡩࡴࡧࡶࠤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡩ࡯࡯ࡵࡷࡥࡳࡺࡳ࠯ࡔࡨࡱࡴࡺࡥࡆࡴࡵࡳࡷࡀࠠࡕࡪࡨࠤࡩ࡫ࡶࡪࡥࡨࠤࡷ࡫ࡴࡶࡴࡱࡩࡩࠦࡡࠡࡴࡨࡱࡴࡺࡥࠡࡧࡵࡶࡴࡸࠠࡤࡱࡧࡩ࠳ࠦࡓࡦࡧࠣ࠾ࡵࡿ࠺ࡢࡶࡷࡶ࠿ࡦࡧࡰࡖࡨࡲࡳࡧ࠮ࡤࡱࡱࡷࡹࡧ࡮ࡵࡵ࠱ࡖࡪࡳ࡯ࡵࡧࡈࡶࡷࡵࡲ࠯ࡥࡲࡨࡪࡦࠠࡧࡱࡵࠤࡩ࡫ࡴࡢ࡫࡯ࡷ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡤ࡭ࡸ࡫ࡳࠡࡖࡼࡴࡪࡋࡲࡳࡱࡵ࠾ࠥ࡯ࡦࠡࡩࡵࡳࡺࡶࠠࡪࡵࠣࡲࡴࡺࠠࡢࡰࠣ࡭ࡳࡹࡴࡢࡰࡦࡩࠥࡵࡦࠡ࠼ࡳࡽ࠿ࡩ࡬ࡢࡵࡶ࠾ࡥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡣࡰࡰࡶࡸࡦࡴࡴࡴ࠰ࡊࡶࡴࡻࡰࡡࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨঐ")
        if not isinstance(group, goTenna.settings.Group):
            raise TypeError(l1l11l_opy_ (u"ࠨࡧࡳࡱࡸࡴࠥࡹࡨࡰࡷ࡯ࡨࠥࡨࡥࠡࡣࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡳࡱࡸࡴ࠱ࠦࡩࡴࠢࡾࢁࠧ঑")
                            .format(type(group)))
        l1l11111l1_opy_ = l1l11l_opy_ (u"ࠧࡥࡧ࡯ࡩࡹ࡫࡟ࡨ࡫ࡧࠫ঒")
        command = goTenna.binary_utils.l11lll_opy_[l1l11111l1_opy_]\
                  + goTenna.binary_utils.l1ll1l_opy_(self.sdk_token, group.gid,
                                                       l1lll_opy_=True)
        self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"ࠨࡽࢀ࠾ࠥࢁࡽࠨও").format(l1l11111l1_opy_, binascii.hexlify(command)))
        self.l1l111l111_opy_.write_binary(command)
        res = self._1ll111ll1_opy_(l1l11111l1_opy_, command)
        if goTenna.binary_utils.l111_opy_(goTenna.util.l1lll11_opy_(res[0])):
            code = goTenna.constants.ErrorCodes.UNKNOWN
            raise goTenna.constants.RemoteError(code, l1l11l_opy_ (u"ࠩࡾࢁࠬঔ").format(binascii.hexlify(res)))
        try:
            self.l1l1l11l1l_opy_.remove(group.gid)
        except ValueError:
            self._1l1ll1l_opy_.warning(l1l11l_opy_ (u"ࠥ࡫ࡷࡵࡵࡱࠢࡪ࡭ࡩࠦࡻࡾࠢ࡬ࡷࠥࡴ࡯ࡵࠢ࡮ࡲࡴࡽ࡮ࠣক")
                                 .format(group.gid))
    def l1l11lll1l_opy_(self, *args, **kwargs):
        raise NotImplementedError
    def l1l1lll1ll_opy_(self):
        l1l11l_opy_ (u"ࠦࠧࠨࠠࡒࡷࡨࡶࡾࠦࡷࡩࡧࡷ࡬ࡪࡸࠠ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠢࡤࡶࡪࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡧࡩࡻ࡯ࡣࡦ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡡࡪࡵࡨࡷࠥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡣࡰࡰࡶࡸࡦࡴࡴࡴ࠰ࡗ࡭ࡲ࡫࡯ࡶࡶࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲ࠿ࠦࡔࡩࡧࠣࡨࡪࡼࡩࡤࡧࠣ࡭ࡸࠦ࡮ࡰࠢ࡯ࡳࡳ࡭ࡥࡳࠢࡦࡳࡳࡴࡥࡤࡶࡨࡨࠥࡧ࡮ࡥࠢࡧ࡭ࡩࠦ࡮ࡰࡶࠣࡶࡪࡹࡰࡰࡰࡧ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡳࡣ࡬ࡷࡪࡹࠠࡨࡱࡗࡩࡳࡴࡡ࠯ࡥࡲࡲࡸࡺࡡ࡯ࡶࡶ࠲ࡗ࡫࡭ࡰࡶࡨࡉࡷࡸ࡯ࡳ࠼ࠣࡘ࡭࡫ࠠࡥࡧࡹ࡭ࡨ࡫ࠠࡳࡧࡷࡹࡷࡴࡥࡥࠢࡤࠤࡷ࡫࡭ࡰࡶࡨࠤࡪࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠯ࠢࡖࡩࡪࠦ࠺ࡱࡻ࠽ࡥࡹࡺࡲ࠻ࡢࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡧࡴࡴࡳࡵࡣࡱࡸࡸ࠴ࡒࡦ࡯ࡲࡸࡪࡋࡲࡳࡱࡵ࠲ࡨࡵࡤࡦࡢࠣࡪࡴࡸࠠࡥࡧࡷࡥ࡮ࡲࡳ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷࡧࡩࡴࡧࡶࠤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡩ࡯࡯ࡵࡷࡥࡳࡺࡳ࠯ࡐࡲࡸࡈࡵ࡮࡯ࡧࡦࡸࡪࡪࡅࡹࡥࡨࡴࡹ࡯࡯࡯࠼ࠣࡘ࡭࡫ࠠࡥࡧࡹ࡭ࡨ࡫ࠠࡪࡵࠣࡲࡴࡺࠠࡤࡱࡱࡲࡪࡩࡴࡦࡦࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢখ")
        try:
            return bool(self.device_info[l1l11l_opy_ (u"ࠬࡴࡵ࡮ࡡࡶࡸࡴࡸࡥࡥࡡࡰࡷ࡬࠭গ")])
        except TypeError:
            raise goTenna.constants.NotConnectedException()
    def l1l1lll111_opy_(self):
        l1l11l_opy_ (u"ࠨࠢࠣࠢࡊࡩࡹࠦࡴࡩࡧࠣࡪ࡮ࡸࡳࡵࠢࡰࡩࡸࡹࡡࡨࡧࠣࡥࡻࡧࡩ࡭ࡣࡥࡰࡪࠦࡦࡳࡱࡰࠤࡹ࡮ࡥࠡࡦࡨࡺ࡮ࡩࡥ࠭ࠢ࡬ࡪࠥࡧ࡮ࡺ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡢ࡫ࡶࡩࡸࠦࡧࡰࡖࡨࡲࡳࡧ࠮ࡤࡱࡱࡷࡹࡧ࡮ࡵࡵ࠱ࡖࡪࡳ࡯ࡵࡧࡈࡶࡷࡵࡲ࠻ࠢࡌࡪࠥࡺࡨࡦࡴࡨࠤࡼࡧࡳࠡࡣࡱࠤࡪࡸࡲࡰࡴࠣ࡫ࡪࡺࡴࡪࡰࡪࠤࡹ࡮ࡥࠡ࡯ࡨࡷࡸࡧࡧࡦࠢࠫࡪࡴࡸࠠࡪࡰࡶࡸࡦࡴࡣࡦ࠮ࠣࡲࡴࠦ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠡࡹࡨࡶࡪࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠫࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡡࡪࡵࡨࡷࠥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡣࡰࡰࡶࡸࡦࡴࡴࡴ࠰ࡗ࡭ࡲ࡫࡯ࡶࡶࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲ࠿ࠦࡉࡧࠢࡷ࡬ࡪࠦࡤࡦࡸ࡬ࡧࡪࠦࡤࡪࡦࠣࡲࡴࡺࠠࡳࡧࡶࡴࡴࡴࡤࠡ࡫ࡱࠤࡹ࡮ࡥࠡࡵࡳࡩࡨ࡯ࡦࡪࡧࡧࠤࡹ࡯࡭ࡦ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲࡸࠦࡧࡰࡖࡨࡲࡳࡧ࠮࡮ࡧࡶࡷࡦ࡭ࡥ࠯ࡏࡨࡷࡸࡧࡧࡦ࠼ࠣࡘ࡭࡫ࠠ࡮ࡧࡶࡷࡦ࡭ࡥ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨঘ")
        l1l11111l1_opy_ = l1l11l_opy_ (u"ࠧࡨࡧࡷࡣ࡫࡯ࡲࡴࡶࡢࡷࡹࡵࡲࡦࡦࡢࡱࡪࡹࡳࡢࡩࡨࠫঙ")
        command = goTenna.binary_utils.l11lll_opy_[l1l11111l1_opy_]
        self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"ࠨࡽࢀ࠾ࠥࢁࡽࠨচ").format(l1l11111l1_opy_, binascii.hexlify(command)))
        self.l1l111l111_opy_.write_binary(command)
        res = self._1ll111ll1_opy_(l1l11111l1_opy_, command)
        if goTenna.binary_utils.l111_opy_(goTenna.util.l1lll11_opy_(res[0])):
            return None
        self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"ࠩࡵࡩࡸࡶ࠺ࠡࡽࢀࠫছ").format(binascii.hexlify(res)))
        return goTenna.message.build_from_device_response(res[2:],
                                                          self._1l11l1l11_opy_)
    def store_emergency(self, l111ll1l_opy_):
        l1l11l_opy_ (u"ࠥࠦࠧࠦࡓࡵࡱࡵࡩࠥࡧ࡮ࠡࡧࡰࡩࡷ࡭ࡥ࡯ࡥࡼࠤࡲ࡫ࡳࡴࡣࡪࡩ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡࡖ࡫࡭ࡸࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡸ࡫࡯ࡰࠥࡨࡥࠡࡵࡷࡳࡷ࡫ࡤࠡ࡫ࡱࡸࡪࡸ࡮ࡢ࡮࡯ࡽࠥࡧ࡮ࡥࠢࡥࡶࡴࡧࡤࡤࡣࡶࡸࠥࡸࡥࡱࡧࡤࡸࡪࡪ࡬ࡺࠢ࡬ࡪࠥ࡫࡭ࡦࡴࡪࡩࡳࡩࡹࠡࡤࡨࡥࡨࡵ࡮ࠡ࡯ࡲࡨࡪࠦࡩࡴࠢࡨࡲࡦࡨ࡬ࡦࡦࠣࡦࡾࠦࡥࡪࡶ࡫ࡩࡷࠦࡴࡩࡧࠣࡦࡺࡺࡴࡰࡰࠣࡷࡪࡷࡵࡦࡰࡦࡩࠥࡵࡲࠡࡶ࡫࡭ࡸࠦࡓࡅࡍ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡧࡰࡖࡨࡲࡳࡧ࠮࡮ࡧࡶࡷࡦ࡭ࡥ࠯ࡏࡨࡷࡸࡧࡧࡦࠢࡰࡩࡸࡹࡡࡨࡧࡢࡳࡧࡰ࠺ࠡࡏࡨࡷࡸࡧࡧࡦࠢࡷࡳࠥࡹࡥ࡯ࡦࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡡࡪࡵࡨࡷࠥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡣࡰࡰࡶࡸࡦࡴࡴࡴ࠰ࡗ࡭ࡲ࡫࡯ࡶࡶࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲ࠿ࠦࡔࡩࡧࠣࡨࡪࡼࡩࡤࡧࠣ࡭ࡸࠦ࡮ࡰࠢ࡯ࡳࡳ࡭ࡥࡳࠢࡦࡳࡳࡴࡥࡤࡶࡨࡨࠥࡧ࡮ࡥࠢࡧ࡭ࡩࠦ࡮ࡰࡶࠣࡶࡪࡹࡰࡰࡰࡧ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡳࡣ࡬ࡷࡪࡹࠠࡨࡱࡗࡩࡳࡴࡡ࠯ࡥࡲࡲࡸࡺࡡ࡯ࡶࡶ࠲ࡗ࡫࡭ࡰࡶࡨࡉࡷࡸ࡯ࡳ࠼ࠣࡘ࡭࡫ࠠࡥࡧࡹ࡭ࡨ࡫ࠠࡳࡧࡷࡹࡷࡴࡥࡥࠢࡤࠤࡷ࡫࡭ࡰࡶࡨࠤࡪࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠯ࠢࡖࡩࡪࠦ࠺ࡱࡻ࠽ࡥࡹࡺࡲ࠻ࡢࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡧࡴࡴࡳࡵࡣࡱࡸࡸ࠴ࡒࡦ࡯ࡲࡸࡪࡋࡲࡳࡱࡵ࠲ࡨࡵࡤࡦࡢࠣࡪࡴࡸࠠࡥࡧࡷࡥ࡮ࡲࡳ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨজ")
        if not  isinstance(l111ll1l_opy_, goTenna.message.Message):
            raise TypeError(l1l11l_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࡤࡵࡢ࡫ࠢࡶ࡬ࡴࡻ࡬ࡥࠢࡥࡩࠥࡓࡥࡴࡵࡤ࡫ࡪ࠲ࠠࡪࡵࠣࡿࢂ࠭ঝ")
                            .format(type(l111ll1l_opy_)))
        l1l11111l1_opy_ = l1l11l_opy_ (u"ࠬࡹࡴࡰࡴࡨࡣࡪࡳࡥࡳࡩࡨࡲࡨࡿࠧঞ")
        command = goTenna.binary_utils.l11lll_opy_[l1l11111l1_opy_] \
                              + l111ll1l_opy_.to_bytes(self.sdk_token)
        self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"࠭ࡻࡾ࠼ࠣࡿࢂ࠭ট").format(l1l11111l1_opy_, binascii.hexlify(command)))
        self.l1l111l111_opy_.write_binary(command)
        res = self._1ll111ll1_opy_(l1l11111l1_opy_, command)
        if goTenna.binary_utils.l111_opy_(goTenna.util.l1lll11_opy_(res[0])):
            err = goTenna.util.l1lll11_opy_(res[1])
            raise goTenna.constants.RemoteError(err, l1l11l_opy_ (u"ࠧࡼࡿࠪঠ").format(binascii.hexlify(res)))
    def send_message(self, l111ll1l_opy_):
        l1l11l_opy_ (u"ࠣࠤࠥࠤࡘ࡫࡮ࡥࠢࡤࠤࡧࡸ࡯ࡢࡦࡦࡥࡸࡺࠠ࡮ࡧࡶࡷࡦ࡭ࡥ࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࡙࡮ࡩࡴࠢࡰࡩࡸࡹࡡࡨࡧࠣࡻ࡮ࡲ࡬ࠡࡤࡨࠤࡷ࡫ࡣࡦ࡫ࡹࡩࡩࠦࡢࡺࠢࡤࡰࡱࠦࡧࡰࡖࡨࡲࡳࡧࡳࠡࡹ࡬ࡸ࡭࡯࡮ࠡࡴࡤࡨ࡮ࡵࠠࡳࡣࡱ࡫ࡪ࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡱࡪࡹࡳࡢࡩࡨ࠲ࡒ࡫ࡳࡴࡣࡪࡩࠥࡳࡥࡴࡵࡤ࡫ࡪࡥ࡯ࡣ࡬࠽ࠤࡒ࡫ࡳࡴࡣࡪࡩࠥࡺ࡯ࠡࡵࡨࡲࡩ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥࡴࠢࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡧࡴࡴࡳࡵࡣࡱࡸࡸ࠴ࡔࡪ࡯ࡨࡳࡺࡺࡅࡹࡥࡨࡴࡹ࡯࡯࡯࠼ࠣࡘ࡭࡫ࠠࡥࡧࡹ࡭ࡨ࡫ࠠࡪࡵࠣࡲࡴࠦ࡬ࡰࡰࡪࡩࡷࠦࡣࡰࡰࡱࡩࡨࡺࡥࡥࠢࡤࡲࡩࠦࡤࡪࡦࠣࡲࡴࡺࠠࡳࡧࡶࡴࡴࡴࡤ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷࡧࡩࡴࡧࡶࠤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡩ࡯࡯ࡵࡷࡥࡳࡺࡳ࠯ࡔࡨࡱࡴࡺࡥࡆࡴࡵࡳࡷࡀࠠࡕࡪࡨࠤࡩ࡫ࡶࡪࡥࡨࠤࡷ࡫ࡴࡶࡴࡱࡩࡩࠦࡡࠡࡴࡨࡱࡴࡺࡥࠡࡧࡵࡶࡴࡸࠠࡤࡱࡧࡩ࠳ࠦࡓࡦࡧࠣ࠾ࡵࡿ࠺ࡢࡶࡷࡶ࠿ࡦࡧࡰࡖࡨࡲࡳࡧ࠮ࡤࡱࡱࡷࡹࡧ࡮ࡵࡵ࠱ࡖࡪࡳ࡯ࡵࡧࡈࡶࡷࡵࡲ࠯ࡥࡲࡨࡪࡦࠠࡧࡱࡵࠤࡩ࡫ࡴࡢ࡫࡯ࡷ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥড")
        if not isinstance(l111ll1l_opy_, goTenna.message.Message):
            raise TypeError(l1l11l_opy_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࡢࡳࡧࡰࠠࡴࡪࡲࡹࡱࡪࠠࡣࡧࠣࡑࡪࡹࡳࡢࡩࡨ࠰ࠥ࡯ࡳࠡࡽࢀࠫঢ")
                            .format(type(l111ll1l_opy_)))
        l1l11111l1_opy_ = l1l11l_opy_ (u"ࠪࡷࡪࡴࡤࡠ࡯ࡨࡷࡸࡧࡧࡦࠩণ")
        command = goTenna.binary_utils.l11lll_opy_[l1l11111l1_opy_] \
                              + l111ll1l_opy_.to_bytes(self.sdk_token)
        self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"ࠫࢀࢃ࠺ࠡࡽࢀࠫত").format(l1l11111l1_opy_, binascii.hexlify(command)))
        self.l1l111l111_opy_.write_binary(command)
        res = self._1ll111ll1_opy_(l1l11111l1_opy_, command, timeout_override=30)
        if goTenna.binary_utils.l111_opy_(goTenna.util.l1lll11_opy_(res[0])):
            err = goTenna.constants.ErrorCodes.UNKNOWN
            raise goTenna.constants.RemoteError(err, l1l11l_opy_ (u"ࠬࢁࡽࠨথ").format(binascii.hexlify(res)))
    def l1l1ll11ll_opy_(self):
        l1l11l_opy_ (u"ࠨࠢࠣࠢࡇࡩࡱ࡫ࡴࡦࠢࡷ࡬ࡪࠦ࡬ࡦࡣࡶࡸ࠲ࡸࡥࡤࡧࡱࡸࡱࡿࠠࡳࡧࡦࡩ࡮ࡼࡥࡥࠢࡰࡩࡸࡹࡡࡨࡧࠣࡪࡷࡵ࡭ࠡࡶ࡫ࡩࠥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢࡗ࡬ࡪࠦࡦࡪࡰࡤࡰࠥࡶࡡࡳࡶࠣࡳ࡫ࠦࡴࡩࡧࠣࡲࡴࡸ࡭ࡢ࡮ࠣࡱࡪࡹࡳࡢࡩࡨࠤࡷ࡫ࡴࡳ࡫ࡨࡺࡦࡲࠠࡧ࡮ࡲࡻ࠱ࠦࡡࡧࡶࡨࡶࠥࡩࡨࡦࡥ࡮࡭ࡳ࡭ࠠࡪࡨࠣࡸ࡭࡫ࡲࡦࠢࡤࡶࡪࠦ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠡࡣࡱࡨࠥࡺࡨࡦࡰࠣࡶࡪࡺࡲࡪࡧࡹ࡭ࡳ࡭ࠠࡵࡪࡨࠤ࡫࡯ࡲࡴࡶ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴࠠࡣࡱࡲࡰ࠿ࠦࡷࡩࡧࡷ࡬ࡪࡸࠠࡰࡴࠣࡲࡴࡺࠠ࡮ࡱࡵࡩࠥࡳࡥࡴࡵࡤ࡫ࡪࡹࠠࡢࡴࡨࠤࡸࡺ࡯ࡳࡧࡧࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡳࡣ࡬ࡷࡪࡹࠠࡨࡱࡗࡩࡳࡴࡡ࠯ࡥࡲࡲࡸࡺࡡ࡯ࡶࡶ࠲࡙࡯࡭ࡦࡱࡸࡸࡊࡾࡣࡦࡲࡷ࡭ࡴࡴ࠺ࠡࡖ࡫ࡩࠥࡪࡥࡷ࡫ࡦࡩࠥ࡯ࡳࠡࡰࡲࠤࡱࡵ࡮ࡨࡧࡵࠤࡨࡵ࡮࡯ࡧࡦࡸࡪࡪࠠࡢࡰࡧࠤࡩ࡯ࡤࠡࡰࡲࡸࠥࡸࡥࡴࡲࡲࡲࡩ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥࡴࠢࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡧࡴࡴࡳࡵࡣࡱࡸࡸ࠴ࡒࡦ࡯ࡲࡸࡪࡋࡲࡳࡱࡵ࠾࡚ࠥࡨࡦࠢࡧࡩࡻ࡯ࡣࡦࠢࡵࡩࡹࡻࡲ࡯ࡧࡧࠤࡦࠦࡲࡦ࡯ࡲࡸࡪࠦࡥࡳࡴࡲࡶࠥࡩ࡯ࡥࡧ࠱ࠤࡘ࡫ࡥࠡ࠼ࡳࡽ࠿ࡧࡴࡵࡴ࠽ࡤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡩ࡯࡯ࡵࡷࡥࡳࡺࡳ࠯ࡔࡨࡱࡴࡺࡥࡆࡴࡵࡳࡷ࠴ࡣࡰࡦࡨࡤࠥ࡬࡯ࡳࠢࡧࡩࡹࡧࡩ࡭ࡵ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣদ")
        l1l11111l1_opy_ = l1l11l_opy_ (u"ࠧࡥࡧ࡯ࡩࡹ࡫࡟ࡧ࡫ࡵࡷࡹࡥࡳࡵࡱࡵࡩࡩࡥ࡭ࡦࡵࡶࡥ࡬࡫ࠧধ")
        command = goTenna.binary_utils.l11lll_opy_[l1l11111l1_opy_]
        self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"ࠨࡽࢀ࠾ࠥࢁࡽࠨন").format(l1l11111l1_opy_, binascii.hexlify(command)))
        self.l1l111l111_opy_.write_binary(command)
        res = self._1ll111ll1_opy_(l1l11111l1_opy_, command)
        if goTenna.binary_utils.l111_opy_(goTenna.util.l1lll11_opy_(res[0])):
            return 0
        return struct.unpack(l1l11l_opy_ (u"ࠩࠤࡆࡇࡎࠧ঩"), res)[2]
    def l1l111ll1l_opy_(self):
        l1l11l_opy_ (u"ࠥࠦࠧࠦࡒࡦࡶࡵ࡭ࡪࡼࡥࠡࡣࠣࡱࡪࡹࡳࡢࡩࡨࠤࡦࡴࡤࠡࡦࡨࡰࡪࡺࡥࠡ࡫ࡷࠤ࡫ࡸ࡯࡮ࠢࡷ࡬ࡪࠦࡧࡰࡖࡨࡲࡳࡧࠬࠡࡣ࡯ࡰࡴࡽࡩ࡯ࡩࠣࡥࡨࡩࡥࡴࡵࠣࡸࡴࠦࡴࡩࡧࠣࡲࡪࡾࡴ࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲࠥࡺࡵࡱ࡮ࡨ࠾ࠥ࠮ࡲࡦࡵࡸࡰࡹࠦ࡯ࡧࠢࡪࡩࡹࡥ࡭ࡦࡵࡶࡥ࡬࡫ࠬࠡࡴࡨࡷࡺࡲࡴࠡࡱࡩࠤࡩ࡫࡬ࡦࡶࡨࡣ࡫࡯ࡲࡴࡶࡢࡱࡪࡹࡳࡢࡩࡨ࠭ࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡳࡣ࡬ࡷࡪࡹࠠࡨࡱࡗࡩࡳࡴࡡ࠯ࡥࡲࡲࡸࡺࡡ࡯ࡶࡶ࠲࡙࡯࡭ࡦࡱࡸࡸࡊࡾࡣࡦࡲࡷ࡭ࡴࡴ࠺ࠡࡖ࡫ࡩࠥࡪࡥࡷ࡫ࡦࡩࠥ࡯ࡳࠡࡰࡲࠤࡱࡵ࡮ࡨࡧࡵࠤࡨࡵ࡮࡯ࡧࡦࡸࡪࡪࠠࡢࡰࡧࠤࡩ࡯ࡤࠡࡰࡲࡸࠥࡸࡥࡴࡲࡲࡲࡩ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥࡴࠢࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡧࡴࡴࡳࡵࡣࡱࡸࡸ࠴ࡒࡦ࡯ࡲࡸࡪࡋࡲࡳࡱࡵ࠾࡚ࠥࡨࡦࠢࡧࡩࡻ࡯ࡣࡦࠢࡵࡩࡹࡻࡲ࡯ࡧࡧࠤࡦࠦࡲࡦ࡯ࡲࡸࡪࠦࡥࡳࡴࡲࡶࠥࡩ࡯ࡥࡧ࠱ࠤࡘ࡫ࡥࠡ࠼ࡳࡽ࠿ࡧࡴࡵࡴ࠽ࡤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡩ࡯࡯ࡵࡷࡥࡳࡺࡳ࠯ࡔࡨࡱࡴࡺࡥࡆࡴࡵࡳࡷ࠴ࡣࡰࡦࡨࡤࠥ࡬࡯ࡳࠢࡧࡩࡹࡧࡩ࡭ࡵ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣপ")
        msg = None
        more = 0
        if self.l1l1lll1ll_opy_():
            msg = self.l1l1lll111_opy_()
            more = self.l1l1ll11ll_opy_()
        return (msg, more)
    def echo(self):
        l1l11l_opy_ (u"ࠦࠧࠨࠠࡔࡧࡱࡨࠥࡧࠠࡤࡱࡰࡱࡦࡴࡤࠡࡶࡲࠤࡹ࡮ࡥࠡࡩࡲࡘࡪࡴ࡮ࡢ࠮ࠣࡻࡦ࡯ࡴࠡࡨࡲࡶࠥࡧࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠮ࠣࡥࡳࡪࠠࡧ࡮ࡤࡷ࡭ࠦࡴࡩࡧࠣࡐࡊࡊ࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣࡑࡦࡿࠠࡣࡧࠣࡹࡸ࡫ࡤࠡࡶࡲࠤࡸ࡮࡯ࡸࠢࡺ࡬࡮ࡩࡨࠡࡩࡲࡘࡪࡴ࡮ࡢࠢࡷ࡬ࡪࠦࡤࡳ࡫ࡹࡩࡷࠦࡩࡴࠢࡦࡹࡷࡸࡥ࡯ࡶ࡯ࡽࠥࡩ࡯࡮࡯ࡸࡲ࡮ࡩࡡࡵ࡫ࡱ࡫ࠥࡽࡩࡵࡪ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣফ")
        l1l11111l1_opy_ = l1l11l_opy_ (u"ࠬ࡫ࡣࡩࡱࠪব")
        command = goTenna.binary_utils.l11lll_opy_[l1l11111l1_opy_]
        self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"࠭ࡻࡾ࠼ࠣࡿࢂ࠭ভ").format(l1l11111l1_opy_, binascii.hexlify(command)))
        self.l1l111l111_opy_.write_binary(command)
        self._1ll111ll1_opy_(l1l11111l1_opy_, command)
    def l1ll11ll1l_opy_(self, filepath, version_major, version_minor):
        l1l11l_opy_ (u"ࠢࠣࠤ࡙ࠣࡵࡪࡡࡵࡧࠣࡸ࡭࡫ࠠࡧ࡫ࡵࡱࡼࡧࡲࡦࠢࡲࡲࠥࡧࠠࡤࡱࡱࡲࡪࡩࡴࡦࡦࠣࡨࡪࡼࡩࡤࡧ࠯ࠤࡦࡴࡤࠡࡤ࡯ࡳࡨࡱࠠࡶࡰࡷ࡭ࡱࠦࡴࡩࡧࠣࡴࡷࡵࡣࡦࡵࡶࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࡹ࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣࡅࠥࡽࡲࡢࡲࡳࡩࡷࠦࡡࡳࡱࡸࡲࡩࠦ࠺ࡱࡻ࠽ࡱࡪࡺࡨ࠻ࡢࡣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡵࡸ࡯࠯ࡒࡵࡳ࠳ࡻࡰࡥࡣࡷࡩࡤ࡬ࡩࡳ࡯ࡺࡥࡷ࡫ࡠࡡࠢࡷ࡬ࡦࡺࠠࡢ࡮࡯ࡳࡼࡹࠠࡵࡪࡨࠤࡺࡹࡥࠡࡱࡩࠤࡳࡵࡲ࡮ࡣ࡯ࠤࡲ࡫ࡴࡩࡱࡧࠤࡨࡧ࡬࡭ࠢࡶࡽࡳࡺࡡࡹࠢࡤࡲࡩࠦࡢ࡭ࡱࡦ࡯ࡸࠦࡵ࡯ࡶ࡬ࡰࠥࡺࡨࡦࠢࡸࡴࡩࡧࡴࡦࠢ࡬ࡷࠥࡩ࡯࡮ࡲ࡯ࡩࡹ࡫࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣࡊࡴࡸࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࠢࡧࡳࡨࡻ࡭ࡦࡰࡷࡥࡹ࡯࡯࡯ࠢࡶࡩࡪࠦ࠺ࡱࡻ࠽ࡱࡪࡺࡨ࠻ࡢࡣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡵࡸ࡯࠯ࡒࡵࡳ࠳ࡻࡰࡥࡣࡷࡩࡤ࡬ࡩࡳ࡯ࡺࡥࡷ࡫ࡠࡡ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢম")
        for _ in self.update_firmware(filepath, version_major, version_minor):
            pass
    def update_firmware(self, filepath, version_major, version_minor):
        l1l11l_opy_ (u"ࠣࠤࠥࠤ࡚ࡶࡤࡢࡶࡨࠤࡹ࡮ࡥࠡࡨ࡬ࡶࡲࡽࡡࡳࡧࠣࡳࡳࠦࡡࠡࡥࡲࡲࡳ࡫ࡣࡵࡧࡧࠤ࡬ࡵࡔࡦࡰࡱࡥࠥࡪࡥࡷ࡫ࡦࡩ࠳ࠦࡐࡳࡱࡦࡩࡪࡪࠠࡪࡰࠣࡧ࡭ࡻ࡮࡬ࡵ࠯ࠤࡾ࡯ࡥ࡭ࡦ࡬ࡲ࡬ࠦࡰࡳࡱࡪࡶࡪࡹࡳࠡ࡫ࡱࡪࡴࡸ࡭ࡢࡶ࡬ࡳࡳ࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡲࡴࡺࡥ࠻ࠢࡗ࡬࡮ࡹࠠ࡮ࡧࡷ࡬ࡴࡪࠠࡪࡵࠣࡥࠥ࡭ࡥ࡯ࡧࡵࡥࡹࡵࡲࠡࡣࡱࡨࠥࡹࡨࡰࡷ࡯ࡨࠥࡨࡥࠡࡥࡤࡰࡱ࡫ࡤࠡࡹ࡬ࡸ࡭ࠦࡠࡡࡨࡲࡶࠥࡺࡡࡴ࡭ࠣ࡭ࡳࠦ࡯ࡣ࡬࠱ࡹࡵࡪࡡࡵࡧࡢࡪ࡮ࡸ࡭ࡸࡣࡵࡩࡥࡦࠠࡴࡻࡱࡸࡦࡾ࠮ࠡࡋࡩࠤࡨࡧ࡬࡭ࡧࡧࠤࡹ࡮ࡩࡴࠢࡺࡥࡾ࠲ࠠࡡࡢࡷࡥࡸࡱࡠࡡࠢࡺ࡭ࡱࡲࠠࡣࡧࠣࡥࠥ࡬࡬ࡰࡣࡷࠤࡧ࡫ࡴࡸࡧࡨࡲࠥ࠶ࠠࡢࡰࡧࠤ࠶ࠦࠨࡪࡰࡦࡰࡺࡹࡩࡷࡧࠬࠤࡪࡹࡴࡪ࡯ࡤࡸ࡮ࡴࡧࠡࡶ࡫ࡩࠥࡶࡲࡰࡩࡵࡩࡸࡹࠠࡰࡨࠣࡸ࡭࡫ࠠࡧ࡫ࡵࡱࡼࡧࡲࡦࠢࡸࡴࡩࡧࡴࡦ࠰ࠣࡘ࡭࡯ࡳࠡࡸࡤࡰࡺ࡫ࠠࡴࡪࡲࡹࡱࡪࠠ࡯ࡱࡷࠤࡧ࡫ࠠࡶࡵࡨࡨࠥࡺ࡯ࠡࡦࡨࡸࡪࡸ࡭ࡪࡰࡨࠤࡼ࡮ࡥ࡯ࠢࡷ࡬ࡪࠦࡵࡱࡦࡤࡸࡪࠦࡩࡴࠢࡧࡳࡳ࡫࠻ࠡࡱࡱࡰࡾࠦࡴࡩ࡫ࡶࠤࡲ࡫ࡴࡩࡱࡧࠫࡸࠦࡧࡦࡰࡨࡶࡦࡺ࡯ࡳࠢࡨࡼ࡭ࡧࡵࡴࡶ࡬ࡲ࡬࠲ࠠࡰࡴࠣࡥࡳࠦࡥࡹࡥࡨࡴࡹ࡯࡯࡯ࠢࡥࡩ࡮ࡴࡧࠡࡴࡤ࡭ࡸ࡫ࡤࠡ࡫ࡱࡨ࡮ࡩࡡࡵࡧࡶࠤࡹ࡮ࡡࡵࠢࡷ࡬ࡪࠦࡵࡱࡦࡤࡸࡪࠦࡨࡢࡵࠣࡩ࡮ࡺࡨࡦࡴࠣࡷࡺࡩࡣࡦࡧࡧࡩࡩࠦ࡯ࡳࠢࡩࡥ࡮ࡲࡥࡥ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡷࡢࡴࡱ࡭ࡳ࡭࠺ࠡࡖ࡫࡭ࡸࠦ࡭ࡦࡶ࡫ࡳࡩࠦࡤࡰࡧࡶࠤࡦࠦࡢࡢࡵ࡬ࡧࠥࡹࡡ࡯࡫ࡷࡽࠥࡩࡨࡦࡥ࡮ࠤࡴࡴࠠࡵࡪࡨࠤ࡫࡯࡬ࡦࠢ࠰ࠤࡪࡴࡳࡶࡴࡨࡷࠥࡺࡨࡢࡶࠣ࡭ࡹࡹࠠࡴࡷࡩࡪ࡮ࡾࠠࡪࡵࠣࡤࡥ࠴ࡢࡪࡰࡣࡤ࠱ࠦࡥࡴࡵࡨࡲࡹ࡯ࡡ࡭࡮ࡼࠤ࠲ࠦࡢࡶࡶࠣ࡭࡫ࠦࡴࡩࡧࠣࡪ࡮ࡲࡥࠡ࡫ࡶࠤࡳࡵࡴࠡࡣࠣࡺࡦࡲࡩࡥࠢࡪࡳ࡙࡫࡮࡯ࡣࠣࡪ࡮ࡸ࡭ࡸࡣࡵࡩࠥࡻࡰࡥࡣࡷࡩ࠱ࠦ࡮ࡰࠢࡨࡶࡷࡵࡲࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡵࡥ࡮ࡹࡥࡥࠢࡸࡲࡹ࡯࡬ࠡࡶ࡫ࡩࠥ࡫࡮ࡥࠢࡲࡪࠥࡺࡨࡦࠢࡳࡶࡴࡩࡥࡴࡵ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺࡯ࡱࡷࡩ࠿ࠦࡔࡩ࡫ࡶࠤࡲ࡫ࡴࡩࡱࡧࠤࡼ࡯࡬࡭ࠢࡷࡥࡰ࡫ࠠࡢࠢ࡯ࡳࡳ࡭ࠠࡵ࡫ࡰࡩࠥࡹࡩ࡯ࡥࡨࠤ࡮ࡺࠠࡩࡣࡶࠤࡹࡵࠠࡴࡧࡱࡨࠥࡵࡶࡦࡴࠣࡸ࡭࡫ࠠࡦࡰࡷ࡭ࡷ࡫ࠠࡧ࡫ࡵࡱࡼࡧࡲࡦࠢࡩ࡭ࡱ࡫ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡲࡴࡺࡥ࠻ࠢࡗ࡬࡮ࡹࠠ࡮ࡧࡷ࡬ࡴࡪࠠࡳࡧࡥࡳࡴࡺࡳࠡࡶ࡫ࡩࠥࡪࡥࡷ࡫ࡦࡩࠥ࡯ࡦࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡵࡷࡶࠥ࡬ࡩ࡭ࡧࡳࡥࡹ࡮࠺ࠡࡖ࡫ࡩࠥ࡬ࡩ࡭ࡧࠣࡴࡦࡺࡨࠡࡶࡲࠤ࡫ࡲࡡࡴࡪࠣࡸ࡭࡫ࠠࡥࡧࡹ࡭ࡨ࡫ࠠࡸ࡫ࡷ࡬࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡪࡰࡷࠤࡻ࡫ࡲࡴ࡫ࡲࡲࡤࡳࡡ࡫ࡱࡵ࠾࡚ࠥࡨࡦࠢࡰࡥ࡯ࡵࡲࠡࡸࡨࡶࡸ࡯࡯࡯ࠢࡲࡪࠥࡺࡨࡦࠢࡸࡴࡩࡧࡴࡦࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣ࡭ࡳࡺࠠࡷࡧࡵࡷ࡮ࡵ࡮ࡠ࡯࡬ࡲࡴࡸ࠺ࠡࡖ࡫ࡩࠥࡳࡩ࡯ࡱࡵࠤࡻ࡫ࡲࡴ࡫ࡲࡲࠥࡵࡦࠡࡶ࡫ࡩࠥࡻࡰࡥࡣࡷࡩࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡳࡣ࡬ࡷࡪࡹࠠࡨࡱࡗࡩࡳࡴࡡ࠯ࡥࡲࡲࡸࡺࡡ࡯ࡶࡶ࠲࡙࡯࡭ࡦࡱࡸࡸࡊࡾࡣࡦࡲࡷ࡭ࡴࡴ࠺ࠡࡋࡩࠤࡹ࡮ࡥࠡࡦࡨࡺ࡮ࡩࡥࠡ࡫ࡶࠤࡳࡵࠠ࡭ࡱࡱ࡫ࡪࡸࠠࡤࡱࡱࡲࡪࡩࡴࡦࡦ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡢ࡫ࡶࡩࡸࠦࡧࡰࡖࡨࡲࡳࡧ࠮ࡤࡱࡱࡷࡹࡧ࡮ࡵࡵ࠱ࡖࡪࡳ࡯ࡵࡧࡈࡶࡷࡵࡲ࠻ࠢࡌࡪࠥࡺࡨࡦࡴࡨࠤ࡮ࡹࠠࡢࡰࠣࡩࡷࡸ࡯ࡳࠢࡸࡴࡩࡧࡴࡪࡰࡪࠤࡹ࡮ࡥࠡࡨ࡬ࡶࡲࡽࡡࡳࡧࠣࡳࡳࠦࡴࡩࡧࠣࡨࡪࡼࡩࡤࡧ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡢ࡫ࡶࡩࡸࠦࡖࡢ࡮ࡸࡩࡊࡸࡲࡰࡴ࠽ࠤࡎ࡬ࠠࡵࡪࡨࠤ࡫࡯࡬ࡦࠢࡧࡳࡪࡹࠠ࡯ࡱࡷࠤࡵࡧࡳࡴࠢࡷ࡬ࡪࠦࡳࡢࡰ࡬ࡸࡾࠦࡣࡩࡧࡦ࡯ࡸ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦয")
        if not filepath.endswith(l1l11l_opy_ (u"ࠩ࠱ࡦ࡮ࡴࠧর")):
            raise ValueError(l1l11l_opy_ (u"ࠪࡊ࡮ࡲࡥࠡࡦࡲࡩࡸࠦ࡮ࡰࡶࠣࡥࡵࡶࡥࡢࡴࠣࡸࡴࠦࡢࡦࠢࡤࠤ࡫࡯ࡲ࡮ࡹࡤࡶࡪ࠴ࠧ঱"))
        if not isinstance(version_major, int):
            raise TypeError(version_major)
        if not isinstance(version_minor, int):
            raise TypeError(version_minor)
        l1ll11ll11_opy_ = goTenna.l11l1ll1l_opy_.l1l1111l1l_opy_.l1ll11l1ll_opy_(filepath,
                                                                      version_major,
                                                                      version_minor)
        def _11llll1ll_opy_(sent):
            return float(sent)/float(len(l1ll11ll11_opy_))
        l1l1ll1l11_opy_ = 0
        for (l1l1llll11_opy_, l1l11l1ll1_opy_, timeout) in l1ll11ll11_opy_:
            l1l11lll11_opy_ = None
            for _ in range(timeout):
                try:
                    self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"࡚ࠫࡶࡤࡢࡶࡨࠤࡋ࡝࠺ࠡࡽࢀࠫল").format(binascii.hexlify(l1l1llll11_opy_)))
                    self.l1l111l111_opy_.write_binary(l1l1llll11_opy_)
                    l11lllll11_opy_ = self.l1l111l111_opy_.read_binary_blocking(timeout_override=timeout,
                                                        interstitial_sleeps=None)
                    self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"࡛ࠬࡰࡥࡣࡷࡩࠥࡌࡗࠡࡴࡶࡴ࠿ࠦࡻࡾࠩ঳").format(binascii.hexlify(l11lllll11_opy_)))
                except Exception as l1l1llll1l_opy_: # pylint: disable=broad-except
                    if l1l11l1ll1_opy_:
                        break
                    else:
                        l1l11lll11_opy_ = l1l1llll1l_opy_
                        yield _11llll1ll_opy_(l1l1ll1l11_opy_)
                else:
                    break
            else:
                if None is not l1l11lll11_opy_:
                    raise l1l11lll11_opy_ # pylint: disable=l1l11l1111_opy_-l1l1l1l111_opy_-type
                else:
                    raise goTenna.constants.RemoteError(0, l1l11l_opy_ (u"ࠨࡕ࡯࡭ࡱࡳࡼࡴࠢ঴"))
            l1l1ll1l11_opy_ += 1
            yield _11llll1ll_opy_(l1l1ll1l11_opy_)
    def l1ll11llll_opy_(self):
        l1l11l_opy_ (u"ࠢࠣࠤࠣࡋࡪࡺࠠࡢࠢࡶࡰࡪࡽࠠࡰࡨࠣࡨࡪࡼࡩࡤࡧࠣ࡭ࡳ࡬࡯ࡳ࡯ࡤࡸ࡮ࡵ࡮ࠡࡶ࡫ࡥࡹࠦࡩࡴࠢࡵࡩࡱ࡫ࡶࡢࡰࡷࠤࡹࡵࠠࡰࡥࡦࡥࡸ࡯࡯࡯ࡣ࡯ࡰࡾࠦࡰࡰ࡮࡯࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࡕࡪࡨࠤࡩ࡫ࡶࡪࡥࡨࠤ࡮ࡴࡦࡰࡴࡰࡥࡹ࡯࡯࡯ࠢࡳࡹࡱࡲࡥࡥࠢࡥࡽࠥࡺࡨࡪࡵࠣࡱࡪࡺࡨࡰࡦࠣ࡭ࡸࠦࡰࡳ࡫ࡰࡥࡷ࡯࡬ࡺࠢࡧࡩ࡫࡯࡮ࡦࡦࠣࡦࡾࠦࡨࡪࡵࡷࡳࡷࡿ࠻ࠡ࡫ࡷࠤ࡮ࡹࠠࡸࡪࡤࡸࠥࡺࡨࡦࠢࡲࡸ࡭࡫ࡲࠡࡩࡲࡘࡪࡴ࡮ࡢࠢࡳࡰࡦࡺࡦࡰࡴࡰࡷࠥࡶࡵ࡭࡮ࠣࡪࡷࡵ࡭ࠡࡶ࡫ࡩࠥࡪࡥࡷ࡫ࡦࡩࠥࡧ࡮ࡥࠢࡨ࡭ࡹ࡮ࡥࡳࠢࡶࡸࡴࡸࡥࠡ࡫ࡱࡸࡪࡸ࡮ࡢ࡮࡯ࡽࠥࡵࡲࠡࡲࡵࡩࡸ࡫࡮ࡵࠢࡷࡳࠥࡺࡨࡦࠢࡸࡷࡪࡸ࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱࠤࡩ࡯ࡣࡵ࠼ࠣࡅࠥࡪࡩࡤࡶ࡬ࡳࡳࡧࡲࡺࠢࡲࡪࠥࡪࡥࡷ࡫ࡦࡩࠥ࡯࡮ࡧࡱࡵࡱࡦࡺࡩࡰࡰ࠽ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥ࠭࡮ࡶ࡯ࡢࡷࡹࡵࡲࡦࡦࡢࡱࡸ࡭ࠧ࠻ࠢ࡬ࡲࡹ࠲ࠠ࡯ࡷࡰࡦࡪࡸࠠࡰࡨࠣࡱࡪࡹࡳࡢࡩࡨࡷࠥࡹࡴࡰࡴࡨࡨࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡪࡥࡷ࡫ࡦࡩࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠧࡣࡣࡷࡸࡪࡸࡹࡠࡲࡨࡶࡨ࡫࡮ࡵࡣࡪࡩࠬࡀࠠࡪࡰࡷ࠰ࠥࡨࡡࡵࡶࡨࡶࡾࠦ࡬ࡦࡸࡨࡰࠥࡧࡳࠡࡣࠣࡴࡪࡸࡣࡦࡰࡷࡥ࡬࡫ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠩࡷࡶࡦࡴࡳ࡮࡫ࡷࡸࡪࡸ࡟ࡵࡧࡰࡴࡪࡸࡡࡵࡷࡵࡩࠬࡀࠠࡪࡰࡷ࠰ࠥࡺࡥ࡮ࡲࡨࡶࡦࡺࡵࡳࡧࠣ࡭ࡳࠦࡃࠡࡱࡩࠤࡹ࡮ࡥࠡࡶࡵࡥࡳࡹ࡭ࡪࡶࡷࡩࡷࠦࠨࡳࡧ࡯ࡩࡻࡧ࡮ࡵࠢࡷࡳࠥࡺࡨࡦࡴࡰࡥࡱࠦࡴࡩࡴࡲࡸࡹࡲࡩ࡯ࡩࠬࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥ࠭ࡦࡸࡡࡹࡩࡷࡹࡩࡰࡰࠪ࠾ࠥࡺࡵࡱ࡮ࡨࠤ࠭࡯࡮ࡵ࠮ࠣ࡭ࡳࡺࠬࠡ࡫ࡱࡸ࠮࠲ࠠࡵࡪࡨࠤ࡫࡯ࡲ࡮ࡹࡤࡶࡪࠦࡶࡦࡴࡶ࡭ࡴࡴࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠩࡶࡽࡸࡺࡥ࡮ࡡࡷࡩࡲࡶࡥࡳࡣࡷࡹࡷ࡫ࠧ࠻ࠢ࡬ࡲࡹ࠲ࠠࡢ࡯ࡥ࡭ࡪࡴࡴࠡࡶࡨࡱࡵ࡫ࡲࡢࡶࡸࡶࡪࠦࡩ࡯ࠢࡆࠤࡴ࡬ࠠࡵࡪࡨࠤࡸࡿࡳࡵࡧࡰࠤ࠭ࡵ࡮࡭ࡻࠣࡥࡻࡧࡩ࡭ࡣࡥࡰࡪࠦࡡࡧࡶࡨࡶࠥࡌࡗࠡࡸࡨࡶࡸ࡯࡯࡯ࠢ࠳࠲࠶࠺࠮࠲࠳ࠬࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥ࠭ࡳࡦࡴ࡬ࡥࡱ࠭࠺ࠡࡤࡼࡸࡪࡹࠬࠡࡵࡨࡶ࡮ࡧ࡬ࠡࡰࡸࡱࡧ࡫ࡲࠡࡱࡩࠤࡹ࡮ࡥࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠪࡰࡪࡪ࡟ࡦࡰࡤࡦࡱ࡫ࡤࠨ࠼ࠣࡦࡴࡵ࡬࠭ࠢࡺ࡬ࡪࡺࡨࡦࡴࠣࡸ࡭࡫ࠠ࡮ࡣ࡬ࡲࠥࡒࡅࡅࠢ࡬ࡷࠥ࡫࡮ࡢࡤ࡯ࡩࡩࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঵")
        #pylint: enable=line-too-long
        l1l11111l1_opy_ = l1l11l_opy_ (u"ࠨࡩࡨࡸࡤࡹࡹࡴࡡ࡬ࡲ࡫ࡵࠧশ")
        command = goTenna.binary_utils.l11lll_opy_[l1l11111l1_opy_]
        self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"ࠩࡾࢁ࠿ࠦࡻࡾࠩষ").format(l1l11111l1_opy_, binascii.hexlify(command)))
        self.l1l111l111_opy_.write_binary(command)
        res = self._1ll111ll1_opy_(l1l11111l1_opy_, command)
        if goTenna.binary_utils.l111_opy_(goTenna.util.l1lll11_opy_(res[0])):
            code = goTenna.constants.ErrorCodes.UNKNOWN
            raise goTenna.constants.RemoteError(code, l1l11l_opy_ (u"ࠪࡿࢂ࠭স").format(binascii.hexlify(res)))
        try:
            data = struct.unpack(l1l11l_opy_ (u"ࠫࠦ࠭হ")   +
                                 l1l11l_opy_ (u"ࠬࡎࠧ঺")   +
                                 l1l11l_opy_ (u"࠭ࡈࠨ঻")   +
                                 l1l11l_opy_ (u"ࠧࡩ়ࠩ")   +
                                 l1l11l_opy_ (u"ࠨࡄࠪঽ")   +
                                 l1l11l_opy_ (u"ࠩࡅࡆࡇ࠭া") + # l1l1l1111l_opy_ version major minor l1l1ll1l1l_opy_
                                 l1l11l_opy_ (u"ࠪ࡬ࠬি")   +
                                 l1l11l_opy_ (u"ࠫࡇ࠭ী")   +
                                 l1l11l_opy_ (u"ࠬ࠷࠲ࡴࠩু") + # serial no
                                 l1l11l_opy_ (u"࠭ࡂࡃࠩূ")  + # device type, l1ll111l1l_opy_ version (l1l1ll1lll_opy_)
                                 l1l11l_opy_ (u"ࠧࡀࠩৃ")   +
                                 l1l11l_opy_ (u"ࠨࡊࠪৄ")  # l1l1l111l1_opy_ version (l1l1ll1lll_opy_)
                                 ,
                                 res[2:])
        except struct.error:
            data = struct.unpack(l1l11l_opy_ (u"ࠩࠤࠫ৅")   + # l1ll1111l1_opy_ (l1l1lll1l1_opy_ order)
                                 l1l11l_opy_ (u"ࠪࡌࠬ৆")   + # l1l1ll1ll1_opy_ l1l1l1l1l1_opy_ msg
                                 l1l11l_opy_ (u"ࠫࡍ࠭ে")   + # l1l1ll111l_opy_ level
                                 l1l11l_opy_ (u"ࠬ࡮ࠧৈ")   + # l1l1ll11l1_opy_ temp
                                 l1l11l_opy_ (u"࠭ࡂࠨ৉")   + # error
                                 l1l11l_opy_ (u"ࠧࡃࡄࡅࠫ৊") + # l1l1l1111l_opy_ version major minor l1l1ll1l1l_opy_
                                 l1l11l_opy_ (u"ࠨࡪࠪো")   + # system temp
                                 l1l11l_opy_ (u"ࠩࡅࠫৌ")   + # One l1l1l1l11l_opy_ l1l111111l_opy_
                                 l1l11l_opy_ (u"ࠪ࠵࠵ࡹ্ࠧ") + # serial no
                                 l1l11l_opy_ (u"ࠫࡇࡈࠧৎ")  + # device type, l1ll111l1l_opy_ version (l1l1ll1lll_opy_)
                                 l1l11l_opy_ (u"ࠬࡅࠧ৏")   + # l1l1l11lll_opy_ enabled
                                 l1l11l_opy_ (u"࠭ࡈࠨ৐")
                                 ,
                                 res[2:])
        self.device_info[l1l11l_opy_ (u"ࠧ࡯ࡷࡰࡣࡸࡺ࡯ࡳࡧࡧࡣࡲࡹࡧࠨ৑")] = data[0]
        self.device_info[l1l11l_opy_ (u"ࠨࡤࡤࡸࡹ࡫ࡲࡺࡡࡳࡩࡷࡩࡥ࡯ࡶࡤ࡫ࡪ࠭৒")] = self._1l1l1ll11_opy_(data[1])
        self.device_info[l1l11l_opy_ (u"ࠩࡷࡶࡦࡴࡳ࡮࡫ࡷࡸࡪࡸ࡟ࡵࡧࡰࡴࡪࡸࡡࡵࡷࡵࡩࠬ৓")] = data[2]
        self.device_info[l1l11l_opy_ (u"ࠪࡩࡷࡸ࡯ࡳࡡࡩࡰࡦ࡭ࡳࠨ৔")] = data[3]
        self.device_info[l1l11l_opy_ (u"ࠫ࡫ࡽ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ৕")] = (data[4], data[5], data[6])
        self.device_info[l1l11l_opy_ (u"ࠬࡹࡹࡴࡶࡨࡱࡤࡺࡥ࡮ࡲࡨࡶࡦࡺࡵࡳࡧࠪ৖")] = data[7]
        self.device_info[l1l11l_opy_ (u"࠭ࡳࡦࡴ࡬ࡥࡱ࠭ৗ")] = data[9]
        self.device_info[l1l11l_opy_ (u"ࠧ࡭ࡧࡧࡣࡪࡴࡡࡣ࡮ࡨࡨࠬ৘")] = data[12]
        self.device_info[l1l11l_opy_ (u"ࠨࡤ࡯ࡹࡪࡺ࡯ࡰࡶ࡫ࡣࡪࡴࡡࡣ࡮ࡨࡨࠬ৙")] = False
        return self.device_info
    def _1l1l1ll11_opy_(self, l111lll_opy_):
        raise NotImplementedError
    def set_emergency_beacon(self, enabled):
        l1l11l_opy_ (u"ࠤࠥࠦࠥࡋ࡮ࡢࡤ࡯ࡩࠥࡵࡲࠡࡦ࡬ࡷࡦࡨ࡬ࡦࠢࡷ࡬ࡪࠦࡥ࡮ࡧࡵ࡫ࡪࡴࡣࡺࠢࡥࡩࡦࡩ࡯࡯࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡨ࡯ࡰ࡮ࠣࡩࡳࡧࡢ࡭ࡧࡧ࠾ࠥ࡝ࡨࡦࡶ࡫ࡩࡷࠦࡴࡰࠢࡨࡲࡦࡨ࡬ࡦࠢࠫࡤࡥ࡚ࡲࡶࡧࡣࡤ࠮ࠦ࡯ࡳࠢࡧ࡭ࡸࡧࡢ࡭ࡧࠣࠬࡥࡦࡆࡢ࡮ࡶࡩࡥࡦࠩࠡࡶ࡫ࡩࠥࡨࡥࡢࡥࡲࡲ࠳ࠦࡉࡧࠢࡷ࡬ࡪࠦࡢࡦࡣࡦࡳࡳࠦࡩࡴࠢࡨࡲࡦࡨ࡬ࡦࡦࠣࡻ࡮ࡺࡨࡰࡷࡷࠤࡦࡴࠠࡦ࡯ࡨࡶ࡬࡫࡮ࡤࡻࠣࡱࡪࡹࡳࡢࡩࡨࠤࡧ࡫ࡩ࡯ࡩࠣࡷࡹࡵࡲࡦࡦ࠯ࠤࡳࡵࠠ࡮ࡧࡶࡷࡦ࡭ࡥࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡶࡩࡳࡺ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡦ࡯ࡳࡦࡵࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡨࡵ࡮ࡴࡶࡤࡲࡹࡹ࠮ࡕ࡫ࡰࡩࡴࡻࡴࡆࡺࡦࡩࡵࡺࡩࡰࡰ࠽ࠤ࡙࡮ࡥࠡࡦࡨࡺ࡮ࡩࡥࠡ࡫ࡶࠤࡳࡵࠠ࡭ࡱࡱ࡫ࡪࡸࠠࡤࡱࡱࡲࡪࡩࡴࡦࡦࠣࡥࡳࡪࠠࡥ࡫ࡧࠤࡳࡵࡴࠡࡴࡨࡷࡵࡵ࡮ࡥ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡡࡪࡵࡨࡷࠥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡣࡰࡰࡶࡸࡦࡴࡴࡴ࠰ࡕࡩࡲࡵࡴࡦࡇࡵࡶࡴࡸ࠺ࠡࡖ࡫ࡩࠥࡪࡥࡷ࡫ࡦࡩࠥࡸࡥࡵࡷࡵࡲࡪࡪࠠࡢࠢࡵࡩࡲࡵࡴࡦࠢࡨࡶࡷࡵࡲࠡࡥࡲࡨࡪ࠴ࠠࡔࡧࡨࠤ࠿ࡶࡹ࠻ࡣࡷࡸࡷࡀࡠࡨࡱࡗࡩࡳࡴࡡ࠯ࡥࡲࡲࡸࡺࡡ࡯ࡶࡶ࠲ࡗ࡫࡭ࡰࡶࡨࡉࡷࡸ࡯ࡳ࠰ࡦࡳࡩ࡫ࡠࠡࡨࡲࡶࠥࡪࡥࡵࡣ࡬ࡰࡸ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦ৚")
        l1ll11111l_opy_ = bool(enabled)
        tlv = goTenna.tlv.l1l1l11111_opy_.l1l1l11ll1_opy_(l1ll11111l_opy_)
        l1l11111l1_opy_ = l1l11l_opy_ (u"ࠪࡷࡪࡺ࡟ࡱࡴࡲࡴࡪࡸࡴࡺࠩ৛")
        command = goTenna.binary_utils.l11lll_opy_[l1l11111l1_opy_] \
                  + tlv.to_bytes()
        self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"ࠫࢀࢃ࠺ࠡࡽࢀࠫড়").format(l1l11111l1_opy_, binascii.hexlify(command)))
        self.l1l111l111_opy_.write_binary(command)
        res = self._1ll111ll1_opy_(l1l11111l1_opy_, command)
        if goTenna.binary_utils.l111_opy_(goTenna.util.l1lll11_opy_(res[0])):
            code = goTenna.constants.ErrorCodes.UNKNOWN
            raise goTenna.constants.RemoteError(code, l1l11l_opy_ (u"ࠬࢁࡽࠨঢ়").format(binascii.hexlify(res)))
        self.device_info[l1l11l_opy_ (u"࠭ࡥ࡮ࡧࡵ࡫ࡪࡴࡣࡺࡡࡥࡩࡦࡩ࡯࡯ࡡࡨࡲࡦࡨ࡬ࡦࡦࠪ৞")] = enabled
    def l1l11l1l1l_opy_(self):
        l1l11l_opy_ (u"ࠢࠣࠤࠣࡋࡪࡺࠠࡸࡪࡨࡸ࡭࡫ࡲࠡࡱࡵࠤࡳࡵࡴࠡࡶ࡫ࡩࠥࡨࡥࡢࡥࡲࡲࠥ࡯ࡳࠡࡧࡱࡥࡧࡲࡥࡥ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡦࡶࡸࡶࡳࡹࠠࡣࡱࡲࡰ࠿ࠦࡗࡩࡧࡷ࡬ࡪࡸࠠࡵࡪࡨࠤࡧ࡫ࡡࡤࡱࡱࠤ࡮ࡹࠠࡦࡰࡤࡦࡱ࡫ࡤ࠯ࠢࡄࡰࡸࡵࠠࡴࡧࡷࡷࠥࡺࡨࡦࠢࡧࡩࡻ࡯ࡣࡦࠢ࡬ࡲ࡫ࡵࠠࡧ࡮ࡤ࡫࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡤ࡭ࡸ࡫ࡳࠡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡦࡳࡳࡹࡴࡢࡰࡷࡷ࠳࡚ࡩ࡮ࡧࡲࡹࡹࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮࠻ࠢࡗ࡬ࡪࠦࡤࡦࡸ࡬ࡧࡪࠦࡩࡴࠢࡱࡳࠥࡲ࡯࡯ࡩࡨࡶࠥࡩ࡯࡯ࡰࡨࡧࡹ࡫ࡤࠡࡣࡱࡨࠥࡪࡩࡥࠢࡱࡳࡹࠦࡲࡦࡵࡳࡳࡳࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡦ࡯ࡳࡦࡵࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡨࡵ࡮ࡴࡶࡤࡲࡹࡹ࠮ࡓࡧࡰࡳࡹ࡫ࡅࡳࡴࡲࡶ࠿ࠦࡔࡩࡧࠣࡨࡪࡼࡩࡤࡧࠣࡶࡪࡺࡵࡳࡰࡨࡨࠥࡧࠠࡳࡧࡰࡳࡹ࡫ࠠࡦࡴࡵࡳࡷࠦࡣࡰࡦࡨ࠲࡙ࠥࡥࡦࠢ࠽ࡴࡾࡀࡡࡵࡶࡵ࠾ࡥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡣࡰࡰࡶࡸࡦࡴࡴࡴ࠰ࡕࡩࡲࡵࡴࡦࡇࡵࡶࡴࡸ࠮ࡤࡱࡧࡩࡥࠦࡦࡰࡴࠣࡨࡪࡺࡡࡪ࡮ࡶ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤয়")
        type_code = goTenna.tlv.l1l1l11111_opy_.l1l1l11ll1_opy_.l1l11llll1_opy_
        l1l11111l1_opy_ = l1l11l_opy_ (u"ࠨࡩࡨࡸࡤࡶࡲࡰࡲࡨࡶࡹࡿࠧৠ")
        command = goTenna.binary_utils.l11lll_opy_[l1l11111l1_opy_] \
                  + goTenna.tlv.l1l1l11111_opy_.l1ll1111ll_opy_(type_code).to_bytes()
        self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"ࠩࡾࢁ࠿ࠦࡻࡾࠩৡ").format(l1l11111l1_opy_, binascii.hexlify(command)))
        self.l1l111l111_opy_.write_binary(command)
        res = self._1ll111ll1_opy_(l1l11111l1_opy_, command)
        if goTenna.binary_utils.l111_opy_(goTenna.util.l1lll11_opy_(res[0])):
            code = goTenna.constants.ErrorCodes.UNKNOWN
            raise goTenna.constants.RemoteError(code, l1l11l_opy_ (u"ࠪࡿࢂ࠭ৢ").format(binascii.hexlify(res)))
        v = goTenna.tlv.basic_tlv.TLV.l1l111l1ll_opy_(res[2:],
                                                     (goTenna.tlv.l1l1l11111_opy_.l1l1l11ll1_opy_,))
        self.device_info[l1l11l_opy_ (u"ࠫࡪࡳࡥࡳࡩࡨࡲࡨࡿ࡟ࡣࡧࡤࡧࡴࡴ࡟ࡦࡰࡤࡦࡱ࡫ࡤࠨৣ")] = v[0].enabled
        return v[0].enabled
    def l1l11ll1l1_opy_(self):
        l1l11l_opy_ (u"ࠧࠨࠢࠡࡉࡨࡸࠥࡽࡨࡦࡶ࡫ࡩࡷࠦ࡯ࡳࠢࡱࡳࡹࠦࡴࡩࡧࠣࡼࠥࡩࡡࡱࡣࡥ࡭ࡱ࡯ࡴࡺࠢ࡬ࡷࠥ࡫࡮ࡢࡤ࡯ࡩࡩ࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰࡶࠤࡧࡵ࡯࡭࠼࡛ࠣ࡭࡫ࡴࡩࡧࡵࠤࡹ࡮ࡥࠡࡺࠣࡧࡦࡶࡡࡣ࡫࡯࡭ࡹࡿࠠࡪࡵࠣࡩࡳࡧࡢ࡭ࡧࡧ࠲ࠥࡇ࡬ࡴࡱࠣࡷࡪࡺࡳࠡࡶ࡫ࡩࠥࡪࡥࡷ࡫ࡦࡩࠥ࡯࡮ࡧࡱࠣࡪࡱࡧࡧ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷࡧࡩࡴࡧࡶࠤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡩ࡯࡯ࡵࡷࡥࡳࡺࡳ࠯ࡖ࡬ࡱࡪࡵࡵࡵࡇࡻࡧࡪࡶࡴࡪࡱࡱ࠾࡚ࠥࡨࡦࠢࡧࡩࡻ࡯ࡣࡦࠢ࡬ࡷࠥࡴ࡯ࠡ࡮ࡲࡲ࡬࡫ࡲࠡࡥࡲࡲࡳ࡫ࡣࡵࡧࡧࠤࡦࡴࡤࠡࡦ࡬ࡨࠥࡴ࡯ࡵࠢࡵࡩࡸࡶ࡯࡯ࡦ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡢ࡫ࡶࡩࡸࠦࡧࡰࡖࡨࡲࡳࡧ࠮ࡤࡱࡱࡷࡹࡧ࡮ࡵࡵ࠱ࡖࡪࡳ࡯ࡵࡧࡈࡶࡷࡵࡲ࠻ࠢࡗ࡬ࡪࠦࡤࡦࡸ࡬ࡧࡪࠦࡲࡦࡶࡸࡶࡳ࡫ࡤࠡࡣࠣࡶࡪࡳ࡯ࡵࡧࠣࡩࡷࡸ࡯ࡳࠢࡦࡳࡩ࡫࠮ࠡࡕࡨࡩࠥࡀࡰࡺ࠼ࡤࡸࡹࡸ࠺ࡡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡦࡳࡳࡹࡴࡢࡰࡷࡷ࠳ࡘࡥ࡮ࡱࡷࡩࡊࡸࡲࡰࡴ࠱ࡧࡴࡪࡥࡡࠢࡩࡳࡷࠦࡤࡦࡶࡤ࡭ࡱࡹ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ৤")
        type_code = goTenna.tlv.l1l1l11111_opy_.l1ll11l111_opy_.l1l11llll1_opy_
        l1l11111l1_opy_ = l1l11l_opy_ (u"࠭ࡧࡦࡶࡢࡴࡷࡵࡰࡦࡴࡷࡽࠬ৥")
        command = goTenna.binary_utils.l11lll_opy_[l1l11111l1_opy_] \
                  + goTenna.tlv.l1l1l11111_opy_.l1ll1111ll_opy_(type_code).to_bytes()
        self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"ࠧࡼࡿ࠽ࠤࢀࢃࠧ০").format(l1l11111l1_opy_, binascii.hexlify(command)))
        self.l1l111l111_opy_.write_binary(command)
        res = self._1ll111ll1_opy_(l1l11111l1_opy_, command)
        if goTenna.binary_utils.l111_opy_(goTenna.util.l1lll11_opy_(res[0])):
            return False
        v = goTenna.tlv.basic_tlv.TLV.l1l111l1ll_opy_(res[2:],
                                                     (goTenna.tlv.l1l1l11111_opy_.l1ll11l111_opy_,))
        self.device_info[l1l11l_opy_ (u"ࠨࡺࡢࡩࡳࡧࡢ࡭ࡧࠪ১")] = v[0].enabled
        return v[0].enabled
    def set_operation_mode(self, mode):
        l1l11l_opy_ (u"ࠤ࡙ࠥࠦࠥࡥࡵࠢࡷ࡬ࡪࠦࡤࡦࡸ࡬ࡧࡪ࠭ࡳࠡ࡯ࡲࡨࡪ࠲ࠠࡣࡧࡷࡻࡪ࡫࡮ࠡࡑࡉࡊࠥࡧ࡮ࡥࠢࡑࡓࡗࡓࡁࡍࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡲࡵࡤࡦ࠼ࠣࡅࠥࡳࡥ࡮ࡤࡨࡶࠥࡵࡦࠡ࠼ࡳࡽ࠿ࡩ࡬ࡢࡵࡶ࠾ࡥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡑࡳࡩࡷࡧࡴࡪࡱࡱࡑࡴࡪࡥࡴࡢ࠱ࠤ࡙࡮ࡥࠡ࡯ࡲࡨࡪࠦࡴࡰࠢࡶࡩࡹ࠴ࠠࡔࡱࡰࡩࠥࡳ࡯ࡥࡧࡶࠤ࠭ࡘࡅࡍࡃ࡜࠭ࠥࡳࡡࡺࠢࡱࡳࡹࠦࡢࡦࠢࡤࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠥࡵ࡮ࠡࡶ࡫࡭ࡸࠦࡤࡦࡸ࡬ࡧࡪ࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡦ࡯ࡳࡦࡵࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡨࡵ࡮ࡴࡶࡤࡲࡹࡹ࠮ࡕ࡫ࡰࡩࡴࡻࡴࡆࡺࡦࡩࡵࡺࡩࡰࡰ࠽ࠤ࡙࡮ࡥࠡࡦࡨࡺ࡮ࡩࡥࠡ࡫ࡶࠤࡳࡵࠠ࡭ࡱࡱ࡫ࡪࡸࠠࡤࡱࡱࡲࡪࡩࡴࡦࡦࠣࡥࡳࡪࠠࡥ࡫ࡧࠤࡳࡵࡴࠡࡴࡨࡷࡵࡵ࡮ࡥ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡡࡪࡵࡨࡷࠥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡣࡰࡰࡶࡸࡦࡴࡴࡴ࠰ࡕࡩࡲࡵࡴࡦࡇࡵࡶࡴࡸ࠺ࠡࡖ࡫ࡩࠥࡪࡥࡷ࡫ࡦࡩࠥࡸࡥࡵࡷࡵࡲࡪࡪࠠࡢࠢࡵࡩࡲࡵࡴࡦࠢࡨࡶࡷࡵࡲࠡࡥࡲࡨࡪ࠴ࠠࡔࡧࡨࠤ࠿ࡶࡹ࠻ࡣࡷࡸࡷࡀࡠࡨࡱࡗࡩࡳࡴࡡ࠯ࡥࡲࡲࡸࡺࡡ࡯ࡶࡶ࠲ࡗ࡫࡭ࡰࡶࡨࡉࡷࡸ࡯ࡳ࠰ࡦࡳࡩ࡫ࡠࠡࡨࡲࡶࠥࡪࡥࡵࡣ࡬ࡰࡸ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦ২")
        if mode == goTenna.constants.OperationModes.RELAY:
            raise ValueError(l1l11l_opy_ (u"ࠥࡍࡳࡼࡡ࡭࡫ࡧࠤࡴࡶࡥࡳࡣࡷ࡭ࡴࡴࠠ࡮ࡱࡧࡩࠥࢁࡽࠣ৩")
                             .format(goTenna.constants.OperationModes.name(mode)))
        l1ll11lll1_opy_ = l1l1l11111_opy_.l1l1l1ll1l_opy_(mode)
        l1l11111l1_opy_ = l1l11l_opy_ (u"ࠫࡸ࡫ࡴࡠࡲࡵࡳࡵ࡫ࡲࡵࡻࠪ৪")
        l1l111l1l1_opy_ = goTenna.binary_utils.l11lll_opy_[l1l11111l1_opy_] \
                     + l1ll11lll1_opy_.to_bytes()
        self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"ࠬࢁࡽ࠻ࠢࡾࢁࠬ৫").format(l1l11111l1_opy_, binascii.hexlify(l1l111l1l1_opy_)))
        self.l1l111l111_opy_.write_binary(l1l111l1l1_opy_)
        res = self._1ll111ll1_opy_(l1l11111l1_opy_, l1l111l1l1_opy_)
        if goTenna.binary_utils.l111_opy_(goTenna.util.l1lll11_opy_(res[0])):
            code = goTenna.util.l1lll11_opy_(res[2])
            raise goTenna.constants.RemoteError(code, l1l11l_opy_ (u"࠭ࠧ৬"))
    def l1l1ll1111_opy_(self, l1l1l1l1ll_opy_=True, l11lllll1l_opy_=True, l1ll111lll_opy_=False,
                         l1l11ll111_opy_=False, l1l11l1lll_opy_=True, l1l11lllll_opy_=True):
        l1l11l_opy_ (u"ࠢࠣࠤࠣࡗࡪࡺࠠࡵࡪࡨࠤࡩ࡫ࡶࡪࡥࡨࠫࡸࠦ࡮ࡦࡶࡺࡳࡷࡱࠠ࡮ࡱࡧࡩࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡮ࡧࡶ࡬࡮ࡴࡧ࠻ࠢࡄࡰࡱࡵࡷࠡ࡯ࡨࡷ࡭࡯࡮ࡨࠢࡲࡪࠥࡳࡥࡴࡵࡤ࡫ࡪࡹࠠࡰࡰࠣࡸ࡭࡯ࡳࠡࡦࡨࡺ࡮ࡩࡥ࠼ࠢࡷࡶࡺ࡫ࠠࡰࡴࠣࡪࡦࡲࡳࡦ࠮ࠣࡨࡪ࡬ࡡࡶ࡮ࡷࠤ࡮ࡹࠠࡵࡴࡸࡩ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡵࡴࡤࡲࡸࡳࡩࡵࡡࡲࡶ࡮࡭ࡩ࡯ࡣࡷࡩࡩࡀࠠࡂ࡮࡯ࡳࡼࠦࡴࡳࡣࡱࡷࡲ࡯ࡴࡪࡱࡱࠤࡴ࡬ࠠࡰࡴ࡬࡫࡮ࡴࡡࡵࡧࡧࠤࡲ࡫ࡳࡴࡣࡪࡩࡸࠦ࡯࡯ࠢࡷ࡬࡮ࡹࠠࡥࡧࡹ࡭ࡨ࡫࠻ࠡࡶࡵࡹࡪࠦ࡯ࡳࠢࡩࡥࡱࡹࡥ࠭ࠢࡧࡩ࡫ࡧࡵ࡭ࡶࠣ࡭ࡸࠦࡴࡳࡷࡨ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡦ࡭ࡱࡲࡨ࡮ࡴࡧࡠࡵ࡫ࡳࡺࡺ࠺ࠡࡃ࡯ࡰࡴࡽࠠࡧ࡮ࡲࡳࡩࠦ࡯࡯ࠢࡶ࡬ࡴࡻࡴࠡ࡯ࡨࡷࡸࡧࡧࡦࡵࠣࡳࡳࠦࡴࡩ࡫ࡶࠤࡩ࡫ࡶࡪࡥࡨ࠿ࠥࡺࡲࡶࡧࠣࡳࡷࠦࡦࡢ࡮ࡶࡩ࠱ࠦࡤࡦࡨࡤࡹࡱࡺࠠࡪࡵࠣࡪࡦࡲࡳࡦ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤ࡫ࡲ࡯ࡰࡦ࡬ࡲ࡬ࡥࡧࡳࡱࡸࡴ࠿ࠦࡁ࡭࡮ࡲࡻࠥ࡬࡬ࡰࡱࡧࠤࡴࡴࠠࡨࡴࡲࡹࡵࠦ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠡࡱࡱࠤࡹ࡮ࡩࡴࠢࡧࡩࡻ࡯ࡣࡦ࠽ࠣࡸࡷࡻࡥࠡࡱࡵࠤ࡫ࡧ࡬ࡴࡧ࠯ࠤࡩ࡫ࡦࡢࡷ࡯ࡸࠥ࡯ࡳࠡࡨࡤࡰࡸ࡫࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡩࡰࡴࡵࡤࡪࡰࡪࡣࡵࡸࡩࡷࡣࡷࡩ࠿ࠦࡁ࡭࡮ࡲࡻࠥ࡬࡬ࡰࡱࡧࠤࡴࡴࠠࡱࡴ࡬ࡺࡦࡺࡥࠡ࡯ࡨࡷࡸࡧࡧࡦࡵࠣࡳࡳࠦࡴࡩ࡫ࡶࠤࡩ࡫ࡶࡪࡥࡨ࠿ࠥࡺࡲࡶࡧࠣࡳࡷࠦࡦࡢ࡮ࡶࡩ࠱ࠦࡤࡦࡨࡤࡹࡱࡺࠠࡪࡵࠣࡸࡷࡻࡥ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡪࡱࡵ࡯ࡥ࡫ࡱ࡫ࡤ࡫࡭ࡦࡴࡪࡩࡳࡩࡹ࠻ࠢࡄࡰࡱࡵࡷࠡࡨ࡯ࡳࡴࡪࠠࡰࡰࠣࡩࡲ࡫ࡲࡨࡧࡱࡧࡾࠦ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠡࡱࡱࠤࡹ࡮ࡩࡴࠢࡧࡩࡻ࡯ࡣࡦ࠽ࠣࡸࡷࡻࡥࠡࡱࡵࠤ࡫ࡧ࡬ࡴࡧ࠯ࠤࡩ࡫ࡦࡢࡷ࡯ࡸࠥ࡯ࡳࠡࡶࡵࡹࡪ࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡦ࡯ࡳࡦࡵࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡨࡵ࡮ࡴࡶࡤࡲࡹࡹ࠮ࡕ࡫ࡰࡩࡴࡻࡴࡆࡺࡦࡩࡵࡺࡩࡰࡰ࠽ࠤ࡙࡮ࡥࠡࡦࡨࡺ࡮ࡩࡥࠡ࡫ࡶࠤࡳࡵࠠ࡭ࡱࡱ࡫ࡪࡸࠠࡤࡱࡱࡲࡪࡩࡴࡦࡦࠣࡥࡳࡪࠠࡥ࡫ࡧࠤࡳࡵࡴࠡࡴࡨࡷࡵࡵ࡮ࡥ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡡࡪࡵࡨࡷࠥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡣࡰࡰࡶࡸࡦࡴࡴࡴ࠰ࡕࡩࡲࡵࡴࡦࡇࡵࡶࡴࡸ࠺ࠡࡖ࡫ࡩࠥࡪࡥࡷ࡫ࡦࡩࠥࡸࡥࡵࡷࡵࡲࡪࡪࠠࡢࠢࡵࡩࡲࡵࡴࡦࠢࡨࡶࡷࡵࡲࠡࡥࡲࡨࡪ࠴ࠠࡔࡧࡨࠤ࠿ࡶࡹ࠻ࡣࡷࡸࡷࡀࡠࡨࡱࡗࡩࡳࡴࡡ࠯ࡥࡲࡲࡸࡺࡡ࡯ࡶࡶ࠲ࡗ࡫࡭ࡰࡶࡨࡉࡷࡸ࡯ࡳ࠰ࡦࡳࡩ࡫ࡠࠡࡨࡲࡶࠥࡪࡥࡵࡣ࡬ࡰࡸ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦ৭")
        l1l11111l1_opy_ = l1l11l_opy_ (u"ࠨࡵࡨࡸࡤࡶࡲࡰࡲࡨࡶࡹࡿࠧ৮")
        l1l11l11ll_opy_ = l1l1l11111_opy_.l1l1llllll_opy_(l1l1l1l1ll_opy_, l11lllll1l_opy_,
                                                l1ll111lll_opy_, l1l11ll111_opy_,
                                                l1l11l1lll_opy_, l1l11lllll_opy_)
        command = goTenna.binary_utils.l11lll_opy_[l1l11111l1_opy_] \
                  + l1l11l11ll_opy_.to_bytes()
        self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"ࠩࡾࢁ࠿ࠦࡻࡾࠩ৯").format(l1l11111l1_opy_, binascii.hexlify(command)))
        self.l1l111l111_opy_.write_binary(command)
        self._1ll111ll1_opy_(l1l11111l1_opy_, command)
    def l1l11l11l1_opy_(self):
        l1l11l_opy_ (u"ࠥࠦࠧࠦࡇࡦࡶࠣࡸ࡭࡫ࠠࡥࡧࡹ࡭ࡨ࡫ࠧࡴࠢࡱࡩࡹࡽ࡯ࡳ࡭ࠣࡱࡴࡪࡥࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷࡧࡩࡴࡧࡶࠤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡩ࡯࡯ࡵࡷࡥࡳࡺࡳ࠯ࡖ࡬ࡱࡪࡵࡵࡵࡇࡻࡧࡪࡶࡴࡪࡱࡱ࠾࡚ࠥࡨࡦࠢࡧࡩࡻ࡯ࡣࡦࠢ࡬ࡷࠥࡴ࡯ࠡ࡮ࡲࡲ࡬࡫ࡲࠡࡥࡲࡲࡳ࡫ࡣࡵࡧࡧࠤࡦࡴࡤࠡࡦ࡬ࡨࠥࡴ࡯ࡵࠢࡵࡩࡸࡶ࡯࡯ࡦ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡢ࡫ࡶࡩࡸࠦࡧࡰࡖࡨࡲࡳࡧ࠮ࡤࡱࡱࡷࡹࡧ࡮ࡵࡵ࠱ࡖࡪࡳ࡯ࡵࡧࡈࡶࡷࡵࡲ࠻ࠢࡗ࡬ࡪࠦࡤࡦࡸ࡬ࡧࡪࠦࡲࡦࡶࡸࡶࡳ࡫ࡤࠡࡣࠣࡶࡪࡳ࡯ࡵࡧࠣࡩࡷࡸ࡯ࡳࠢࡦࡳࡩ࡫࠮ࠡࡕࡨࡩࠥࡀࡰࡺ࠼ࡤࡸࡹࡸ࠺ࡡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡦࡳࡳࡹࡴࡢࡰࡷࡷ࠳ࡘࡥ࡮ࡱࡷࡩࡊࡸࡲࡰࡴ࠱ࡧࡴࡪࡥࡡࠢࡩࡳࡷࠦࡤࡦࡶࡤ࡭ࡱࡹ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧৰ")
        type_code = goTenna.tlv.l1l1l11111_opy_.l1l1llllll_opy_.l1l11llll1_opy_
        l1l11111l1_opy_ = l1l11l_opy_ (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡵ࡫ࡲࡵࡻࠪৱ")
        command = goTenna.binary_utils.l11lll_opy_[l1l11111l1_opy_] \
                  + goTenna.tlv.l1l1l11111_opy_.l1ll1111ll_opy_(type_code).to_bytes()
        self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"ࠬࢁࡽ࠻ࠢࡾࢁࠬ৲").format(l1l11111l1_opy_, binascii.hexlify(command)))
        self.l1l111l111_opy_.write_binary(command)
        res = self._1ll111ll1_opy_(l1l11111l1_opy_, command)
        if goTenna.binary_utils.l111_opy_(goTenna.util.l1lll11_opy_(res[0])):
            return False
        v = goTenna.tlv.basic_tlv.TLV.l1l111l1ll_opy_(res[2:],
                                                     (goTenna.tlv.l1l1l11111_opy_.l1l1llllll_opy_,))
        return v
    def _1ll111ll1_opy_(self, l1l11111l1_opy_, l1l1lll11l_opy_, timeout_override=10):
        l1l11l_opy_ (u"ࠨࠢࠣࠢࡕࡩࡦࡪࠠࡵࡪࡨࠤࡧ࡯࡮ࡢࡴࡼࠤࡧࡲ࡯ࡤ࡭ࠣࡶࡪࡹࡰࡰࡰࡶࡩࠥࡳࡡࡵࡪࡦ࡭ࡳ࡭ࠠࡢࠢࡦࡳࡲࡳࡡ࡯ࡦ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡣ࡮ࡦࡢࡲࡦࡳࡥ࠻ࠢࡖࡸࡷ࡯࡮ࡨࠢࡱࡥࡲ࡫ࠠࡰࡨࠣࡸ࡭࡫ࠠࡤࡱࡰࡱࡦࡴࡤ࠭ࠢࡸࡷࡪࡪࠠࡧࡱࡵࠤࡩ࡫ࡢࡶࡩࠣࡴࡷ࡯࡮ࡵࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡲࡪ࡟ࡣ࡫ࡱ࠾ࠥࡈࡩ࡯ࡣࡵࡽࠥࡩ࡯࡮࡯ࡤࡲࡩࠦࡵࡴࡧࡧࠤࡲࡧࡴࡩࡥ࡬ࡲ࡬ࠦࡴࡩࡧࠣࡶࡪࡹࡰࡰࡰࡶࡩࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤ৳")
        l11llllll_opy_ = datetime.datetime.utcnow()
        while True:
            now = datetime.datetime.utcnow()
            l11lllll11_opy_ = self.l1l111l111_opy_.read_binary_blocking(timeout_override=timeout_override-
                                                                 (now-l11llllll_opy_).total_seconds())
            self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"ࠧࡼࡿࠣࡶࡸࡶ࠺ࠡࡽࢀࠫ৴").format(l1l11111l1_opy_, binascii.hexlify(l11lllll11_opy_)))
            if goTenna.binary_utils.l1lll1_opy_(goTenna.util.l1lll11_opy_(l11lllll11_opy_[0]))\
               == goTenna.util.l1lll11_opy_(l1l1lll11l_opy_[0]):
                return l11lllll11_opy_
class l1l111ll11_opy_(l1l1111111_opy_):
    _1l111lll1_opy_ = collections.OrderedDict(sorted({
        54834: 100, 54512: 99, 54404: 98, 54297: 97, 54176: 96, 54069: 95,
        53975: 94, 53881: 93, 53754: 92, 53673: 91, 53626: 90, 53499: 89,
        53405: 88, 53298: 87, 53237: 86, 53143: 85, 53070: 84, 52976: 83,
        52882: 82, 52801: 81, 52754: 80, 52647: 79, 52560: 78, 52493: 77,
        52412: 76, 52359: 75, 52238: 74, 52157: 73, 52070: 72, 51963: 71,
        51923: 70, 51815: 69, 51735: 68, 51648: 67, 51594: 66, 51520: 65,
        51466: 64, 51399: 63, 51346: 62, 51305: 61, 51238: 60, 51191: 59,
        51124: 58, 51084: 57, 51071: 56, 50990: 55, 50977: 54, 50916: 53,
        50910: 52, 50856: 51, 50816: 50, 50789: 49, 50755: 48, 50742: 47,
        50709: 46, 50662: 45, 50641: 44, 50621: 43, 50595: 42, 50568: 41,
        50541: 40, 50527: 39, 50480: 38, 50474: 37, 50434: 36, 50420: 35,
        50387: 34, 50360: 33, 50319: 32, 50293: 31, 50232: 30, 50199: 29,
        50152: 28, 50105: 27, 50078: 26, 50038: 25, 49984: 24, 49937: 23,
        49877: 22, 49837: 21, 49763: 20, 49702: 19, 49649: 18, 49562: 17,
        49488: 16, 49387: 15, 49313: 14, 49273: 13, 49226: 12, 49186: 11,
        49132: 10, 49058: 9, 48944: 8, 48710: 7, 48475: 6, 47717: 5, 47019: 4,
        46141: 3, 45021: 2, 42975: 1, 40218: 0,
    }.items(), key=lambda i: i[0]))
    def _1l1l1ll11_opy_(self, l111lll_opy_):
        return goTenna.util.l1lll1ll_opy_(self._1l111lll1_opy_, l111lll_opy_)
    def l1l11lll1l_opy_(self, groups, rf_settings):
        l1l11l_opy_ (u"ࠣࠤࠥࠤࡗ࡫࡭ࡰࡸࡨࠤࡦࡲ࡬ࠡࡵࡨࡸࡹ࡯࡮ࡨࡵࠣࡪࡷࡵ࡭ࠡࡶ࡫ࡩࠥࡸࡥ࡮ࡱࡷࡩࠥ࡭࡯ࡕࡧࡱࡲࡦࠦࡡ࡯ࡦࠣࡶࡪࡶ࡬ࡢࡥࡨࠤࡹ࡮ࡥ࡮ࠢࡺ࡭ࡹ࡮ࠠࡵࡪࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࡹࡥࡵࡶ࡬ࡲ࡬ࡹࠠࡧࡱࡵࠤࡹ࡮ࡥࠡࡥࡸࡶࡷ࡫࡮ࡵࠢࡸࡷࡪࡸ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢ࡯࡭ࡸࡺ࡛ࡨࡱࡗࡩࡳࡴࡡ࠯ࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡷࡵࡵࡱ࡟ࠣ࡫ࡷࡵࡵࡱࡵ࠽ࠤࡎࡴࠠࡵࡪࡨࠤ࡫ࡻࡴࡶࡴࡨ࠰ࠥࡽࡩ࡭࡮ࠣࡧࡴࡴࡦࡪࡩࡸࡶࡪࠦࡴࡩࡧࠣࡨࡪࡼࡩࡤࡧࠣࡻ࡮ࡺࡨࠡ࡭ࡱࡳࡼࡴࠠࡨࡴࡲࡹࡵࡹ࠮ࠡࡋࡪࡲࡴࡸࡥࡥࠢ࡬ࡲࠥࡺࡨࡪࡵࠣࡅࡕࡏࠠࡷࡧࡵࡷ࡮ࡵ࡮࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡒࡇࡕࡨࡸࡹ࡯࡮ࡨࡵࠣࡶ࡫ࡥࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠻ࠢࡕࡊࠥࡹࡥࡵࡶ࡬ࡲ࡬ࡹࠠࡵࡱࠣࡧࡴࡴࡦࡪࡩࡸࡶࡪࠦࡴࡩࡧࠣࡨࡪࡼࡩࡤࡧࠣࡻ࡮ࡺࡨ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷࡧࡩࡴࡧࡶࠤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡩ࡯࡯ࡵࡷࡥࡳࡺࡳ࠯ࡖ࡬ࡱࡪࡵࡵࡵࡇࡻࡧࡪࡶࡴࡪࡱࡱ࠾࡚ࠥࡨࡦࠢࡧࡩࡻ࡯ࡣࡦࠢ࡬ࡷࠥࡴ࡯ࠡ࡮ࡲࡲ࡬࡫ࡲࠡࡥࡲࡲࡳ࡫ࡣࡵࡧࡧࠤࡦࡴࡤࠡࡦ࡬ࡨࠥࡴ࡯ࡵࠢࡵࡩࡸࡶ࡯࡯ࡦ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡢ࡫ࡶࡩࡸࠦࡧࡰࡖࡨࡲࡳࡧ࠮ࡤࡱࡱࡷࡹࡧ࡮ࡵࡵ࠱ࡖࡪࡳ࡯ࡵࡧࡈࡶࡷࡵࡲ࠻ࠢࡗ࡬ࡪࠦࡤࡦࡸ࡬ࡧࡪࠦࡲࡦࡶࡸࡶࡳ࡫ࡤࠡࡣࠣࡶࡪࡳ࡯ࡵࡧࠣࡩࡷࡸ࡯ࡳࠢࡦࡳࡩ࡫࠮ࠡࡕࡨࡩࠥࡀࡰࡺ࠼ࡤࡸࡹࡸ࠺ࡡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡦࡳࡳࡹࡴࡢࡰࡷࡷ࠳ࡘࡥ࡮ࡱࡷࡩࡊࡸࡲࡰࡴ࠱ࡧࡴࡪࡥࡡࠢࡩࡳࡷࠦࡤࡦࡶࡤ࡭ࡱࡹ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ৵")
        self.set_operation_mode(goTenna.constants.OperationModes.NORMAL)
        self.echo()
        if not self.l1l11ll1l1_opy_():
            return
        self.l1ll11l1l1_opy_()
        self.l1ll1l1111_opy_(self.gid)
        self.set_rf_settings(rf_settings)
        self.l1l1ll1111_opy_(l1l1l1l1ll_opy_=True, l11lllll1l_opy_=True,
                              l1ll111lll_opy_=False, l1l11ll111_opy_=False,
                              l1l11l1lll_opy_=True, l1l11lllll_opy_=True)
        for group in groups:
            self.add_group_gid(group)
    def set_rf_settings(self, settings):
        l1l11l_opy_ (u"ࠤ࡛ࠥࠦࠥࡰࡥࡣࡷࡩࠥࡺࡨࡦࠢࡦࡳࡳࡴࡥࡤࡶࡨࡨࠥ࡭࡯ࡕࡧࡱࡲࡦࠦࡷࡪࡶ࡫ࠤࡦࠦࡳࡦࡶࠣࡳ࡫ࠦࡧࡰࡖࡨࡲࡳࡧ࠮ࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡕࡊࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡩࡲࡸࡪࡴ࡮ࡢ࠰ࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡗࡌࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠡࡵࡨࡸࡹ࡯࡮ࡨࡵ࠽ࠤ࡙࡮ࡥࠡࡵࡨࡸࡹ࡯࡮ࡨࡵࠣࡸࡴࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡦࠢࡷ࡬ࡪࠦࡤࡦࡸ࡬ࡧࡪࠦࡷࡪࡶ࡫࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡳࡣ࡬ࡷࡪࡹࠠࡨࡱࡗࡩࡳࡴࡡ࠯ࡥࡲࡲࡸࡺࡡ࡯ࡶࡶ࠲࡙࡯࡭ࡦࡱࡸࡸࡊࡾࡣࡦࡲࡷ࡭ࡴࡴ࠺ࠡࡖ࡫ࡩࠥࡪࡥࡷ࡫ࡦࡩࠥ࡯ࡳࠡࡰࡲࠤࡱࡵ࡮ࡨࡧࡵࠤࡨࡵ࡮࡯ࡧࡦࡸࡪࡪࠠࡢࡰࡧࠤࡩ࡯ࡤࠡࡰࡲࡸࠥࡸࡥࡴࡲࡲࡲࡩ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥࡴࠢࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡧࡴࡴࡳࡵࡣࡱࡸࡸ࠴ࡒࡦ࡯ࡲࡸࡪࡋࡲࡳࡱࡵ࠾࡚ࠥࡨࡦࠢࡧࡩࡻ࡯ࡣࡦࠢࡵࡩࡹࡻࡲ࡯ࡧࡧࠤࡦࠦࡲࡦ࡯ࡲࡸࡪࠦࡥࡳࡴࡲࡶࠥࡩ࡯ࡥࡧ࠱ࠤࡘ࡫ࡥࠡ࠼ࡳࡽ࠿ࡧࡴࡵࡴ࠽ࡤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡩ࡯࡯ࡵࡷࡥࡳࡺࡳ࠯ࡔࡨࡱࡴࡺࡥࡆࡴࡵࡳࡷ࠴ࡣࡰࡦࡨࡤࠥ࡬࡯ࡳࠢࡧࡩࡹࡧࡩ࡭ࡵ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣ৶")
        l1l11111l1_opy_ = l1l11l_opy_ (u"ࠪࡷࡪࡺ࡟ࡱࡴࡲࡴࡪࡸࡴࡺࠩ৷")
        l1l111l11l_opy_ = l1l1l11111_opy_.l1l1l1lll1_opy_(settings.power_enum)
        l1l11ll1ll_opy_ = goTenna.binary_utils.l11lll_opy_[l1l11111l1_opy_] \
                        + l1l111l11l_opy_.to_bytes()
        self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"ࠫࢀࢃ࠺ࠡࡽࢀࠫ৸").format(l1l11111l1_opy_, binascii.hexlify(l1l11ll1ll_opy_)))
        self.l1l111l111_opy_.write_binary(l1l11ll1ll_opy_)
        self._1ll111ll1_opy_(l1l11111l1_opy_, l1l11ll1ll_opy_)
        l1l1l1llll_opy_ = l1l1l11111_opy_.l1l111llll_opy_(settings)
        l1l1111lll_opy_ = goTenna.binary_utils.l11lll_opy_[l1l11111l1_opy_] \
                       + l1l1l1llll_opy_.to_bytes()
        self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"ࠬࢁࡽ࠻ࠢࡾࢁࠬ৹").format(l1l11111l1_opy_, binascii.hexlify(l1l1111lll_opy_)))
        self.l1l111l111_opy_.write_binary(l1l1111lll_opy_)
        self._1ll111ll1_opy_(l1l11111l1_opy_, l1l1111lll_opy_)
        l1l1111l11_opy_ = l1l1l11111_opy_.l1ll111l11_opy_(settings.bandwidth.mask, settings.bandwidth.bitrate)
        l1l1l111ll_opy_ = goTenna.binary_utils.l11lll_opy_[l1l11111l1_opy_] \
                       + l1l1111l11_opy_.to_bytes()
        self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"࠭ࡻࡾ࠼ࠣࡿࢂ࠭৺").format(l1l11111l1_opy_, binascii.hexlify(l1l1l111ll_opy_)))
        self.l1l111l111_opy_.write_binary(l1l1l111ll_opy_)
        self._1ll111ll1_opy_(l1l11111l1_opy_, l1l1l111ll_opy_)
class l1ll111111_opy_(l1l1111111_opy_):
    _1l111lll1_opy_ = collections.OrderedDict(sorted({
        41705: 100, 41506: 99, 41327: 98, 41159: 97, 40980: 96, 40821: 95,
        40672: 94, 40513: 93, 40364: 92, 40235: 91, 40176: 90, 40046: 89,
        39868: 88, 39828: 87, 39659: 86, 39530: 85, 39441: 84, 39351: 83,
        39232: 82, 39153: 81, 39044: 80, 38895: 79, 38795: 78, 38716: 77,
        38607: 76, 38547: 75, 38398: 74, 38309: 73, 38200: 72, 38100: 71,
        38051: 70, 37892: 69, 37782: 68, 37673: 67, 37574: 66, 37485: 65,
        37445: 64, 37316: 63, 37266: 62, 37157: 61, 37097: 60, 36988: 59,
        36909: 58, 36839: 57, 36750: 56, 36730: 55, 36621: 54, 36531: 53,
        36462: 52, 36422: 51, 36353: 50, 36303: 49, 36263: 48, 36214: 47,
        36184: 46, 36134: 45, 36104: 44, 36085: 43, 36035: 42, 36015: 41,
        36005: 40, 35946: 39, 35936: 38, 35896: 37, 35856: 36, 35856: 35,
        35806: 34, 35777: 33, 35757: 32, 35717: 31, 35687: 30, 35658: 29,
        35618: 28, 35598: 27, 35548: 26, 35538: 25, 35469: 24, 35449: 23,
        35389: 22, 35360: 21, 35310: 20, 35231: 19, 35171: 18, 35121: 17,
        35092: 16, 34992: 15, 34962: 14, 34863: 13, 34833: 12, 34724: 11,
        34645: 10, 34565: 9, 34486: 8, 34396: 7, 34377: 6, 34228: 5, 34138: 4,
        34049: 3, 33930: 2, 33821: 1
    }.items(), key=lambda i: i[0]))
    def _1l1l1ll11_opy_(self, l111lll_opy_):
        return goTenna.util.l1lll1ll_opy_(self._1l111lll1_opy_, l111lll_opy_)
    def l1l11lll1l_opy_(self, groups, geo_settings):
        l1l11l_opy_ (u"ࠢࠣࠤࠣࡖࡪࡳ࡯ࡷࡧࠣࡥࡱࡲࠠࡴࡧࡷࡸ࡮ࡴࡧࡴࠢࡩࡶࡴࡳࠠࡵࡪࡨࠤࡷ࡫࡭ࡰࡶࡨࠤ࡬ࡵࡔࡦࡰࡱࡥࠥࡧ࡮ࡥࠢࡵࡩࡵࡲࡡࡤࡧࠣࡸ࡭࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡴࡩࡧࠍࠤࠥࠦࠠࠡࠢࠣࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸࠦࡦࡰࡴࠣࡸ࡭࡫ࠠࡤࡷࡵࡶࡪࡴࡴࠡࡷࡶࡩࡷ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡ࡮࡬ࡷࡹࡡࡧࡰࡖࡨࡲࡳࡧ࠮ࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡶࡴࡻࡰ࡞ࠢࡪࡶࡴࡻࡰࡴ࠼ࠣࡍࡳࠦࡴࡩࡧࠣࡪࡺࡺࡵࡳࡧ࠯ࠤࡼ࡯࡬࡭ࠢࡦࡳࡳ࡬ࡩࡨࡷࡵࡩࠥࡺࡨࡦࠢࡧࡩࡻ࡯ࡣࡦࠢࡺ࡭ࡹ࡮ࠠ࡬ࡰࡲࡻࡳࠦࡧࡳࡱࡸࡴࡸ࠴ࠠࡊࡩࡱࡳࡷ࡫ࡤࠡ࡫ࡱࠤࡹ࡮ࡩࡴࠢࡄࡔࡎࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡦ࡯ࡳࡦࡵࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡨࡵ࡮ࡴࡶࡤࡲࡹࡹ࠮ࡕ࡫ࡰࡩࡴࡻࡴࡆࡺࡦࡩࡵࡺࡩࡰࡰ࠽ࠤ࡙࡮ࡥࠡࡦࡨࡺ࡮ࡩࡥࠡ࡫ࡶࠤࡳࡵࠠ࡭ࡱࡱ࡫ࡪࡸࠠࡤࡱࡱࡲࡪࡩࡴࡦࡦࠣࡥࡳࡪࠠࡥ࡫ࡧࠤࡳࡵࡴࠡࡴࡨࡷࡵࡵ࡮ࡥ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡡࡪࡵࡨࡷࠥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡣࡰࡰࡶࡸࡦࡴࡴࡴ࠰ࡕࡩࡲࡵࡴࡦࡇࡵࡶࡴࡸ࠺ࠡࡖ࡫ࡩࠥࡪࡥࡷ࡫ࡦࡩࠥࡸࡥࡵࡷࡵࡲࡪࡪࠠࡢࠢࡵࡩࡲࡵࡴࡦࠢࡨࡶࡷࡵࡲࠡࡥࡲࡨࡪ࠴ࠠࡔࡧࡨࠤ࠿ࡶࡹ࠻ࡣࡷࡸࡷࡀࡠࡨࡱࡗࡩࡳࡴࡡ࠯ࡥࡲࡲࡸࡺࡡ࡯ࡶࡶ࠲ࡗ࡫࡭ࡰࡶࡨࡉࡷࡸ࡯ࡳ࠰ࡦࡳࡩ࡫ࡠࠡࡨࡲࡶࠥࡪࡥࡵࡣ࡬ࡰࡸ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦ৻")
        self.echo()
        self.l1l11ll1l1_opy_()
        self.l1ll11l1l1_opy_()
        self.l1ll1l1111_opy_(self.gid)
        self.set_geo_settings(geo_settings)
        for group in groups:
            self.add_group_gid(group)
    def set_geo_settings(self, settings):
        l1l11l_opy_ (u"ࠣࠤࠥࠤ࡚ࡶࡤࡢࡶࡨࠤࡹ࡮ࡥࠡࡥࡲࡲࡳ࡫ࡣࡵࡧࡧࠤ࡬ࡵࡔࡦࡰࡱࡥࠥࡽࡩࡵࡪࠣࡥࠥࡹࡥࡵࠢࡲࡪࠥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡳࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡩࡲࡸࡪࡴ࡮ࡢ࠰ࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫࡯ࡔࡧࡷࡸ࡮ࡴࡧࡴࠢࡶࡩࡹࡺࡩ࡯ࡩࡶ࠾࡚ࠥࡨࡦࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠤࡹࡵࠠࡤࡱࡱࡪ࡮࡭ࡵࡳࡧࠣࡸ࡭࡫ࠠࡥࡧࡹ࡭ࡨ࡫ࠠࡸ࡫ࡷ࡬࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡤ࡭ࡸ࡫ࡳࠡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡦࡳࡳࡹࡴࡢࡰࡷࡷ࠳࡚ࡩ࡮ࡧࡲࡹࡹࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮࠻ࠢࡗ࡬ࡪࠦࡤࡦࡸ࡬ࡧࡪࠦࡩࡴࠢࡱࡳࠥࡲ࡯࡯ࡩࡨࡶࠥࡩ࡯࡯ࡰࡨࡧࡹ࡫ࡤࠡࡣࡱࡨࠥࡪࡩࡥࠢࡱࡳࡹࠦࡲࡦࡵࡳࡳࡳࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡦ࡯ࡳࡦࡵࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡨࡵ࡮ࡴࡶࡤࡲࡹࡹ࠮ࡓࡧࡰࡳࡹ࡫ࡅࡳࡴࡲࡶ࠿ࠦࡔࡩࡧࠣࡨࡪࡼࡩࡤࡧࠣࡶࡪࡺࡵࡳࡰࡨࡨࠥࡧࠠࡳࡧࡰࡳࡹ࡫ࠠࡦࡴࡵࡳࡷࠦࡣࡰࡦࡨ࠲࡙ࠥࡥࡦࠢ࠽ࡴࡾࡀࡡࡵࡶࡵ࠾ࡥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡣࡰࡰࡶࡸࡦࡴࡴࡴ࠰ࡕࡩࡲࡵࡴࡦࡇࡵࡶࡴࡸ࠮ࡤࡱࡧࡩࡥࠦࡦࡰࡴࠣࡨࡪࡺࡡࡪ࡮ࡶ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤৼ")
        l1l1lllll1_opy_ = l1l1l11111_opy_.l1ll11l11l_opy_(settings.region)
        l1l11111l1_opy_ = l1l11l_opy_ (u"ࠩࡶࡩࡹࡥࡧࡦࡱࡢࡪࡪࡴࡣࡪࡰࡪࠫ৽")
        l11llllll1_opy_ = goTenna.binary_utils.l11lll_opy_[l1l11111l1_opy_] \
                        + l1l1lllll1_opy_.to_bytes()
        self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"ࠪࡿࢂࡀࠠࡼࡿࠪ৾").format(l1l11111l1_opy_, binascii.hexlify(l11llllll1_opy_)))
        self.l1l111l111_opy_.write_binary(l11llllll1_opy_)
        self._1ll111ll1_opy_(l1l11111l1_opy_, l11llllll1_opy_)