# coding: utf8
import sys
ll_opy_ = sys.version_info [0] == 2
l1llll_opy_ = 2048
l11l1_opy_ = 7
def l1l11l_opy_ (l1l111_opy_):
    global l1_opy_
    l11ll1_opy_ = ord (l1l111_opy_ [-1])
    l1l1l1_opy_ = l1l111_opy_ [:-1]
    l11ll_opy_ = l11ll1_opy_ % len (l1l1l1_opy_)
    l1ll_opy_ = l1l1l1_opy_ [:l11ll_opy_] + l1l1l1_opy_ [l11ll_opy_:]
    if ll_opy_:
        l1l11_opy_ = unicode () .join ([unichr (ord (char) - l1llll_opy_ - (l1l1_opy_ + l11ll1_opy_) % l11l1_opy_) for l1l1_opy_, char in enumerate (l1ll_opy_)])
    else:
        l1l11_opy_ = str () .join ([chr (ord (char) - l1llll_opy_ - (l1l1_opy_ + l11ll1_opy_) % l11l1_opy_) for l1l1_opy_, char in enumerate (l1ll_opy_)])
    return eval (l1l11_opy_)
# Copyright (C) 2018 goTenna, Inc. This file is distributed as part of the
# goTenna USB SDK. See the associated license for more information.
l1l11l_opy_ (u"ࠤࠥࠦࠥࡇࠠࡧ࡫࡯ࡩࠥࡵࡦࠡࡷࡷ࡭ࡱ࡯ࡴࡪࡧࡶࠤࡹ࡮ࡡࡵࠢࡧࡳࡳࡺࠠࡣࡧ࡯ࡳࡳ࡭ࠠࡢࡰࡼࡻ࡭࡫ࡲࡦࠢ࡬ࡲࠥࡶࡡࡳࡶ࡬ࡧࡺࡲࡡࡳࠢࠥࠦࠧࡠ")
import itertools
import sys
import datetime
import calendar
import time
import logging
import os
import six
import goTenna.constants
# This section l1ll111l_opy_ a l11l1lll_opy_ l1llll1ll_opy_ tools to handle l11llll1_opy_ l111111l_opy_ in
# the l1ll1l1l_opy_ l1l111ll_opy_ 2 and l1l111ll_opy_ 3 l11111ll_opy_. l1l11l1_opy_, l111111_opy_ are for l111111l_opy_ in
# strings l1l1l1lll_opy_ l1ll11l1l_opy_ l1l1l11_opy_ l1l1l1l_opy_ l111111l_opy_ in l1111l1_opy_ (for instance, Queue).
# l1llll1l1_opy_ of the l1ll11l11_opy_ and types l111lll1_opy_ here are l11ll1l1_opy_ self l1l1ll1ll_opy_
# l1l1l1lll_opy_ here are l1l1l1ll_opy_ for l1ll1ll1l_opy_ that are not.
# l1l1lll1_opy_ for l1l1lll1l_opy_ l1ll1ll_opy_ and l11l11_opy_ l1l1ll11l_opy_ and l1l1l11l_opy_ to l1ll1l11_opy_:
# In l1lll11l_opy_, the type str is l1lll1l11_opy_ l11lll11_opy_ a bytestring, while the unicode
# type is used for unicode l1l11111_opy_ strings. l111l1l1_opy_, l1l111l1_opy_ l11111ll_opy_ l1lll1l1_opy_ l111ll11_opy_.
# In l1l111ll_opy_ 3, the type str is for text: a l1ll1l1l1_opy_ of characters, that l1lll11l1_opy_
# l11ll111_opy_ encoding. The bytestring type is bytes. This means in l1l111ll_opy_ 2,
# l1111ll1_opy_ (u"ࠪࡠࡽ࠶࠰ࠨࡡ")[0] == l1111ll1_opy_ (u"ࠫࡡࡾ࠰࠱ࠩࡢ") while in l1l111ll_opy_ 3, l1111ll1_opy_ (u"ࠬࡢࡸ࠱࠲ࠪࡣ")[0] == 0.
# l1lll11_opy_, l1l11l1l_opy_, and l1l11ll_opy_ handle this
#
#   - l1lll11_opy_ wraps this l1l1lll11_opy_ so that
#     l1lll11_opy_(l1111ll1_opy_ (u"࠭࡜ࡹ࠲࠳ࠫࡤ")[0]) == 0 no l1ll1l111_opy_ the l1l111ll_opy_ version, e.g. by
#     l1ll1l1_opy_ ord() in l1lll11l_opy_
#   - l1l11ll_opy_ is the l11l1l11_opy_ of l1lll11_opy_, e.g. l1lll11l_opy_
#     chr()
#   - l1l11l1l_opy_ is so l1lll111_opy_ l11l1ll_opy_ l1ll11l1_opy_ l1lllll_opy_ l1ll1ll_opy_ in l111l1l_opy_
#     while l1111l_opy_ l1llll1l_opy_ l1l1lll11_opy_, e.g.
#     l1l11l1l_opy_(l1111ll1_opy_ (u"ࠧ࡝ࡺ࠳࠴ࠬࡥ")[0]) == l1111ll1_opy_ (u"ࠨ࡞ࡻ࠴࠵࠭ࡦ") no l1ll1l111_opy_ the Python version
#
#
# l11111_opy_ difference is that unicode encoding l1ll11ll1_opy_ from a l111llll_opy_ module in
# l1lll11l_opy_ to part of the str class in l111l1l_opy_. s2b and b2s l1lllll11_opy_ this l11ll11l_opy_.
_MODULE_LOGGER = logging.getLogger(__name__)
if sys.version_info[0] < 3:
    import codecs
    def s2b(obj):
        return codecs.encode(obj, l1l11l_opy_ (u"ࠩࡘࡘࡋ࠳࠸ࠨࡧ"))
    def b2s(obj):
        return codecs.decode(obj, l1l11l_opy_ (u"࡙࡙ࠪࡌ࠭࠹ࠩࡨ"))
    l1l1ll111_opy_ = str
    UnicodeType = unicode
    StrType = (unicode, str)
    l1l1l1l1_opy_ = itertools.l1l1l1l1_opy_
    l1l1l111_opy_ = itertools.l1l1l111_opy_
    l1lll11_opy_ = ord
    l1l11ll_opy_ = chr
    l1l11l1l_opy_ = lambda b: b
    if sys.l1l1ll11_opy_ < 0xffffffffffff:
        l1l1ll1l1_opy_ = long
        def convert_gid(l1111111_opy_):
            return l1111111_opy_
    else:
        l1l1ll1l1_opy_ = int
        def convert_gid(l1111111_opy_):
            return int(l1111111_opy_)
    def ensure_bytes(l1111ll_opy_):
        if not isinstance(l1111ll_opy_, (str, bytes, bytearray)):
            raise TypeError(l1l11l_opy_ (u"ࠦࡒࡻࡳࡵࠢࡥࡩࠥࡧࠠࡴࡶࡵ࡭ࡳ࡭࡬ࡪ࡭ࡨࠤࡴࡸࠠࡣࡻࡷࡩࡸࡲࡩ࡬ࡧࠣࡸࡾࡶࡥ࠭ࠢ࡬ࡷࠥࢁࡽࠣࡩ")\
                            .format(type(l1111ll_opy_)))
        else:
            return l1111ll_opy_
else:
    def s2b(obj):
        return obj.encode(l1l11l_opy_ (u"࡛ࠬࡔࡇ࠯࠻ࠫࡪ"))
    def b2s(obj):
        return obj.decode(l1l11l_opy_ (u"࠭ࡕࡕࡈ࠰࠼ࠬ࡫"))
    l1l1ll111_opy_ = bytes
    UnicodeType = str
    StrType = str
    l1l1l1l1_opy_ = zip
    l1l1l111_opy_ = itertools.zip_longest
    l1lll11_opy_ = lambda l11lll1l_opy_: l11lll1l_opy_
    l1l11ll_opy_ = lambda l1lll1l1l_opy_: bytes([l1lll1l1l_opy_])
    l1l11l1l_opy_ = l1l11ll_opy_
    l1l1ll1l1_opy_ = int
    def convert_gid(l1111111_opy_):
        return l1111111_opy_
    def ensure_bytes(l1111ll_opy_):
        if isinstance(l1111ll_opy_, str):
            res = l1111ll_opy_.encode(sys.getdefaultencoding())
            return res
        elif isinstance(l1111ll_opy_, (bytes)):
            return l1111ll_opy_
        else:
            raise TypeError(l1l11l_opy_ (u"ࠢࡎࡷࡶࡸࠥࡨࡥࠡࡣࠣࡷࡹࡸࡩ࡯ࡩ࡯࡭ࡰ࡫ࠠࡰࡴࠣࡦࡾࡺࡥࡴ࡮࡬࡯ࡪࠦࡴࡺࡲࡨ࠰ࠥ࡯ࡳࠡࡽࢀࠦ࡬")\
                            .format(type(l1111ll_opy_)))
def l1ll111_opy_(iterator):
    l1l11l_opy_ (u"ࠣࠤࠥࠤࡆࠦࡧࡦࡰࡨࡶࡦࡺ࡯ࡳࠢࡷ࡬ࡦࡺࠠࡺ࡫ࡨࡰࡩࡹࠠࡦࡸࡨࡶࡾࡺࡨࡪࡰࡪࠤ࡮ࡴࠠࡪࡶࡶࠤ࡮ࡴࡰࡶࡶࠣࡴࡷ࡫ࡣࡪࡵࡨࡰࡾࠦ࡯࡯ࡥࡨ࠲ࠏࠦࠠࠡࠢࠥࠦࠧ࡭")
    for i in iterator:
        yield i
def l1ll111ll_opy_(*iterables):
    if not iterables:
        return None
    if len(iterables) == 1:
        return iterables[0]
    to_return = iterables[0]
    for it in iterables[1:]:
        to_return += it
    return to_return
def l1l1lllll_opy_(iterator):
    ret = six.b(l1l11l_opy_ (u"ࠩࠪ࡮"))
    for i in iterator:
        ret += l1l11l1l_opy_(i)
    return ret
def l111l11l_opy_(l1ll1ll1_opy_):
    l1l11l_opy_ (u"ࠥࠦࠧࠦࡔࡢ࡭ࡨࠤࡦࠦ࠺ࡱࡻ࠽ࡧࡱࡧࡳࡴ࠼ࡣࡨࡦࡺࡥࡵ࡫ࡰࡩ࠳ࡪࡡࡵࡧࡷ࡭ࡲ࡫ࡠࠡࡣࡱࡨࠥࡳࡡ࡬ࡧࠣ࡭ࡹࠦࡕࡕࡅࠍࠎࠥࠦࠠࠡࡋࡩࠤࡹ࡮ࡥࠡ࠼ࡳࡽ࠿ࡩ࡬ࡢࡵࡶ࠾ࡥࡪࡡࡵࡧࡷ࡭ࡲ࡫࠮ࡥࡣࡷࡩࡹ࡯࡭ࡦࡢࠣ࡭ࡸࠦ࡮ࡢ࡫ࡹࡩ࠱ࠦࡩࡵࠢ࡬ࡷࠥࡧࡳࡴࡷࡰࡩࡩࠦࡴࡩࡣࡷࠤ࡮ࡺࠠࡪࡵࠣ࡭ࡳࠦࡕࡕࡅࠣࡥࡱࡸࡥࡢࡦࡼ࠲ࠏࠦࠠࠡࠢࡌࡪࠥ࡯ࡴࠡ࡫ࡶࠤࡦࡽࡡࡳࡧ࠯ࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡨࡥࠡࡥࡲࡲࡻ࡫ࡲࡵࡧࡧࠤࡹࡵࠠࡖࡖࡆࠤࡦࡴࡤࠡ࡯ࡤࡨࡪࠦ࡮ࡢ࡫ࡹࡩࠥࡹ࡯ࠡࡹࡨࠤࡩࡵࠠ࡯ࡱࡷࠤࡳ࡫ࡥࡥࠢࡷࡳࠥࡶࡵ࡭࡮ࠣ࡭ࡳࠦࡴࡪ࡯ࡨࡾࡴࡴࡥࠡࡪࡤࡲࡩࡲࡩ࡯ࡩࠣࡴࡦࡩ࡫ࡢࡩࡨࡷ࠳ࠐࠠࠡࠢࠣࠦࠧࠨ࡯")
    if not isinstance(l1ll1ll1_opy_, datetime.datetime):
        raise TypeError(l1l11l_opy_ (u"࡙ࠦ࡯࡭ࡦࡱࡥ࡮ࠥࡹࡨࡰࡷ࡯ࡨࠥࡨࡥࠡࡣࠣࡨࡦࡺࡥࡵ࡫ࡰࡩ࠳ࡪࡡࡵࡧࡷ࡭ࡲ࡫ࠢࡰ"))
    if None is not l1ll1ll1_opy_.tzinfo and None is not l1ll1ll1_opy_.utcoffset():
        return (l1ll1ll1_opy_ - l1ll1ll1_opy_.utcoffset()).replace(tzinfo=None)
    else:
        return l1ll1ll1_opy_
def time_from_various(options):
    l1l11l_opy_ (u"ࠧࠨࠢࠡࡖࡤ࡯ࡪࠦ࡯࡯ࡧࠣࡳ࡫ࠦࡡࠡࡸࡤࡶ࡮࡫ࡴࡺࠢࡲࡪࠥࡺࡩ࡮ࡧࠣࡳࡧࡰࡥࡤࡶࡶࠤࡦࡴࡤࠡ࡯ࡤ࡯ࡪࠦࡩࡵࠢࡤࠤࡵࡸ࡯ࡱࡧࡵࠤࡩࡧࡴࡦࡶ࡬ࡱࡪࠐࠊࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡴࡶࡴࡪࡱࡱࡷ࠿ࠦࡔࡩࡧࠣࡸ࡮ࡳࡥࠡࡱࡥ࡮ࡪࡩࡴࠋࠢࠣࠤࠥࡀࡴࡺࡲࡨࠤࡴࡶࡴࡪࡱࡱࡷ࠿ࠦࡤࡢࡶࡨࡸ࡮ࡳࡥ࠯ࡦࡤࡸࡪࡺࡩ࡮ࡧࠣࡳࡷࠦࡩ࡯ࡶࠣࡳࡷࠦࡴࡶࡲ࡯ࡩࠏࠐࠠࠡࠢࠣࡤࡥࡵࡰࡵ࡫ࡲࡲࡸࡦࡠࠡࡵ࡫ࡳࡺࡲࡤࠡࡤࡨࠤࡪ࡯ࡴࡩࡧࡵࠤࡦࠦ࠺ࡱࡻ࠽ࡧࡱࡧࡳࡴ࠼ࡣࡨࡦࡺࡥࡵ࡫ࡰࡩ࠳ࡪࡡࡵࡧࡷ࡭ࡲ࡫ࡠ࠭ࠢࡣࡤ࡮ࡴࡴࡡࡢࠣࡶࡪࡶࡲࡦࡵࡨࡲࡹ࡯࡮ࡨࠢࡤࠤ࡚ࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠥ࠮ࡩ࡯ࠢࡘࡘࡈ࠯ࠬࠡࡱࡵࠤࡦࠦࡴࡶࡲ࡯ࡩࠥࡧࡳࠡࡲࡵࡳࡩࡻࡣࡦࡦࠣࡦࡾࠦ࠺ࡱࡻ࠽ࡱࡪࡺࡨ࠻ࡢࡷ࡭ࡲ࡫࠮࡮࡭ࡷ࡭ࡲ࡫ࡠ࠯ࠌࠍࠤࠥࠦࠠ࠻ࡴࡨࡸࡺࡸ࡮ࠡࡦࡤࡸࡪࡺࡩ࡮ࡧ࠱ࡨࡦࡺࡥࡵ࡫ࡰࡩ࠿ࠦࡔࡩࡧࠣࡧࡴࡴࡶࡦࡴࡷࡩࡩࠦࡤࡢࡶࡨࡸ࡮ࡳࡥࠡࡱࡥ࡮ࡪࡩࡴ࠯ࠢࡌࡪࠥࡺࡨࡦࠢ࡬ࡲࡵࡻࡴࠡࡹࡤࡷࠥࡧ࡮ࠡࡣࡺࡥࡷ࡫ࠠࡥࡣࡷࡩࡹ࡯࡭ࡦ࠮ࠣ࡭ࡹࠦࡷࡪ࡮࡯ࠤࡧ࡫ࠠࡢࡹࡤࡶࡪࡁࠠࡪࡨࠣࡸ࡭࡫ࠠࡪࡰࡳࡹࡹࠦࡷࡢࡵࠣࡥࡳࡿࡴࡩ࡫ࡱ࡫ࠥ࡫࡬ࡴࡧ࠯ࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡨࡥࠡࡰࡤ࡭ࡻ࡫࠮ࠡࡋࡱࠤࡦࡲ࡬ࠡࡥࡤࡷࡪࡹࠬࠡ࡫ࡷࠤࡼ࡯࡬࡭ࠢࡥࡩ࡛ࠥࡔࡄ࠰ࠍࠤࠥࠦࠠࠣࠤࠥࡱ")
    if isinstance(options, int):
        result = datetime.datetime.utcfromtimestamp(options)
    elif isinstance(options, datetime.datetime):
        result = l111l11l_opy_(options)
    elif isinstance(options, (tuple, time.struct_time)):
        l1l1111_opy_ = calendar.timegm(options)
        result = datetime.datetime.utcfromtimestamp(l1l1111_opy_)
    else:
        raise TypeError(l1l11l_opy_ (u"࠭ࡴࡪ࡯ࡨࠤࡲࡧࡹࠡࡤࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡢࡵࠣࡥࡳࠦࡩ࡯ࡶ࡙࡙ࠣࡉࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲ࠯ࠤࡩࡧࡴࡦࡶ࡬ࡱࡪ࠴ࡤࡢࡶࡨࡸ࡮ࡳࡥࠡࠪࡱࡥ࡮ࡼࡥࠡࡱࡵࠤࡦࡽࡡࡳࡧࠬ࠰ࠥࡵࡲࠡࡶ࡬ࡱࡪ࠴ࡳࡵࡴࡸࡧࡹࡥࡴࡪ࡯ࡨ࠱ࡱ࡯࡫ࡦࠢࡷࡹࡵࡲࡥ࠭ࠢࡥࡹࡹࠦ࡮ࡰࡶࠣࡿࢂ࠭ࡲ")
                        .format(type(options)))
    return l111l1_opy_(result)
def l111l1_opy_(l1ll1ll1_opy_):
    return l1ll1ll1_opy_ - datetime.timedelta(microseconds=l1ll1ll1_opy_.microsecond)
def display_bytestring(bytestring):
    l1l11l_opy_ (u"ࠢࠣࠤࠣࡘࡺࡸ࡮ࠡࡣࠣࡦࡾࡺࡥࡴࡶࡵ࡭ࡳ࡭ࠠࡪࡰࡷࡳࠥࡧࠠ࡭ࡱࡱ࡫ࠥ࡮ࡥࡹࠢࡶࡸࡷ࡯࡮ࡨ࠮ࠣࡩ࡬ࠦࠧ࡝ࡺ࠳࠴ࡡࡾ࠰࠲࡞ࡻ࠴࠷࠭࠭࠿ࠩ࠳ࡼ࠵࠶࠰࠲࠲࠵ࠫࠧࠨࠢࡳ")
    return l1l11l_opy_ (u"ࠨ࠲ࡻࠫࡴ") + l1l11l_opy_ (u"ࠩࠪࡵ").join([l1l11l_opy_ (u"ࠪࡿ࠿࠶࠲ࡹࡿࠪࡶ").format(l1lll11_opy_(s))
                           for s in bytestring])
def firmware_hash16(contents):
    l1lll111l_opy_ = 0x00aa
    l1ll1llll_opy_ = 0
    for b in contents:
        l1lll111l_opy_ = ((48271 * (l1lll111l_opy_ + l1lll11_opy_(b)) + 1) & 0xffffffff) % 0x7fffffff
        l1ll1llll_opy_ = l1ll1llll_opy_ ^ l1lll111l_opy_
    return (l1ll1llll_opy_ >> 16) ^ (l1ll1llll_opy_ & 0xffff)
def l1lll1ll_opy_(l11l1l1l_opy_, l111lll_opy_):
    items = iter(l11l1l1l_opy_.items())
    try:
        prev = next(items)
        l1l111l_opy_ = next(items)
        while l1l111l_opy_[0] <= l111lll_opy_:
            prev = l1l111l_opy_
            l1l111l_opy_ = next(items)
    except StopIteration:
        pass
    return prev[1]
def l1ll11lll_opy_(l1ll11ll_opy_,
                       l1ll1l1ll_opy_, l1111l1l_opy_,
                       device_types):
    l1l11l_opy_ (u"ࠦࠧࠨࠠࡇ࡫࡯ࡸࡪࡸࠠࡢࡰࠣ࡭ࡹ࡫ࡲࡢࡤ࡯ࡩࠥࡵࡦࠡࡦࡨࡺ࡮ࡩࡥࡴࠢࡤࡲࡩࠦࡲࡦࡶࡸࡶࡳࠦ࡯࡯࡮ࡼࠤࡹ࡮࡯ࡴࡧࠣࡱࡦࡺࡣࡩ࡫ࡱ࡫ࠥࡺࡨࡦࠢࡩ࡭ࡱࡺࡥࡳ࠰ࠍࠎࠥࠦࠠࠡࡖ࡫࡭ࡸࠦࡲࡦ࡮࡬ࡩࡸࠦ࡯࡯ࠢࡳࡰࡦࡺࡦࡰࡴࡰ࠱ࡩ࡫ࡰࡦࡰࡧࡩࡳࡺࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࡣ࡯࡭ࡹࡿࠠࡰࡨࠣ࠾ࡵࡿ࠺࡮ࡱࡧࡹࡱ࡫࠺ࡡࡵࡨࡶ࡮ࡧ࡬࠯ࡶࡲࡳࡱࡹ࠮࡭࡫ࡶࡸࡤࡶ࡯ࡳࡶࡶࡤ࠳ࠦࡉࡧࠢࡷ࡬ࡪࠦࡥࡹࡶࡨࡲࡩ࡫ࡤࠡࡦࡨࡺ࡮ࡩࡥࠡ࡫ࡱࡪࡴࡸ࡭ࡢࡶ࡬ࡳࡳࠦࡴࡩࡣࡷࠤࡲࡵࡤࡶ࡮ࡨࠤࡵࡸ࡯ࡷ࡫ࡧࡩࡸࠦ࡯࡯ࠢࡶࡳࡲ࡫ࠠࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡴࡷ࡫ࡳࡦࡰࡷ࠰ࠥࡺࡨࡪࡵࠣࡪࡺࡴࡣࡵ࡫ࡲࡲࠥ࡬ࡡ࡭࡮ࡶࠤࡧࡧࡣ࡬ࠢࡷࡳࠥࡶࡥࡳ࡯࡬ࡷࡸ࡯ࡶࡦࠢࡥࡩ࡭ࡧࡶࡪࡱࡵࠤࡦࡴࡤࠡࡴࡨࡸࡺࡸ࡮ࡴࠢࡨࡺࡪࡸࡹࡵࡪ࡬ࡲ࡬ࠦࡩࡵࠢࡶࡩࡪࡹ࠮ࠡࡈࡲࡶࠥ࡯࡮ࡴࡶࡤࡲࡨ࡫ࠬࠡࡱࡱࠤ࡜࡯࡮ࡥࡱࡺࡷࠥࡶࡹࡴࡧࡵ࡭ࡦࡲࠠࡥࡱࡨࡷࠥࡴ࡯ࡵࠢࡦࡥࡵࡺࡵࡳࡧࠣࡸ࡭࡫ࠠࡱࡴࡲࡨࡺࡩࡴࠡࡵࡷࡶ࡮ࡴࡧࠡࡨࡵࡳࡲࠦࡡࠡࡗࡖࡆࠥࡪࡥࡷ࡫ࡦࡩࠥࡧ࡮ࡥࠢࡶࡳࠥࡦࡠࡥࡧࡹ࡭ࡨ࡫࡟ࡵࡻࡳࡩࡸࡦࡠࠡ࡫ࡶࠤ࡮࡭࡮ࡰࡴࡨࡨ࠳ࠐࠊࠡࠢࠣࠤࡊࡧࡣࡩࠢࡧࡩࡻ࡯ࡣࡦࠢࡳࡥࡸࡹࡥࡥࠢ࡬ࡲࡹࡵࠠࡵࡪࡨࠤ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࠦࡳࡩࡱࡸࡰࡩࠦࡡࡵࠢࡷ࡬ࡪࠦࡢࡢࡴࡨࠤࡲ࡯࡮ࡪ࡯ࡸࡱࠥࡨࡥࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡹࡩࡷ࡯ࡦࡪࡧࡧࠤࡹࡵࠠࡣࡧࠣࡥࠥ࡭࡯ࡕࡧࡱࡲࡦࠦࡤࡦࡸ࡬ࡧࡪࠦ࡯ࡧࠢࡶࡳࡲ࡫ࠠࡵࡻࡳࡩ࠳ࠐࠊࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤ࡮ࡺࡥࡳ࡝ࡶࡩࡷ࡯ࡡ࡭࠰ࡷࡳࡴࡲࡳ࠯࡮࡬ࡷࡹࡥࡰࡰࡴࡷࡷ࠳ࡒࡩࡴࡶࡓࡳࡷࡺࡉ࡯ࡨࡲࡡࠥࡪࡥࡷ࡫ࡦࡩࡤࡲࡩࡴࡶ࠽ࠤ࡙࡮ࡥࠡ࡮࡬ࡷࡹࠦ࡯ࡧࠢࡧࡩࡻ࡯ࡣࡦࡵࠣࡸࡴࠦࡦࡪ࡮ࡷࡩࡷ࠴ࠠࡔࡪࡲࡹࡱࡪࠠࡣࡧࠣࡥࠥࡲࡩࡴࡶࠣࡳ࡫ࠦ࡮ࡢ࡯ࡨࡨࠥࡺࡵࡱ࡮ࡨࡷࠥࡽࡩࡵࡪࠣࡥࡹࠦ࡬ࡦࡣࡶࡸࠥࡦࡠࡱࡴࡲࡨࡺࡩࡴࡡࡢࠣࠬࡷ࡫ࡰࡳࡧࡶࡩࡳࡺࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡱࡴࡲࡨࡺࡩࡴ࠭ࠢࡣࡤࠬ࠿࠰࠱ࠩࡣࡤ࠱ࠦࡠࡡࠩࡓࡖࡔ࠭ࡠࡡ࠮ࠣࡳࡷࠦࡠࡡࡐࡲࡲࡪࡦࡠࠪ࠮ࠣࡤࡥࡹࡥࡳ࡫ࡤࡰࡤࡴࡵ࡮ࡤࡨࡶࡥࡦࠠࠩࡵࡷࡶ࡮ࡴࡧࠡࡱࡵࠤࡥࡦࡎࡰࡰࡨࡤࡥ࠯ࠠࡢࡰࡧࠤࡥࡦࡤࡦࡸ࡬ࡧࡪࡦࡠࠡࠪࡶࡳࡲ࡫ࠠࡪࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠤࡹ࡮ࡥࠡࡵࡨࡰࡪࡩࡴࡦࡦࠣࡧࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴࠠࡤ࡮ࡤࡷࡸࠦࡡࡤࡥࡨࡴࡹࡹࠩ࠯ࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡩࡵࡧࡵ࡟ࡸࡺࡲ࡞ࠢࡶࡩࡷ࡯ࡡ࡭ࡡࡥࡰࡦࡩ࡫࡭࡫ࡶࡸ࠿ࠦࡁ࡯ࠢ࡬ࡸࡪࡸࡡࡣ࡮ࡨࠤࡴ࡬ࠠࡴࡧࡵ࡭ࡦࡲࠠ࡯ࡷࡰࡦࡪࡸࡳࠡࡶ࡫ࡥࡹࠦ࡭ࡢࡻࠣࡲࡴࡺࠠࡣࡧࠣࡧࡴࡴ࡮ࡦࡥࡷࡩࡩࠦࡴࡰ࠰ࠣࡅࠥࡪࡥࡷ࡫ࡦࡩࠥࡽࡩࡵࡪࠣࡲࡴࠦࡳࡦࡴ࡬ࡥࡱࠦ࡮ࡶ࡯ࡥࡩࡷࠦ࡭ࡢࡶࡦ࡬ࡪࡹࠠࡢࠢࡑࡳࡳ࡫ࠠࡪࡰࠣࡸ࡭࡯ࡳࠡ࡮࡬ࡷࡹ࠴ࠊࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤ࡮ࡺࡥࡳ࡝ࡶࡸࡷࡣࠠࡴࡧࡵ࡭ࡦࡲ࡟ࡸࡪ࡬ࡸࡪࡲࡩࡴࡶ࠽ࠤࡆࡴࠠࡪࡶࡨࡶࡦࡨ࡬ࡦࠢࡲࡪࠥࡹࡥࡳ࡫ࡤࡰࠥࡴࡵ࡮ࡤࡨࡶࡸࠦࡴࡩࡣࡷࠤࡲࡧࡹࠡࡱࡱࡰࡾࠦࡢࡦࠢࡦࡳࡳࡴࡥࡤࡶࡨࡨࠥࡺ࡯࠯ࠢࡗࡥࡰ࡫ࡳࠡࡲࡵ࡭ࡴࡸࡩࡵࡻࠣࡳࡻ࡫ࡲࠡࡢࡣࡷࡪࡸࡩࡢ࡮ࡢࡦࡱࡧࡣ࡬࡮࡬ࡷࡹࡦࡠ࠯ࠢࡄࠤࡩ࡫ࡶࡪࡥࡨࠤࡼ࡯ࡴࡩࠢࡱࡳࠥࡹࡥࡳ࡫ࡤࡰࠥࡴࡵ࡮ࡤࡨࡶࠥࡳࡡࡵࡥ࡫ࡩࡸࠦࡡࠡࡐࡲࡲࡪࠦࡩ࡯ࠢࡷ࡬࡮ࡹࠠ࡭࡫ࡶࡸ࠳ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣ࡭ࡹ࡫ࡲ࡜ࡵࡷࡶࡢࠦࡤࡦࡸ࡬ࡧࡪࡥࡴࡺࡲࡨࡷ࠿ࠦࡁ࡯ࠢ࡬ࡸࡪࡸࡡࡣ࡮ࡨࠤࡴ࡬ࠠࡥࡧࡹ࡭ࡨ࡫ࠠࡵࡻࡳࡩࡸࠦࡴࡰࠢࡦࡳࡳࡴࡥࡤࡶࠣࡸࡴ࠴ࠠࡂࠢࡧࡩࡻ࡯ࡣࡦࠢࡺ࡭ࡹ࡮ࠠ࡯ࡱࠣࡨࡪࡼࡩࡤࡧࠣࡸࡾࡶࡥࠡ࡯ࡤࡸࡨ࡮ࡥࡴࠢࡤࠤࡓࡵ࡮ࡦࠢ࡬ࡲࠥࡺࡨࡪࡵࠣࡰ࡮ࡹࡴ࠯ࠌࠣࠤࠥࠦࠢࠣࠤࡷ")
    to_return = []
    if os.name == l1l11l_opy_ (u"ࠬࡴࡴࠨࡸ"):
        device_types = (l1l11l_opy_ (u"࠭࠹࠱࠲ࠪࡹ"), l1l11l_opy_ (u"ࠧࡱࡴࡲࠫࡺ"), None)
    for device in l1ll11ll_opy_:
        try:
            if device.product not in device_types:
                continue
        except KeyError:
            continue
        if l1111l1l_opy_:
            if device.serial_number not in l1111l1l_opy_:
                continue
        elif l1ll1l1ll_opy_:
            if device.serial_number in l1ll1l1ll_opy_:
                continue
        to_return.append(device)
    return to_return
class GroupCompletion(object):
    l1l11l_opy_ (u"ࠣࠤࠥࠤࡆࡴࠠࡰࡤ࡭ࡩࡨࡺࠠࡵࡪࡤࡸࠥࡺࡲࡢࡥ࡮ࡷࠥࡺࡨࡦࠢࡹࡥࡷ࡯࡯ࡶࡵࠣࡴ࡭ࡧࡳࡦࡵࠣࡳ࡫ࠦࡧࡳࡱࡸࡴࠥࡩࡲࡦࡣࡷ࡭ࡴࡴ࠮ࠋࠢࠣࠤࠥࠨࠢࠣࡻ")
    _LOGGER = _MODULE_LOGGER.getChild(l1l11l_opy_ (u"ࠩࡊࡶࡴࡻࡰࡊࡰࡹ࡭ࡹ࡫ࠧࡼ"))
    def __init__(self, l11l1l1_opy_, l1ll11111_opy_):
        self.l11111l_opy_ = None
        self.l1lll1lll_opy_ = True
        self.l11ll1ll_opy_ = {}
        self.method_callback = l11l1l1_opy_
        self.invite_callback = l1ll11111_opy_
    def register_invite(self, corr_id, idx):
        if not self.l11ll1ll_opy_:
            self.l1lll1lll_opy_ = False
        self._LOGGER.info(l1l11l_opy_ (u"ࠥࡅࡩࡪࠠࡪࡰࡹ࡭ࡹ࡫࠺ࠡ࡯ࡨࡱࡧ࡫ࡲࠡࡽࢀ࠰ࠥࡩࡩࡥࠢࡾࢁࠧࡽ").format(idx, corr_id))
        self.l11ll1ll_opy_[corr_id] = idx
    def _1l11ll1_opy_(self):
        if self.l11ll1ll_opy_\
           or None is self.l11111l_opy_:
            return
        if l1l11l_opy_ (u"ࠫࡪࡸࡲࡰࡴࠪࡾ") in self.l11111l_opy_:
            l11l111l_opy_(self.method_callback,
                       l1l11l_opy_ (u"ࠬࡓࡥࡵࡪࡲࡨࠥࡩࡡ࡭࡮ࡥࡥࡨࡱࠠࡧࡱࡵࠤ࡫ࡧࡩ࡭ࡧࡧࠤ࡬ࡸ࡯ࡶࡲࠣ࡭ࡳࡼࡩࡵࡧࠪࡿ"),
                       self._LOGGER,
                       **self.l11111l_opy_)
        elif not self.l1lll1lll_opy_:
            code = goTenna.constants.ErrorCodes.TIMEOUT
            kwargs = {l1l11l_opy_ (u"࠭ࡥࡳࡴࡲࡶࠬࢀ"): True,
                      l1l11l_opy_ (u"ࠧࡥࡧࡷࡥ࡮ࡲࡳࠨࢁ"): {l1l11l_opy_ (u"ࠨࡥࡲࡨࡪ࠭ࢂ"): code,
                                  l1l11l_opy_ (u"ࠩࡰࡷ࡬࠭ࢃ"): l1l11l_opy_ (u"ࠪࡅࡱࡲࠠࡨࡴࡲࡹࡵࠦࡩ࡯ࡸ࡬ࡸࡪࡹࠠࡧࡣ࡬ࡰࡪࡪࠧࢄ")}}
            l11l111l_opy_(self.method_callback,
                       l1l11l_opy_ (u"ࠫࡌࡸ࡯ࡶࡲࠣࡧࡷ࡫ࡡࡵ࡫ࡲࡲࠥࡳࡥࡵࡪࡲࡨࠥࡩࡡ࡭࡮ࡥࡥࡨࡱࠧࢅ"),
                       self._LOGGER,
                       **kwargs)
        else:
            kwargs = {l1l11l_opy_ (u"ࠬࡹࡵࡤࡥࡨࡷࡸ࠭ࢆ"): True}
            l11l111l_opy_(self.method_callback,
                       l1l11l_opy_ (u"࠭ࡇࡳࡱࡸࡴࠥࡩࡲࡦࡣࡷ࡭ࡴࡴࠠ࡮ࡧࡷ࡬ࡴࡪࠠࡤࡣ࡯ࡰࡧࡧࡣ࡬ࠩࢇ"),
                       self._LOGGER,
                       **kwargs)
    def gid_set_callback(self, *args, **kwargs):
        l1l11l_opy_ (u"ࠢࠣࠤࠣࡇࡦࡲ࡬ࡣࡣࡦ࡯ࠥ࡬࡯ࡳࠢࡶࡩࡹࡺࡩ࡯ࡩࠣࡋࡎࡊࠠࡵࡪࡤࡸࠥࡽࡩ࡭࡮ࠣࡷࡹࡵࡲࡦࠢࡵࡩࡸࡻ࡬ࡵࡵࠣࡥࡳࡪࠠ࡮ࡣࡼࡦࡪࠦࡣࡢ࡮࡯ࠤࡹ࡮ࡥࠡࡱࡹࡩࡷࡧ࡬࡭ࠢࡰࡩࡹ࡮࡯ࡥࠢࡦࡥࡱࡲࡢࡢࡥ࡮ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣ࢈")
        for idx, l1llll111_opy_ in enumerate((l1l11l_opy_ (u"ࠨࡥࡲࡶࡷ࡫࡬ࡢࡶ࡬ࡳࡳࡥࡩࡥࠩࢉ"), l1l11l_opy_ (u"ࠩࡶࡹࡨࡩࡥࡴࡵࠪࢊ"), l1l11l_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࡶࠫࢋ"),
                                       l1l11l_opy_ (u"ࠫࡪࡸࡲࡰࡴࠪࢌ"), l1l11l_opy_ (u"ࠬࡪࡥࡵࡣ࡬ࡰࡸ࠭ࢍ"))):
            if len(args) > idx:
                kwargs[l1llll111_opy_] = args[idx]
            else:
                break
        if kwargs.get(l1l11l_opy_ (u"࠭ࡥࡳࡴࡲࡶࠬࢎ"), None):
            self.l11111l_opy_ = {l1l11l_opy_ (u"ࠧࡦࡴࡵࡳࡷ࠭࢏"): True, l1l11l_opy_ (u"ࠨࡦࡨࡸࡦ࡯࡬ࡴࠩ࢐"): kwargs[l1l11l_opy_ (u"ࠩࡧࡩࡹࡧࡩ࡭ࡵࠪ࢑")]}
        else:
            self.l11111l_opy_ = {l1l11l_opy_ (u"ࠪࡷࡺࡩࡣࡦࡵࡶࠫ࢒"): True}
        self._1l11ll1_opy_()
    def invite_complete_callback(self, *args, **kwargs):
        l1l11l_opy_ (u"ࠦࠧࠨࠠࡄࡣ࡯ࡰࡧࡧࡣ࡬ࠢࡩࡳࡷࠦࡳࡦࡰࡧ࡭ࡳ࡭ࠠࡪࡰࡹ࡭ࡹ࡫ࡳࠡࡶ࡫ࡥࡹࠦࡷࡪ࡮࡯ࠤࡸࡺ࡯ࡳࡧࠣࡸ࡭࡫ࠠࡳࡧࡶࡹࡱࡺࡳ࠭ࠢࡦࡥࡱࡲࠠࡵࡪࡨࠤ࡮ࡴࡶࡪࡶࡨࠤࡨࡧ࡬࡭ࡤࡤࡧࡰ࠲ࠠࡢࡰࡧࠤࡲࡧࡹࡣࡧࠣࡧࡦࡲ࡬ࠡࡶ࡫ࡩࠥࡵࡶࡦࡴࡤࡰࡱࠦ࡭ࡦࡶ࡫ࡳࡩࠦࡣࡢ࡮࡯ࡦࡦࡩ࡫ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࢓")
        for idx, l1llll111_opy_ in enumerate((l1l11l_opy_ (u"ࠬࡩ࡯ࡳࡴࡨࡰࡦࡺࡩࡰࡰࡢ࡭ࡩ࠭࢔"), l1l11l_opy_ (u"࠭ࡳࡶࡥࡦࡩࡸࡹࠧ࢕"),
                                       l1l11l_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࡳࠨ࢖"), l1l11l_opy_ (u"ࠨࡧࡵࡶࡴࡸࠧࢗ"), l1l11l_opy_ (u"ࠩࡧࡩࡹࡧࡩ࡭ࡵࠪ࢘"))):
            if len(args) > idx:
                kwargs[l1llll111_opy_] = args[idx]
            else:
                break
        if l1l11l_opy_ (u"ࠪࡧࡴࡸࡲࡦ࡮ࡤࡸ࡮ࡵ࡮ࡠ࡫ࡧ࢙ࠫ") not in kwargs:
            raise TypeError(l1l11l_opy_ (u"ࠦࡒࡻࡳࡵࠢࡳࡥࡸࡹࠠࡤࡱࡵࡶࡪࡲࡡࡵ࡫ࡲࡲࠥࡏࡄ࢚ࠣ"))
        if kwargs.get(l1l11l_opy_ (u"ࠬ࡫ࡲࡳࡱࡵ࢛ࠫ"), None):
            l11lllll_opy_ = {l1l11l_opy_ (u"࠭ࡳࡶࡥࡦࡩࡸࡹࠧ࢜"): kwargs.get(l1l11l_opy_ (u"ࠧࡴࡷࡦࡧࡪࡹࡳࠨ࢝"), None),
                          l1l11l_opy_ (u"ࠨࡧࡵࡶࡴࡸࠧ࢞"): kwargs.get(l1l11l_opy_ (u"ࠩࡨࡶࡷࡵࡲࠨ࢟"), None),
                          l1l11l_opy_ (u"ࠪࡨࡪࡺࡡࡪ࡮ࡶࠫࢠ"): kwargs.get(l1l11l_opy_ (u"ࠫࡩ࡫ࡴࡢ࡫࡯ࡷࠬࢡ"), None)}
            l11l111l_opy_(self.invite_callback,
                       l1l11l_opy_ (u"ࠬࡍࡲࡰࡷࡳࠤࡨࡸࡥࡢࡶ࡬ࡳࡳࠦࡩ࡯ࡸ࡬ࡸࡪࠦࡣࡢ࡮࡯ࡦࡦࡩ࡫ࠨࢢ"),
                       self._LOGGER,
                       self.l11ll1ll_opy_[kwargs[l1l11l_opy_ (u"࠭ࡣࡰࡴࡵࡩࡱࡧࡴࡪࡱࡱࡣ࡮ࡪࠧࢣ")]],
                       **l11lllll_opy_)
            del self.l11ll1ll_opy_[kwargs[l1l11l_opy_ (u"ࠧࡤࡱࡵࡶࡪࡲࡡࡵ࡫ࡲࡲࡤ࡯ࡤࠨࢤ")]]
            self._1l11ll1_opy_()
    def invite_acknowledged_callback(self, *args, **kwargs):
        l1l11l_opy_ (u"ࠣࠤࠥࠤࡈࡧ࡬࡭ࡤࡤࡧࡰࠦࡦࡰࡴࠣࡥࡨࡱ࡮ࡰࡹ࡯ࡩࡩ࡭ࡥࡥࠢ࡬ࡲࡻ࡯ࡴࡦࡵࠣࠦࠧࠨࢥ")
        for idx, l1llll111_opy_ in enumerate((l1l11l_opy_ (u"ࠩࡦࡳࡷࡸࡥ࡭ࡣࡷ࡭ࡴࡴ࡟ࡪࡦࠪࢦ"), l1l11l_opy_ (u"ࠪࡷࡺࡩࡣࡦࡵࡶࠫࢧ"))):
            if len(args) > idx:
                kwargs[l1llll111_opy_] = args[idx]
            else:
                break
        if kwargs[l1l11l_opy_ (u"ࠫࡸࡻࡣࡤࡧࡶࡷࠬࢨ")]:
            self.l1lll1lll_opy_ = True
        l11lllll_opy_ = {l1l11l_opy_ (u"ࠬࡹࡵࡤࡥࡨࡷࡸ࠭ࢩ"): kwargs[l1l11l_opy_ (u"࠭ࡳࡶࡥࡦࡩࡸࡹࠧࢪ")]}
        l11l111l_opy_(self.invite_callback,
                   l1l11l_opy_ (u"ࠧࡈࡴࡲࡹࡵࠦࡣࡳࡧࡤࡸ࡮ࡵ࡮ࠡ࡫ࡱࡺ࡮ࡺࡥࠡࡥࡤࡰࡱࡨࡡࡤ࡭ࠪࢫ"),
                   self._LOGGER,
                   self.l11ll1ll_opy_[kwargs[l1l11l_opy_ (u"ࠨࡥࡲࡶࡷ࡫࡬ࡢࡶ࡬ࡳࡳࡥࡩࡥࠩࢬ")]],
                   **l11lllll_opy_)
        del self.l11ll1ll_opy_[kwargs[l1l11l_opy_ (u"ࠩࡦࡳࡷࡸࡥ࡭ࡣࡷ࡭ࡴࡴ࡟ࡪࡦࠪࢭ")]]
        self._1l11ll1_opy_()
def l11l111l_opy_(cb, l111l11_opy_, logger, *args, **kwargs):
    try:
        cb(*args, **kwargs)
    except Exception:
        if hasattr(cb, l1l11l_opy_ (u"ࠪࡣࡤࡩࡡ࡭࡮ࡢࡣࠬࢮ")) and hasattr(cb, l1l11l_opy_ (u"ࠫࡤࡥ࡮ࡢ࡯ࡨࡣࡤ࠭ࢯ")):
            name = l1l11l_opy_ (u"ࠬࠦࡻࡾࠩࢰ").format(getattr(cb, l1l11l_opy_ (u"࠭࡟ࡠࡰࡤࡱࡪࡥ࡟ࠨࢱ"),
                                        l1l11l_opy_ (u"ࠧࠩࡷࡱ࡯ࡳࡵࡷ࡯ࠢࡰࡩࡹ࡮࡯ࡥࠫࠪࢲ")))
        else:
            name = repr(cb)
        logger.exception(l1l11l_opy_ (u"ࠣࡽࢀࡿࢂࠦࡦࡢ࡫࡯ࡩࡩࠧࠢࢳ").format(l111l11_opy_, name))
class l11l11ll_opy_:
    l1l11l_opy_ (u"ࠤࠥࠦࠏࠦࠠࠡࠢࡘࡸ࡮ࡲࡩࡵࡻࠣࡧࡱࡧࡳࡴࠢࡩࡳࡷࠦࡨࡢࡰࡧࡰ࡮ࡴࡧࠡࡤ࡬ࡸࡷࡧࡴࡦ࠯ࡥࡥࡸ࡫ࡤࠡ࡯ࡨࡷࡸࡧࡧࡦࠢࡤࡧࡰࠦࡴࡪ࡯ࡨࡳࡺࡺࡳ࠯ࠌࠍࠤࠥࠦࠠࡕࡪࡨࠤࡨࡲࡡࡴࡵࠣ࡭ࡸࠦࡤࡦࡵ࡬࡫ࡳ࡫ࡤࠡࡶࡲࠤࡸࡺࡩࡤ࡭ࠣࡥࡷࡵࡵ࡯ࡦࠣࡪࡴࡸࠠࡢࠢ࡯ࡳࡳ࡭ࠠࡵ࡫ࡰࡩࠥࡧ࡮ࡥࠢࡥࡩࠥࡩࡨࡦࡥ࡮ࡩࡩࠦࡢࡰࡶ࡫ࠤࡼ࡮ࡥ࡯ࠢࡤࡧࡰࠦ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠡࡣࡵࡶ࡮ࡼࡥࠡࡣࡱࡨࠥࡶࡥࡳ࡫ࡲࡨ࡮ࡩࡡ࡭࡮ࡼࠤࡹࡵࠠࡤࡪࡨࡧࡰࠦࡴࡪ࡯ࡨࡳࡺࡺࡳ࠯ࠢࡌࡸࠥ࡮ࡡ࡯ࡦ࡯ࡩࡸࠦࡡ࡭࡮ࠣࡸ࡭࡫ࠠࡢࡥ࡮ࠤࡨࡧ࡬࡭ࡤࡤࡧࡰࡹࠠࡪࡰࡷࡩࡷࡴࡡ࡭࡮ࡼ࠲ࠏࠐࠠࠡࠢࠣࡍࡹࠦࡳࡩࡱࡸࡰࡩࠦࡢࡦࠢࡥࡹ࡮ࡲࡴࠡࡹ࡫ࡩࡳࠦࡴࡩࡧࠣࡦ࡮ࡺࡲࡢࡶࡨࠤࡨ࡮ࡡ࡯ࡩࡨࡷࠥࡧ࡮ࡥࠢࡩࡩࡩࠦࡴࡩࡧࠣࡦ࡮ࡺࡲࡢࡶࡨ࠲ࠥࡌࡲࡰ࡯ࠣࡸ࡭࡫࡮ࠡࡱࡱ࠰ࠏࠦࠠࠡࠢ࠰ࠤࡈࡧ࡬࡭ࡵࠣࡸࡴࠦ࠺ࡱࡻ࠽ࡱࡪࡺࡨ࠻ࡢࡤࡨࡩࡦࠠࡸ࡫࡯ࡰࠥࡧࡵࡵࡱࡰࡥࡹ࡯ࡣࡢ࡮࡯ࡽࠥࡹࡴࡰࡴࡨࠤࡹ࡮ࡥࠡࡲࡤࡷࡸ࡫ࡤࠡ࡫ࡱࠤࡲ࡫ࡳࡴࡣࡪࡩࠬࡹࠠࡩࡣࡶ࡬ࠥ࡬࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡࡥ࡫ࡩࡨࡱࡩ࡯ࡩࠣࡥࡳࡪࠠࡧ࡫ࡪࡹࡷ࡫ࠠࡰࡷࡷࠤࡦࠦࡴࡪ࡯ࡨࡳࡺࡺࠠࡣࡣࡶࡩࡩࠦ࡯࡯ࠢࡷ࡬ࡪࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡦࡦࠣࡦ࡮ࡺࡲࡢࡶࡨࠎࠥࠦࠠࠡ࠯ࠣࡇࡦࡲ࡬ࡴࠢࡷࡳࠥࡀࡰࡺ࠼ࡰࡩࡹ࡮࠺ࡡࡥ࡫ࡩࡨࡱ࡟ࡵ࡫ࡰࡩࡸࡦࠠࡸ࡫࡯ࡰࠥ࡭ࡥࡵࠢࡷ࡬ࡪࠦࡣࡶࡴࡵࡩࡳࡺࠠࡵ࡫ࡰࡩࠥࡧ࡮ࡥࠢࡦ࡬ࡪࡩ࡫ࠡࡶ࡬ࡱࡪࡵࡵࡵࡵࠣࡦࡦࡹࡥࡥࠢࡲࡲࠥࡺࡨࡢࡶ࠯ࠤࡦࡻࡴࡰ࡯ࡤࡸ࡮ࡩࡡ࡭࡮ࡼࠤࡨࡧ࡬࡭࡫ࡱ࡫ࠥࡺࡨࡦࠢࡵࡩ࡬࡯ࡳࡵࡧࡵࡩࡩࠦࡡࡤ࡭ࠣࡧࡦࡲ࡬ࡣࡣࡦ࡯ࠥࡵࡦࠡࡣࡱࡽࠥ࡫ࡸࡱ࡫ࡵࡩࡩࠦ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠋࠢࠣࠤࠥ࠳ࠠࡄࡣ࡯ࡰࡸࠦࡴࡰࠢ࠽ࡴࡾࡀ࡭ࡦࡶ࡫࠾ࡥࡩࡨࡦࡥ࡮ࡣࡦࡸࡲࡪࡸࡨࡨࡥࠦࡷࡪ࡮࡯ࠤࡷ࡫ࡴࡳ࡫ࡨࡺࡪࠦࡴࡩࡧࠣࡶࡪ࡭ࡩࡴࡶࡨࡶࡪࡪࠠࡩࡣࡱࡨࡱ࡫ࡲࡴࠢࡩࡳࡷࠦࡴࡩࡧࠣࡱࡪࡹࡳࡢࡩࡨࠤ࡭ࡧࡳࡩࠢࡤࡲࡩࠦࡣࡢ࡮࡯ࠤࡹ࡮ࡥࠡࡣࡦ࡯ࠥࡺࡩ࡮ࡧࡲࡹࡹࠐࠠࠡࠢࠣࠦࠧࠨࢴ")
    def __init__(self, bitrate):
        l1l11l_opy_ (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡃࡷ࡬ࡰࡩࠦࡡࠡࡏࡨࡷࡸࡧࡧࡦࡃࡦ࡯ࡍࡧ࡮ࡥ࡮ࡨࡶࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤࢵ")
        self._11l111_opy_ = bitrate
        self._1ll11l_opy_ = {}
        self._1l1ll1l_opy_ = _MODULE_LOGGER.getChild(self.__class__.__name__)
    def add(self, message, ack_callback):
        l1lll1ll1_opy_ = datetime.datetime.utcnow()\
                     + self._11l111_opy_.timeouts[message.max_hops-1]
        if message.payload.hash_id in self._1ll11l_opy_:
            self._1l1ll1l_opy_.warning(l1l11l_opy_ (u"ࠫࡉࡻࡰ࡭࡫ࡦࡥࡹ࡫ࠠ࡮ࡧࡶࡷࡦ࡭ࡥࠡࡵࡷ࡭ࡱࡲࠠࡢࡹࡤ࡭ࡹ࡯࡮ࡨࠢࡤࡧࡰ࠲ࠠࡤࡱࡱࡷ࡮ࡪࡥࡳࠢࡦ࡬ࡦࡴࡧࡪࡰࡪࠤࡹ࡮ࡥࠡࡥࡲࡹࡳࡺࡥࡳࠢ࡬ࡲࠥࡺࡨࡦࠢࡰࡩࡸࡹࡡࡨࡧࠣࡳࡧࡰࡥࡤࡶࠣࡸࡴࠦࡡࡷࡱ࡬ࡨࠥ࡬ࡡ࡭ࡵࡨࠤࡩ࡫ࡤࡶࡲ࡯࡭ࡨࡧࡴࡪࡱࡱࠫࢶ"))
        self._1l1ll1l_opy_.debug(l1l11l_opy_ (u"ࠬࡇࡤࡥ࡫ࡱ࡫ࠥࡳࡳࡨࡊࡤࡷ࡭ࡏࡤࠡࡽ࠽ࡼࢂ࠭ࢷ").format(message.payload.hash_id))
        self._1ll11l_opy_[message.payload.hash_id] = (l1lll1ll1_opy_, ack_callback)
    def l111l111_opy_(self, now):
        l1ll1111_opy_ = []
        for key, l1lll1111_opy_ in self._1ll11l_opy_.items():
            if l1lll1111_opy_[0] < now:
                l1ll1111_opy_.append((key, l1lll1111_opy_[1]))
        for to in l1ll1111_opy_:
            del self._1ll11l_opy_[to[0]]
            kwargs = {l1l11l_opy_ (u"࠭ࡳࡶࡥࡦࡩࡸࡹࠧࢸ"): False}
            l11l111l_opy_(to[1],
                       l1l11l_opy_ (u"ࠧࡢࡥ࡮ࠤࡹ࡯࡭ࡦࡱࡸࡸࠥ࡬࡯ࡳࠢࡾࢁࠬࢹ").format(hex(to[0])),
                       self._1l1ll1l_opy_,
                       **kwargs)
    def l1ll1111l_opy_(self, l1l1l1ll1_opy_):
        try:
            _, callback = self._1ll11l_opy_.pop(l1l1l1ll1_opy_)
        except KeyError:
            self._1l1ll1l_opy_.warning(l1l11l_opy_ (u"ࠣࡔࡨࡧࡪ࡯ࡶࡦࡦࠣࡥࡨࡱࠠࡸ࡫ࡷ࡬ࠥࡻ࡮࡮ࡣࡷࡧ࡭࡫ࡤࠡࡪࡤࡷ࡭ࠦࡻࡾࠤࢺ")\
                                 .format(hex(l1l1l1ll1_opy_)))
            return
        if callback:
            kwargs = {l1l11l_opy_ (u"ࠩࡶࡹࡨࡩࡥࡴࡵࠪࢻ"): True}
            l11l111l_opy_(callback,
                       l1l11l_opy_ (u"ࠪࡥࡨࡱࠠࡤࡣ࡯ࡰࡧࡧࡣ࡬ࠢࡩࡳࡷࠦࡻࡾࠩࢼ").format(hex(l1l1l1ll1_opy_)),
                       self._1l1ll1l_opy_,
                       **kwargs)
    def clear(self):
        self._1ll11l_opy_.clear()
def l1l1llll_opy_(iterable, n, fillvalue=None):
    l1l11l_opy_ (u"ࠦࠧࠨࠠࡄࡱ࡯ࡰࡪࡩࡴࠡࡦࡤࡸࡦࠦࡩ࡯ࡶࡲࠤ࡫࡯ࡸࡦࡦ࠰ࡰࡪࡴࡧࡵࡪࠣࡧ࡭ࡻ࡮࡬ࡵࠣࡳࡷࠦࡢ࡭ࡱࡦ࡯ࡸࠐࠊࠡࠢࠣࠤ࡬ࡸ࡯ࡶࡲࡨࡶ࠭࠭ࡁࡃࡅࡇࡉࡋࡍࠧ࠭ࠢ࠶࠰ࠥ࠭ࡸࠨࠫࠣ࠱࠲ࡄࠠࡂࡄࡆࠤࡉࡋࡆࠡࡉࡻࡼࠏࠐࠠࠡࠢࠣࡘ࡭࡯ࡳࠡ࡫ࡶࠤࡦࡴࠠࡪࡶࡨࡶࡹࡵ࡯࡭ࡵࠣࡶࡪࡩࡩࡱࡧࠣࡪࡷࡵ࡭ࠡࡪࡷࡸࡵࡹ࠺࠰࠱ࡧࡳࡨࡹ࠮ࡱࡻࡷ࡬ࡴࡴ࠮ࡰࡴࡪ࠳࠷࠵࡬ࡪࡤࡵࡥࡷࡿ࠯ࡪࡶࡨࡶࡹࡵ࡯࡭ࡵ࠱࡬ࡹࡳ࡬࠯ࠌࠣࠤࠥࠦࠢࠣࠤࢽ")
    args = [iter(iterable)] * n
    return l1l1l111_opy_(fillvalue=fillvalue, *args)
class l11l1111_opy_(object):
    l1l11l_opy_ (u"ࠧࠨࠢࠡࡃࡱࠤࡴࡨࡪࡦࡥࡷࠤࡹࡵࠠ࡮ࡣࡱࡥ࡬࡫ࠠ࡬ࡧࡼࠤࡪࡾࡣࡩࡣࡱ࡫ࡪࠦࡳࡵࡣࡷࡩࠥࡧ࡮ࡥࠢࡳࡶࡴࡼࡩࡥࡧࠣࡧࡦࡲ࡬ࡣࡣࡦ࡯ࡸࠐࠊࠡࠢࠣࠤ࡙࡮ࡩࡴࠢ࡬ࡷࠥࡻࡳࡦࡦࠣࡦࡾࠦࡴࡩࡧࠣࡶࡪࡹࡴࠡࡱࡩࠤࡹ࡮ࡥࠡࡵࡼࡷࡹ࡫࡭ࠡࡶࡲࠤࡲࡧ࡮ࡢࡩࡨࠤࡰ࡫ࡹࠡࡧࡻࡧ࡭ࡧ࡮ࡨࡧࠣࡷࡹࡧࡴࡦ࠰ࠣࡍࡹࠦࡩࡴࠢ࡬ࡲ࡮ࡺࡩࡢ࡮࡬ࡾࡪࡪࠠࡸ࡫ࡷ࡬ࠥࡧࠠࡱࡴ࡬ࡺࡦࡺࡥࠡࡉࡌࡈࠥࡺࡨࡢࡶࠣ࡭ࡸࠦࡴࡩࡧࠣࡸࡦࡸࡧࡦࡶࠣࡳ࡫ࠦࡴࡩࡧࠣ࡯ࡪࡿࠠࡦࡺࡦ࡬ࡦࡴࡧࡦ࠮ࠣࡸ࡭࡫ࠠ࡭ࡱࡦࡥࡱࠦࡰࡶࡤ࡯࡭ࡨࠦ࡫ࡦࡻ࠯ࠤࡦࠦࡣࡢ࡮࡯ࡦࡦࡩ࡫ࠡࡶࡲࠤ࡮ࡴࡶࡰ࡭ࡨࠤࡼ࡮ࡥ࡯ࠢࡦࡳࡲࡶ࡬ࡦࡶࡨ࠰ࠥࡧࠠ࡭ࡱࡪ࡫ࡪࡸࠬࠡࡣࡱࡨࠥࡺࡨࡦࠢࡧࡶ࡮ࡼࡥࡳࠢ࡬ࡲࡸࡺࡡ࡯ࡥࡨࠤࡹ࡮ࡡࡵࠢࡲࡻࡳࡹࠠࡪࡶ࠱ࠤ࡙࡮ࡩࡴࠢࡥࡥࡨࡱࡲࡦࡨࡨࡶࡪࡴࡣࡦࠢ࡬ࡷࠥࡸࡥࡲࡷ࡬ࡶࡪࡪࠠࡵࡱࠣ࡭ࡳࡼ࡯࡬ࡧࠣࡸ࡭࡫ࠠ࡬ࡧࡼࠤࡪࡾࡣࡩࡣࡱ࡫ࡪࠦ࡭ࡦࡵࡶࡥ࡬࡫ࡳ࠯ࠌࠍࠤࠥࠦࠠࡕࡪࡨࠤࡨࡵ࡮ࡵࡧࡻࡸࠥࡧ࡬ࡴࡱࠣ࡬ࡦࡴࡤ࡭ࡧࡶࠤࡹ࡮ࡥࠡࡲࡵࡳࡧࡲࡥ࡮ࠢࡲࡪࠥࡳࡥࡴࡵࡤ࡫ࡪࡹࠠࡸ࡫ࡷ࡬ࠥ࡫࡮ࡤࡴࡼࡴࡹ࡯࡯࡯ࠢࡨࡲࡦࡨ࡬ࡦࡦࠣࡦࡪ࡯࡮ࡨࠢࡶࡩࡳࡺࠠࡵࡱࠣࡸ࡭࡫ࠠࡵࡣࡵ࡫ࡪࡺࠠࡣࡧࡩࡳࡷ࡫ࠠ࡬ࡧࡼࠤࡪࡾࡣࡩࡣࡱ࡫ࡪࠦࡨࡢࡵࠣࡦࡪ࡫࡮ࠡࡥࡲࡱࡵࡲࡥࡵࡧࡧ࠲࡙ࠥࡩ࡯ࡥࡨࠤࡰ࡫ࡹࠡࡧࡻࡧ࡭ࡧ࡮ࡨࡧࠣ࡭ࡸࠦࡩ࡯࡫ࡷ࡭ࡦࡺࡥࡥࠢࡺ࡬ࡪࡴࠠࡢࠢࡰࡩࡸࡹࡡࡨࡧࠣ࡭ࡸࠦࡳࡦࡰࡷࠤࡹࡵࠠࡢࠢࡷࡥࡷ࡭ࡥࡵࠢࡩࡳࡷࠦࡷࡩ࡫ࡦ࡬ࠥࡽࡥࠡࡪࡤࡺࡪࠦ࡮ࡰࠢࡳࡹࡧࡲࡩࡤࠢ࡮ࡩࡾ࠲ࠠࡵࡪࡨࡶࡪࠦࡷࡪ࡮࡯ࠤࡦࡲࡷࡢࡻࡶࠤࡧ࡫ࠠࡢࡶࠣࡰࡪࡧࡳࡵࠢࡲࡲࡪࠦࡳࡶࡥ࡫ࠤࡲ࡫ࡳࡴࡣࡪࡩࡀࠦࡳࡪࡰࡦࡩࠥࡺࡨࡦࠢࡧࡶ࡮ࡼࡥࡳࠢ࡬ࡷࠥࡺࡨࡳࡧࡤࡨࡪࡪࠠࡢࡰࡧࠤࡴࡶࡥࡳࡣࡷࡩࡸࠦ࡯࡯ࠢࡤࠤࡶࡻࡥࡶࡧࠣࡷࡾࡹࡴࡦ࡯࠯ࠤ࡮ࡺࠠࡪࡵࠣࡴࡴࡹࡳࡪࡤ࡯ࡩࠥ࡬࡯ࡳࠢࡷ࡬ࡪࡸࡥࠡࡶࡲࠤࡧ࡫ࠠ࡮ࡣࡱࡽࠥࡹࡵࡤࡪࠣࡱࡪࡹࡳࡢࡩࡨࡷ࠳ࠦࡗࡩࡧࡱࠤࡦࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡪࡵࠣࡷࡪࡴࡴࠡࡶࡲࠤࡦࠦࡴࡢࡴࡪࡩࡹࠦࡦࡰࡴࠣࡻ࡭࡯ࡣࡩࠢࡷ࡬ࡪࡸࡥࠡ࡫ࡶࠤࡳࡵࠠࡱࡷࡥࡰ࡮ࡩࠠ࡬ࡧࡼ࠰ࠥࡺࡨࡦࠢࡧࡶ࡮ࡼࡥࡳࠢࡩ࡭ࡷࡹࡴࠡࡥࡵࡩࡦࡺࡥࡴࠢࡤࠤ࠿ࡶࡹ࠻ࡥ࡯ࡥࡸࡹ࠺ࡡࡍࡨࡽࡊࡾࡣࡩࡣࡱ࡫ࡪࡉ࡯࡯ࡶࡨࡼࡹࡦࠠࡢࡰࡧࠤ࡮ࡴࡩࡵ࡫ࡤࡸࡪࡹࠠ࡬ࡧࡼࠤࡪࡾࡣࡩࡣࡱ࡫ࡪࠦࡩࡧࠢࡷ࡬ࡪࡸࡥࠡ࡫ࡶࠤࡳࡵࠠࡤࡱࡱࡸࡪࡾࡴࠡࡨࡲࡶࠥࡺࡨࡦࠢࡧࡩࡸࡺࡩ࡯ࡣࡷ࡭ࡴࡴࠬࠡࡣࡱࡨࠥࡺࡨࡦࡰࠣࡩࡳࡷࡵࡦࡷࡨࡷࠥࡺࡨࡦࠢࡰࡩࡸࡹࡡࡨࡧࠣࠬࡼ࡯ࡴࡩࠢ࠽ࡴࡾࡀ࡭ࡦࡶ࡫࠾ࡥ࡫࡮ࡲࡷࡨࡹࡪࡥ࡭ࡦࡵࡶࡥ࡬࡫ࡠࠪࠢࡲࡲࠥࡺࡨࡦࠢࡦࡳࡳࡺࡥࡹࡶࠣࡪࡴࡸࠠࡵࡪࡨࠤࡩ࡫ࡳࡵ࡫ࡱࡥࡹ࡯࡯࡯࠰ࠣࡍ࡫ࠦࡴࡩࡧࠣ࡯ࡪࡿࠠࡦࡺࡦ࡬ࡦࡴࡧࡦࠢࡶࡹࡨࡩࡥࡦࡦࡶ࠰ࠥࡺࡨࡦࠢࡦࡳࡳࡺࡥࡹࡶࠣࡷࡪࡴࡤࡴࠢࡤࡰࡱࠦࡴࡩࡧࠣࡩࡳࡷࡵࡦࡷࡨࡨࠥࡳࡥࡴࡵࡤ࡫ࡪࡹࠠࡪࡰࠣࡸ࡭࡫ࠠࡴࡣࡰࡩࠥࡵࡲࡥࡧࡵࠤ࡮ࡴࠠࡸࡪ࡬ࡧ࡭ࠦࡴࡩࡧࡼࠤࡼ࡫ࡲࡦࠢࡨࡲࡶࡻࡥࡶࡧࡧ࠲ࠥࡏࡦࠡࡶ࡫ࡩࠥࡱࡥࡺࠢࡨࡼࡨ࡮ࡡ࡯ࡩࡨࠤ࡫ࡧࡩ࡭ࡵ࠯ࠤࡹ࡮ࡥࠡࡥࡲࡲࡹ࡫ࡸࡵࠢࡩࡥ࡮ࡲࡳࠡࡣ࡯ࡰࠥࡺࡨࡦࠢࡰࡩࡸࡹࡡࡨࡧࡶࠤ࡮ࡴࠠࡵࡪࡨࠤࡴࡸࡤࡦࡴࠣࡸ࡭࡫ࡹࠡࡹࡨࡶࡪࠦࡥ࡯ࡳࡸࡩࡺ࡫ࡤࠡࡵ࡬ࡱ࡮ࡲࡡࡳ࡮ࡼࠤࡹࡵࠠࡩࡱࡺࠤࡹ࡮ࡥࠡࡦࡵ࡭ࡻ࡫ࡲࠡࡹࡲࡹࡱࡪࠠࡧࡣ࡬ࡰࠥࡺࡨࡦ࡯࠱ࠎࠏࠦࠠࠡࠢࡒࡲࡨ࡫ࠠࡢࡰࠣ࡭ࡳࡹࡴࡢࡰࡦࡩࠥ࡯ࡳࠡ࡫ࡱ࡭ࡹ࡯ࡡ࡭࡫ࡽࡩࡩ࠲ࠠࡪࡶࠣ࡬ࡦࡹࠠࡵࡱࠣࡦࡪࠦࡩ࡯ࡨࡲࡶࡲ࡫ࡤࠡࡹ࡫ࡥࡹࠦࡳࡵࡣࡪࡩࠥࡵࡦࠡࡶ࡫ࡩࠥࡱࡥࡺࠢࡨࡼࡨ࡮ࡡ࡯ࡩࡨࠤࡵࡸ࡯ࡤࡧࡶࡷࠥ࡯ࡴࠡ࡫ࡶࠤ࡮ࡴࠠࡸ࡫ࡷ࡬ࠥࡵ࡮ࡦࠢࡲࡪࠥࡀࡰࡺ࠼ࡰࡩࡹ࡮࠺ࡡࡧࡻࡧ࡭ࡧ࡮ࡨࡧࡢ࡭ࡳ࡯ࡴࡪࡣࡷࡩࡩࡦࠬࠡ࠼ࡳࡽ࠿ࡳࡥࡵࡪ࠽ࡤࡷ࡫ࡳࡱࡱࡱࡷࡪࡥࡲࡦࡥࡨ࡭ࡻ࡫ࡤࡡ࠮ࠣࡳࡷࠦ࠺ࡱࡻ࠽ࡱࡪࡺࡨ࠻ࡢࡵࡩࡶࡻࡥࡴࡶࡢࡶࡪࡩࡥࡪࡸࡨࡨࡥ࠴ࠠࡕࡪࡨࡷࡪࠦࡣࡢࡰࠣࡥࡱࡹ࡯ࠡࡤࡨࠤࡺࡹࡥࡥࠢࡲࡲࠥࡧ࡮ࠡ࡫ࡱ࠱ࡵࡸ࡯ࡨࡴࡨࡷࡸࠦ࠺ࡱࡻ࠽ࡧࡱࡧࡳࡴ࠼ࡣࡏࡪࡿࡅࡹࡥ࡫ࡥࡳ࡭ࡥࡄࡱࡱࡸࡪࡾࡴࡡࠢࡷࡳࠥࡩࡨࡢࡰࡪࡩࠥ࡯ࡴࡴࠢࡶࡸࡦࡺࡥࠡ࡫ࡩࠤࡦࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡪࡵࠣࡶࡪࡩࡥࡪࡸࡨࡨࠥࡵࡵࡵࠢࡲࡪࠥࡵࡲࡥࡧࡵࠤ࠲ࠦࡦࡰࡴࠣ࡭ࡳࡹࡴࡢࡰࡦࡩ࠱ࠦࡡࠡࡦࡨࡰࡦࡿࡥࡥࠢࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡴࡸࠠࡢࡰࡲࡸ࡭࡫ࡲࠡࡰࡲࡨࡪࠦࡩ࡯࡫ࡷ࡭ࡦࡺࡩ࡯ࡩࠣࡥࠥࡸࡥࡲࡷࡨࡷࡹࠦࡷࡩ࡫࡯ࡩࠥࡵࡵࡳࠢࡶ࡭ࡩ࡫ࠧࡴࠢࡵࡩࡶࡻࡥࡴࡶࠣ࡭ࡸࠦࡩ࡯ࠢࡳࡶࡴ࡭ࡲࡦࡵࡶ࠲ࠏࠐࠠࠡࠢࠣࡗࡴࡳࡥࠡࡧࡻࡸࡪࡸ࡮ࡢ࡮ࠣࡱࡪࡺࡨࡰࡦࡶࠤࡼ࡯࡬࡭ࠢࡦࡥࡺࡹࡥࠡࡶࡵࡥࡳࡹࡩࡵ࡫ࡲࡲࡸࠦࡴࡰࠢࡤࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡨࠦࡳࡵࡣࡷࡩ࠱ࠦࡷࡪࡶ࡫ࠤࡦࡹࡳࡰࡥ࡬ࡥࡹ࡫ࡤࠡࡣࡦࡸ࡮ࡵ࡮ࡴ࠮ࠣࡥࡳࡿࠠࡵ࡫ࡰࡩࠥࡺࡨࡦࡻࠣࡥࡷ࡫ࠠࡤࡣ࡯ࡰࡪࡪ࠮ࠡࡖ࡫࡭ࡸࠦࡩࡥࡧࡰࡴࡴࡺࡥ࡯ࡥࡼࠤࡸࡻࡰࡱࡱࡵࡸࡸࠦ࡯ࡶࡶࠣࡳ࡫ࠦ࡯ࡳࡦࡨࡶࠥࡵࡲࠡࡦࡨࡰࡦࡿࡥࡥࠢ࡮ࡩࡾࠦࡥࡹࡥ࡫ࡥࡳ࡭ࡥࠡ࡯ࡨࡸ࡭ࡵࡤࡴ࠼ࠍࠤࠥࠦࠠ࠮࡚ࠢ࡬ࡪࡴࠠ࠻ࡲࡼ࠾ࡲ࡫ࡴࡩ࠼ࡣࡩࡽࡩࡨࡢࡰࡪࡩࡤ࡯࡮ࡪࡶ࡬ࡥࡹ࡫ࡤࡡࠢ࡬ࡷࠥࡩࡡ࡭࡮ࡨࡨ࠱ࠦࡴࡩࡧࠣࡧࡴࡴࡴࡦࡺࡷࠤࡼ࡯࡬࡭ࠢࡪࡩࡳ࡫ࡲࡢࡶࡨࠤࡦࡴࡤࠡࡵࡨࡲࡩࠦࡡࠡ࠼ࡳࡽ࠿ࡩ࡬ࡢࡵࡶ࠾ࡥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡰࡢࡻ࡯ࡳࡦࡪ࠮ࡌࡧࡼࡖࡪࡷࡵࡦࡵࡷࡔࡦࡿ࡬ࡰࡣࡧࡤࠥࡺ࡯ࠡࡶ࡫ࡩࠥࡪࡥࡴࡶ࡬ࡲࡦࡺࡩࡰࡰ࠱ࠤࡎࡺࠠࡸ࡫࡯ࡰࠥࡺࡨࡦࡰࠣࡩࡳࡺࡥࡳࠢࡷ࡬ࡪࠦࡳࡵࡣࡷࡩࠥࡀࡰࡺ࠼ࡤࡸࡹࡸ࠺ࡡࡃ࡚ࡅࡎ࡚ࡉࡏࡉࡢࡖࡊࡗࡕࡆࡕࡗࡣࡆࡉࡋࡡ࠰ࠍࠤࠥࠦࠠ࠮࡚ࠢ࡬ࡪࡴࠠ࠻ࡲࡼ࠾ࡲ࡫ࡴࡩ࠼ࡣࡶࡪࡹࡰࡰࡰࡶࡩࡤࡸࡥࡤࡧ࡬ࡺࡪࡪࡠࠡ࡫ࡶࠤࡨࡧ࡬࡭ࡧࡧ࠰ࠥࡺࡨࡦࠢ࡮ࡩࡾࠦࡥࡹࡥ࡫ࡥࡳ࡭ࡥࠡࡲࡵࡳࡨ࡫ࡳࡴࠢ࡬ࡷࠥࡩ࡯࡯ࡵ࡬ࡨࡪࡸࡥࡥࠢࡷࡳࠥࡨࡥࠡࡥࡲࡱࡵࡲࡥࡵࡧ࠱ࠤ࡙࡮ࡥࠡࡥࡲࡲࡹ࡫ࡸࡵࠢࡺ࡭ࡱࡲࠠࡪࡰࡹࡳࡰ࡫ࠠࡪࡶࡶࠤࡸࡻࡣࡤࡧࡶࡷࠥࡩࡡ࡭࡮ࡥࡥࡨࡱࠠࡢࡰࡧࠤࡸ࡫࡮ࡥࠢࡤࡲࡾࠦࡥ࡯ࡳࡸࡩࡺ࡫ࡤࠡ࡯ࡨࡷࡸࡧࡧࡦࡵ࠱ࠎࠥࠦࠠࠡ࠯࡛ࠣ࡭࡫࡮ࠡ࠼ࡳࡽ࠿ࡳࡥࡵࡪ࠽ࡤࡷ࡫ࡱࡶࡧࡶࡸࡤࡸࡥࡤࡧ࡬ࡺࡪࡪࡠࠡ࡫ࡶࠤࡨࡧ࡬࡭ࡧࡧ࠰ࠥࡺࡨࡦࠢࡦࡳࡳࡺࡥࡹࡶࠣࡻ࡮ࡲ࡬ࠡࡩࡨࡲࡪࡸࡡࡵࡧࠣࡥࡳࡪࠠࡴࡧࡱࡨࠥࡧࠠ࠻ࡲࡼ࠾ࡨࡲࡡࡴࡵ࠽ࡤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡶࡡࡺ࡮ࡲࡥࡩ࠴ࡋࡦࡻࡕࡩࡸࡶ࡯࡯ࡵࡨࡔࡦࡿ࡬ࡰࡣࡧࡤࠥࡺ࡯ࠡࡶ࡫ࡩࠥࡪࡥࡴࡶ࡬ࡲࡦࡺࡩࡰࡰ࠱ࠤࡎࡺࠠࡸ࡫࡯ࡰࠥࡺࡨࡦࡰࠣࡩࡳࡺࡥࡳࠢࡷ࡬ࡪࠦࡳࡵࡣࡷࡩࠥࡀࡰࡺ࠼ࡤࡸࡹࡸ࠺ࡡࡃ࡚ࡅࡎ࡚ࡉࡏࡉࡢࡖࡊ࡙ࡐࡐࡐࡖࡉࡤࡇࡃࡌࡢ࠱ࠎࠏࠦࠠࠡࠢࡌࡲࠥࡧࡤࡥ࡫ࡷ࡭ࡴࡴࠠࡵࡱࠣࡸ࡭࡫ࠠࡢࡤࡲࡺࡪࠦࡴࡳࡣࡱࡷ࡮ࡺࡩࡰࡰࡶ࠰ࠥࡺࡨࡦࡴࡨࠤࡦࡸࡥࠡ࡯ࡲࡶࡪࠦࡴࡳࡣࡱࡷ࡮ࡺࡩࡰࡰࡶࠤࡹࡸࡩࡨࡩࡨࡶࡪࡪࠠࡣࡻࠣࡱࡪࡹࡳࡢࡩࡨࠤࡦࡩ࡫࡯ࡱࡺࡰࡪࡪࡧࡦ࡯ࡨࡲࡹࡹࠠࡰࡴࠣࡶࡪࡩࡥࡪࡸࡨࡨࠥࡳࡥࡴࡵࡤ࡫ࡪࡹࠠࡵࡪࡤࡸࠥࡪࡥࡱࡧࡱࡨࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡩࡵࡳࡴࡨࡲࡹࠦࡳࡵࡣࡷࡩࠥࡵࡦࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡨࡼࡹࡀࠊࠡࠢࠣࠤ࠲ࠦࡗࡩ࡫࡯ࡩࠥࡺࡨࡦࠢࡦࡳࡳࡺࡥࡹࡶࠣ࡭ࡸࠦࡩ࡯ࠢࡷ࡬ࡪࠦ࠺ࡱࡻ࠽ࡥࡹࡺࡲ࠻ࡢࡄ࡛ࡆࡏࡔࡊࡐࡊࡣࡗࡋࡑࡖࡇࡖࡘࡤࡇࡃࡌࡢࠣࡷࡹࡧࡴࡦ࠮ࠣ࡭࡫ࠦࡩࡵࠢࡵࡩࡨ࡫ࡩࡷࡧࡶࠤࡦࠦࡰࡰࡵ࡬ࡸ࡮ࡼࡥࠡࡣࡦ࡯ࡳࡵࡷ࡭ࡧࡧ࡫ࡪࡳࡥ࡯ࡶࠣࡸࡴࠦࡩࡵࡵࠣࡶࡪࡷࡵࡦࡵࡷࠤࡲ࡫ࡳࡴࡣࡪࡩࠥ࡯ࡴࠡࡹ࡬ࡰࡱࠦ࡭ࡰࡸࡨࠤࡹࡵࠠࡵࡪࡨࠤ࠿ࡶࡹ࠻ࡣࡷࡸࡷࡀࡠࡂ࡙ࡄࡍ࡙ࡏࡎࡈࡡࡕࡉࡘࡖࡏࡏࡕࡈࡤࠥࡹࡴࡢࡶࡨ࠲ࠥࡏࡦࠡ࡫ࡷࠤࡷ࡫ࡣࡦ࡫ࡹࡩࡸࠦࡡࠡࡰࡨ࡫ࡦࡺࡩࡷࡧࠣࡥࡨࡱ࡮ࡰࡹ࡯ࡩࡩ࡭ࡥ࡮ࡧࡱࡸ࠱ࠦࡩࡵࠢࡺ࡭ࡱࡲࠠࡧࡣ࡬ࡰ࠱ࠦࡣࡢ࡮࡯ࠤ࡮ࡺࡳࠡࡨࡤ࡭ࡱࡻࡲࡦࠢࡦࡥࡱࡲࡢࡢࡥ࡮࠰ࠥࡧ࡮ࡥࠢࡦࡥࡺࡹࡥࠡࡣ࡯ࡰࠥ࡫࡮ࡲࡷࡨࡹࡪࡪࠠ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠢࡷࡳࠥ࡬ࡡࡪ࡮࠱ࠎࠥࠦࠠࠡ࠯࡛ࠣ࡭࡯࡬ࡦࠢࡷ࡬ࡪࠦࡣࡰࡰࡷࡩࡽࡺࠠࡪࡵࠣ࡭ࡳࠦࡴࡩࡧࠣ࠾ࡵࡿ࠺ࡢࡶࡷࡶ࠿ࡦࡁࡘࡃࡌࡘࡎࡔࡇࡠࡔࡈࡗࡕࡕࡎࡔࡇࡢࡅࡈࡑࡠࠡࡵࡷࡥࡹ࡫ࠬࠡ࡫ࡩࠤ࡮ࡺࠠࡳࡧࡦࡩ࡮ࡼࡥࡴࠢࡤࠤࡵࡵࡳࡪࡶ࡬ࡺࡪࠦࡡࡤ࡭ࡱࡳࡼࡲࡥࡥࡩࡨࡱࡪࡴࡴࠡࡶࡲࠤ࡮ࡺࡳࠡࡴࡨࡵࡺ࡫ࡳࡵࠢࡰࡩࡸࡹࡡࡨࡧࠣ࡭ࡹࠦࡷࡪ࡮࡯ࠤࡸࡻࡣࡤࡧࡨࡨ࠱ࠦࡣࡢ࡮࡯ࠤ࡮ࡺࡳࠡࡵࡸࡧࡨ࡫ࡳࡴࠢࡦࡥࡱࡲࡢࡢࡥ࡮࠰ࠥࡧ࡮ࡥࠢࡶࡩࡳࡪࠠࡢ࡮࡯ࠤࡪࡴࡱࡶࡧࡸࡩࡩࠦ࡭ࡦࡵࡶࡥ࡬࡫ࡳ࠯ࠢࡌࡪࠥ࡯ࡴࠡࡴࡨࡧࡪ࡯ࡶࡦࡵࠣࡥࠥࡴࡥࡨࡣࡷ࡭ࡻ࡫ࠠࡢࡥ࡮ࡲࡴࡽ࡬ࡦࡦࡪࡩࡲ࡫࡮ࡵ࠮ࠣ࡭ࡹࠦࡷࡪ࡮࡯ࠤ࡫ࡧࡩ࡭࠮ࠣࡧࡦࡲ࡬ࠡ࡫ࡷࡷࠥ࡬ࡡࡪ࡮ࡸࡶࡪࠦࡣࡢ࡮࡯ࡦࡦࡩ࡫࠭ࠢࡤࡲࡩࠦࡣࡢࡷࡶࡩࠥࡧ࡬࡭ࠢࡨࡲࡶࡻࡥࡶࡧࡧࠤࡲ࡫ࡳࡴࡣࡪࡩࡸࠦࡴࡰࠢࡩࡥ࡮ࡲ࠮ࠋࠢࠣࠤࠥࠨࠢࠣࢾ")
    l1ll1lll1_opy_ = 0
    l111ll_opy_ = 1
    l11111l1_opy_ = 2
    l1l1llll1_opy_ = (l1ll1lll1_opy_, l111ll_opy_, l11111l1_opy_)
    def __init__(self, destination, l111l1ll_opy_, callback, driver):
        l1l11l_opy_ (u"ࠨࠢࠣࠢࡅࡹ࡮ࡲࡤࠡࡶ࡫ࡩࠥࡑࡥࡺࡇࡻࡧ࡭ࡧ࡮ࡨࡧࡆࡳࡳࡺࡥࡹࡶ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡧࡰࡖࡨࡲࡳࡧ࠮ࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡍࡉࠦࡤࡦࡵࡷ࡭ࡳࡧࡴࡪࡱࡱ࠾࡚ࠥࡨࡦࠢࡤࡨࡩࡸࡥࡴࡵࠣࡳ࡫ࠦࡴࡩࡧࠣࡳࡹ࡮ࡥࡳࠢࡶ࡭ࡩ࡫ࠠࡰࡨࠣࡸ࡭࡫ࠠ࡬ࡧࡼࠤࡪࡾࡣࡩࡣࡱ࡫ࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡣࡻࡷࡩࡸࡲࡩ࡬ࡧࠣࡰࡴࡩࡡ࡭ࡡࡳࡹࡧࡱࡥࡺ࠼ࠣࡘ࡭࡫ࠠ࡭ࡱࡦࡥࡱࠦࡰࡶࡤ࡮ࡩࡾ࠲ࠠࡦࡰࡦࡳࡩ࡫ࡤࠡࡣࡱࡨࠥࡸࡥࡢࡦࡼࠤࡹࡵࠠࡵࡴࡤࡲࡸࡳࡩࡵࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡦࡲ࡬ࡢࡤ࡯ࡩࠥࡩࡡ࡭࡮ࡥࡥࡨࡱ࠺ࠡࡃࠣࡧࡦࡲ࡬ࡣࡣࡦ࡯ࠥࡺࡨࡢࡶࠣࡻ࡮ࡲ࡬ࠡࡤࡨࠤࡨࡧ࡬࡭ࡧࡧࠤࡼ࡮ࡥ࡯ࠢࡷ࡬ࡪࠦ࡫ࡦࡻࠣࡩࡽࡩࡨࡢࡰࡪࡩࠥࡹࡵࡤࡥࡨࡩࡩࡹࠠࡰࡴࠣࡪࡦ࡯࡬ࡴ࠮ࠣࡷ࡮ࡳࡩ࡭ࡣࡵࠤࡹࡵࠠࡢࠢࡰࡩࡹ࡮࡯ࡥࠢࡦࡥࡱࡲࡢࡢࡥ࡮ࠤࡦࡹࠠࡥࡧࡷࡥ࡮ࡲࡥࡥࠢ࡬ࡲࠥࡀࡰࡺ࠼ࡦࡰࡦࡹࡳ࠻ࡢࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡨࡷ࡯ࡶࡦࡴ࠱ࡈࡷ࡯ࡶࡦࡴࡣࠤࡧࡻࡴࠡࡹ࡬ࡸ࡭ࡵࡵࡵࠢࡷ࡬ࡪࠦࡣࡰࡴࡵࡩࡱࡧࡴࡪࡱࡱࠤࡎࡊࠠ࠮ࠢࡷ࡬ࡪࠦ࠺ࡱࡻ࠽ࡧࡱࡧࡳࡴ࠼ࡣࡏࡪࡿࡅࡹࡥ࡫ࡥࡳ࡭ࡥࡄࡱࡱࡸࡪࡾࡴࡡࠢ࡬ࡸࡸ࡫࡬ࡧࠢ࡬ࡷࠥࡺࡨࡦࠢࡳࡩࡷࡹࡩࡴࡶࡨࡲࡹࠦࡉࡅ࠰ࠣࡘ࡭࡫ࠠࡤࡣ࡯ࡰࡧࡧࡣ࡬ࠢ࡬ࡷࠥࡩࡡ࡭࡮ࡨࡨࠥࡵ࡮࡭ࡻࠣࡻ࡮ࡺࡨࠡ࡭ࡨࡽࡼࡵࡲࡥࠢࡤࡶ࡬ࡹ࠮ࠡࡖ࡫ࡩࠥ࡬࡯ࡳ࡯ࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡦࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࠳࠴ࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢ࠽࠾ࠥࡱࡥࡺࡡࡨࡼࡨ࡮ࡡ࡯ࡩࡨࡣࡨࡧ࡬࡭ࡤࡤࡧࡰ࠮ࡳࡶࡥࡦࡩࡸࡹࠬࠡࡴࡨࡷࡺࡲࡴࡴ࠮ࠣࡩࡷࡸ࡯ࡳ࠮ࠣࡨࡪࡺࡡࡪ࡮ࡶ࠭ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡣࡱࡲࡰࠥࡹࡵࡤࡥࡨࡷࡸࡀࠠࡡࡢࡗࡶࡺ࡫ࡠࡡࠢ࡬ࡪࠥࡺࡨࡦࠢࡨࡼࡨ࡮ࡡ࡯ࡩࡨࠤࡸࡻࡣࡤࡧࡨࡨࡪࡪࠬࠡࡢࡣࡊࡦࡲࡳࡦࡢࡣࠤࡴࡸࠠࡡࡢࡑࡳࡳ࡫ࡠࡡࠢࡲࡸ࡭࡫ࡲࡸ࡫ࡶࡩࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡵࡷࡳࡰࡪࡡࡧࡰࡖࡨࡲࡳࡧ࠮ࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡍࡉ࠲ࠠࡣࡻࡷࡩࡸࡲࡩ࡬ࡧࡠࠤࡷ࡫ࡳࡶ࡮ࡷ࠾ࠥࡏࡦࠡࡶ࡫ࡩࠥࡱࡥࡺࠢࡨࡼࡨ࡮ࡡ࡯ࡩࡨࠤࡸࡻࡣࡤࡧࡨࡨࡪࡪࠬࠡࡣࠣࡸࡺࡶ࡬ࡦࠢࡲࡪࠥࡦࡠࠩࡦࡨࡷࡹ࡯࡮ࡢࡶ࡬ࡳࡳ࠲ࠠࡰࡶ࡫ࡩࡷࡥ࡫ࡦࡻࠬࡤࡥ࠴ࠠࡊࡨࠣࡸ࡭࡫ࠠ࡬ࡧࡼࠤࡪࡾࡣࡩࡣࡱ࡫ࡪࠦࡦࡢ࡫࡯ࡩࡩ࠲ࠠࡡࡢࡑࡳࡳ࡫ࡠࡡ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡨ࡯ࡰ࡮ࠣࡩࡷࡸ࡯ࡳ࠼ࠣࡤࡥ࡚ࡲࡶࡧࡣࡤࠥ࡯ࡦࠡࡶ࡫ࡩࠥ࡫ࡸࡤࡪࡤࡲ࡬࡫ࠠࡧࡣ࡬ࡰࡪࡪࠬࠡࡢࡣࡊࡦࡲࡳࡦࡢࡣࠤࡴࡸࠠࡡࡢࡑࡳࡳ࡫ࡠࡡࠢ࡬ࡪࠥ࡯ࡴࠡࡵࡸࡧࡨ࡫ࡥࡥࡧࡧ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡥ࡫ࡦࡸࠥࡪࡥࡵࡣ࡬ࡰࡸࡀࠠࡊࡨࠣࡸ࡭࡫ࠠ࡬ࡧࡼࠤࡪࡾࡣࡩࡣࡱ࡫ࡪࠦࡦࡢ࡫࡯ࡩࡩ࠲ࠠࡡࡢࡧ࡭ࡨࡺࡠࡡࠢࡲࡪࠥ࡫ࡸࡱ࡮ࡤࡲࡦࡺ࡯ࡳࡻࠣ࡭ࡳ࡬࡯ࡳ࡯ࡤࡸ࡮ࡵ࡮ࠡࡣࡥࡳࡺࡺࠠࡵࡪࡨࠤࡪࡸࡲࡰࡴ࠱ࠤࡎ࡬ࠠࡵࡪࡨࠤࡰ࡫ࡹࠡࡧࡻࡧ࡭ࡧ࡮ࡨࡧࠣࡷࡺࡩࡣࡦࡧࡧࡩࡩ࠲ࠠࡡࡢࡑࡳࡳ࡫ࡠࡡ࠰ࠍࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡧࡰࡖࡨࡲࡳࡧ࠮ࡥࡴ࡬ࡺࡪࡸ࠮ࡅࡴ࡬ࡺࡪࡸࠠࡥࡴ࡬ࡺࡪࡸ࠺ࠡࡃࠣࡦࡦࡩ࡫ࡳࡧࡩࡩࡷ࡫࡮ࡤࡧࠣࡸࡴࠦࡴࡩࡧࠣࡨࡷ࡯ࡶࡦࡴࠣࡹࡸ࡯࡮ࡨࠢࡷ࡬࡮ࡹࠠࡤࡱࡱࡸࡪࡾࡴ࠯ࠢࡗ࡬࡮ࡹࠠࡪࡵࠣࡶࡪࡷࡵࡪࡴࡨࡨࠥࡹ࡯ࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡨࡼࡹࠦࡣࡢࡰࠣࡷࡪࡴࡤࠡ࡫ࡷࡷࠥࡱࡥࡺࠢࡨࡼࡨ࡮ࡡ࡯ࡩࡨࠤࡲ࡫ࡳࡴࡣࡪࡩࡸ࠲ࠠࡣࡷࡷࠤࡹ࡮ࡥࠡࡦࡵ࡭ࡻ࡫ࡲࠡ࡫ࡶࠤࡸࡺࡩ࡭࡮ࠣࡶࡪࡷࡵࡪࡴࡨࡨࠥࡺ࡯ࠡࡰࡲࡸ࡮࡬ࡹࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡨࡼࡹࠦ࡯ࡧࠢ࡬ࡲࡨࡵ࡭ࡪࡩࡱࠤࡰ࡫ࡹࠡࡧࡻࡧ࡭ࡧ࡮ࡨࡧࠣࡱࡪࡹࡳࡢࡩࡨࡷࠥࡸࡥ࡭ࡣࡷࡩࡩࠦࡴࡰࠢ࡬ࡸࡸࠦࡤࡦࡵࡷ࡭ࡳࡧࡴࡪࡱࡱ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤࢿ")
        self._destination = destination
        self._11ll11_opy_ = callback
        self._11l1ll1_opy_ = []
        self._LOGGER = driver._LOGGER.getChild(self.__class__.__name__)
        self._1llll11l_opy_ = driver
        self._1ll1lll_opy_ = None
        self._11lll1_opy_ = None
        self._1llll11_opy_ = l111l1ll_opy_
    def _11ll1l_opy_(self, l1ll1l11l_opy_, error, details):
        kwargs = {l1l11l_opy_ (u"ࠧࡴࡷࡦࡧࡪࡹࡳࠨࣀ"): l1ll1l11l_opy_,
                  l1l11l_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨࣁ"): (self._destination,
                             self._11lll1_opy_),
                  l1l11l_opy_ (u"ࠩࡨࡶࡷࡵࡲࠨࣂ"): error, l1l11l_opy_ (u"ࠪࡨࡪࡺࡡࡪ࡮ࡶࠫࣃ"): details}
        l11l111l_opy_(self._11ll11_opy_,
                   l1l11l_opy_ (u"ࠫࡨࡧ࡬࡭ࡤࡤࡧࡰࠦࡦࡰࡴࠣ࡯ࡪࡿࠠࡦࡺࡦ࡬ࡦࡴࡧࡦࠩࣄ"),
                   self._LOGGER, **kwargs)
        if l1ll1l11l_opy_:
            self._LOGGER.info(l1l11l_opy_ (u"ࠧࡑࡥࡺࠢࡨࡼࡨ࡮ࡡ࡯ࡩࡨࠤ࡫ࡵࡲࠡࡽࢀࠤࡸࡻࡣࡤࡧࡨࡨࡪࡪࠢࣅ")
                              .format(self._destination))
        else:
            self._LOGGER.error(l1l11l_opy_ (u"ࠨࡋࡦࡻࠣࡩࡽࡩࡨࡢࡰࡪࡩࠥ࡬࡯ࡳࠢࡾࢁࠥ࡬ࡡࡪ࡮ࡨࡨ࠿ࠦࡻࡾࠤࣆ")
                               .format(self._destination, error))
    @property
    def destination(self):
        l1l11l_opy_ (u"ࠢࠣࠤࠣࡋࡪࡺࠠࡵࡪࡨࠤࡩ࡫ࡳࡵ࡫ࡱࡥࡹ࡯࡯࡯ࠢࡲࡪࠥࡺࡨࡦࠢ࡮ࡩࡾࠦࡥࡹࡥ࡫ࡥࡳ࡭ࡥࠡࠤࠥࠦࣇ")
        return self._destination
    def _1l1111l_opy_(self, *args, **kwargs):
        l1l11l_opy_ (u"ࠣࠤࠥࠤࡆࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠡࡶ࡫ࡥࡹࠦࡳࡩࡱࡸࡰࡩࠦࡢࡦࠢࡳࡥࡸࡹࡥࡥࠢࡷࡳࠥࡀࡰࡺ࠼ࡧࡶ࡮ࡼࡥࡳ࠼ࡣࡷࡪࡴࡤࡠࡲࡵ࡭ࡻࡧࡴࡦࡢࠣࡥࡸࠦࡡࠡ࡯ࡨࡸ࡭ࡵࡤࠡࡥࡤࡰࡱࡨࡡࡤ࡭ࠣࡪࡴࡸࠠࡵࡪࡨࠤࡰ࡫ࡹࠡࡴࡨࡵࡺ࡫ࡳࡵࠢࡰࡩࡸࡹࡡࡨࡧ࠱ࠤࠧࠨࠢࣈ")
        if not kwargs.get(l1l11l_opy_ (u"ࠩࡶࡹࡨࡩࡥࡴࡵࠪࣉ"), False):
            self._11ll1l_opy_(False, True, kwargs.get(l1l11l_opy_ (u"ࠥࡨࡪࡺࡡࡪ࡮ࡶࠦ࣊"), {}))
            self.complete(False)
    def _11l11l_opy_(self, *args, **kwargs):
        l1l11l_opy_ (u"ࠦࠧࠨࠠࡂࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡹ࡮ࡡࡵࠢࡶ࡬ࡴࡻ࡬ࡥࠢࡥࡩࠥࡶࡡࡴࡵࡨࡨࠥࡺ࡯ࠡ࠼ࡳࡽ࠿ࡪࡲࡪࡸࡨࡶ࠿ࡦࡳࡦࡰࡧࡣࡵࡸࡩࡷࡣࡷࡩࡥࠦࡡࡴࠢࡤࠤࠧࠨࠢ࣋")
        if len(args) > 1:
            l1ll1l11l_opy_ = args[1]
        else:
            l1ll1l11l_opy_ = kwargs[l1l11l_opy_ (u"ࠬࡹࡵࡤࡥࡨࡷࡸ࠭࣌")]
        if l1ll1l11l_opy_:
            if self._1ll1lll_opy_ == self.l1ll1lll1_opy_:
                self._1ll1lll_opy_ = self.l111ll_opy_
            elif self._1ll1lll_opy_ == self.l11111l1_opy_:
                self._LOGGER.info(l1l11l_opy_ (u"ࠨࡋࡦࡻࠣࡩࡽࡩࡨࡢࡰࡪࡩࠥ࡬࡯ࡳࠢࡾࢁࠥࡩ࡯࡮ࡲ࡯ࡩࡹ࡫ࠢ࣍")
                                  .format(self._destination))
                self._11ll1l_opy_(True, None, None)
                self.complete(True)
        else:
            self._LOGGER.error(l1l11l_opy_ (u"ࠢࡌࡧࡼࠤࡪࡾࡣࡩࡣࡱ࡫ࡪࠦࡦࡰࡴࠣࡿࢂࠦࡦࡢ࡫࡯ࡩࡩࠦࡩ࡯ࠢࡶࡸࡦ࡭ࡥࠡࡽࢀ࠾ࠥࡧࡣ࡬ࠢࡷ࡭ࡲ࡫࡯ࡶࡶࠥ࣎")
                               .format(self._destination, self._1ll1lll_opy_))
            details = {l1l11l_opy_ (u"ࠨࡥࡲࡨࡪ࣏࠭"): goTenna.constants.ErrorCodes.TIMEOUT,
                       l1l11l_opy_ (u"ࠩࡰࡷ࡬࣐࠭"): l1l11l_opy_ (u"ࠪࡏࡪࡿࠠࡳࡧࡴࡹࡪࡹࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡤࡧࡰࡴ࡯ࡸ࡮ࡨࡨ࡬࡫ࡤࠨ࣑")}
            self._11ll1l_opy_(False, True, details)
            self.complete(False)
    def l11llll_opy_(self, retryer):
        l1l11l_opy_ (u"ࠦࠧࠨࠠࡆࡰࡴࡹࡪࡻࡥࠡࡣࠣࡱࡪࡹࡳࡢࡩࡨࠤ࡫ࡵࡲࠡࡶࡵࡥࡳࡹ࡭ࡪࡵࡶ࡭ࡴࡴࠠࠩࡱࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡰࡦࡺࡩࡰࡰࠬࠤࡴࡴࡣࡦࠢࡷ࡬ࡪࠦ࡫ࡦࡻࠣࡩࡽࡩࡨࡢࡰࡪࡩࠥࡹࡵࡤࡥࡨࡩࡩࡹࠠࠩࡱࡵࠤ࡫ࡧࡩ࡭ࡵࠬ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࡕࡪ࡬ࡷࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡴࡪࡲࡹࡱࡪࠠࡣࡧࠣࡧࡦࡲ࡬ࡦࡦࠣ࡭ࡳࡹࡴࡦࡣࡧࠤࡴ࡬ࠠ࠻ࡲࡼ࠾ࡲ࡫ࡴࡩ࠼ࡣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡩࡸࡩࡷࡧࡵࡣࡧࡧࡣ࡬ࡧࡱࡨ࠳ࡊࡲࡪࡸࡨࡶࡇࡧࡣ࡬ࡧࡱࡨ࠳ࡥࡩ࡯ࡸࡲ࡯ࡪࡥࡣࡰ࡯ࡰࡥࡳࡪࡠࠡࡨࡲࡶࠥࡳࡥࡴࡵࡤ࡫ࡪࡹࠠࡴࡧࡱࡸࠥࡺ࡯ࠡࡣࡧࡨࡷ࡫ࡳࡴࡧࡶࠤࡨࡻࡲࡳࡧࡱࡸࡱࡿࠠࡶࡰࡧࡩࡷ࡭࡯ࡪࡰࡪࠤࡰ࡫ࡹࠡࡧࡻࡧ࡭ࡧ࡮ࡨࡧ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡍࡦࡵࡶࡥ࡬࡫ࡒࡦࡶࡵࡽࡪࡸࠠࡳࡧࡷࡶࡾ࡫ࡲ࠻ࠢࡗ࡬ࡪࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡳࡧࡷࡶࡾ࡫ࡲࠡࡨࡲࡶࠥࡺࡨࡦࠢࡰࡩࡸࡹࡡࡨࡧࠣࡸࡴࠦࡢࡦࠢࡨࡲࡶࡻࡥࡶࡧࡧ࠲ࠥࡏࡦࠡࡶ࡫ࡩࠥࡱࡥࡺࠢࡨࡼࡨ࡮ࡡ࡯ࡩࡨࠤࡸࡻࡣࡤࡧࡨࡨࡸ࠲ࠠࡵࡪࡨࠤࡨࡵ࡮ࡵࡧࡻࡸࠥ࡯࡮ࡷࡱ࡮ࡩࡸࠦ࠺ࡱࡻ࠽ࡱࡪࡺࡨ࠻ࡢࡐࡩࡸࡹࡡࡨࡧࡕࡩࡹࡸࡹࡦࡴ࠱ࡷࡹࡧࡲࡵࡢ࠱ࠤࡎ࡬ࠠࡪࡶࠣࡪࡦ࡯࡬ࡴ࠮ࠣࡸ࡭࡫ࠠࡤࡱࡱࡸࡪࡾࡴࠡ࡫ࡱࡺࡴࡱࡥࡴࠢ࠽ࡴࡾࡀ࡭ࡦࡶ࡫࠾ࡥࡓࡥࡴࡵࡤ࡫ࡪࡘࡥࡵࡴࡼࡩࡷ࠴ࡦࡢ࡫࡯ࡤ࠳ࡧࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤ࣒ࠥࠦ")
        self._11l1ll1_opy_.append(retryer)
    def complete(self, l1111lll_opy_):
        l1l11l_opy_ (u"ࠧࠨࠢࠡࡇࡱࡨࠥࡺࡨࡦࠢ࡮ࡩࡾࠦࡥࡹࡥ࡫ࡥࡳ࡭ࡥࠡࡲࡵࡳࡨ࡫ࡳࡴ࠮ࠣࡻ࡮ࡺࡨࠡࡣࠣࡷࡺࡩࡣࡦࡵࡶࠤࡴࡸࠠࡧࡣ࡬ࡰࡺࡸࡥࠡࠤ࣓ࠥࠦ")
        for message in self._11l1ll1_opy_:
            if l1111lll_opy_:
                message.start()
            else:
                message.l11l1l_opy_(False,
                             details={l1l11l_opy_ (u"࠭ࡣࡰࡦࡨࠫࣔ"): goTenna.constants.ErrorCodes.KEY_EXCHANGE_FAILED,
                                      l1l11l_opy_ (u"ࠧ࡮ࡵࡪࠫࣕ"): l1l11l_opy_ (u"ࠨࡍࡨࡽࠥ࡫ࡸࡤࡪࡤࡲ࡬࡫ࠠࡧࡣ࡬ࡰࡪࡪ࠺ࠡࡦࡨࡷࡹ࡯࡮ࡢࡶ࡬ࡳࡳࠦࡇࡊࡆࠣࡱࡦࡿࠠࡣࡧࠣ࡭ࡳࡩ࡯ࡳࡴࡨࡧࡹࠦ࡯ࡳࠢࡧࡩࡸࡺࡩ࡯ࡣࡷ࡭ࡴࡴࠠ࡮ࡣࡼࠤࡧ࡫ࠠࡰࡨࡩࡰ࡮ࡴࡥࠨࣖ")})
        self._11l1ll1_opy_ = []
    def l111ll1_opy_(self):
        l1l11l_opy_ (u"ࠤ࡙ࠥࠦࠥࡥࡵࠢࡷ࡬ࡪࠦࡣࡰࡰࡷࡩࡽࡺࠠࡵࡱࠣ࡭ࡳ࡯ࡴࡢࡶࡨࠤࡦࠦ࡮ࡦࡹࠣࡩࡽࡩࡨࡢࡰࡪࡩࠥࡧ࡮ࡥࠢࡦࡥࡺࡹࡥࠡ࡫ࡷࠤࡹࡵࠠࡴࡧࡱࡨࠥࡧࠠࡳࡧࡴࡹࡪࡹࡴ࠯ࠤࠥࠦࣗ")
        self._LOGGER.info(l1l11l_opy_ (u"ࠥࡏࡪࡿࠠࡦࡺࡦ࡬ࡦࡴࡧࡦࠢ࡬ࡲ࡮ࡺࡩࡢࡶࡨࡨࠥࡽࡩࡵࡪࠣࡿࢂࠨࣘ")
                          .format(self._destination))
        self._1ll1lll_opy_ = self.l1ll1lll1_opy_
        l1llll1_opy_ = goTenna.payload.KeyRequestPayload(self._1llll11_opy_)
        self._1llll11l_opy_.send_private(self._destination, l1llll1_opy_,
                                  self._1l1111l_opy_,
                                  self._11l11l_opy_,
                                  encrypt=False)
    def l1lllllll_opy_(self, msg):
        l1l11l_opy_ (u"ࠦࠧࠨࠠࡔࡧࡷࠤࡹ࡮ࡥࠡࡥࡲࡲࡹ࡫ࡸࡵࠢࡷࡳࠥࡸࡥࡲࡷࡨࡷࡹࠦࡲࡦࡥࡨ࡭ࡻ࡫ࡤࠡࡵࡷࡥࡹ࡫ࠠࡢࡰࡧࠤࡨࡧࡵࡴࡧࠣ࡭ࡹࠦࡴࡰࠢࡶࡩࡳࡪࠠࡢࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࡕࡪࡨࠤࡴࡺࡨࡦࡴࠣࡷ࡮ࡪࡥࠨࡵࠣࡶࡪࡷࡵࡦࡵࡷࠤࡲ࡫ࡳࡴࡣࡪࡩࠥ࡯ࡳࠡࡲࡤࡷࡸ࡫ࡤࠡ࡫ࡱࠤ࡭࡫ࡲࡦࠢࡶࡳࠥࡺࡨࡦࠢ࡮ࡩࡾࠦࡩࡵࠢࡦࡳࡳࡺࡡࡪࡰࡶࠤࡨࡧ࡮ࠡࡤࡨࠤࡵࡸ࡯ࡱࡧࡵࡰࡾࠦࡳࡦࡰࡷࠤ࡮ࡴࠠࡵࡪࡨࠤࡰ࡫ࡹࠡࡧࡻࡧ࡭ࡧ࡮ࡨࡧࠣࡧࡴࡳࡰ࡭ࡧࡷࡩࠥࡩࡡ࡭࡮ࡥࡥࡨࡱࠬࠡࡴࡨࡱࡴࡼࡩ࡯ࡩࠣࡥࠥࡶ࡯ࡴࡵ࡬ࡦࡱ࡫ࠠࡳࡣࡦࡩࠥࡩ࡯࡯ࡦ࡬ࡸ࡮ࡵ࡮ࠡࡥࡤࡹࡸ࡫ࡤࠡࡤࡼࠤࡴࡺࡨࡦࡴࠣࡴࡦࡸࡴࡴࠢࡲࡪࠥࡺࡨࡦࠢࡖࡈࡐࠦࡣࡩࡧࡦ࡯࡮ࡴࡧࠡࡨࡲࡶࠥࡧࠠ࡬ࡧࡼࠤ࡫ࡵࡲࠡࡶ࡫ࡩࠥ࡭ࡩࡷࡧࡱࠤࡩ࡫ࡳࡵࠢࡥࡩ࡫ࡵࡲࡦࠢࡨࡼࡨ࡮ࡡ࡯ࡩࡨࠤ࡮ࡹࠠࡤࡱࡰࡴࡱ࡫ࡴࡦ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥ࡭࡯ࡕࡧࡱࡲࡦ࠴࡭ࡦࡵࡶࡥ࡬࡫࠮ࡎࡧࡶࡷࡦ࡭ࡥ࠻ࠢࡗ࡬ࡪࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡧࡴࡲࡱࠥࡺࡨࡦࠢࡲࡸ࡭࡫ࡲࠡࡵ࡬ࡨࡪࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡥࡹࡥ࡫ࡥࡳ࡭ࡥࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧࣙ")
        self._LOGGER.info(l1l11l_opy_ (u"ࠧࡑࡥࡺࠢࡨࡼࡨ࡮ࡡ࡯ࡩࡨࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡸࡥࡤࡧ࡬ࡺࡪࡪࠠࡧࡴࡲࡱࠥࢁࡽࠣࣚ")
                          .format(msg.payload.sender))
        self._1ll1lll_opy_ = self.l11111l1_opy_
        self._11lll1_opy_ = msg.payload.key_bytes
        l1ll111l1_opy_ = goTenna.payload.KeyResponsePayload(self._1llll11_opy_)
        self._1llll11l_opy_.send_private(self._destination, l1ll111l1_opy_,
                                  self._1l1111l_opy_,
                                  self._11l11l_opy_,
                                  encrypt=False)
    def l1llllll1_opy_(self, msg):
        l1l11l_opy_ (u"ࠨࠢࠣࠢࡌࡲࡩ࡯ࡣࡢࡶࡨࠤࡹࡵࠠࡵࡪࡨࠤࡨࡻࡲࡳࡧࡱࡸࠥࡩ࡯࡯ࡶࡨࡼࡹࠦࡴࡩࡣࡷࠤࡰ࡫ࡹࠡࡧࡻࡧ࡭ࡧ࡮ࡨࡧࠣ࡭ࡸࠦࡣࡰ࡯ࡳࡰࡪࡺࡥ࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࡙࡮ࡥࠡࡱࡷ࡬ࡪࡸࠠࡴ࡫ࡧࡩࠬࡹࠠࡳࡧࡶࡴࡴࡴࡳࡦࠢࡰࡩࡸࡹࡡࡨࡧࠣ࡭ࡸࠦࡰࡢࡵࡶࡩࡩࠦࡩ࡯ࠢ࡫ࡩࡷ࡫ࠠࡴࡱࠣࡸ࡭࡫ࠠ࡬ࡧࡼࠤ࡮ࡺࠠࡤࡱࡱࡸࡦ࡯࡮ࡴࠢࡦࡥࡳࠦࡢࡦࠢࡳࡶࡴࡶࡥࡳ࡮ࡼࠤࡸ࡫࡮ࡵࠢ࡬ࡲࠥࡺࡨࡦࠢ࡮ࡩࡾࠦࡥࡹࡥ࡫ࡥࡳ࡭ࡥࠡࡥࡲࡱࡵࡲࡥࡵࡧࠣࡧࡦࡲ࡬ࡣࡣࡦ࡯࠱ࠦࡲࡦ࡯ࡲࡺ࡮ࡴࡧࠡࡣࠣࡴࡴࡹࡳࡪࡤ࡯ࡩࠥࡸࡡࡤࡧࠣࡧࡴࡴࡤࡪࡶ࡬ࡳࡳࠦࡣࡢࡷࡶࡩࡩࠦࡢࡺࠢࡲࡸ࡭࡫ࡲࠡࡲࡤࡶࡹࡹࠠࡰࡨࠣࡸ࡭࡫ࠠࡔࡆࡎࠤࡨ࡮ࡥࡤ࡭࡬ࡲ࡬ࠦࡦࡰࡴࠣࡥࠥࡱࡥࡺࠢࡩࡳࡷࠦࡴࡩࡧࠣ࡫࡮ࡼࡥ࡯ࠢࡧࡩࡸࡺࠠࡣࡧࡩࡳࡷ࡫ࠠࡦࡺࡦ࡬ࡦࡴࡧࡦࠢ࡬ࡷࠥࡩ࡯࡮ࡲ࡯ࡩࡹ࡫࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧࣛ")
        self._LOGGER.info(l1l11l_opy_ (u"ࠢࡌࡧࡼࠤࡪࡾࡣࡩࡣࡱ࡫ࡪࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡࡴࡨࡧࡪ࡯ࡶࡦࡦࠣࡪࡷࡵ࡭ࠡࡽࢀࠦࣜ")
                          .format(msg.payload.sender))
        self._11lll1_opy_ = msg.payload.key_bytes
        self._11ll1l_opy_(True, None, None)
        self.complete(True)
class MessageRetryer(object):
    l1l11l_opy_ (u"ࠣࠤࠥࠤࡆࠦࡣ࡭ࡣࡶࡷࠥࡺࡨࡢࡶࠣ࡬ࡦࡴࡤ࡭ࡧࡶࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡸࡥࡵࡴࡼࠤࡸ࡫࡭ࡢࡰࡷ࡭ࡨࡹࠠࠣࠤࠥࣝ")
    def __init__(self, driver, corr_id, l111ll1l_opy_, method_callback,
                 ack_callback, l11l11l1_opy_):
        l1l11l_opy_ (u"ࠤࠥࠦࠥࡏ࡮ࡪࡶ࡬ࡥࡱ࡯ࡺࡦࠢࡤࠤࡒ࡫ࡳࡴࡣࡪࡩࡗ࡫ࡴࡳࡻࡨࡶࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡨࡱࡗࡩࡳࡴࡡ࠯ࡦࡵ࡭ࡻ࡫ࡲ࠯ࡆࡵ࡭ࡻ࡫ࡲࠡࡦࡵ࡭ࡻ࡫ࡲ࠻ࠢࡗ࡬ࡪࠦࡄࡳ࡫ࡹࡩࡷࠦࡩ࡯ࡵࡷࡥࡳࡩࡥࠡࡥࡵࡩࡦࡺࡩ࡯ࡩࠣࡸ࡭࡯ࡳࠡࡴࡨࡸࡷࡿࡩࡦࡴ࠱ࠤ࡙࡮ࡩࡴࠢ࡬ࡷࠥࡻࡳࡦࡦࠣࡸࡴࠦࡳࡦࡰࡧࠤࡹ࡮ࡥࠡࡴࡨࡸࡷ࡯ࡥࡴࠢࡤࡲࡩࠦࡧࡦࡶࠣࡲࡪࡽࠠࡦࡰࡦࡶࡾࡶࡴࡪࡱࡱࠤࡨࡵࡵ࡯ࡶࡨࡶࡸ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡷࡸ࡭ࡩ࠴ࡵࡶ࡫ࡧࠤࡨࡵࡲࡳࡡ࡬ࡨ࠿ࠦࡔࡩࡧࠣࡧࡴࡸࡲࡦ࡮ࡤࡸ࡮ࡵ࡮ࠡࡋࡇࠤ࡫ࡵࡲࠡࡶ࡫ࡩࠥࡵࡲࡪࡩ࡬ࡲࡦࡲࠠࡪࡰࡹࡳࡨࡧࡴࡪࡱࡱࠤࡴ࡬ࠠࡵࡪࡨࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡹࡥ࡯ࡦ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥ࡭࡯ࡕࡧࡱࡲࡦ࠴࡭ࡦࡵࡶࡥ࡬࡫࠮ࡎࡧࡶࡷࡦ࡭ࡥࠡ࡯ࡨࡷࡸࡧࡧࡦࡡࡲࡦ࡯ࡀࠠࡕࡪࡨࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡺ࡯ࠡࡵࡨࡲࡩ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡ࡯ࡨࡸ࡭ࡵࡤࡠࡥࡤࡰࡱࡨࡡࡤ࡭࠽ࠤ࡙࡮ࡥࠡ࡯ࡨࡸ࡭ࡵࡤࠡࡥࡤࡰࡱࡨࡡࡤ࡭ࠣࡪࡴࡸࠠࡵࡪࡨࠤࡲ࡫ࡳࡴࡣࡪࡩ࠳ࠦࡆࡰࡴࠣࡱࡴࡸࡥ࠭ࠢࡶࡩࡪࠦ࠺ࡱࡻ࠽ࡧࡱࡧࡳࡴ࠼ࡣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡩࡸࡩࡷࡧࡵ࠲ࡉࡸࡩࡷࡧࡵࡤ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡢࡥ࡮ࡣࡨࡧ࡬࡭ࡤࡤࡧࡰࡀࠠࡕࡪࡨࠤࡦࡩ࡫ࠡࡥࡤࡰࡱࡨࡡࡤ࡭ࠣࡪࡴࡸࠠࡵࡪࡨࠤࡲ࡫ࡳࡴࡣࡪࡩ࠳ࠦࡆࡰࡴࠣࡱࡴࡸࡥ࠭ࠢࡶࡩࡪࠦ࠺ࡱࡻ࠽ࡱࡪࡺࡨ࠻ࡢࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡨࡷ࡯ࡶࡦࡴ࠱ࡈࡷ࡯ࡶࡦࡴ࠱ࡷࡪࡴࡤࡠࡲࡵ࡭ࡻࡧࡴࡦࡢࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡱ࡯ࡳࡵ࡝࡬ࡲࡹࡣࠠࡳࡧࡷࡶࡾࡥࡰࡢࡶࡷࡩࡷࡴ࠺ࠡࡖ࡫ࡩࠥࡽࡡࡺࠢࡷ࡬ࡪࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡴࡪࡲࡹࡱࡪࠠࡣࡧࠣࡶࡪࡺࡲࡪࡧࡧ࠲࡚ࠥࡨࡪࡵࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡦࡪࠦࡡࠡ࡮࡬ࡷࡹࠦ࡯ࡧࠢ࡫ࡳࡵࠦࡣࡰࡷࡱࡸࡸ࠲ࠠࡦࡣࡦ࡬ࠥࡵࡦࠡࡹ࡫࡭ࡨ࡮ࠠࡪࡵࠣࡰࡪࡹࡳࠡࡶ࡫ࡥࡳࠦ࠺ࡱࡻ࠽ࡥࡹࡺࡲ࠻ࡢࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡧࡴࡴࡳࡵࡣࡱࡸࡸ࠴ࡍࡂ࡚ࡢࡌࡔࡖࡓࡡ࠰ࠣࡉࡦࡩࡨࠡࡶ࡬ࡱࡪࠦࡡࠡ࡯ࡨࡷࡸࡧࡧࡦࠢࡶࡩࡳࡪࠠࡧࡣ࡬ࡰࡸ࠲ࠠࡪࡶࠣࡻ࡮ࡲ࡬ࠡࡤࡨࠤࡷ࡫ࡴࡳ࡫ࡨࡨࠥࡽࡩࡵࡪࠣࡸ࡭࡫ࠠ࡯ࡧࡻࡸࠥ࡫࡬ࡦ࡯ࡨࡲࡹࠦ࡯ࡧࠢࡣࡤࡷ࡫ࡴࡳࡻࡢࡴࡦࡺࡴࡦࡴࡱࡤࡥࠦࡵ࡯ࡶ࡬ࡰࠥࡺࡨࡦࡴࡨࠤࡦࡸࡥࠡࡰࡲࠤࡲࡵࡲࡦࠢࡨࡰࡪࡳࡥ࡯ࡶࡶ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤࣞ")
        self._1llll11l_opy_ = driver
        self._LOGGER = self._1llll11l_opy_._LOGGER.getChild(self.__class__.__name__)
        self._1lll1l_opy_ = corr_id
        self._message = l111ll1l_opy_
        self._1l11l11_opy_ = method_callback
        self._1llllll_opy_ = ack_callback
        if any([int(retry) > goTenna.constants.MAX_HOPS
                for retry in l11l11l1_opy_]):
            raise ValueError(l1l11l_opy_ (u"ࠥࡅࡱࡲࠠࡦ࡮ࡨࡱࡪࡴࡴࡴࠢࡲࡪࠥࡺࡨࡦࠢࡵࡩࡹࡸࡹࠡࡲࡤࡸࡹ࡫ࡲ࡯ࠢࡰࡹࡸࡺࠠࡣࡧࠣࡹࡳࡪࡥࡳࠢࡾࢁࠧࣟ")
                             .format(goTenna.constants.MAX_HOPS))
        self._1lllll1l_opy_ = l11l11l1_opy_
        self._1l1lll_opy_ = None
    def start(self):
        l1l11l_opy_ (u"ࠦࠧࠨࠠࡃࡧࡪ࡭ࡳࠦࡴࡩࡧࠣࡱࡪࡹࡳࡢࡩࡨࠤࡸ࡫࡮ࡥࠢࡺ࡭ࡹ࡮ࠠࡳࡧࡷࡶ࡮࡫ࡳ࠯ࠢࠥࠦࠧ࣠")
        self._LOGGER.info(l1l11l_opy_ (u"ࠧࡓࡥࡴࡵࡤ࡫ࡪࠦࡻࡾࠢࡵࡩࡹࡸࡩࡦࡵࠣࡦࡪ࡭ࡵ࡯ࠤ࣡").format(self._1lll1l_opy_))
        def _1111l11_opy_(l1ll1ll11_opy_):
            for retry in l1ll1ll11_opy_:
                yield int(retry)
        self._1l1lll_opy_ = _1111l11_opy_(self._1lllll1l_opy_)
        self._1lll11ll_opy_(False)
    def l11l1l_opy_(self, l1l1ll1_opy_, details=None):
        l1l11l_opy_ (u"ࠨࠢࠣࠢࡐࡥࡷࡱࠠࡵࡪࡨࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡧࡳࠡࡨࡤ࡭ࡱ࡫ࡤ࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࡙࡮ࡩࡴࠢࡰࡥࡾࠦࡢࡦࠢࡸࡷࡪࡪࠠࡪࡨࠣࡶࡪࡺࡲࡪࡧࡶࠤࡦࡸࡥࠡࡷࡶࡩࡩࠦࡵࡱࠢࡲࡶࠥ࡯ࡦࠡࡵࡲࡱࡪࡺࡨࡪࡰࡪࠤ࡮ࡴࡶࡢ࡮࡬ࡨࡦࡺࡥࡴࠢࡷ࡬ࡪࠦ࡭ࡦࡵࡶࡥ࡬࡫࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࣢")
        self._LOGGER.info(l1l11l_opy_ (u"ࠢࡎࡧࡶࡷࡦ࡭ࡥࠡࡽࢀࠤࡦࡺࡴࡦ࡯ࡳࡸࠥ࡬ࡡࡪ࡮ࡶࣣࠦ").format(self._1lll1l_opy_))
        if l1l1ll1_opy_:
            kwargs = {l1l11l_opy_ (u"ࠨࡥࡲࡶࡷ࡫࡬ࡢࡶ࡬ࡳࡳࡥࡩࡥࠩࣤ"): self._1lll1l_opy_,
                      l1l11l_opy_ (u"ࠩࡶࡹࡨࡩࡥࡴࡵࠪࣥ"): False}
            l11l111l_opy_(self._1llllll_opy_,
                       l1l11l_opy_ (u"ࠪࡅࡨࡱ࡮ࡰࡹ࡯ࡩࡩ࡭ࡥࠡࡥࡤࡰࡱࡨࡡࡤ࡭ࠣࡪࡴࡸࠠ࡮ࡧࡶࡷࡦ࡭ࡥࠡࡽࢀࣦࠫ")
                       .format(self._1lll1l_opy_),
                       self._LOGGER, **kwargs)
        else:
            kwargs = {l1l11l_opy_ (u"ࠫࡨࡵࡲࡳࡧ࡯ࡥࡹ࡯࡯࡯ࡡ࡬ࡨࠬࣧ"): self._1lll1l_opy_,
                      l1l11l_opy_ (u"ࠬ࡫ࡲࡳࡱࡵࠫࣨ"): True, l1l11l_opy_ (u"࠭ࡤࡦࡶࡤ࡭ࡱࡹࣩࠧ"):  details}
            l11l111l_opy_(self._1l11l11_opy_,
                       l1l11l_opy_ (u"ࠧࡎࡧࡷ࡬ࡴࡪࠠࡤࡣ࡯ࡰࡧࡧࡣ࡬ࠢࡩࡳࡷࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡼࡿࠪ࣪").format(self._1lll1l_opy_),
                       self._LOGGER, **kwargs)
    def _1lll11ll_opy_(self, l1l1ll1_opy_, details=None):
        if self._1l1lll_opy_ is None:
            self.start()
        try:
            hops = next(self._1l1lll_opy_)
        except StopIteration:
            hops = None
        if hops is None:
            self.l11l1l_opy_(l1l1ll1_opy_, details)
            return
        self._LOGGER.info(l1l11l_opy_ (u"ࠣࡏࡨࡷࡸࡧࡧࡦࠢࡾࢁࠥࡹࡥ࡯ࡦࠣࡥࡹࡺࡥ࡮ࡲࡷࠤࡼ࡯ࡴࡩࠢࡾࢁࠥ࡮࡯ࡱࡵࠥ࣫")
                          .format(self._1lll1l_opy_, hops))
        if self._message.destination:
            l1lllll1_opy_ = self._message.destination
        else:
            l1lllll1_opy_ = goTenna.settings.GID.broadcast()
        new_counter = self._1llll11l_opy_._encryption_manager.next_encryption_counter(l1lllll1_opy_)
        self._message.update_encryption_counter(new_counter)
        self._message.set_max_hops(hops)
        self._1llll11l_opy_._invoke_command(self._1llll11l_opy_.device.send_message,
                                     self._1lll1l_opy_,
                                     self.method_callback,
                                     (self._message,))
    def method_callback(self, *args, **kwargs):
        if kwargs.get(l1l11l_opy_ (u"ࠩࡶࡹࡨࡩࡥࡴࡵࠪ࣬"), False):
            kwargs[l1l11l_opy_ (u"ࠪࡧࡴࡸࡲࡦ࡮ࡤࡸ࡮ࡵ࡮ࡠ࡫ࡧ࣭ࠫ")] = self._1lll1l_opy_
            l11l111l_opy_(self._1l11l11_opy_,
                       l1l11l_opy_ (u"ࠫࡲ࡫ࡴࡩࡱࡧࠤࡨࡧ࡬࡭ࡤࡤࡧࡰࠦࡦࡰࡴࠣࡿࢂ࣮࠭").format(self._1lll1l_opy_),
                       self._LOGGER, **kwargs)
            if self._1llllll_opy_:
                self._1llll11l_opy_._1l11lll_opy_.add(self._message, self.ack_callback)
        else:
            self._1lll11ll_opy_(False, kwargs.get(l1l11l_opy_ (u"ࠬࡪࡥࡵࡣ࡬ࡰࡸ࣯࠭"), None))
    def ack_callback(self, *args, **kwargs):
        if args:
            l1ll1l11l_opy_ = args[0]
        else:
            l1ll1l11l_opy_ = kwargs[l1l11l_opy_ (u"࠭ࡳࡶࡥࡦࡩࡸࡹࣰࠧ")]
        if l1ll1l11l_opy_:
            kwargs = {l1l11l_opy_ (u"ࠧࡤࡱࡵࡶࡪࡲࡡࡵ࡫ࡲࡲࡤ࡯ࡤࠨࣱ"): self._1lll1l_opy_, l1l11l_opy_ (u"ࠨࡵࡸࡧࡨ࡫ࡳࡴࣲࠩ"): True}
            l11l111l_opy_(self._1llllll_opy_,
                       l1l11l_opy_ (u"ࠩࡤࡧࡰࠦࡣࡢ࡮࡯ࡦࡦࡩ࡫ࠡࡨࡲࡶࠥࢁࡽࠨࣳ").format(self._1lll1l_opy_),
                       self._LOGGER, **kwargs)
        else:
            self._1lll11ll_opy_(True)