# coding: utf8
# Copyright (C) 2018 goTenna, Inc. This file is distributed as part of the
# goTenna USB SDK. See the associated license for more information.
"""
Module containing useful contents for communicating with
goTennas.
"""

import sys
import datetime

SHARING_FREQUENCIES = {
    'HALF_MINUTE': 1,
    'ONE_MINUTE': 2,
    'ONE_AND_HALF_MINUTE': 3,
    'TWO_MINUTES': 4,
    'TWO_AND_HALF_MINUTE': 5,
    'THREE_MINUTES': 6,
    'FIVE_MINUTES': 7
}

def sharing_frequency(name):
    """ Look up a location sharing frequency from its name.

    :param str name: A key (any case) of :py:attr:`SHARING_FREQUENCIES`
    :returns int: The code of the frequnecy
    :raises KeyError: If ``name`` is not a valid sharing frequency
    """
    return SHARING_FREQUENCIES[name.upper()]

def sharing_frequency_name(frequency_code):
    """ Look up the name of a sharing frequency

    :param int frequency_code: The code, a value of :py:attr:`SHARING_FREQUENCIES`
    :returns str: The key of the frequency
    :raises KeyError: If ``frequency_code`` is not in :py:attr:`SHARING_FREQUENCIES`
    """
    for (key, val) in SHARING_FREQUENCIES.items():
        if val == frequency_code:
            return key
    raise KeyError(frequency_code)

#: Specify the type of a message used with send-generic
MESSAGE_TYPES = {
    'private': 0,
    'group': 1,
    'broadcast': 2,
    'emergency': 3
}

def message_type(name):
    """ Look up a message type from its name.

    :param str name: A key of :py:attr:`MESSAGE_TYPES`
    :returns int: The code of the type
    :raises KeyError: If ``name`` is not a valid message type name
    """
    return MESSAGE_TYPES[name]

def message_type_name(type_code):
    """ Look up a message type name from a code

    :param int type_code: A value of :py:attr:`MESSAGE_TYPES`
    :returns str: The name of the type code
    :raises KeyError: If ``type_code`` is not a value of :py:attr:`constants.MESSAGE_TYPES`
    """
    for (key, val) in MESSAGE_TYPES.items():
        if val == type_code:
            return key
    raise KeyError(type_code)


class POWERLEVELS(object):
    """ A class defining acceptable values for transmit power.
    Only the values defined in this class should be stored in
    RFSettings.
    """
    # pylint disable=no-init

    HALF_W, ONE_W, TWO_W, FIVE_W = range(4)

    @staticmethod
    def valid(value):
        """ A validator to ensure a given value is OK
        """
        return value in list(range(4))

    @staticmethod
    def name(value):
        """ Get the name of a power level from its value """
        for k in ('half_w', 'one_w', 'two_w', 'five_w'):
            if getattr(POWERLEVELS, k.upper(), None) == value:
                return k
        raise ValueError(value)

    @staticmethod
    def value(name):
        """ Get the value of a powerlevel from a string name """
        ret = getattr(POWERLEVELS, name.upper(), None)
        if not ret:
            raise KeyError(name)
        return ret

BANDS = ((142000000, 175000000), (445000000, 480000000))

MINIMUMVERSION = (0, 14, 35)
""" The minimum version this SDK will work with. Checked by :py:class:`goTenna.driver.Driver` when it connects to a device; to manually check, use :py:meth:`goTenna.constants.version_ok`"""

MAXIMUMVERSION = (256, 256, 256)
""" The maximum version this SDK will work with. Checked by :py:class:`goTenna.driver.Driver` when it connects to a device; to manually check, use :py:meth:`goTenna.constants.version_ok`"""

def version_below(version_a, version_b):
    """ Compare two version tuples.

    :param tuple(int,int,int) version_a: The first version
    :param tuple(int,int,int) version_b: The second version

    :returns bool: True if version_a < version_b; False otherwise
    """
    results = []
    for a, b in zip(version_a, version_b):
        if a < b: results.append(True)
        elif a > b: results.append(False)
        else: results.append(None)
    for res in results:
        if None is not res: return res

def version_ok(version_major, version_minor, version_bugfix):
    # pylint: disable=line-too-long
    """ Check if the version tuple (expanded into the arguments) from a firmware is OK with the stored acceptable version of the SDK.

    :param int version_major: The major version of the firmware.
    :param int version_minor: The minor version of the firmware.
    :param int version_bugfix: The bugfix version of the firmware

    :returns bool: True if the firmware and SDK versions are compatible. False otherwise.

    :note: This method is called automatically on connection by :py:class:`goTenna.driver.Driver`. Most use cases of the SDK do not require calling it directly.
    """
    # pylint: enable=line-too-long
    if version_below((version_major, version_minor, version_bugfix),
                     MINIMUMVERSION):
        return False
    elif version_below(MAXIMUMVERSION,
                       (version_major, version_minor, version_bugfix)):
        return False
    else:
        return True

MAXLENGTH = 220

class ErrorCodes(object):
    """ A class with members denoting remote error codes that
    the goTenna device may send. These are used as the ``code`` value
    of :py:class:`goTenna.constants.RemoteError`
    """

    #: No such method exists
    NOMETHOD = -1

    #: Time out executing command
    TIMEOUT = -2

    #: OS error communicating with device
    OSERROR = -3

    #: Internal Python exception
    EXCEPTION = -4

    #: Version mismatch
    VERSION = -5

    #: Key exchange failed
    KEY_EXCHANGE_FAILED = -6

    #: No error has occurred.
    NONE = 0

    #: An unknown error on the device has occurred.
    UNKNOWN = 1

    #: An error has occurred within the device's long term storage handling.
    FLASH = 2

    #: An error has occurred within the device's internal message passing.
    INVALID_DST = 3

    #: An unhandled command was sent to the device.
    UNEXPECTED_CMD = 4

    #: Invalid arguments were passed to the device
    INVALID_DATA = 5

    #: RF communication was unavailable or a message failed to send.
    UNAVAILABLE = 6

    #: Current conditions make RF communication impossible, the command should be retried.
    RETRY_LATER = 7

    #: Internal error.
    SW_ERROR = 8

    #: The intended receiver is not currently available; the message may be retried when it is expected the receiver is present.
    RECEIVER_UNAVAILABLE = 9

    #: No acknowledgement was received for the current message.
    ACK_NOT_RECEIVED = 10

    #: The device was unable to find a clear timeslice to broadcast in.
    RANDOM_BACKOFF_EXHAUSTED = 11

    #: The device was too hot and needed to wait to retry
    THERMAL_BACKOFF = 12

    #: The channel is currently busy.
    BUSY_CHANNEL = 13

    #: The built in key exchange protocol with the specified destination is complete, and messages may now be sent.
    KEY_EXCHANGE_COMPLETE = 14

    #: Key exchange with the specified destination is ongoing. Messages should be sent until the key exchange is complete.
    KEY_EXCHANGE_PARTIAL = 15

    #: The RF section of the device is not ready to operate.
    TRX_NOT_READY = 16

class TimeoutException(OSError):
    """ An exception representing a command that timed out waiting for its success message.
    """
    def __init__(self, msg, timeout):
        #: The timeout that was exceeded
        self.timeout = timeout
        if msg.endswith('\n'):
            msg = msg[:-1]
        #: A message to help identify the command
        self.msg = msg
        super(TimeoutException, self).__init__()

    def __str__(self):
        message = 'GoTenna communication timed out after {0}s. Command: {1}'\
                  .format(self.timeout, self.msg)
        return message

class RemoteError(Exception):
    """ An exception representing a remote error returned from a
    goTenna device.
    """
    def __init__(self, code, msg):
        #: :py:class:`goTenna.constants.ErrorCodes` member representing the error from the device
        self.code = code

        #: String representing a human readable error message. May be empty.
        self.msg = msg
        super(RemoteError, self).__init__()

    def __str__(self):
        return 'Remote error: {}: {}'.format(self.code,
                                             self.msg)

class NotConnectedException(Exception):
    """ An exception raised when a method is called on a not-yet-connected device.
    """
    def __init__(self):
        super(NotConnectedException, self).__init__()

    def __str__(self):
        return 'Not connected'

class LAYER8_MESSAGE_TYPES(object):
    # pylint: disable=line-too-long
    """ Message types provided for convenience.

    These are intended for use with the :py:class:`goTenna.tlv.MessageTypeTLV` TLV for packing into message payloads. By default, the :py:attr:`TEXT_ONLY` type is used when a :py:class:`goTenna.message.Payload` is built with :py:meth:`goTenna.message.Payload.text`, and :py:attr:`SET_GROUP_GID` is used when a group invitation is created with :py:meth:`goTenna.message.Payload.group_invite`.

    These message types are used only at the application layer and are provided for convenience; they are not mandatory.
    """
    # pylint: enable=line-too-long
    CUSTOM = '-1'
    TEXT_ONLY = '0'
    TEXT_AND_LOCATION = '1'
    LOCATION_ONLY = '2'
    LOCATION_REQUEST_ONLY = '3'
    LOCATION_REQUEST_AND_TEXT = '4'
    SET_GROUP_GID = '5'
    LOG_ON_TEXT_ONLY = '6'
    PING_TEXT_ONLY = '7'
    FIRMWARE_PUBLIC_KEY_RESPONSE = '8'
    USER_PUBLIC_KEY_RESPONSE = '9'
    PUBLIC_KEY_REQUEST = '10'
    FILE_TRANSFER = '11'
    NET_RELAY_REQUEST = '12'
    NET_RELAY_SUCCESS_RESPONSE = '13'
    MESH_PUBLIC_KEY_REQUEST = '14'
    MESH_PUBLIC_KEY_RESPONSE = '15'
    FREQUENCY_SLOT_AND_TEXT = '16'
    FREQUENCY_SLOT = '17'
    TEXT_AND_MAP_PERIMETER = '18'
    PERIMETER_ONLY = '19'
    TEXT_AND_MAP_ROUTE = '20'
    MAP_ROUTE_ONLY = '21'
    TEXT_AND_CIRCLE = '22'
    CIRCLE_ONLY = '23'
    TEXT_AND_SQUARE = '24'
    SQUARE_ONLY = '25'
    GATEWAY_ADVERTISEMENT = '26'
    BINARY_ONLY = '27'

    @classmethod
    def valid(cls, to_check):
        return to_check in vars(cls).values()

#: The maximum possible value for a GID
GID_MAX = 0xffffffffffff

MAX_HOPS = 6
"""The maximum number of times a message may hop on a goTenna network. """

class Bitrate(object):
    # pylint: disable=line-too-long
    """ A bitrate with a rate in bits per second and index. This class should not be instantiated directly; it is present to define the allowed bitrates in `MASKS` and to configure :py:class:`goTenna.settings.Bandwidth` objects."""
    # pylint: enable=line-too-long
    def __init__(self, index, rate, timeouts):
        self._index = index
        self._rate = rate
        self._timeouts = timeouts

    @property
    def index(self):
        """ The index of the bitrate. """
        return self._index

    @property
    def timeouts(self):
        """ The list of configured timeouts as a list of :py:class:`datetime.timedelta` """
        return self._timeouts

    @property
    def rate(self):
        """ The datarate as an int in bits/s. """
        return self._rate

    def __str__(self):
        return '{:0.2f} kbps'.format(float(self._rate)/1000)

    def __repr__(self):
        return '<goTenna.constants.Bitrate: ' + str(self) + '>'

    def __eq__(self, other):
        if not isinstance(other, Bitrate):
            return False
        return self._rate == other._rate

    def __ne__(self, other):
        return not self.__eq__(other)

class Mask(object):
    # pylint: disable=line-too-long
    """ A channel mask with frequency in Hz, index, and allowed bitrates. This class should not be instantiated directly; it is present to define the allowed masks in `:py:attr:`MASKS` and to configure :py:class:`goTenna.settings.Bandwidth` objects."""
    # pylint: enable=line-too-long
    def __init__(self, index, width, allowed_bitrates):
        self._index = index
        self._width = width
        self._allowed_bitrates = allowed_bitrates

    @property
    def index(self):
        """ The index of the mask. """
        return self._index

    @property
    def width(self):
        """ The width of the mask as an int in Hz. """
        return self._width

    @property
    def allowed_bitrates(self):
        """ The allowed bitrates for this mask. A list of `goTenna.constants.Bitrate`."""
        return [br for br in self._allowed_bitrates]

    def bitrate_allowed(self, bitrate):
        """ A query method that checks if a given bitrate is allowed at this mask.

        :param goTenna.constants.Bitrate bitrate: The bitrate to check/
        :returns Bool:
        """
        return bitrate in self.allowed_bitrates

    def __str__(self):
        return '{:0.2f} kHz'.format(float(self._width)/1000)

    def __repr__(self):
        return '<goTenna.constants.Mask: ' + str(self) + '>'

    def __eq__(self, other):
        if not isinstance(other, Mask):
            return False
        # only compare other masks and make sure that the width matches
        # and that nothing has changed the allowed bitrates
        return other.width == self.width\
            and all([e[0] == e[1]
                     for e in zip(self.allowed_bitrates,
                                  other.allowed_bitrates)])

    def __ne__(self, other):
        return not self.__eq__(other)

class Bandwidth(object):
    # pylint: disable=line-too-long
    """ A bandwidth with frequency in kHz, index, and allowed masks. This class should not be instantiated directly; it is present to define the allowed bandwidth in `:py:attr:`BANDWIDTH_KHZ` and to configure :py:class:`goTenna.settings.RFSettings` objects."""
    # pylint: enable=line-too-long
    def __init__(self, index, bandwidth, mask_idx, bitrate_idx):
        self._index = index
        self._bandwidth = bandwidth
        if not mask_idx in [m.index for m in MASKS]:
            raise ValueError("mask_idx {} out of MASK range".format(mask_idx))
        self._mask_idx = mask_idx
        if not bitrate_idx in [b.index for b in MASKS[mask_idx]._allowed_bitrates]:
            raise ValueError("bitrate_idx out of MASK[{}] range".format(mask_idx))
        self._bitrate_idx = bitrate_idx

        self.mask = MASKS[self._mask_idx]
        for br in self.mask.allowed_bitrates:
            if br.index == self._bitrate_idx:
                self.bitrate = br

    @property
    def index(self):
        """ The index of the mask. """
        return self._index

    @property
    def bandwidth(self):
        """ The bandwidth an float in kHz. """
        return self._bandwidth

    @property
    def allowed_bandwidth(self):
        """ The allowed bandwidth. A list of `goTenna.constants.Bandwidth`."""
        return [m.bandwidth for m in BANDWIDTH_KHZ]

    def __str__(self):
        return '{:0.2f} kHz'.format(float(self._bandwidth))

    def __repr__(self):
        return '<goTenna.constants.Bandwidth: ' + str(self) + '>'

    def __eq__(self, other):
        if not isinstance(other, Bandwidth):
            return False
        # only compare other masks and make sure that the width matches
        # and that nothing has changed the allowed mask and bitrate
        return other.bandwidth == self.bandwidth\
            and other._mask_idx == self._mask_idx\
            and other._bitrate_idx == self._bitrate_idx\

    def __ne__(self, other):
        return not self.__eq__(other)

MESH_BITRATE = Bitrate(0, 24000, [datetime.timedelta(seconds=3.0),
                                  datetime.timedelta(seconds=5.4),
                                  datetime.timedelta(seconds=7.8),
                                  datetime.timedelta(seconds=10.2),
                                  datetime.timedelta(seconds=12.6),
                                  datetime.timedelta(seconds=14.9)])

MASKS = [
    Mask(0, 6250, [Bitrate(1, 4800, [datetime.timedelta(seconds=11.2),
                                     datetime.timedelta(seconds=20.6),
                                     datetime.timedelta(seconds=29.8),
                                     datetime.timedelta(seconds=38.9),
                                     datetime.timedelta(seconds=47.9),
                                     datetime.timedelta(seconds=56.9)])]),
    Mask(1, 12500, [Bitrate(1, 9600, [datetime.timedelta(seconds=5.5),
                                      datetime.timedelta(seconds=10),
                                      datetime.timedelta(seconds=24.5),
                                      datetime.timedelta(seconds=18.9),
                                      datetime.timedelta(seconds=23.2),
                                      datetime.timedelta(seconds=27.6)])]),
    Mask(2, 25000, [Bitrate(1, 19200, [datetime.timedelta(seconds=2.8),
                                       datetime.timedelta(seconds=5.1),
                                       datetime.timedelta(seconds=7.3),
                                       datetime.timedelta(seconds=9.5),
                                       datetime.timedelta(seconds=11.7),
                                       datetime.timedelta(seconds=13.8)])])
]

BANDWIDTH_KHZ = [
    Bandwidth(0, 4.84, 0, 1), 
    Bandwidth(1, 7.28, 1, 1), 
    Bandwidth(2, 11.80, 2, 1) 
]

""" Valid channel masks and valid bitrates for those masks. Only values from the list are accepted when configuring a device. """

LOCATION_NAME_LENGTH_MAX = 32
""" Maximum length for a location name to send in a :py:class:`tlv.LocationNameTLV`"""

LOCATION_TYPES = {
    'invalid': '0',
    'my_pin': '1',
    'others_pin': '2',
    'my_location_pin': '3',
    'others_location_pin': '4',
    'others_old_location_pin': '5',
    'user_location_request': '6',
    'location_whitelist_auto_generated': '7',
    'location_periodic_sharing_auto_generated': '8',
    'search_pin': '9'
}
""" Types of locations we can encode. Best used with :py:meth:`location_type` and :py:meth:`location_type_name`."""

def location_type(name):
    """ Look up a location type from its name.

    :param str name: Key of :py:attr:`LOCATION_TYPES`
    :raises KeyError: If ``name`` is not a key of :py:attr:`LOCATION_TYPES`.
    """
    return LOCATION_TYPES[name]

def location_type_name(loc_type):
    """ Look up a location type name from the value.

    :param loc_type: Value of :py:attr:`LOCATION_TYPES`
    :raises KeyError: If ``loc_type`` is not in :py:attr:`LOCATION_TYPES`
    """
    for k, v in LOCATION_TYPES.items():
        if v == loc_type:
            return k
    raise KeyError(loc_type)

class SDKLevels:
    NORMAL = 0
    SUPER = 1

class OperationModes:
    FIRST_VERSION_AVAILABLE = (0, 15, 17)
    OFF = 0
    NORMAL = 1
    RELAY = 2

    @classmethod
    def name(cls, mode):
        """ The name of a member of this class

        :param mode: Member of this class
        :returns str: The name of the mode
        :raises KeyError: If the mode is not valid
        """
        return {cls.OFF: "off",
                cls.NORMAL: "normal",
                cls.RELAY: "relay"}[mode]

    @classmethod
    def mode(cls, name):
        """ The member of this class corresponding to the name.

        :param name: The name of a member of this class (with any capitalization)
        :returns int: The member of the class
        :raises KeyError: If the name is not valid
        """
        return {'off': cls.OFF,
                'normal': cls.NORMAL,
                'relay': cls.RELAY}[name.lower()]

class GEO_REGION(object):
    """ A class defining acceptable values for geo region.
    Only the values defined in this class should be stored in GeoSettings.
    """
    # pylint disable=no-init

    DICT = {
        #0 : 'REGION_UNKNOWN',
        1: 'REGION_NORTH_AMERICA',
        2: 'REGION_EUROPE',
        3: 'REGION_SOUTH_AFRICA',
        4: 'REGION_AUSTRALIA',
        5: 'REGION_NEW_ZEALAND',
        6: 'REGION_SINGAPORE',
        7: 'REGION_TAIWAN',
        8: 'REGION_JAPAN',
        9: 'REGION_SOUTH_KOREA',
        10: 'REGION_HONG_KONG',
        #11: 'REGION_INVALID'
    }

    @classmethod
    def valid(cls, value):
        """ A validator to ensure a given value is OK
        """
        return value in cls.DICT

    @classmethod
    def name(cls, value):
        """ Get the name of a power level from its value """
        if cls.valid(value):
            return cls.DICT[value]
        else:
            raise ValueError(value)

    @classmethod
    def value(cls, name):
        """ Get the value of a powerlevel from a string name """
        for region_val, region_name in cls.DICT.items():
            if region_name == name:
                ret = region_val
        if not ret:
            raise KeyError(name)
        return ret
