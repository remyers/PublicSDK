# coding: utf8
# Copyright (C) 2018 goTenna, Inc. This file is distributed as part of the
# goTenna USB SDK. See the associated license for more information.
"""
Classes and functions for interacting with the settings
"""

import uuid
import os
import copy
import struct
import six

import goTenna.constants

class GID(object):
    # pylint: disable=line-too-long
    """ A class containing the configuration of a contact. A contact has a GID, and some string representing a name. The string is used for cosmetic purposes and, if you desire, lookup.

    .. note ::
      The SDK will usually store the numeric identifier part of the GID as a :py:class:`int`. However, on python2 systems it is possible for :py:class:`int` to be too short to contain the GID (it is 6 bytes, and python2 only guarantees 32 bites in :py:class:`int`). If the SDK detects this is the case (by using :py:meth:`sys.max_int`), GID numeric IDs will be stored as :py:class:`long` and must be specified as :py:class:`long`. If it is not the case, any arguments passed as :py:class:`long` will be converted to :py:class:`int` internally.


    """
    # pylint: enable=line-too-long
    PRIVATE = 0
    GROUP = 1
    BROADCAST = 2
    EMERGENCY = 3

    @classmethod
    def broadcast(cls):
        # pylint: disable=line-too-long
        """ Generate the broadcast GID.

        This GID is used for all broadcast-class messages. It should not be used for identity.
        """
        # pylint: enable=line-too-long
        return cls(1111111111, goTenna.settings.GID.BROADCAST)

    @classmethod
    def emergency(cls):
        # pylint: disable=line-too-long
        """ Generate the emergency GID.

        This GID is used for all emergency-class messages. It should not be used for identity.
        """
        # pylint: enable=line-too-long
        return cls(9999999999, goTenna.settings.GID.EMERGENCY)

    @classmethod
    def gateway(cls):
        # pylint: disable=line-too-long
        """ Generate the gateway GID.

        This GID is used as the private GID for all gateway devices. It should not be used for anything else.
        """
        # pylint: enable=line-too-long
        return cls(5555555555, goTenna.settings.GID.PRIVATE)

    @classmethod
    def generate(cls, gid_type):
        # pylint: disable=line-too-long
        """ Generate a new GID that should be unique (through use of :py:mod:`uuid`)

        :param gid_type: A GID type, either :py:attr:`PRIVATE` or :py:attr:`GROUP` (the broadcast messages have fixed GIDs and thus cannot be generated).
        :raises exception.KeyError: if ``gid_type`` is invalid.
        :return GID: The newly-created GID.
        """
        # pylint: enable=line-too-long
        if gid_type not in [cls.PRIVATE, cls.GROUP]:
            if gid_type in [cls.BROADCAST, cls.EMERGENCY]:
                raise KeyError('{0} GIDs should not be generated, use goTenna.settings.GID.{0}()'
                               .format(cls.type_name(gid_type)))
            else:
                raise KeyError('gid_type {} is not valid'.format(gid_type))
        # This should be random since this uses uuid4() and not uuid1()
        # Also force the correct formatting
        to_return = int(str(uuid.uuid4().int)[-13:]) + 90000000000000

        return cls(to_return, gid_type)

    @staticmethod
    def type_name(gid_type):
        # pylint: disable=line-too-long
        """ Get a human-readable name for a GID type.

        :param int gid_type: One of :py:attr:`PRIVATE`, :py:attr:`GROUP`, or :py:attr:`BROADCAST`.

        :returns str: The name of the type.

        :raises exception.KeyError: If ``gid_type`` is not one of the above.
        """
        # pylint: enable=line-too-long
        if gid_type == GID.PRIVATE:
            return 'private'
        if gid_type == GID.GROUP:
            return 'group'
        if gid_type == GID.BROADCAST:
            return 'broadcast'
        if gid_type == GID.EMERGENCY:
            return 'emergency'
        raise KeyError('gid_type {} is not valid'.format(gid_type))

    @staticmethod
    def type_code(type_name):
        # pylint: disable=line-too-long
        """ Get a gid_type from a human readable name (i.e. as returned from :py:meth:`type_name`)

        :returns int: The GID type, suitable for passing to :py:meth:`__init__`.

        :raises exception.KeyError: If ``type_name`` is not one of those returned by :py:meth:`type_name`.
        """
        # pylint: enable=line-too-long
        if type_name == 'private':
            return GID.PRIVATE
        if type_name == 'group':
            return GID.GROUP
        if type_name == 'broadcast':
            return GID.BROADCAST
        if type_name == 'emergency':
            return GID.EMERGENCY
        raise KeyError('no gid type named {}'.format(type_name))

    def __init__(self, gid_val, gid_type, via_gateway=None):
        # pylint: disable=line-too-long
        """ Build an instance of :py:class:`GID`.

        :param gid_val: The GID. This should be an integral type in [0, :py:attr:`goTenna.constants.GID_MAX`]. On python2, :py:class:`long` is always accepted and :py:class:`int` is accepted if :py:meth:`sys.maxint` is > 0xffffffffffff (6 bytes unsigned). The value is stored internally as :py:class:`int` if possible (same criterion as accepting an :py:class:`int` as input) and :py:class:`long` otherwise. On python 3, only :py:class:`int` is accepted and used as the backing store.
        :param int gid_type: The type of the GID. This should be one of :py:attr:`PRIVATE`, :py:attr:`GROUP`, :py:attr:`BROADCAST`, or :py:attr:`EMERGENCY`
        :param via_gateway: the GID of the gateway this ID is accessible through, if it is remote; otherwise ``None``. If a gateway is specified, it should be the value returned by :py:meth:`goTenna.settings.GID.gateway()`.
        :type via_gateway: goTenna.settings.GID or None

        :raises exception.TypeError: If ``gid_val`` is not an integral type.
        :raises exception.ValueError: If ``gid_val`` is outside valid bounds.
        :raises exception.KeyError: If ``gid_type`` is not valid.
        """
        # pylint: enable=line-too-long
        if not isinstance(gid_val, six.integer_types):
            raise TypeError("gid_val must be integral, gid {} is type {}"
                            .format(gid_val, type(gid_val)))
        if gid_val > goTenna.constants.GID_MAX:
            raise ValueError("gid_val must be < {}, not {}"
                             .format(goTenna.constants.GID_MAX, gid_val))
        if gid_type not in (GID.PRIVATE, GID.GROUP, GID.BROADCAST, GID.EMERGENCY):
            raise KeyError('gid_type {} is invalid'.format(gid_type))
        if gid_type in (GID.PRIVATE, GID.GROUP)\
           and gid_val in (self.broadcast().gid_val, self.emergency().gid_val):
            raise ValueError("Private and group GIDs must not have special value {}"
                             .format(self.broadcast().gid_val))
        if None is not via_gateway:
            if via_gateway != GID.gateway():
                raise ValueError("Invalid gateway {}".format(via_gateway))
            if gid_type != GID.PRIVATE:
                raise ValueError("Only private GIDs can be accessed via a gateway")
        self._via_gateway = via_gateway
        self._gid_val = goTenna.util.convert_gid(gid_val)
        self._gid_type = gid_type

    @property
    def gid_type(self):
        """ The type of the GID.

        :returns int: :py:attr:`GID.PRIVATE`, :py:attr:`GID.GROUP`, or :py:attr:`GID.BROADCAST`
        """
        return self._gid_type

    @property
    def gid_val(self):
        """ The numeric value of the GID.

        :returns int: The GID.
        """
        return self._gid_val

    @property
    def via_gateway(self):
        """ The gateway by which this GID is accessible, or ``None`` if it is local.

        :returns GID or None: The gateway
        """
        return self._via_gateway

    def __repr__(self):
        return '<GID: {} {}{}>'.format(GID.type_name(self.gid_type), self.gid_val,
                                       ' via gateway={}'.format(self.via_gateway)
                                       if self.via_gateway
                                       else '')

    def to_dict(self):
        """ Create a dict representing this class (e.g. for serialization)
        """
        return {'gid_val': self.gid_val,
                'gid_type': self.gid_type,
                'via_gateway': self.via_gateway.to_dict() if self.via_gateway
                               else None}

    def __eq__(self, other):
        return isinstance(other, GID)\
            and other.gid_val == self.gid_val\
            and other.gid_type == self.gid_type\
            and other.via_gateway == self.via_gateway

    def __hash__(self):
        return hash(self.gid_val) + (hash(self.gid_type)*(pow(10, 15)))

    def __ne__(self, other):
        return not self.__eq__(other)

class Group(object):
    # pylint: disable=line-too-long
    """ A named tuple containing the configuration of a group. A group

    - Is associated with a specific group GID, which identifies the group
    - Is associated with a specific private GID, which is the local owner
    - Contains the membership index of that owner GID
    - Contains a list of other GIDs and membership index making up the rest of the group membership

    Owner, member, and group GIDs are stored as :py:attr:`GID`
    """
    # pylint: enable=line-too-long

    MAX_MEMBERS = 11

    @classmethod
    def from_dict(cls, settings_dict):
        """ Factory for building a Group object from a settings dict.

        :param dict settings_dict: A dictionary of settings to scan.
        """
        return cls(GID(**settings_dict['gid']),
                   [GID(**m) for m in settings_dict['members']],
                   settings_dict['shared_secret'])

    @classmethod
    def create_new(cls, members):
        # pylint: disable=line-too-long
        """ Factory for creating a new Group object that does not yet exist on the network.

        :param list[goTenna.settings.GID] members: The members of the group to create. This should include the owner of the group at index 0.

        To create a new Group from a notification, use :py:meth:`from_invite`.
        """
        # pylint: enable=line-too-long
        return cls(GID.generate(GID.GROUP),
                   members,
                   os.urandom(32))

    def __init__(self, group_gid, members, shared_secret):
        # pylint: disable=line-too-long
        """ Build a Group object.

        :param GID group_gid: The GID/name that identifies the group
        :param list[GID] members: Members of the group, including the local user. The member index will be generated from an individual's location in the list.
        :param shared_secret: The cryptographic shared secret. It should be a byteslike of 32 bytes precisely.
        :type shared_secret: None or bytearray

        This method will generate group indices for all members. The local user should be specified along with the rest of the group members.

        There must be at least two members.

        :note: This constructor should rarely be used directly; instead, use one of the factory methods :py:meth:`settings.Group.create_new`, :py:meth:`settings.Group.from_dict`, or :py:meth:`settings.Group.from_invite`

        :note: Groups are considered to be immutable once created. Their members are accessed through read-only accessors. To change the membership of the group create, a new group and stop using the old one.

        :raises exception.ValueError: If there are fewer than 3 or more than :py:attr:`MAX_MEMBERS` members, or if the shared secret is invalid
        :raises exception.TypeError: If the type of one of the arguments is incorrect.
        """
        # pylint: enable=line-too-long
        if not isinstance(group_gid, goTenna.settings.GID):
            raise TypeError('group_gid must be GID, is {}'
                            .format(type(group_gid)))
        if group_gid.gid_type != goTenna.settings.GID.GROUP:
            raise ValueError('group_gid must have type GROUP, is {}'
                             .format(group_gid))
        self._gid = group_gid
        if len(members) > self.MAX_MEMBERS:
            raise ValueError("there must be fewer than {} members"
                             .format(self.MAX_MEMBERS))
        if not members:
            raise ValueError("there must be at least 0 members in a group")
        for idx, m in enumerate(members):
            if not isinstance(m, goTenna.settings.GID):
                raise TypeError('members must be a list of gids, elem {} is {}'
                                .format(idx, type(m)))
            if m.gid_type != goTenna.settings.GID.PRIVATE:
                raise ValueError('members must all be private gids, elem {} is {}'
                                 .format(idx, m))
            if m.via_gateway:
                raise ValueError("groups may not contain GIDs only accessible via gateway")
        self._members = members
        if None is shared_secret:
            shared_secret = os.urandom(32)
        try:
            struct.pack('1s', shared_secret[:1])
        except Exception:
            raise TypeError("shared_secret should be byteslike, is {}"
                            .format(type(shared_secret)))
        if len(shared_secret) != 32:
            raise ValueError("shared_secret should be len 32, is {}"\
                             .format(len(shared_secret)))
        self._shared_secret = shared_secret

    def __eq__(self, other):
        return isinstance(other, Group)\
            and self.members == other.members\
            and self.shared_secret == other.shared_secret\
            and self.gid == other.gid

    def __ne__(self, other):
        return not self.__eq__(other)

    def __repr__(self):
        return '<{}: gid={}, members={}, shared_secret={}>'\
            .format(self.__class__.__name__,
                    self.gid, self.members,
                    goTenna.util.display_bytestring(self.shared_secret))

    @property
    def members(self):
        # pylint: disable=line-too-long
        """ Read-only accessor for group members.

        :note: Returns a copy of the member list. Modifying the member list returned by this property will have no effect on the member list stored in the group.
        """
        # pylint: enable=line-too-long
        return copy.deepcopy(self._members)

    @property
    def shared_secret(self):
        # pylint: disable=line-too-long
        """ Read-only accessor for the group shared secret.

        :note: Returns a copy of the shared secret. Modifying the shared secret returned by this property will have no effect on the secret stored in the group.
        """
        # pylint: enable=line-too-long
        return copy.deepcopy(self._shared_secret)

    @property
    def gid(self):
        # pylint: disable=line-too-long
        """ Read-only accessor for the group GID.

        :note: Returns a copy of the GID. Modifying the GID returned by this property will have no effect on the GID stored in the group.
        """
        # pylint: enable=line-too-long
        return copy.deepcopy(self._gid)

    def to_dict(self):
        """ Return the settings that need to be stored in a dict. """
        return {'gid': self._gid.to_dict(),
                'members': [m.to_dict() for m in self._members],
                'shared_secret': self._shared_secret}

class RFSettings(object):
    # pylint: disable=line-too-long
    """ A class containing RF settings.

    This defines control and data frequencies, transmission power, bandwidth, and datarate.

    RFSettings objects must include at least one control frequency and at least one data frequency. All frequencies must be within the bands supported by goTenna.

    The power and bandwidth values must be valid supported values.

    It defines a to_dict() method for easy serialization.
    """
    # pylint: enable=line-too-long

    def __repr__(self):
        to_ret = '<{}:'.format(self.__class__.__name__)
        if self.valid:
            to_ret += 'valid, '
        else:
            to_ret += 'freqs {}, power {}, bandwidth {}, '\
                      .format('valid' if self.freqs_valid else 'invalid',
                              'valid' if goTenna.constants.POWERLEVELS.valid(self.power_enum) else 'invalid',
                              'valid' if self.bandwidth_valid else 'invalid')
        to_ret += 'control_freqs={}, data_freqs={}, power={}, bandwidth={}>'\
                                  .format(self.control_freqs, self.data_freqs,
                                          self.power_enum, self.bandwidth)
        return to_ret

    def __eq__(self, other):
        return isinstance(other, RFSettings)\
            and self.control_freqs == other.control_freqs\
            and self.data_freqs == other.data_freqs\
            and self.power_enum == other.power_enum\
            and self.bandwidth == other.bandwidth

    def __ne__(self, other):
        return not self.__eq__(other)

    def __init__(self, data_freqs=None, power_enum=None,
                 control_freqs=None, bandwidth=None):
        # pylint: disable=line-too-long
        """
        Build an RFSettings object.

        Though all the parameters in the constructor are optional, this is to allow early instantiation and late configuration of the object. An RFSettings object cannot be used to configure a device until it itself is fully configured. You can check if the object is fully configured by using the `RFSettings.valid` property.

        :param list[int] data_freqs: An iterable containing frequencies of the data channels, in Hz

        :param goTenna.constants.POWERLEVELS power_enum: The transmission power. One of the values defined in goTenna.constants.POWERLEVELS

        :param list[int] control_freqs: The frequencies to use for control channels.

        :param goTenna.constants.Bandwidth bandwidth: The bandwidth for the channels specified here. This must be a member of :py:attr:`goTenna.constants.BANDWIDTH_KHZ`.

        The settings here implicitly control the frequency-hopping behavior of the device. The device will move through the list of configured frequencies in the order specified by the lists owned by this object. To change the order of frequency hopping, change the order of the frequencies in the list.

        There must be a minimum of one data frequency and one control frequency specified in this object. However, these need not be unique. To configure the device to only ever use a single frequency, specify the same frequency as the single control and data channel.
        """
        # pylint: enable=line-too-long
        if None is not power_enum:
            if not goTenna.constants.POWERLEVELS.valid(power_enum):
                raise KeyError("power_enum must be a member of goTenna.constants.POWERLEVELS")
        if None is control_freqs:
            self.control_freqs = []
        elif not isinstance(control_freqs, list)\
             or not all(list(map(lambda arg: isinstance(arg, int),
                                 control_freqs))):
            raise TypeError('control_freqs must be a list of integer frequencies')
        else:
            self.control_freqs = control_freqs
        if None is data_freqs:
            data_freqs = []
        elif not isinstance(data_freqs, list)\
             or not all(list(map(lambda arg: isinstance(arg, int),
                                 data_freqs))):
            raise TypeError('data_freqs must be a list of integer frequencies')
        if None is not bandwidth and bandwidth not in goTenna.constants.BANDWIDTH_KHZ:
                raise ValueError("bandwidth {} is not in goTenna.constants.BANDWIDTH_KHZ"
                                 .format(bandwidth))
        self.bandwidth = bandwidth
        self.data_freqs = data_freqs
        self.power_enum = power_enum

    def to_dict(self):
        """ Return the settings that need to be stored in a dict. """
        if not self.bandwidth:
            bandwidth = None
        else:
            bandwidth = self.bandwidth.bandwidth
        return {'control_freqs': self.control_freqs,
                'data_freqs': self.data_freqs,
                'power_enum': self.power_enum,
                'bandwidth': bandwidth}

    @staticmethod
    def from_dict(settings_dict):
        """ Helper for building an RFSettings class from a dict of settings

        :param dict settings_dict: The dict to scan
        """
        bandwidth = settings_dict.get('bandwidth', None)
        if None is not bandwidth:
            for m in goTenna.constants.BANDWIDTH_KHZ:
                if m.bandwidth == bandwidth:
                    bandwidth = m
                    break
            else:
                raise ValueError("bandwidth {} is not valid".format(bandwidth))
        return RFSettings(control_freqs=settings_dict['control_freqs'],
                          data_freqs=settings_dict['data_freqs'],
                          power_enum=settings_dict['power_enum'],
                          bandwidth=bandwidth)

    @property
    def valid(self):
        """ Determine whether the RFSettings object contains valid settings.
        """
        return goTenna.constants.POWERLEVELS.valid(self.power_enum)\
            and self.freqs_valid\
            and self.bandwidth_valid

    @property
    def bandwidth_valid(self):
        # pylint: disable=line-too-long
        """ Determine whether the bandwidth of the object is valid.

        This is a subset of the validation performed by :py:meth:`goTenna.settings.RFSettings.valid` and is used by that method.
        """
        # pylint: enable=line-too-long
        return self.bandwidth is not None\
            and self.bandwidth in goTenna.constants.BANDWIDTH_KHZ\

    @property
    def freqs_valid(self):
        # pylint: disable=line-too-long
        """ Determine whether the frequency content of the object is valid.

        This is a subset of the validation performed by :py:meth:`goTenna.settings.RFSettings.valid` and is used by that method.
        """
        # pylint: enable=line-too-long
        return self.control_freqs and self.data_freqs\
            and all(list(map(RFSettings.validate_freq, self.control_freqs)))\
            and all(list(map(RFSettings.validate_freq, self.data_freqs)))

    @staticmethod
    def validate_freq(freq):
        """ Validate whether a given frequency is in an acceptable band.

        :param int freq: The frequency to check.
        :return bool: True if the frequency is acceptable.

        Acceptable bands are defined by :py:data:`goTenna.constants.BAND`
        """
        for band in goTenna.constants.BANDS:
            if freq >= band[0] and freq < band[1]:
                return True
        return False

class GeoSettings(object):
    # pylint: disable=line-too-long
    """ A class containing Geo settings.

    This defines the operating region.
    The region value must be valid supported value.

    It defines a to_dict() method for easy serialization.
    """
    # pylint: enable=line-too-long

    def __repr__(self):
        to_ret = '<{}:'.format(self.__class__.__name__)
        if self.valid:
            to_ret += 'valid, '
        else:
            to_ret += 'region {}'.format('valid' if self.region_valid else 'invalid')
        to_ret += 'region={}>'.format(self.region)
        return to_ret

    def __eq__(self, other):
        return isinstance(other, GeoSettings)\
            and self.region == other.region

    def __ne__(self, other):
        return not self.__eq__(other)

    def __init__(self, region=None):
        # pylint: disable=line-too-long
        """
        Build an GeoSettings object.

        Though all the parameters in the constructor are optional, this is to allow early instantiation and late configuration of the object. An GeoSettings object cannot be used to configure a device until it itself is fully configured. You can check if the object is fully configured by using the `GeoSettings.valid` property.

        :param goTenna.constants.GEO_REGION region: The geo region. One of the values defined in goTenna.constants.GEO_REGION
        """
        # pylint: enable=line-too-long
        self.region_valid = False
        if None is not region:
            if goTenna.constants.GEO_REGION.valid(region):
                self.region = region
                self.region_valid = True
            else:
                raise KeyError("region must be a member of goTenna.constants.GEO_REGION")

    def to_dict(self):
        """ Return the settings that need to be stored in a dict. """
        if not self.region:
            region = None
        else:
            region = self.region

        return {'region': region}

    @staticmethod
    def from_dict(settings_dict):
        """ Helper for building a GeoSettings class from a dict of settings

        :param dict settings_dict: The dict to scan
        """
        region = settings_dict.get('region', None)
        if None is region:
            raise ValueError("region not specified")
        if not goTenna.constants.GEO_REGION.valid(region):
            raise KeyError("region value {} invalid, must be a member of"\
                           " goTenna.constants.GEO_REGION"\
                           .format(region))

        return GeoSettings(region=region)

    @property
    def valid(self):
        """ Determine whether the GeoSettings object contains valid settings.
        """
        return goTenna.constants.GEO_REGION.valid(self.region)


class SpiSettings(object):
    # pylint: disable=line-too-long
    """ A class containing SPI settings.

    This defines the SPI settings, defaulted to allow a connection
    with a Rasp PI on /dev/spidev0.0

    It defines a to_dict() method for easy serialization.
    """
    # pylint: enable=line-too-long

    def __repr__(self):
        to_ret = '<{}:'.format(self.__class__.__name__)
        if self.valid:
            to_ret += 'valid, '
        to_ret += 'bus_no={}, chip_no={}, request_gpio={}, ready_gpio={}>'.format(self.bus_no, self.chip_no, self.request_gpio, self.ready_gpio)
        return to_ret

    def __eq__(self, other):
        return isinstance(other, SpiSettings)\
            and self.bus_no == other.bus_no\
            and self.chip_no == other.chip_no\
            and self.request_gpio == other.request_gpio\
            and self.ready_gpio == other.ready_gpio

    def __ne__(self, other):
        return not self.__eq__(other)

    def __init__(self, bus_no=0, chip_no=0, request_gpio=22, ready_gpio=27):
        # pylint: disable=line-too-long
        """
        Build an SpiSettings object.

        Though all the parameters in the constructor are optional, this is to allow early instantiation and late configuration of the object. An GeoSettings object cannot be used to configure a device until it itself is fully configured. You can check if the object is fully configured by using the `SpiSettings.valid` property.

        """
        # pylint: enable=line-too-long
        self.bus_no = bus_no
        self.chip_no = chip_no
        self.request_gpio = request_gpio
        self.ready_gpio = ready_gpio
        self.spi_valid = True

    def to_dict(self):
        """ Return the settings that need to be stored in a dict. """
        return {'bus_no': self.bus_no,
                'chip_no': self.chip_no,
                'request_gpio': self.request_gpio,
                'ready_gpio': self.ready_gpio}

    @staticmethod
    def from_dict(settings_dict):
        """ Helper for building a SpiSettings class from a dict of settings

        :param dict settings_dict: The dict to scan
        """
        bus_no = settings_dict.get('bus_no', None)
        chip_no = settings_dict.get('chip_no', None)
        request_gpio = settings_dict.get('request_gpio', None)
        ready_gpio = settings_dict.get('ready_gpio', None)
        if None is bus_no or None is chip_no or None is request_gpio or None is ready_gpio:
            raise ValueError("spi not specified")

        return SpiSettings(bus_no, chip_no, request_gpio, ready_gpio)

    @property
    def valid(self):
        """ Determine whether the SpiSettings object contains valid settings.
        """
        return True


class GoTennaSettings(object):
    # pylint: disable=line-too-long
    """ A class containing goTenna settings such as the RFSettings 
    and GeoSettings.
    """
    # pylint: enable=line-too-long

    def __init__(self, rf_settings=None, geo_settings=None):
        # pylint: disable=line-too-long
        """
        Build an GoTennaSettings object.

        """
        # pylint: enable=line-too-long
        self.rf_settings = rf_settings
        self.geo_settings = geo_settings

    @property
    def rf_settings_valid(self):
        """ Determine whether the RFSettings object contains valid settings.
        """
        if None is not self.rf_settings:
            if isinstance(self.rf_settings, goTenna.settings.RFSettings):
                return self.rf_settings.valid
        return False

    @property
    def geo_settings_valid(self):
        """ Determine whether the GeoSettings object contains valid settings.
        """
        if None is not self.geo_settings:
            if isinstance(self.geo_settings, goTenna.settings.GeoSettings):
                return self.geo_settings.valid
        return False


