# coding: utf8
# Copyright (C) 2018 goTenna, Inc. This file is distributed as part of the
# goTenna USB SDK. See the associated license for more information.
""" Classes and functions for the goTenna storage layer.

This module defines both the high level storage interface to which storage objects given to :py:class:`goTenna.driver.Driver` must adhere and a concrete implementation that stores data in a local file encrypted with the SDK token.
"""
import json
import os
import base64

import six
from cryptography import fernet
from cryptography.hazmat.primitives.kdf import pbkdf2
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
import goTenna

class StorageInterface(object):
    # pylint: disable=line-too-long
    """ A class defining how a goTenna SDK compliant storage class should work.

    The primary job of the storage interface is to store the known public keys for other private GIDs, and the members and shared secrets for known groups. Each of these are only valid for a specific private GID with which the SDK is configured.

    Implementers of this interface must provide

    - the backend methods :py:meth:`load`, :py:meth:`store`, and :py:meth:`remove_records` which provide the storage backend. :py:meth:`load` and :py:meth:`store` load and store data in nonvolatile storage respectively. When these methods are called, they must read from the nonvolatile storage and write to it, but the implementation can read and write to the backend at every times if desired. :py:meth:`remove_records` deletes all records for the GID and can be used to erase key material for a GID that is no longer used.
    - the frontend properties :py:attr:`groups`, :py:attr:`link_pubkeys`, and :py:attr:`local_key` with setter, which provide the interface for the rest of the SDK to access data in the same structured way no matter the backend data structures.

    """
    # pylint: enable=line-too-long

    def remove_records(self, gid):
        # pylint: disable=line-too-long
        """ Remove the records for the given private GID.

        This method can be used to delete the stored private key for the GID and any public keys for links to other private GIDs and groups that the private key is in.

        This method should not be called on a GID that is currently active.
        """
        # pylint: enable=line-too-long
        raise NotImplementedError()

    def load(self, gid):
        # pylint: disable=line-too-long
        """ Load the data stored for the given private GID.

        When this function is called, it should always read from the nonvolatile storage; however, it does not need to be the only place the implementation reads from the nonvolatile storage.

        :param goTenna.settings.GID gid: The private GID to load the configuration for.
        :returns bytes: The encrypted data
        """
        raise NotImplementedError()

    def store(self):
        # pylint: disable=line-too-long
        """ Update the stored data for the GID specified in :py:meth:`load`

        By the time this function returns, the settings should be stored persistently in case the application terminates. It does not need to be the only place where the backend writes to nonvolatile storage.
        """
        raise NotImplementedError()

    @property
    def encryption_counters(self):
        # pylint: disable=line-too-long
        """ A property for the stored per-destination cryptographic encryption_counters.

        The :py:class:`StorageInterface` stores a history of the encryption_counters used for each destination GID, whether group or private. This is used to reject duplicate messages and ensure that sent messages are not rejected as duplicates. The storage of these encryption_counters should preserve the order in which they were added.

        :return dict[gid]->list[int]: A mapping between a destination GID and the encryption_counter history for it.
        """
        raise NotImplementedError()

    @property
    def groups(self):
        # pylint: disable=line-too-long
        """ A property for the stored groups.

        The :py:class:`StorageInterface` stores data representing groups that the local GID is part of.

        :returns dict: A dict mapping group GIDs (as :py:class:`goTenna.settings.GID`) to the :py:class:`goTenna.settings.Group` object for that group. """
        raise NotImplementedError()

    @property
    def link_pubkeys(self):
        # pylint: disable=line-too-long
        """ A property for the stored public keys for other devices.

        When encryption is enabled, the SDK automatically exchanges public keys with any device that is sent a private message and stores them in this object.

        :returns dict: A dict mapping other private GIDs (as :py:class:`goTenna.settings.GID`) to the public key for that GID (as ``byteslike``)."""
        raise NotImplementedError()

    @property
    def local_key(self):
        # pylint: disable=line-too-long
        """ :returns byteslike: The encoded private key for the GID this object was initialized with. """
        raise NotImplementedError()

    @local_key.setter
    def set_local_key(self, key):
        """ Set the encoded private key for the GID this object was initialized with. """
        raise NotImplementedError()

class EncryptedFileStorage(StorageInterface):
    # pylint: disable=line-too-long
    """ A storage implementation that stores data in a file, encrypted with the current SDK key.
    """
    # pylint: enable=line-too-long

    _SALT = six.b('c_vWbsMCRMFIv4E_MMF3lQm96J6_L9mmjmSgLmSXC9Y=')
    _BACKEND = default_backend()

    def __init__(self, sdk_key, filename='.goTenna', work_factor=100000):
        # pylint: disable=line-too-long
        """
        Construct a :py:class:`EncryptedFileStorage`.

        The file storage is encrypted, since it stores key material for any private GID used with the SDK.

        :param str sdk_key: The SDK key being used with this SDK instance. The key is used as an input to the encryption used in the file storage, ensuring that other users of the goTenna SDK cannot read data encrypted with a different key.
        :param str filename: The file to use for storage. By default this is a dotfile in the directory in which Python is invoked and loads the SDK.
        :param int work_factor: The work factor to use for the key derivation function. Higher values make the encryption of the config more resistant to bruteforcing, but may take a long time on non-powerful systems.

        :raises ValueError: If the specified file exists (or can be created) but cannot be decrypted, either because it does not contain encrypted data or because it was encrypted with a different SDK key.
        :raises OSError: If the specified file does not exist and cannot be created (for instance because the specified directory does not exist)
        """
        # pylint: enable=line-too-long
        kdf = pbkdf2.PBKDF2HMAC(algorithm=hashes.SHA256(),
                                length=32,
                                salt=self._SALT,
                                iterations=work_factor,
                                backend=self._BACKEND)
        sdk_key_bytes = goTenna.util.ensure_bytes(sdk_key)
        self._key = base64.urlsafe_b64encode(kdf.derive(sdk_key_bytes))
        self._filename = filename
        self._ensure_file(filename)
        self._cache = open(filename, 'rb').read()
        self._crypt = fernet.Fernet(self._key)
        self._cache = self._load_and_decrypt(self._crypt, filename)
        self._correct_types = {}
        self._gid = None

    @staticmethod
    def _ensure_file(filename):
        if not os.path.exists(filename):
            try:
                open(filename, 'wb').close()
            except IOError as ioe:
                raise OSError("{} cannot be created {}"
                              .format(filename,
                                      ':'.join([str(arg) for arg in ioe.args])))

    @staticmethod
    def _load_and_decrypt(crypt, filename):
        contents = open(filename, 'rb').read()
        if not contents:
            return {}
        try:
            decrypted = crypt.decrypt(contents)
        except fernet.InvalidToken:
            raise ValueError("{} could not be decrypted".format(filename))
        ret = json.loads(goTenna.util.b2s(decrypted))
        return ret

    @staticmethod
    def _encrypt_and_write(crypt, filename, data):
        contents = goTenna.util.s2b(json.dumps(data))
        crypted = crypt.encrypt(contents)
        with open(filename, 'wb') as f:
            f.write(crypted)
            f.flush()

    @staticmethod
    def _deserialize(local_gid, serialized_dict):
        """ Deserialize a hierarchical dict storing serializable data into a dict holding the correct types"""
        to_return = {
            # The key stays bytes
            'local_key': serialized_dict.get('local_key', six.b('')),
            # We’ll store links as maps from private GID to pubkey
            'links': {},
            # We’ll store groups as maps from group GID to group object
            'groups': {},
            # Encryption_Counters are a map from GID to list of ints
            'encryption_counters': {},
        }

        for k, v in serialized_dict.get('links', {}).items():
            # Generate a GID object from the serialized key and store the value
            to_return['links'][goTenna.settings.GID(int(k),
                                                    goTenna.settings.GID.PRIVATE)]\
                                                    = v
        for obj in serialized_dict.get('groups', []):
            # Generate a GID and group from the serialized values
            group_gid = goTenna.settings.GID(obj['gid'],
                                             goTenna.settings.GID.GROUP)
            group_members = [local_gid] + [
                goTenna.settings.GID(member, goTenna.settings.GID.PRIVATE)
                for member in obj['members']
            ]
            secret\
                = base64.urlsafe_b64decode(goTenna.util.s2b(obj['shared_secret']))
            group = goTenna.settings.Group(group_gid, group_members, secret)
            # Store the group with its own GID as key
            to_return['groups'][group.gid] = group

        for gidhash, lizt in serialized_dict.get('encryption_counters', {}).items():
            gid_val = int(gidhash) // 4
            gid_type = int(gidhash) - (gid_val * 4)
            gid = goTenna.settings.GID(gid_val, gid_type)
            to_return['encryption_counters'][gid] = lizt

        return to_return

    @staticmethod
    def _serialize(deserialized_dict):
        """ Transform a hierarchical dict containing goTenna types into a dict of the same structure holding serializable types"""
        to_return = {'local_key': deserialized_dict.get('local_key', ''),
                     'links': {},
                     'groups': [],
                     'encryption_counters': {}}
        for k, v in deserialized_dict.get('links', {}).items():
            to_return['links'][k.gid_val] = v
        for _, v in deserialized_dict.get('groups', {}).items():
            to_return['groups'].append({
                'gid': v.gid.gid_val,
                'members': [m.gid_val for m in v.members[1:]],
                'shared_secret': goTenna.util.b2s(base64.urlsafe_b64encode(v.shared_secret))
            })
        for gid, lizt in deserialized_dict.get('encryption_counters', {}).items():
            to_return['encryption_counters'][gid.gid_val*4 + gid.gid_type] = lizt
        return to_return

    def remove_records(self, gid):
        if not isinstance(gid, goTenna.settings.GID):
            raise TypeError("gid must be a goTenna.settings.GID but is a {}"
                            .format(type(gid)))
        self._cache = self._load_and_decrypt(self._crypt, self._filename)
        self._cache.pop(str(gid.gid_val))
        self._encrypt_and_write(self._crypt, self._filename, self._cache)

    def load(self, gid):
        if not isinstance(gid, goTenna.settings.GID):
            raise TypeError("gid must be a goTenna.settings.GID but is a {}"
                            .format(type(gid)))
        self._cache = self._load_and_decrypt(self._crypt, self._filename)
        self._gid = gid
        self._correct_types = self._deserialize(gid,
                                                self._cache.get(str(gid.gid_val), {}))
        return self._correct_types

    def store(self):
        if not self._gid:
            raise ValueError("Must load before you can store")
        self._cache[str(self._gid.gid_val)] = self._serialize(self._correct_types)
        self._encrypt_and_write(self._crypt, self._filename, self._cache)

    @property
    def groups(self):
        return self._correct_types['groups']

    @property
    def encryption_counters(self):
        return self._correct_types['encryption_counters']

    @property
    def link_pubkeys(self):
        return self._correct_types['links']

    def _get_local_key(self):
        return self._correct_types['local_key']

    def _set_local_key(self, new_key):
        if not isinstance(new_key, goTenna.util.StrType):
            raise TypeError("key must be byteslike, is {}".format(type(new_key)))
        self._correct_types['local_key'] = new_key

    local_key = property(_get_local_key, _set_local_key)
