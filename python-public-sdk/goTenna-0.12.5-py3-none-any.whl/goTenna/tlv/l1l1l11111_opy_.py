# coding: utf8
import sys
ll_opy_ = sys.version_info [0] == 2
l1llll_opy_ = 2048
l11l1_opy_ = 7
def l1l11l_opy_ (l1l111_opy_):
    global l1_opy_
    l11ll1_opy_ = ord (l1l111_opy_ [-1])
    l1l1l1_opy_ = l1l111_opy_ [:-1]
    l11ll_opy_ = l11ll1_opy_ % len (l1l1l1_opy_)
    l1ll_opy_ = l1l1l1_opy_ [:l11ll_opy_] + l1l1l1_opy_ [l11ll_opy_:]
    if ll_opy_:
        l1l11_opy_ = unicode () .join ([unichr (ord (char) - l1llll_opy_ - (l1l1_opy_ + l11ll1_opy_) % l11l1_opy_) for l1l1_opy_, char in enumerate (l1ll_opy_)])
    else:
        l1l11_opy_ = str () .join ([chr (ord (char) - l1llll_opy_ - (l1l1_opy_ + l11ll1_opy_) % l11l1_opy_) for l1l1_opy_, char in enumerate (l1ll_opy_)])
    return eval (l1l11_opy_)
# Copyright (C) 2018 goTenna, Inc. This file is distributed as part of the
# goTenna USB SDK. See the associated license for more information.
# pylint: disable=line-too-long
l1l11l_opy_ (u"ࠧࠨࠢࠡࡖ࡫ࡩ࡚ࠥࡌࡗࡵࠣࡶࡪࡷࡵࡪࡴࡨࡨࠥࡺ࡯ࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡨࠤࡦࠦࡧࡰࡖࡨࡲࡳࡧࠠࡥࡧࡹ࡭ࡨ࡫࠮ࠋࠌࡗ࡬ࡪࡹࡥࠡࡖࡏ࡚ࡸࠦࡡࡳࡧࠣࡪࡴࡸࠠࡪࡰࡷࡩࡷࡴࡡ࡭ࠢࡸࡷࡪࠦࡷࡩࡧࡱࠤࡨࡵ࡮ࡧ࡫ࡪࡹࡷ࡯࡮ࡨࠢࡤࠤࡩ࡫ࡶࡪࡥࡨ࠿ࠥࡺࡨࡦࡴࡨࠤ࡮ࡹࠠ࡯ࡱࠣࡲࡪ࡫ࡤࠡࡶࡲࠤࡦࡩࡣࡦࡵࡶࠤࡹ࡮ࡥ࡮ࠢࡨࡼࡹ࡫ࡲ࡯ࡣ࡯ࡰࡾ࠴ࠠࡕࡪࡨࡽࠥࡧࡲࡦࠢࡱࡳࡹࠦࡩ࡯ࡶࡨࡲࡩ࡫ࡤࠡࡶࡲࠤࡧ࡫ࠠࡴࡧࡱࡸࠥࡧࡣࡳࡱࡶࡷࠥࡺࡨࡦࠢࡪࡳ࡙࡫࡮࡯ࡣࠣࡲࡪࡺࡷࡰࡴ࡮࠲࡚ࠥ࡯ࠡࡵ࡫ࡥࡷ࡫ࠠࡳࡣࡧ࡭ࡴࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡤࡢࡶࡤ࠰ࠥࡻࡳࡦࠢࡷ࡬ࡪࠦࡡࡱࡲࡵࡳࡵࡸࡩࡢࡶࡨࠤࡲ࡫ࡳࡴࡣࡪࡩ࠳ࠐࠢࠣࠤૼ")
# pylint: enable=line-too-long
import logging
import struct
import itertools
import goTenna.settings
import goTenna.constants
from goTenna.tlv import basic_tlv
_MODULE_LOGGER = logging.getLogger(__name__)
class l1l111llll_opy_(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠨࠢࠣࠢࡗ࡬ࡪࠦࡔࡍࡘࠣࡷࡵ࡫ࡣࡪࡨࡼ࡭ࡳ࡭ࠠࡢࠢࡶࡩࡹࠦ࡯ࡧࠢࡩࡶࡪࡷࡵࡦࡰࡦࡽࠥࡩ࡯࡯ࡨ࡬࡫ࡺࡸࡡࡵ࡫ࡲࡲࡸࠦࠢࠣࠤ૽")
    l1l11llll1_opy_ = 0x25
    _11111ll1l_opy_ = 0x80
    _111111lll_opy_ = 0x01
    def __init__(self, rf_settings):
        l1l11l_opy_ (u"ࠢࠣࠤࠣࡆࡺ࡯࡬ࡥࠢࡷ࡬ࡪࠦࡔࡍࡘࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡔࡉࡗࡪࡺࡴࡪࡰࡪࡷࠥࡸࡦࡠࡵࡨࡸࡹ࡯࡮ࡨࡵ࠽ࠤ࡙࡮ࡥࠡࡱࡥ࡮ࡪࡩࡴࠡࡥࡲࡲࡹࡧࡩ࡯࡫ࡱ࡫ࠥࡺࡨࡦࠢࡩࡶࡪࡷࡵࡦࡰࡦ࡭ࡪࡹࠠࡵࡱࠣࡧࡴࡴࡦࡪࡩࡸࡶࡪ࠴ࠠࡅࡱࡨࡷࠥࡴ࡯ࡵࠢࡱࡩࡪࡪࠠࡵࡱࠣࡦࡪࠦࡶࡢ࡮࡬ࡨ࠱ࠦࡳࡪࡰࡦࡩࠥࡺࡨࡪࡵࠣࡘࡑ࡜ࠠࡥࡱࡨࡷࠥࡴ࡯ࡵࠢࡨࡲࡨࡵࡤࡦࠢࡷࡶࡦࡴࡳ࡮࡫ࡷࠤࡵࡵࡷࡦࡴ࠯ࠤࡧࡻࡴࠡ࡯ࡸࡷࡹࠦࡣࡰࡰࡷࡥ࡮ࡴࠠࡤࡱࡰࡴࡱ࡯ࡡ࡯ࡶࠣࡪࡷ࡫ࡱࡶࡧࡱࡧࡾࠦࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱࠤࡈ࡮ࡡ࡯ࡰࡨࡰࡘࡶࡥࡤࡖࡏ࡚࠿ࠦࡔࡩࡧࠣࡧࡴࡴࡳࡵࡴࡸࡧࡹ࡫ࡤࠡࡱࡥ࡮ࡪࡩࡴࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ૾")
        if not isinstance(rf_settings, goTenna.settings.RFSettings):
            raise TypeError(rf_settings)
        if not rf_settings.freqs_valid:
            raise ValueError((rf_settings.control_freqs, rf_settings.data_freqs))
        self.rf_settings = rf_settings
    def __eq__(self, other):
        return isinstance(other, l1l111llll_opy_)\
            and isinstance(other.rf_settings, goTenna.settings.RFSettings)\
            and self.rf_settings.control_freqs == other.rf_settings.control_freqs\
            and self.rf_settings.data_freqs == other.rf_settings.data_freqs
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    @classmethod
    def deserialize(cls, l111l1llll_opy_):
        number = int(len(l111l1llll_opy_) / 5)
        fmt = l1l11l_opy_ (u"ࠨࠣࠪ૿") + l1l11l_opy_ (u"ࠩࡌࡆࠬ଀")*number
        res = struct.unpack(fmt, l111l1llll_opy_)
        l1llllllll1_opy_ = itertools.islice(res, 0, len(res), 2)
        flags = itertools.islice(res, 1, len(res), 2)
        l1lllll1l1l_opy_ = goTenna.util.l1l1l1l1_opy_(l1llllllll1_opy_, flags)
        l11111l1ll_opy_ = []
        l111111l1l_opy_ = []
        for l1111111ll_opy_ in l1lllll1l1l_opy_:
            if l1111111ll_opy_[1] & cls._11111ll1l_opy_:
                l11111l1ll_opy_.append(l1111111ll_opy_[0])
            else:
                l111111l1l_opy_.append(l1111111ll_opy_[0])
        return cls(goTenna.settings.RFSettings(control_freqs=l11111l1ll_opy_,
                                               data_freqs=l111111l1l_opy_))
    def serialize(self):
        l11111l1l1_opy_ = self.rf_settings.control_freqs + self.rf_settings.data_freqs
        fmt = l1l11l_opy_ (u"ࠪࠥࠬଁ") + l1l11l_opy_ (u"ࠫࡎࡈࠧଂ")*len(l11111l1l1_opy_)
        flags = ([self._11111ll1l_opy_ | self._111111lll_opy_]
                 * len(self.rf_settings.control_freqs))\
                + ([self._111111lll_opy_] * len(self.rf_settings.data_freqs))
        args = []
        for elem in goTenna.util.l1l1l1l1_opy_(l11111l1l1_opy_, flags):
            args.extend(list(elem))
        return struct.pack(fmt, *args)
class l1ll111l11_opy_(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠧࠨࠢࠡࡖࡏ࡚ࠥ࡬࡯ࡳࠢࡶࡩࡳࡪࡩ࡯ࡩࠣࡱࡦࡹ࡫ࡴࠢࡤࡲࡩࠦࡢࡪࡶࡵࡥࡹ࡫ࡳࠡࡶࡲࠤࡹ࡮ࡥࠡࡦࡨࡺ࡮ࡩࡥࠡࡣࡷࠤࡨࡵ࡮ࡧ࡫ࡪࡹࡷࡧࡴࡪࡱࡱࠤࡹ࡯࡭ࡦ࠰ࠍࠤࠥࠦࠠࠣࠤࠥଃ")
    l1l11llll1_opy_ = 0x26
    def __eq__(self, other):
        return isinstance(other, l1ll111l11_opy_)\
            and self.rate == other.rate and self.mask == other.mask
    def __repr__(self):
        return l1l11l_opy_ (u"࠭࠼ࡼࡿ࠽ࠤࡲࡧࡳ࡬࠿ࡾࢁࠥࡸࡡࡵࡧࡀࡿࢂࡄࠧ଄").format(self.__class__.__name__,
                                              self.mask, self.rate)
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __init__(self, mask, rate):
        l1l11l_opy_ (u"ࠢࠣࠤࠍࠤࠥࠦࠠࠡࠢࠣࠤࡇࡻࡩ࡭ࡦࠣࡥ࡙ࠥࡥࡵࡏࡤࡷࡰࡘࡡࡵࡧࡗࡐ࡛࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡧࡴࡴࡳࡵࡣࡱࡸࡸ࠴ࡍࡢࡵ࡮ࠤࡲࡧࡳ࡬࠼ࠣࡘ࡭࡫ࠠ࡮ࡣࡶ࡯ࠥࡺ࡯ࠡࡤࡸ࡭ࡱࡪࠠࡵࡪࡨࠤ࡙ࡒࡖࠡࡹ࡬ࡸ࡭࠴ࠠࡎࡷࡶࡸࠥࡨࡥࠡࡣࡱࠤࡪࡲࡥ࡮ࡧࡱࡸࠥࡵࡦࠡ࠼ࡳࡽ࠿ࡧࡴࡵࡴ࠽ࡤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡩ࡯࡯ࡵࡷࡥࡳࡺࡳ࠯ࡏࡄࡗࡐ࡙ࡠ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡨࡵ࡮ࡴࡶࡤࡲࡹࡹ࠮ࡃ࡫ࡷࡶࡦࡺࡥࠡࡴࡤࡸࡪࡀࠠࡕࡪࡨࠤࡧ࡯ࡴࡳࡣࡷࡩࠥࡺ࡯ࠡࡤࡸ࡭ࡱࡪࠠࡵࡪࡨࠤ࡙ࡒࡖࠡࡹ࡬ࡸ࡭࠴ࠠࡎࡷࡶࡸࠥࡨࡥࠡࡣࠣࡺࡦࡲࡩࡥࠢࡥ࡭ࡹࡸࡡࡵࡧࠣࡪࡴࡸࠠࡵࡪࡨࠤ࡬࡯ࡶࡦࡰࠣࡱࡦࡹ࡫࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨଅ")
        if mask not in goTenna.constants.MASKS:
            raise ValueError(l1l11l_opy_ (u"ࠨࡏࡤࡷࡰࠦࡻࡾࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡤࠤࡻࡧ࡬ࡪࡦࠣࡱࡦࡹ࡫ࠨଆ").format(mask))
        if not mask.bitrate_allowed(rate):
            raise ValueError(l1l11l_opy_ (u"ࠩࡅ࡭ࡹࡸࡡࡵࡧࠣࡿࢂࠦࡩࡴࠢࡱࡳࡹࠦࡡ࡭࡮ࡲࡻࡪࡪࠠࡧࡱࡵࠤࡲࡧࡳ࡬ࠢࡾࢁࠬଇ")
                             .format(rate, mask))
        self.rate = rate
        self.mask = mask
    @classmethod
    def deserialize(cls, l111l1llll_opy_):
        (l1llllll11l_opy_, l1lllll1ll1_opy_) = struct.unpack(l1l11l_opy_ (u"ࠪࠥࡇࡈࠧଈ"), l111l1llll_opy_)
        mask = None
        rate = None
        for m in goTenna.constants.MASKS:
            if l1llllll11l_opy_ == m.index:
                mask = m
        for b in mask.allowed_bitrates:
            if l1lllll1ll1_opy_ == b.index:
                rate = b
        return cls(mask, rate)
    def serialize(self):
        return struct.pack(l1l11l_opy_ (u"ࠫࠦࡈࡂࠨଉ"), self.mask.index, self.rate.index)
class l1lllll1lll_opy_(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠧࠨࠢࠡࡖࡏ࡚ࠥ࡬࡯ࡳࠢ࡬ࡲࡹ࡫ࡲ࡯ࡣ࡯ࠤ࡫ࡧࡵ࡭ࡶࠣ࡭ࡳ࡬࡯࠯ࠌࠣࠤࠥࠦࠢࠣࠤଊ")
    l1l11llll1_opy_ = 0x29
    def __repr__(self):
        return l1l11l_opy_ (u"࠭࠼ࡼࡿ࠽ࠤࢀࢃ࠾ࠨଋ").format(self.__class__.__name__, self.l11111ll11_opy_)
    def __eq__(self, other):
        return isinstance(other, l1lllll1lll_opy_)\
            and self.l11111ll11_opy_ == other.l11111ll11_opy_
    def __init__(self, l11111ll11_opy_):
        l1l11l_opy_ (u"ࠢࠣࠤࠍࠤࠥࠦࠠࠡࠢࠣࠤࡇࡻࡩ࡭ࡦࠣࡥࠥࡌࡡࡶ࡮ࡷࡍࡳ࡬࡯ࡕࡎ࡙࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡥ࡫ࡦࡸࠥ࡬ࡡࡶ࡮ࡷࡣࡦࡺࡴࡳࡵ࠽ࠤ࡙࡮ࡥࠡࡣࡷࡸࡷ࡯ࡢࡶࡶࡨࡷࠥࡵࡦࠡࡶ࡫ࡩࠥ࡬ࡡࡶ࡮ࡷ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤଌ")
        l1llllll1l1_opy_ = (l1l11l_opy_ (u"ࠨࡨࡤࡹࡱࡺ࡟ࡱࡥࠪ଍"), l1l11l_opy_ (u"ࠩࡩࡥࡺࡲࡴࡠ࡮ࡵࠫ଎"), l1l11l_opy_ (u"ࠪࡪࡦࡻ࡬ࡵࡡࡶࡴࠬଏ"), l1l11l_opy_ (u"ࠫ࡫ࡧࡵ࡭ࡶࡢࡸࡾࡶࡥࠨଐ"),
                         l1l11l_opy_ (u"ࠬࡸ࠰ࠨ଑"), l1l11l_opy_ (u"࠭ࡲ࠲ࠩ଒"), l1l11l_opy_ (u"ࠧࡳ࠴ࠪଓ"), l1l11l_opy_ (u"ࠨࡴ࠶ࠫଔ"))
        if not hasattr(l11111ll11_opy_, l1l11l_opy_ (u"ࠩࡢࡣ࡬࡫ࡴࡪࡶࡨࡱࡤࡥࠧକ")):
            raise TypeError(l1l11l_opy_ (u"ࠪࡪࡦࡻ࡬ࡵࡡࡤࡸࡹࡸࡳࠡࡵ࡫ࡳࡺࡲࡤࠡࡤࡨࠤࡦࠦࡤࡪࡥࡷࡰ࡮ࡱࡥࠨଖ"))
        for key in l1llllll1l1_opy_:
            if not isinstance(l11111ll11_opy_[key], int):
                raise TypeError(l1l11l_opy_ (u"ࠫࡋࡧࡵ࡭ࡶࠣࡥࡹࡺࡲࡴࠢࡰࡹࡸࡺࠠࡣࡧࠣ࡭ࡳࡺࡳ࠭ࠢࡾࢁࠥ࡯ࡳࠡࡰࡲࡸࠬଗ")
                                .format(key))
            if l11111ll11_opy_[key] < 0 or l11111ll11_opy_[key] > 0xffffffff:
                raise ValueError(l1l11l_opy_ (u"ࠬࡌࡡࡶ࡮ࡷࠤࡦࡺࡴࡳࡵࠣࡱࡺࡹࡴࠡࡨ࡬ࡸࠥ࡯࡮ࠡ࠵࠵ࠤࡧ࡯ࡴࡴࠩଘ"))
        self.l11111ll11_opy_ = l11111ll11_opy_
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    @classmethod
    def deserialize(cls, l111l1llll_opy_):
        l1111111l1_opy_ = struct.unpack(l1l11l_opy_ (u"࠭ࠡࡍࡎࡏࡐࡑࡒࡌࡍࠩଙ"), l111l1llll_opy_)
        attrs = {
            l1l11l_opy_ (u"ࠧࡧࡣࡸࡰࡹࡥࡰࡤࠩଚ"): l1111111l1_opy_[0],
            l1l11l_opy_ (u"ࠨࡨࡤࡹࡱࡺ࡟࡭ࡴࠪଛ"): l1111111l1_opy_[1],
            l1l11l_opy_ (u"ࠩࡩࡥࡺࡲࡴࡠࡵࡳࠫଜ"): l1111111l1_opy_[2],
            l1l11l_opy_ (u"ࠪࡪࡦࡻ࡬ࡵࡡࡷࡽࡵ࡫ࠧଝ"): l1111111l1_opy_[3],
            l1l11l_opy_ (u"ࠫࡷ࠶ࠧଞ"): l1111111l1_opy_[4],
            l1l11l_opy_ (u"ࠬࡸ࠱ࠨଟ"): l1111111l1_opy_[5],
            l1l11l_opy_ (u"࠭ࡲ࠳ࠩଠ"): l1111111l1_opy_[6],
            l1l11l_opy_ (u"ࠧࡳ࠵ࠪଡ"): l1111111l1_opy_[7]
        }
        return cls(attrs)
    def serialize(self):
        return struct.pack(l1l11l_opy_ (u"ࠨࠣࡏࡐࡑࡒࡌࡍࡎࡏࠫଢ"),
                           self.l11111ll11_opy_.get(l1l11l_opy_ (u"ࠩࡩࡥࡺࡲࡴࡠࡲࡦࠫଣ"), 0xaaaaaaaa),
                           self.l11111ll11_opy_.get(l1l11l_opy_ (u"ࠪࡪࡦࡻ࡬ࡵࡡ࡯ࡶࠬତ"), 0xaaaaaaaa),
                           self.l11111ll11_opy_.get(l1l11l_opy_ (u"ࠫ࡫ࡧࡵ࡭ࡶࡢࡷࡵ࠭ଥ"), 0xaaaaaaaa),
                           self.l11111ll11_opy_.get(l1l11l_opy_ (u"ࠬ࡬ࡡࡶ࡮ࡷࡣࡹࡿࡰࡦࠩଦ"), 0xaaaaaaaa),
                           self.l11111ll11_opy_.get(l1l11l_opy_ (u"࠭ࡲ࠱ࠩଧ"), 0xaaaaaaaa),
                           self.l11111ll11_opy_.get(l1l11l_opy_ (u"ࠧࡳ࠳ࠪନ"), 0xaaaaaaaa),
                           self.l11111ll11_opy_.get(l1l11l_opy_ (u"ࠨࡴ࠵ࠫ଩"), 0xaaaaaaaa),
                           self.l11111ll11_opy_.get(l1l11l_opy_ (u"ࠩࡵ࠷ࠬପ"), 0xaaaaaaaa))
class l11111llll_opy_(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠥࠦࠧࠦࡔࡍࡘࠣࡪࡴࡸࠠ࡭࡫ࡩࡩࡹ࡯࡭ࡦࠢࡶࡸࡦࡺࡩࡴࡶ࡬ࡧࡸ࠴ࠊࠡࠢࠣࠤࠧࠨࠢଫ")
    l1l11llll1_opy_ = 0x2a
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __repr__(self):
        return l1l11l_opy_ (u"ࠫࡁࢁࡽ࠻ࠢࡾࢁࡃ࠭ବ").format(self.__class__.__name__,
                                 self.l111111l11_opy_)
    def __eq__(self, other):
        return isinstance(other, l11111llll_opy_)\
            and self.l111111l11_opy_ == other.l111111l11_opy_
    @staticmethod
    def _1llllll111_opy_():
        return [
            (l1l11l_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪࡹ࡟ࡰࡴ࡬࡫࡮ࡴࡡࡵࡧࡧࠫଭ"), l1l11l_opy_ (u"࠭ࡉࠨମ")),
            (l1l11l_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࡴࡡࡵࡩࡨ࡫ࡩࡷࡧࡧࠫଯ"), l1l11l_opy_ (u"ࠨࡋࠪର")),
            (l1l11l_opy_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࡶࡣࡷ࡫࡬ࡢࡻࡨࡨࠬ଱"), l1l11l_opy_ (u"ࠪࡍࠬଲ")),
            (l1l11l_opy_ (u"ࠫࡹࡾ࡟ࡵ࡫ࡰࡩࡤࡼࡨࡧࡡ࠳ࡴ࠺࠭ଳ"), l1l11l_opy_ (u"ࠬࡏࠧ଴")),
            (l1l11l_opy_ (u"࠭ࡴࡹࡡࡷ࡭ࡲ࡫࡟ࡷࡪࡩࡣ࠶࠭ଵ"), l1l11l_opy_ (u"ࠧࡊࠩଶ")),
            (l1l11l_opy_ (u"ࠨࡶࡻࡣࡹ࡯࡭ࡦࡡࡹ࡬࡫ࡥ࠲ࠨଷ"), l1l11l_opy_ (u"ࠩࡌࠫସ")),
            (l1l11l_opy_ (u"ࠪࡸࡽࡥࡴࡪ࡯ࡨࡣࡻ࡮ࡦࡠ࠷ࠪହ"), l1l11l_opy_ (u"ࠫࡎ࠭଺")),
            (l1l11l_opy_ (u"ࠬࡺࡸࡠࡶ࡬ࡱࡪࡥࡵࡩࡨࡢ࠴ࡵ࠻ࠧ଻"), l1l11l_opy_ (u"࠭ࡉࠨ଼")),
            (l1l11l_opy_ (u"ࠧࡵࡺࡢࡸ࡮ࡳࡥࡠࡷ࡫ࡪࡤ࠷ࠧଽ"), l1l11l_opy_ (u"ࠨࡋࠪା")),
            (l1l11l_opy_ (u"ࠩࡷࡼࡤࡺࡩ࡮ࡧࡢࡹ࡭࡬࡟࠳ࠩି"), l1l11l_opy_ (u"ࠪࡍࠬୀ")),
            (l1l11l_opy_ (u"ࠫࡹࡾ࡟ࡵ࡫ࡰࡩࡤࡻࡨࡧࡡ࠸ࠫୁ"), l1l11l_opy_ (u"ࠬࡏࠧୂ")),
            (l1l11l_opy_ (u"࠭ࡲࡹࡡࡷ࡭ࡲ࡫࡟ࡷࡪࡩࠫୃ"), l1l11l_opy_ (u"ࠧࡊࠩୄ")),
            (l1l11l_opy_ (u"ࠨࡴࡻࡣࡹ࡯࡭ࡦࡡࡸ࡬࡫࠭୅"), l1l11l_opy_ (u"ࠩࡌࠫ୆")),
            (l1l11l_opy_ (u"ࠪࡦࡱ࡫࡟ࡤࡱࡰࡱࡦࡴࡤࡴࡡࡵࡩࡨࡼࡤࠨେ"), l1l11l_opy_ (u"ࠫࡎ࠭ୈ")),
            (l1l11l_opy_ (u"ࠬࡨ࡬ࡦࡡࡰࡩࡸࡹࡡࡨࡧࡶࡣࡸ࡫࡮ࡵࠩ୉"), l1l11l_opy_ (u"࠭ࡉࠨ୊")),
            (l1l11l_opy_ (u"ࠧࡣ࡮ࡨࡣࡲ࡫ࡳࡴࡣࡪࡩࡤ࡫ࡲࡳࡱࡵࡷࠬୋ"), l1l11l_opy_ (u"ࠨࡊࠪୌ")),
            (l1l11l_opy_ (u"ࠩࡥࡥࡹࡺࡥࡳࡻࡢࡧࡾࡩ࡬ࡦࡵ୍ࠪ"), l1l11l_opy_ (u"ࠪࡌࠬ୎")),
            (l1l11l_opy_ (u"ࠫࡺࡶࡴࡪ࡯ࡨࠫ୏"), l1l11l_opy_ (u"ࠬࡎࠧ୐")),
            (l1l11l_opy_ (u"࠭ࡳࡺࡵࡷࡩࡲࡥࡴࡩࡧࡵࡱࡤ࡫ࡶࡦࡰࡷࡷࠬ୑"), l1l11l_opy_ (u"ࠧࡉࠩ୒"))
        ]
    @staticmethod
    def _111111ll1_opy_():
        l11111l11l_opy_ = l1l11l_opy_ (u"ࠨࠣࠪ୓")
        for elem in l11111llll_opy_._1llllll111_opy_():
            l11111l11l_opy_ += elem[1]
        return l11111l11l_opy_
    def __init__(self, l111111l11_opy_):
        l1l11l_opy_ (u"ࠤࠥࠦࠏࠦࠠࠡࠢࠣࠤࠥࠦࡂࡶ࡫࡯ࡨࠥࡧࠠࡍ࡫ࡩࡩࡹ࡯࡭ࡦࡋࡱࡪࡴ࡚ࡌࡗ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡪࡩࡤࡶࠣࡰ࡮࡬ࡥࡵ࡫ࡰࡩࡤࡧࡴࡵࡴࡶ࠾࡚ࠥࡨࡦࠢࡤࡸࡹࡸࡳࠡࡨࡲࡶࠥࡺࡨࡦࠢ࡯࡭࡫࡫ࡴࡪ࡯ࡨࠤ࡮ࡴࡦࡰ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢ୔")
        if not hasattr(l111111l11_opy_, l1l11l_opy_ (u"ࠪࡣࡤ࡭ࡥࡵ࡫ࡷࡩࡲࡥ࡟ࠨ୕")):
            raise TypeError(l1l11l_opy_ (u"ࠫࡱ࡯ࡦࡦࡶ࡬ࡱࡪࡥࡡࡵࡶࡵࡷࠥࡳࡵࡴࡶࠣࡦࡪࠦࡡࠡࡦ࡬ࡧࡹࡲࡩ࡬ࡧࠪୖ"))
        for key in self._1llllll111_opy_():
            if not isinstance(l111111l11_opy_[key[0]], int):
                raise TypeError(l1l11l_opy_ (u"ࠬࢁࡽࠡ࡫ࡶࠤࡳࡵࡴࠡࡣࡱࠤ࡮ࡴࡴࠨୗ").format(key[0]))
            if l111111l11_opy_[key[0]] < 0\
               or l111111l11_opy_[key[0]] > {l1l11l_opy_ (u"࠭ࡈࠨ୘"): 0xffff, l1l11l_opy_ (u"ࠧࡊࠩ୙"): 0xffffffff}[key[1]]:
                raise ValueError(l111111l11_opy_[key[0]])
        self.l111111l11_opy_ = l111111l11_opy_
    def serialize(self):
        l1lllllll1l_opy_ = [self.l111111l11_opy_.get(elem[0], 0)
                    for elem in self._1llllll111_opy_()]
        return struct.pack(self._111111ll1_opy_(), *l1lllllll1l_opy_)
    @classmethod
    def deserialize(cls, l111l1llll_opy_):
        l1llllll1ll_opy_ = struct.unpack(cls._111111ll1_opy_(), l111l1llll_opy_)
        return cls({elem[0]: l1llllll1ll_opy_[idx]
                    for idx, elem in enumerate(cls._1llllll111_opy_())})
class l11111111l_opy_(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠣࠤࠥࠤ࡙ࡒࡖࠡࡶࡼࡴࡪࠦࡦࡰࡴࠣࡴࡪࡸࡩࡰࡦ࡬ࡧࠥ࡯࡮ࡧࡱࠍࠤࠥࠦࠠࠣࠤࠥ୚")
    l1l11llll1_opy_ = 0x2b
    def __repr__(self):
        return l1l11l_opy_ (u"ࠩ࠿ࡿࢂࡀࠠࡼࡿࡁࠫ୛").format(self.__class__.__name__, self.l11111lll1_opy_)
    def __eq__(self, other):
        return isinstance(other, l11111111l_opy_)\
            and self.l11111lll1_opy_ == other.l11111lll1_opy_
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    @staticmethod
    def _111111111_opy_():
        return [
            (l1l11l_opy_ (u"ࠪࡥࡻ࡭࡟ࡳࡵࡶ࡭ࡤࡼࡨࡧࠩଡ଼"), l1l11l_opy_ (u"ࠫࡇ࠭ଢ଼")),
            (l1l11l_opy_ (u"ࠬࡧࡶࡨࡡࡵࡷࡸ࡯࡟ࡶࡪࡩࠫ୞"), l1l11l_opy_ (u"࠭ࡂࠨୟ")),
            (l1l11l_opy_ (u"ࠧࡢࡸࡪࡣࡷ࡫ࡦ࡭ࡧࡦࡸࡪࡪ࡟ࡱࡱࡺࡩࡷࡥࡶࡩࡨࠪୠ"), l1l11l_opy_ (u"ࠨࡄࠪୡ")),
            (l1l11l_opy_ (u"ࠩࡤࡺ࡬ࡥࡲࡦࡨ࡯ࡩࡨࡺࡥࡥࡡࡳࡳࡼ࡫ࡲࡠࡷ࡫ࡪࠬୢ"), l1l11l_opy_ (u"ࠪࡆࠬୣ")),
            (l1l11l_opy_ (u"ࠫࡨ࡮ࡡ࡯ࡡࡥࡹࡸࡿ࡟ࡣࡣࡦ࡯ࡴ࡬ࡦࡴࠩ୤"), l1l11l_opy_ (u"ࠬࡈࠧ୥")),
            (l1l11l_opy_ (u"࠭ࡴࡩࡧࡵࡱࡦࡲ࡟ࡣࡣࡦ࡯ࡴ࡬ࡦࡴࠩ୦"), l1l11l_opy_ (u"ࠧࡃࠩ୧")),
            (l1l11l_opy_ (u"ࠨࡣࡹ࡫ࡤࡸࡳࡴ࡫ࡢࡦࡱ࡫ࠧ୨"), l1l11l_opy_ (u"ࠩࡅࠫ୩")),
            (l1l11l_opy_ (u"ࠪࡷࡾࡹࡴࡦ࡯ࡢࡨࡺࡺࡹࡠࡥࡼࡧࡱ࡫ࠧ୪"), l1l11l_opy_ (u"ࠫࡇ࠭୫")),
            (l1l11l_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪࡹ࡟ࡴࡧࡱࡸࠬ୬"), l1l11l_opy_ (u"࠭ࡂࠨ୭")),
            (l1l11l_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࡴࡡࡵࡩࡨ࡫ࡩࡷࡧࡧࠫ୮"), l1l11l_opy_ (u"ࠨࡄࠪ୯")),
            (l1l11l_opy_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࡶࡣࡷ࡫࡬ࡢࡻࡨࡨࠬ୰"), l1l11l_opy_ (u"ࠪࡆࠬୱ")),
            (l1l11l_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࡸࡥࡲࡦ࡬ࡨࡧࡹ࡫ࡤࠨ୲"), l1l11l_opy_ (u"ࠬࡈࠧ୳")),
            (l1l11l_opy_ (u"࠭ࡵࡱࡶ࡬ࡱࡪ࠭୴"), l1l11l_opy_ (u"ࠧࡉࠩ୵"))
        ]
    @staticmethod
    def _111111ll1_opy_():
        l11111l11l_opy_ = l1l11l_opy_ (u"ࠨࠣࠪ୶")
        for elem in l11111111l_opy_._111111111_opy_():
            l11111l11l_opy_ += elem[1]
        return l11111l11l_opy_
    def __init__(self, l11111lll1_opy_):
        if not hasattr(l11111lll1_opy_, l1l11l_opy_ (u"ࠩࡢࡣ࡬࡫ࡴࡪࡶࡨࡱࡤࡥࠧ୷")):
            raise TypeError(l1l11l_opy_ (u"ࠪࡴࡪࡸࡩࡰࡦ࡬ࡧࡤࡧࡴࡵࡴࡶࠤࡲࡻࡳࡵࠢࡥࡩࠥࡧࠠࡥ࡫ࡦࡸࡱ࡯࡫ࡦࠩ୸"))
        for key in self._111111111_opy_():
            if not isinstance(l11111lll1_opy_[key[0]], int):
                raise TypeError(l1l11l_opy_ (u"ࠫࢀࢃࠠࡪࡵࠣࡲࡴࡺࠠࡢࡰࠣ࡭ࡳࡺࠧ୹").format(key[0]))
            if l11111lll1_opy_[key[0]] < 0\
               or l11111lll1_opy_[key[0]] > {l1l11l_opy_ (u"ࠬࡎࠧ୺"): 0xffff, l1l11l_opy_ (u"࠭ࡂࠨ୻"): 0xff}[key[1]]:
                raise ValueError(l11111lll1_opy_[key[0]])
        self.l11111lll1_opy_ = l11111lll1_opy_
    def serialize(self):
        args = [self.l11111lll1_opy_.get(elem[0], 0)
                for elem in self._111111111_opy_()]
        return struct.pack(self._111111ll1_opy_(), *args)
    @classmethod
    def deserialize(cls, l111l1llll_opy_):
        l1llllll1ll_opy_ = struct.unpack(cls._111111ll1_opy_(), l111l1llll_opy_)
        return cls({elem[0]: l1llllll1ll_opy_[idx]
                    for idx, elem in enumerate(cls._111111111_opy_())})
class l1l1l1lll1_opy_(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠢࠣࠤࠣࡘࡑ࡜ࠠࡵࡱࠣࡷࡵ࡫ࡣࡪࡨࡼࠤࡹࡸࡡ࡯ࡵࡰ࡭ࡹࠦࡰࡰࡹࡨࡶࠥࡧࡴࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡶ࡬ࡱࡪ࠴ࠊࠡࠢࠣࠤࠧࠨࠢ୼")
    l1l11llll1_opy_ = 0x1D
    def __repr__(self):
        return l1l11l_opy_ (u"ࠨ࠾ࡾࢁ࠿ࠦࡰࡰࡹࡨࡶࡂࢁࡽ࠿ࠩ୽").format(self.__class__.__name__,
                                       goTenna.constants.POWERLEVELS.name(self.power))
    def __eq__(self, other):
        return isinstance(other, l1l1l1lll1_opy_) and self.power == other.power
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __init__(self, power):
        if not goTenna.constants.POWERLEVELS.valid(power):
            raise TypeError(l1l11l_opy_ (u"ࠩࡓࡳࡼ࡫ࡲࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡹࡥࡱ࡯ࡤࠨ୾"))
        self.power = power
    def serialize(self):
        return struct.pack(l1l11l_opy_ (u"ࠪࠥࡇ࠭୿"), self.power)
    @classmethod
    def deserialize(cls, l111l1llll_opy_):
        l1llllll1ll_opy_ = struct.unpack(l1l11l_opy_ (u"ࠫࠦࡈࠧ஀"), l111l1llll_opy_)
        return cls(l1llllll1ll_opy_[0])
class l1l1llllll_opy_(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠧࠨࠢࠡࡖࡏ࡚ࠥࡺ࡯ࠡࡵࡳࡩࡨ࡯ࡦࡺࠢࡱࡩࡹࡽ࡯ࡳ࡭ࠣࡱࡴࡪࡥࠡࡣࡷࠤࡨࡵ࡮ࡧ࡫ࡪࡹࡷࡧࡴࡪࡱࡱࠤࡹ࡯࡭ࡦ࠰ࠍࠤࠥࠦࠠࠣࠤࠥ஁")
    l1l11llll1_opy_ = 0x2E
    def __repr__(self):
        return l1l11l_opy_ (u"࠭࠼ࡼࡿ࠽ࠤࡲ࡫ࡳࡩ࡫ࡱ࡫ࡂࢁࡽ࠭ࠢࡷࡼࡤࡵࡲࡪࡩ࡬ࡲࡦࡺࡥࡥ࠿ࡾࢁ࠱ࠦࡦ࡭ࡱࡲࡨ࠿ࠦࡳࡩࡱࡸࡸࡂࢁࡽ࠭ࠢࡪࡶࡴࡻࡰ࠾ࡽࢀ࠰ࠥࡶࡲࡪࡸࡤࡸࡪࡃࡻࡾ࠮ࠣࡩࡲ࡫ࡲࡨࡧࡱࡧࡾࡃࡻࡾࡀࠪஂ").format(
                self.__class__.__name__, self.l1l1l1l1ll_opy_, self.l11lllll1l_opy_,
                self.l1ll111lll_opy_, self.l1l11ll111_opy_, self.l1l11l1lll_opy_,
                self.l1l11lllll_opy_)
    def __eq__(self, other):
        return isinstance(other, l1l1llllll_opy_) \
               and self.l1l1l1l1ll_opy_ == other.l1l1l1l1ll_opy_ \
               and self.l11lllll1l_opy_ == other.l11lllll1l_opy_ \
               and self.l1ll111lll_opy_ == other.l1ll111lll_opy_ \
               and self.l1l11ll111_opy_ == other.l1l11ll111_opy_ \
               and self.l1l11l1lll_opy_ == other.l1l11l1lll_opy_ \
               and self.l1l11lllll_opy_ == other.l1l11lllll_opy_
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __init__(self, l1l1l1l1ll_opy_, l11lllll1l_opy_, l1ll111lll_opy_,
                 l1l11ll111_opy_, l1l11l1lll_opy_, l1l11lllll_opy_):
        self.l1l1l1l1ll_opy_ = l1l1l1l1ll_opy_
        self.l11lllll1l_opy_ = l11lllll1l_opy_
        self.l1ll111lll_opy_ = l1ll111lll_opy_
        self.l1l11ll111_opy_ = l1l11ll111_opy_
        self.l1l11l1lll_opy_ = l1l11l1lll_opy_
        self.l1l11lllll_opy_ = l1l11lllll_opy_
    def serialize(self):
        return struct.pack(l1l11l_opy_ (u"ࠧࠢࡄࡅࡆࡇࡈࡂࠨஃ"), self.l1l1l1l1ll_opy_, self.l11lllll1l_opy_,
                           self.l1ll111lll_opy_, self.l1l11ll111_opy_,
                           self.l1l11l1lll_opy_, self.l1l11lllll_opy_)
    @classmethod
    def deserialize(cls, l111l1llll_opy_):
        (l1l1l1l1ll_opy_, l11lllll1l_opy_, l1ll111lll_opy_, l1l11ll111_opy_,
         l1l11l1lll_opy_, l1l11lllll_opy_) = struct.unpack(l1l11l_opy_ (u"ࠨࠣࡅࡆࡇࡈࡂࡃࠩ஄"), l111l1llll_opy_)
        return cls(l1l1l1l1ll_opy_, l11lllll1l_opy_, l1ll111lll_opy_, l1l11ll111_opy_,
                   l1l11l1lll_opy_, l1l11lllll_opy_)
class l1l1l1ll1l_opy_(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠤ࡚ࠥࠦࠥࡌࡗࠢࡷࡳࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡴࡩࡧࠣࡳࡵ࡫ࡲࡢ࡫ࡷࡳࡳࠦ࡭ࡰࡦࡨࠤࡴ࡬ࠠࡵࡪࡨࠤࡩ࡫ࡶࡪࡥࡨࠎࠥࠦࠠࠡࠤࠥࠦஅ")
    l1l11llll1_opy_ = 0x35
    def __repr__(self):
        return l1l11l_opy_ (u"ࠪࡀࢀࢃ࠺ࠡ࡯ࡲࡨࡪࡃࡻࡾࡀࠪஆ").format(self.__class__.__name__,
                                      goTenna.constants.OperationModes.name(self.mode))
    def __eq__(self, other):
        return isinstance(other, l1l1l1ll1l_opy_) and self.mode == other.mode
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __init__(self, mode):
        l1l11l_opy_ (u"ࠦࠧࠨࠠࡃࡷ࡬ࡰࡩࠦࡡ࡯ࠢࡒࡴࡪࡸࡡࡵ࡫ࡲࡲࡒࡵࡤࡦࡖࡏ࡚࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡ࡫ࡱࡸࠥࡵࡲࠡࡵࡷࡶࠥࡳ࡯ࡥࡧ࠽ࠤ࡙࡮ࡥࠡ࡯ࡲࡨࡪ࠲ࠠࡢࡵࠣࡸ࡭࡫ࠠ࡯ࡣࡰࡩࠥࡵࡲࠡࡸࡤࡰࡺ࡫ࠠࡰࡨࠣࡥࠥࡳࡥ࡮ࡤࡨࡶࠥࡵࡦࠡ࠼ࡳࡽ࠿ࡩ࡬ࡢࡵࡶ࠾ࡥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡣࡰࡰࡶࡸࡦࡴࡴࡴ࠰ࡒࡴࡪࡸࡡࡵ࡫ࡲࡲࡒࡵࡤࡦࡵࡣࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡳࡣ࡬ࡷࡪࡹࠠࡌࡧࡼࡉࡷࡸ࡯ࡳ࠼ࠣࡍ࡫ࠦࡠࡡ࡯ࡲࡨࡪࡦࡠࠡ࡫ࡶࠤࡳࡵࡴࠡࡸࡤࡰ࡮ࡪࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦஇ")
        if mode in (goTenna.constants.OperationModes.OFF,
                    goTenna.constants.OperationModes.NORMAL,
                    goTenna.constants.OperationModes.RELAY):
            self.mode = mode
        else:
            try:
                self.mode = goTenna.constants.OperationModes.mode(mode)
            except Exception:
                raise KeyError(mode)
    def serialize(self):
        return struct.pack(l1l11l_opy_ (u"ࠬࠧࡂࠨஈ"), self.mode)
    @classmethod
    def deserialize(cls, l111l1llll_opy_):
        l1llllll1ll_opy_ = struct.unpack(l1l11l_opy_ (u"࠭ࠡࡃࠩஉ"), l111l1llll_opy_)
        return cls(l1llllll1ll_opy_[0])
class l1l1l11ll1_opy_(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠢࠣࠤࠣࡘࡑ࡜ࠠࡵࡱࠣࡷࡵ࡫ࡣࡪࡨࡼࠤࡹ࡮ࡥࠡࡧࡰࡩࡷ࡭ࡥ࡯ࡥࡼࠤࡧ࡫ࡡࡤࡱࡱࠤࡸࡺࡡࡵࡧࠍࠤࠥࠦࠠࠣࠤࠥஊ")
    l1l11llll1_opy_ = 0x34
    def __repr__(self):
        return l1l11l_opy_ (u"ࠨ࠾ࡾࢁ࠿ࠦࡥ࡯ࡣࡥࡰࡪࡪ࠽ࡼࡿࡁࠫ஋").format(self.__class__.__name__,
                                         self.enabled)
    def __eq__(self, other):
        return isinstance(other, l1l1l11ll1_opy_)\
            and self.enabled == other.enabled
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __init__(self, enabled):
        l1l11l_opy_ (u"ࠤࠥࠦࠥࡈࡵࡪ࡮ࡧࠤࡦࡴࠠࡆ࡯ࡨࡶ࡬࡫࡮ࡤࡻࡅࡩࡦࡩ࡯࡯ࡖࡏ࡚ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡣࡱࡲࡰࠥ࡫࡮ࡢࡤ࡯ࡩࡩࡀࠠࡘࡪࡨࡸ࡭࡫ࡲࠡࡶࡲࠤࡪࡴࡡࡣ࡮ࡨࠤ࠭ࡦࡠࡕࡴࡸࡩࡥࡦࠩࠡࡱࡵࠤࡩ࡯ࡳࡢࡤ࡯ࡩࠥ࠮ࡠࡡࡈࡤࡰࡸ࡫ࡠࡡࠫࠣࡸ࡭࡫ࠠࡣࡧࡤࡧࡴࡴࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥࡴࠢࡗࡽࡵ࡫ࡅࡳࡴࡲࡶ࠿ࠦࡉࡧࠢࡣࡤࡪࡴࡡࡣ࡮ࡨࡨࡥࡦࠠࡤࡣࡱࡲࡴࡺࠠࡣࡧࠣ࡭ࡳࡺࡥࡳࡲࡵࡩࡹ࡫ࡤࠡࡣࡶࠤࡦࠦࡢࡰࡱ࡯ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣ஌")
        self.enabled = bool(enabled)
    def serialize(self):
        return struct.pack(l1l11l_opy_ (u"ࠪࠥࡇ࠭஍"), self.enabled)
    @classmethod
    def deserialize(cls, l111l1llll_opy_):
        (l1llllll1ll_opy_,) = struct.unpack(l1l11l_opy_ (u"ࠫࠦࡈࠧஎ"), l111l1llll_opy_)
        return cls(l1llllll1ll_opy_)
class l1ll11l11l_opy_(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠧࠨࠢࠡࡖࡏ࡚ࠥࡺ࡯ࠡࡵࡳࡩࡨ࡯ࡦࡺࠢࡪࡩࡴࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣࡷࠤࡨࡵ࡮ࡧ࡫ࡪࡹࡷࡧࡴࡪࡱࡱࠤࡹ࡯࡭ࡦ࠰ࠍࠤࠥࠦࠠࠣࠤࠥஏ")
    l1l11llll1_opy_ = 0x1F
    def __repr__(self):
        return l1l11l_opy_ (u"࠭࠼ࡼࡿ࠽ࠤࡷ࡫ࡧࡪࡱࡱࡁࢀࢃ࠾ࠨஐ").format(self.__class__.__name__,
                                        goTenna.constants.GEO_REGION.name(self.region))
    def __eq__(self, other):
        return isinstance(other, l1ll11l11l_opy_) and self.region == other.region
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __init__(self, region):
        if not goTenna.constants.GEO_REGION.valid(region):
            raise TypeError(l1l11l_opy_ (u"ࠧࡑࡱࡺࡩࡷࠦ࡭ࡶࡵࡷࠤࡧ࡫ࠠࡷࡣ࡯࡭ࡩ࠭஑"))
        self.region = region
    def serialize(self):
        return struct.pack(l1l11l_opy_ (u"ࠨࠣࡅࠫஒ"), self.region)
    @classmethod
    def deserialize(cls, l111l1llll_opy_):
        l1llllll1ll_opy_ = struct.unpack(l1l11l_opy_ (u"ࠩࠤࡆࠬஓ"), l111l1llll_opy_)
        return cls(l1llllll1ll_opy_[0])
class l1ll11l111_opy_(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠥࠦࠧࠦࡔࡍࡘࠣࡸࡴࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡵࡪࡨࠤ࡝࠳ࡣࡢࡲࡤࡦ࡮ࡲࡩࡵࡻࠣࡷࡹࡧࡴࡦࠌࠣࠤࠥࠦࠢࠣࠤஔ")
    l1l11llll1_opy_ = 0x3b
    def __repr__(self):
        return l1l11l_opy_ (u"ࠫࡁࢁࡽ࠻ࠢࡨࡲࡦࡨ࡬ࡦࡦࡀࡿࢂࡄࠧக").format(self.__class__.__name__,
                                         self.enabled)
    def __eq__(self, other):
        return isinstance(other, l1ll11l111_opy_)\
            and self.enabled == other.enabled
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __init__(self, enabled):
        l1l11l_opy_ (u"ࠧࠨࠢࠡࡄࡸ࡭ࡱࡪࠠࡢࡰࠣ࡜ࡈࡧࡰࡢࡤ࡯ࡩ࡙ࡒࡖࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡦࡴࡵ࡬ࠡࡧࡱࡥࡧࡲࡥࡥ࠼࡛ࠣ࡭࡫ࡴࡩࡧࡵࠤࡹࡵࠠࡦࡰࡤࡦࡱ࡫ࠠࠩࡢࡣࡘࡷࡻࡥࡡࡢࠬࠤࡴࡸࠠࡥ࡫ࡶࡥࡧࡲࡥࠡࠪࡣࡤࡋࡧ࡬ࡴࡧࡣࡤ࠮ࠦࡴࡩࡧࠣࡼ࠲ࡩࡡࡱࡣࡥ࡭ࡱ࡯ࡴࡺࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷࡧࡩࡴࡧࡶࠤ࡙ࡿࡰࡦࡇࡵࡶࡴࡸ࠺ࠡࡋࡩࠤࡥࡦࡥ࡯ࡣࡥࡰࡪࡪࡠࡡࠢࡦࡥࡳࡴ࡯ࡵࠢࡥࡩࠥ࡯࡮ࡵࡧࡵࡴࡷ࡫ࡴࡦࡦࠣࡥࡸࠦࡡࠡࡤࡲࡳࡱࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ஖")
        self.enabled = bool(enabled)
    def serialize(self):
        return struct.pack(l1l11l_opy_ (u"࠭ࠡࡃࠩ஗"), self.enabled)
    @classmethod
    def deserialize(cls, l111l1llll_opy_):
        (l1llllll1ll_opy_,) = struct.unpack(l1l11l_opy_ (u"ࠧࠢࡄࠪ஘"), l111l1llll_opy_)
        return cls(l1llllll1ll_opy_)
class l1ll1111ll_opy_(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠣࠤࠥࠤ࡙ࡒࡖࠡࡶࡲࠤࡸࡶࡥࡤ࡫ࡩࡽࠥࡧࠠࡴࡻࡶࡸࡪࡳࠠࡱࡴࡲࡴࡪࡸࡴࡺࠢࡷࡳࠥࡸࡥࡵࡴ࡬ࡩࡻ࡫ࠠࠣࠤࠥங")
    l1l11llll1_opy_ = 0x28
    @staticmethod
    def l11111l111_opy_(prop):
        try:
            for tlv in _1lllllllll_opy_:
                if isinstance(tlv, basic_tlv.TLV)\
                   and tlv.l1l11llll1_opy_ == prop:
                    return tlv.__name__
        except Exception:
            return l1l11l_opy_ (u"ࠩ࠿ࡹࡳࡱ࡮ࡰࡹࡱࡂࠬச")
    def __repr__(self):
        return l1l11l_opy_ (u"ࠪࡀࢀࢃ࠺ࠡࡲࡵࡳࡵࡃࡻࡾࠢࠫࡿࢂ࠯࠾ࠨ஛")\
            .format(self.__class__.__name__,
                    self.prop,
                    self.l11111l111_opy_(self.prop))
    def __eq__(self, other):
        return isinstance(other, l1ll1111ll_opy_)\
            and self.prop == other.prop
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __init__(self, prop):
        l1l11l_opy_ (u"ࠦࠧࠨࠠࡃࡷ࡬ࡰࡩࠦࡡࠡࡉࡨࡸࡕࡸ࡯ࡱࡧࡵࡸࡾ࡚ࡌࡗࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤ࡮ࡴࡴࠡࡲࡵࡳࡵࡀࠠࡕࡪࡨࠤࡵࡸ࡯ࡱࡧࡵࡸࡾࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥஜ")
        self.prop = prop
        try:
            _ = struct.pack(l1l11l_opy_ (u"ࠬࠧࡂࠨ஝"), self.prop)
        except struct.error:
            raise TypeError(l1l11l_opy_ (u"ࠨࡰࡳࡱࡳࠤࡲࡻࡳࡵࠢࡩ࡭ࡹࠦࡩ࡯ࠢࡤࠤࡧࡿࡴࡦ࠮ࠣ࡭ࡸࠦࡻࡾࠤஞ")
                            .format(type(self.prop)))
    def serialize(self):
        return struct.pack(l1l11l_opy_ (u"ࠧࠢࡄࠪட"), self.prop)
    @classmethod
    def deserialize(cls, l111l1llll_opy_):
        return cls(struct.unpack(l1l11l_opy_ (u"ࠨࠣࡅࠫ஠"), l111l1llll_opy_)[0])
_1lllllllll_opy_ = [l1lllllll11_opy_ for l1lllllll11_opy_ in vars().values()
        if isinstance(l1lllllll11_opy_, type)
        and issubclass(l1lllllll11_opy_, basic_tlv.TLV)]