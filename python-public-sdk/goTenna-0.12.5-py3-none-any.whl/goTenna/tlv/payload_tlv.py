# coding: utf8
import sys
ll_opy_ = sys.version_info [0] == 2
l1llll_opy_ = 2048
l11l1_opy_ = 7
def l1l11l_opy_ (l1l111_opy_):
    global l1_opy_
    l11ll1_opy_ = ord (l1l111_opy_ [-1])
    l1l1l1_opy_ = l1l111_opy_ [:-1]
    l11ll_opy_ = l11ll1_opy_ % len (l1l1l1_opy_)
    l1ll_opy_ = l1l1l1_opy_ [:l11ll_opy_] + l1l1l1_opy_ [l11ll_opy_:]
    if ll_opy_:
        l1l11_opy_ = unicode () .join ([unichr (ord (char) - l1llll_opy_ - (l1l1_opy_ + l11ll1_opy_) % l11l1_opy_) for l1l1_opy_, char in enumerate (l1ll_opy_)])
    else:
        l1l11_opy_ = str () .join ([chr (ord (char) - l1llll_opy_ - (l1l1_opy_ + l11ll1_opy_) % l11l1_opy_) for l1l1_opy_, char in enumerate (l1ll_opy_)])
    return eval (l1l11_opy_)
# Copyright (C) 2018 goTenna, Inc. This file is distributed as part of the
# goTenna USB SDK. See the associated license for more information.
# pylint: disable=line-too-long
l1l11l_opy_ (u"ࠧࠨࠢࠡࡖࡏ࡚ࡸࠦࡩ࡯ࡶࡨࡲࡩ࡫ࡤࠡࡶࡲࠤࡧ࡫ࠠࡱ࡮ࡤࡧࡪࡪࠠࡪࡰࠣࡱࡪࡹࡳࡢࡩࡨࠤࡵࡧࡹ࡭ࡱࡤࡨࡸࠐࠊࡕࡪࡨࠤ࡙ࡒࡖࡴࠢࡦࡳࡳࡺࡡࡪࡰࡨࡨࠥ࡮ࡥࡳࡧࠣࡥࡷ࡫ࠠࡧࡱࡵࠤࡪࡴࡣࡰࡦ࡬ࡲ࡬ࠦࡤࡢࡶࡤࠤࡹࡵࠠࡴࡧࡱࡨࠥࡼࡩࡢࠢࡷ࡬ࡪࠦࡧࡰࡖࡨࡲࡳࡧࠠ࡯ࡧࡷࡻࡴࡸ࡫࠯ࠢࡌࡲࠥ࡭ࡥ࡯ࡧࡵࡥࡱ࠲ࠠࡵࡪࡨࡽࠥࡹࡨࡰࡷ࡯ࡨࠥࡴ࡯ࡵࠢࡥࡩࠥࡻࡳࡦࡦࠣࡨ࡮ࡸࡥࡤࡶ࡯ࡽࡀࠦࡲࡢࡶ࡫ࡩࡷ࠲ࠠ࡮ࡧࡶࡷࡦ࡭ࡥࠡࡲࡤࡽࡱࡵࡡࡥࡵࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡦࡪࠦࡣࡳࡧࡤࡸࡪࡪࠠࡸ࡫ࡷ࡬ࠥࡺࡨࡦࠢ࡫࡭࡬࡮ࠠ࡭ࡧࡹࡩࡱࠦࡦࡢࡥࡷࡳࡷࡿࠠࡤ࡮ࡤࡷࡸࡳࡥࡵࡪࡲࡨࡸࠦ࡯࡯ࠢ࠽ࡴࡾࡀࡣ࡭ࡣࡶࡷ࠿ࡦࡧࡰࡖࡨࡲࡳࡧ࠮࡮ࡧࡶࡷࡦ࡭ࡥ࠯ࡒࡤࡽࡱࡵࡡࡥࡢ࠯ࠤࡸࡻࡣࡩࠢࡤࡷࠥࡀࡰࡺ࠼ࡰࡩࡹ࡮࠺ࡡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡰࡩࡸࡹࡡࡨࡧ࠱ࡔࡦࡿ࡬ࡰࡣࡧ࠲ࡹ࡫ࡸࡵࡢ࠱ࠎࠧࠨࠢ௿")
# pylint: enable=line-too-long
import struct
import datetime
import logging
import six
import goTenna.constants
import goTenna.settings
import goTenna.util
from goTenna.tlv import basic_tlv
_MODULE_LOGGER = logging.getLogger(__name__)
class l1ll1ll1ll1_opy_(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠨࠢࠣࠢࡄࠤ࡙ࡒࡖࠡࡤࡤࡷࡪࠦࡣ࡭ࡣࡶࡷࠥࡺࡨࡢࡶࠣ࡮ࡺࡹࡴࠡࡪࡲࡰࡩࡹࠠࡢࠢ࡯ࡥࡹ࡯ࡴࡶࡦࡨ࠳ࡱࡵ࡮ࡨ࡫ࡷࡹࡩ࡫ࠠࡱࡣ࡬ࡶࠥࠨࠢࠣఀ")
    def __repr__(self):
        return l1l11l_opy_ (u"ࠧ࠽ࡽࢀ࠾ࠥࢁࡽ࠿ࠩఁ").format(self.__class__.__name__,
                                 self._print_contents())
    def _print_contents(self):
        return l1l11l_opy_ (u"ࠨ࡮ࡤࡸ࡮ࡺࡵࡥࡧࡀࡿࢂ࠲ࠠ࡭ࡱࡱ࡫࡮ࡺࡵࡥࡧࡀࡿࢂ࠭ం").format(self.latitude, self.longitude)
    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and other.position == self.position
    def __init__(self, latitude, longitude):
        l1l11l_opy_ (u"ࠤࠥࠦࠥࡈࡵࡪ࡮ࡧࠤࡹ࡮ࡥࠡࡱࡥ࡮ࡪࡩࡴ࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤ࡫ࡲ࡯ࡢࡶࠣࡰࡦࡺࡩࡵࡷࡧࡩ࠿ࠦࡔࡩࡧࠣࡰࡦࡺࡩࡵࡷࡧࡩࠥࡺ࡯ࠡࡵࡷࡳࡷ࡫ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡨ࡯ࡳࡦࡺࠠ࡭ࡱࡱ࡫࡮ࡺࡵࡥࡧ࠽ࠤ࡙࡮ࡥࠡ࡮ࡲࡲ࡬࡯ࡴࡶࡦࡨࠤࡹࡵࠠࡴࡶࡲࡶࡪࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥࡴࠢࡗࡽࡵ࡫ࡅࡳࡴࡲࡶ࠿ࠦࡉࡧࠢࡲࡲࡪࠦ࡯ࡧࠢ࡯ࡥࡹ࡯ࡴࡶࡦࡨࠤࡴࡸࠠ࡭ࡱࡱ࡫࡮ࡺࡵࡥࡧࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡧࡴࡴࡶࡦࡴࡷ࡭ࡧࡲࡥࠡࡶࡲࠤ࡫ࡲ࡯ࡢࡶ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣః")
        try:
            self._1lll11l1ll_opy_ = float(latitude)
        except (ValueError, TypeError):
            raise TypeError(l1l11l_opy_ (u"ࠪࡰࡦࡺࡩࡵࡷࡧࡩࠥࡳࡵࡴࡶࠣࡦࡪࠦࡣࡰࡰࡹࡩࡷࡺࡩࡣ࡮ࡨࠤࡹࡵࠠࡧ࡮ࡲࡥࡹ࠲ࠠࡪࡵࠣࡿࢂ࠭ఄ")
                            .format(type(latitude)))
        try:
            self._1lll11ll11_opy_ = float(longitude)
        except (ValueError, TypeError):
            raise TypeError(l1l11l_opy_ (u"ࠫࡱࡵ࡮ࡨ࡫ࡷࡹࡩ࡫ࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡥࡲࡲࡻ࡫ࡲࡵ࡫ࡥࡰࡪࠦࡴࡰࠢࡩࡰࡴࡧࡴ࠭ࠢ࡬ࡷࠥࢁࡽࠨఅ")
                            .format(type(longitude)))
    @property
    def latitude(self):
        l1l11l_opy_ (u"ࠧࠨࠢࠡࡖ࡫ࡩࠥࡲࡡࡵ࡫ࡷࡹࡩ࡫ࠬࠡࡣࡶࠤࡦࠦࡦ࡭ࡱࡤࡸࠧࠨࠢఆ")
        return self._1lll11l1ll_opy_
    @property
    def longitude(self):
        l1l11l_opy_ (u"ࠨࠢࠣࠢࡗ࡬ࡪࠦ࡬ࡰࡰࡪ࡭ࡹࡻࡤࡦ࠮ࠣࡥࡸࠦࡡࠡࡨ࡯ࡳࡦࡺࠠࠣࠤࠥఇ")
        return self._1lll11ll11_opy_
    @property
    def position(self):
        l1l11l_opy_ (u"ࠢࠣࠤࠣࡘ࡭࡫ࠠࡱࡱࡶ࡭ࡹ࡯࡯࡯࠮ࠣࡥࡸࠦࡡࠡࠪ࡯ࡥࡹ࡯ࡴࡶࡦࡨ࠰ࠥࡲ࡯࡯ࡩ࡬ࡸࡺࡪࡥࠪࠢࡳࡥ࡮ࡸࠠࠣࠤࠥఈ")
        return (self._1lll11l1ll_opy_, self._1lll11ll11_opy_)
    def serialize(self):
        return struct.pack(l1l11l_opy_ (u"ࠨࠣࡧࡨࠬఉ"), self._1lll11l1ll_opy_, self._1lll11ll11_opy_)
    @classmethod
    def deserialize(cls, value):
        return cls(*struct.unpack(l1l11l_opy_ (u"ࠩࠤࡨࡩ࠭ఊ"), value))
class RequestGIDTLV(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠥࠦࠧࠦࡁࠡࡖࡏ࡚ࠥ࡬࡯ࡳࠢ࡫ࡳࡱࡪࡩ࡯ࡩࠣࡥࠥࡸࡥࡲࡷࡨࡷࡹࠦࡦࡰࡴࠣࡥࠥࡍࡉࡅࠌࠣࠤࠥࠦࠢࠣࠤఋ")
    l1l11llll1_opy_ = 5
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __repr__(self):
        return l1l11l_opy_ (u"ࠫࡁࡘࡥࡲࡷࡨࡷࡹࡍࡉࡅࡖࡏ࡚࠿ࠦࡇࡊࡆࡀࡿࢂࡄࠧఌ").format(self.gid)
    def __eq__(self, other):
        return isinstance(other, RequestGIDTLV) and self._gid == other._gid
    @property
    def gid(self):
        l1l11l_opy_ (u"ࠧࠨࠢࠡࡖ࡫ࡩࠥࡍࡉࡅࠢࡤࡷࡸࡵࡣࡪࡣࡷࡩࡩࠦࡷࡪࡶ࡫ࠤࡹ࡮ࡥࠡࡖࡏ࡚ࠥࠨࠢࠣ఍")
        return self._gid
    def __init__(self, gid):
        l1l11l_opy_ (u"ࠨࠢࠣࠢࡅࡹ࡮ࡲࡤࠡࡣࠣࡖࡪࡷࡵࡦࡵࡷࡋࡎࡊࡔࡍࡘ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࡔࡩ࡫ࡶࠤ࡮ࡹࠠࡶࡵࡸࡥࡱࡲࡹࠡࡷࡶࡩࡩࠦࡡࡴࠢࡷ࡬ࡪࠦࡳࡰࡷࡵࡧࡪࠦࡶࡢ࡮ࡸࡩࠥ࡬࡯ࡳࠢࡶࡳࡲ࡫ࠠࡴࡱࡵࡸࠥࡵࡦࠡࡴࡨࡵࡺ࡫ࡳࡵࠢࡰࡩࡸࡹࡡࡨࡧ࠱ࠤࡆࡹࠠࡴࡷࡦ࡬࠱ࠦࡩࡵࠢࡶ࡬ࡴࡻ࡬ࡥࠢࡥࡩࠥࡧࠠࡱࡴ࡬ࡺࡦࡺࡥࠡࡉࡌࡈ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌࡏࡄࠡࡩ࡬ࡨ࠿ࠦࡔࡩࡧࠣࡋࡎࡊࠠࡵࡱࠣࡴࡦࡩ࡫࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷࡧࡩࡴࡧࡶࠤ࡙ࡿࡰࡦࡇࡵࡶࡴࡸ࠺ࠡࡋࡩࠤࡥࡦࡧࡪࡦࡣࡤࠥ࡯ࡳࠡࡰࡲࡸࠥࡧࠠ࠻ࡲࡼ࠾ࡨࡲࡡࡴࡵ࠽ࡤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡋࡇࡤ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡤ࡭ࡸ࡫ࡳࠡࡘࡤࡰࡺ࡫ࡅࡳࡴࡲࡶ࠿ࠦࡉࡧࠢࡣࡤ࡬࡯ࡤࡡࡢࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡥࠥࡶࡲࡪࡸࡤࡸࡪࠦࡇࡊࡆ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣఎ")
        if not isinstance(gid, goTenna.settings.GID):
            raise TypeError
        if gid.gid_type != goTenna.settings.GID.PRIVATE:
            raise ValueError
        self._gid = gid
    @classmethod
    def deserialize(cls, value):
        l1lll11llll_opy_ = struct.unpack(l1l11l_opy_ (u"ࠧࠢࡓࠪఏ"), value)[0]
        return cls(goTenna.settings.GID(l1lll11llll_opy_, goTenna.settings.GID.PRIVATE))
    def serialize(self):
        return struct.pack(l1l11l_opy_ (u"ࠨࠣࡔࠫఐ"), self.gid.gid_val)
class MapIDTLV(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠤࠥࠦࠥࡇࠠࡕࡎ࡙ࠤ࡭ࡵ࡬ࡥ࡫ࡱ࡫ࠥࡺࡨࡦࠢࡌࡈࠥࡵࡦࠡࡶ࡫ࡩࠥࡳࡡࡱࠢࡤࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡩ࡯࡯ࡶࡤ࡭ࡳࡹࠊࠡࠢࠣࠤࠧࠨࠢ఑")
    l1l11llll1_opy_ = 38
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __repr__(self):
        return l1l11l_opy_ (u"ࠪࡀࢀࢃࠠࡪࡦࡀࡿࢂࡄࠧఒ").format(self.__class__.__name__, self.map_id)
    def __eq__(self, other):
        return isinstance(other, MapIDTLV) and self._id == other._id
    @property
    def map_id(self):
        l1l11l_opy_ (u"ࠦࠧࠨࠠࡕࡪࡨࠤࡲࡧࡰࠡ࡫ࡧࠤࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡪࠠࡣࡻࠣࡸ࡭࡫ࠠࡕࡎ࡙ࠤࠧࠨࠢఓ")
        return self._id
    def __init__(self, map_id):
        l1l11l_opy_ (u"ࠧࠨࠢࠡࡄࡸ࡭ࡱࡪࠠࡢࠢࡐࡥࡵࡏࡄࡕࡎ࡙࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࡎࡣࡳࠤࡎࡊࡳࠡࡣࡵࡩࠥ࠼࠴࠮ࡤ࡬ࡸࠥ࡯࡮ࡵࡧࡪࡩࡷࡹࠠࡪࡰࡷࡩࡳࡪࡥࡥࠢࡷࡳࠥࡻ࡮ࡪࡳࡸࡩࡱࡿࠠࡪࡦࡨࡲࡹ࡯ࡦࡺࠢࡪࡩࡳ࡫ࡲࡪࡥࠣࡱࡦࡶࠠࡰࡤ࡭ࡩࡨࡺࡳࠡࡵࡸࡧ࡭ࠦࡡࡴࠢࡵࡳࡺࡺࡥࡴࠢࡲࡶࠥࡩࡩࡳࡥ࡯ࡩࡸࠦࡡࡤࡴࡲࡷࡸࠦ࡭ࡶ࡮ࡷ࡭ࡵࡲࡥࠡࡥࡲࡱࡲࡻ࡮ࡪࡥࡤࡸ࡮ࡴࡧࠡࡷࡶࡩࡷࡹ࠮ࠡࡖ࡫ࡩࡾࠦࡳࡩࡱࡸࡰࡩࠦࡢࡦࠢࡪࡩࡳ࡫ࡲࡢࡶࡨࡨࠥࡽࡩࡵࡪࠣ࠾ࡵࡿ࠺࡮ࡧࡷ࡬࠿ࡦࡵࡶ࡫ࡧ࠲ࡺࡻࡩࡥ࠶ࡣࠤࡴࡸࠠ࠻ࡲࡼ࠾ࡲ࡫ࡴࡩ࠼ࡣࡳࡸ࠴ࡵࡳࡣࡱࡨࡴࡳࡠࠡࡶࡲࠤࡪࡴࡳࡶࡴࡨࠤ࡬ࡲ࡯ࡣࡣ࡯ࠤࡺࡴࡩࡲࡷࡨࡲࡪࡹࡳ࠯ࠢࡋࡳࡼ࡫ࡶࡦࡴ࠯ࠤࡧࡿࠠࡵࡪࡨࠤࡹ࡯࡭ࡦࠢࡷ࡬ࡪࡿࠠࡢࡴࡨࠤ࡬࡯ࡶࡦࡰࠣࡸࡴࠦࡴࡩ࡫ࡶࠤ࡙ࡒࡖ࠭ࠢࡷ࡬ࡪࡿࠠࡴࡪࡲࡹࡱࡪࠠࡣࡧࠣࡧࡴࡧ࡬ࡦࡵࡦࡩࡩࠦࡴࡰࠢ࡬ࡲࡹ࡫ࡧࡦࡴࡶ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡪࡰࡷࠤࡲࡧࡰࡠ࡫ࡧ࠾࡚ࠥࡨࡦࠢࡌࡈ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡤ࡭ࡸ࡫ࡳࠡࡖࡼࡴࡪࡋࡲࡳࡱࡵ࠾ࠥࡏࡆࠡࡢࡣࡱࡦࡶ࡟ࡪࡦࡣࡤࠥ࡯ࡳࠡࡰࡲࡸࠥࡧ࡮ࠡ࡫ࡱࡸ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥఔ")
        if not isinstance(map_id, six.integer_types):
            raise TypeError(l1l11l_opy_ (u"࠭࡭ࡢࡲࡢ࡭ࡩࠦࡳࡩࡱࡸࡰࡩࠦࡢࡦࠢ࡬ࡲࡹ࡫ࡧࡳࡣ࡯࠰ࠥ࡯ࡳࠡࡽࢀࠫక")
                            .format(type(map_id)))
        self._id = map_id
    @classmethod
    def deserialize(cls, value):
        return cls(struct.unpack(l1l11l_opy_ (u"ࠧࠢࡓࠪఖ"), value)[0])
    def serialize(self):
        return struct.pack(l1l11l_opy_ (u"ࠨࠣࡔࠫగ"), self._id)
class LocationNameTLV(basic_tlv.l1111lll1l_opy_):
    l1l11l_opy_ (u"ࠤࠥࠦࠥࡇࠠࡕࡎ࡙ࠤ࡫ࡵࡲࠡࡪࡲࡰࡩ࡯࡮ࡨࠢࡤࠤࡱࡵࡣࡢࡶ࡬ࡳࡳࠦ࡮ࡢ࡯ࡨࠎࠥࠦࠠࠡࠤࠥࠦఘ")
    l1l11llll1_opy_ = 7
    MAX_LENGTH = 32
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    @property
    def name(self):
        l1l11l_opy_ (u"ࠥࠦࠧࠦࡔࡩࡧࠣࡰࡴࡩࡡࡵ࡫ࡲࡲࠥࡴࡡ࡮ࡧࠣࡥࡸࡹ࡯ࡤ࡫ࡤࡸࡪࡪࠠࡸ࡫ࡷ࡬ࠥࡺࡨࡦࠢࡗࡐ࡛ࠦࠢࠣࠤఙ")
        return self._contents
    @property
    def l1111llll1_opy_(self):
        l1l11l_opy_ (u"ࠦࠧࠨࠠࡕࡪࡨࠤࡲࡧࡸࡪ࡯ࡸࡱࠥࡲࡥ࡯ࡩࡷ࡬ࠥࡵࡦࠡࡶ࡫ࡩ࡚ࠥࡌࡗࠢࠥࠦࠧచ")
        return self.MAX_LENGTH
class LocationLatitudeTLV(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠧࠨࠢࠡࡃࠣࡘࡑ࡜ࠠࡧࡱࡵࠤ࡭ࡵ࡬ࡥ࡫ࡱ࡫ࠥࡧࠠ࡭ࡣࡷ࡭ࡹࡻࡤࡦࠌࠣࠤࠥࠦࠢࠣࠤఛ")
    l1l11llll1_opy_ = 8
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __repr__(self):
        return l1l11l_opy_ (u"࠭࠼ࡍࡱࡦࡥࡹ࡯࡯࡯ࡎࡤࡸ࡮ࡺࡵࡥࡧࡗࡐ࡛ࡀࠠ࡭ࡣࡷ࡭ࡹࡻࡤࡦ࠿ࡾࢁࡃ࠭జ").format(self.latitude)
    def __eq__(self, other):
        return isinstance(other, LocationLatitudeTLV)\
            and self._1lll11l1ll_opy_ == other._1lll11l1ll_opy_
    @property
    def latitude(self):
        l1l11l_opy_ (u"ࠢࠣࠤࠣࡘ࡭࡫ࠠ࡭ࡣࡷ࡭ࡹࡻࡤࡦࠢࡤࡷࡸࡵࡣࡪࡣࡷࡩࡩࠦࡷࡪࡶ࡫ࠤࡹ࡮ࡥࠡࡖࡏ࡚ࠥࠨࠢࠣఝ")
        return self._1lll11l1ll_opy_
    def __init__(self, latitude):
        l1l11l_opy_ (u"ࠣࠤࠥࠤࡇࡻࡩ࡭ࡦࠣࡥࠥࡲࡡࡵ࡫ࡷࡹࡩ࡫ࠠࡕࡎ࡙࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡧ࡮ࡲࡥࡹࠦ࡬ࡢࡶ࡬ࡸࡺࡪࡥ࠻ࠢࡗ࡬ࡪࠦ࡬ࡢࡶ࡬ࡸࡺࡪࡥࠡࡶࡲࠤࡪࡴࡣࡰࡦࡨ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡳࡣ࡬ࡷࡪࡹࠠࡕࡻࡳࡩࡊࡸࡲࡰࡴ࠽ࠤࡎ࡬ࠠࡡࡢ࡯ࡥࡹ࡯ࡴࡶࡦࡨࡤࡥࠦࡩࡴࠢࡱࡳࡹࠦࡡࠡࡨ࡯ࡳࡦࡺ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧఞ")
        if not isinstance(latitude, float):
            raise TypeError(l1l11l_opy_ (u"ࠩࡏࡥࡹ࡯ࡴࡶࡦࡨࠤࡸ࡮࡯ࡶ࡮ࡧࠤࡧ࡫ࠠࡢࠢࡩࡰࡴࡧࡴࠨట"))
        self._1lll11l1ll_opy_ = latitude
    @classmethod
    def deserialize(cls, value):
        return cls(struct.unpack(l1l11l_opy_ (u"ࠪࠥࡩ࠭ఠ"), value)[0])
    def serialize(self):
        return struct.pack(l1l11l_opy_ (u"ࠫࠦࡪࠧడ"), self.latitude)
class LocationLongitudeTLV(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠧࠨࠢࠡࡃࠣࡘࡑ࡜ࠠࡧࡱࡵࠤ࡭ࡵ࡬ࡥ࡫ࡱ࡫ࠥࡲ࡯࡯ࡩ࡬ࡸࡺࡪࡥࠋࠢࠣࠤࠥࠨࠢࠣఢ")
    l1l11llll1_opy_ = 9
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __repr__(self):
        return l1l11l_opy_ (u"࠭࠼ࡍࡱࡦࡥࡹ࡯࡯࡯ࡎࡲࡲ࡬࡯ࡴࡶࡦࡨࡘࡑ࡜࠺ࠡ࡮ࡲࡲ࡬࡯ࡴࡶࡦࡨࡁࢀࢃ࠾ࠨణ").format(self.longitude)
    def __eq__(self, other):
        return isinstance(other, LocationLongitudeTLV)\
            and self.longitude == other.longitude
    @property
    def longitude(self):
        l1l11l_opy_ (u"ࠢࠣࠤࠣࡘ࡭࡫ࠠ࡭ࡱࡱ࡫࡮ࡺࡵࡥࡧࠣࡥࡸࡹ࡯ࡤ࡫ࡤࡸࡪࡪࠠࡸ࡫ࡷ࡬ࠥࡺࡨࡦࠢࡗࡐ࡛ࠦࠢࠣࠤత")
        return self._1lll11ll11_opy_
    def __init__(self, longitude):
        l1l11l_opy_ (u"ࠣࠤࠥࠤࡇࡻࡩ࡭ࡦࠣࡥࠥࡲ࡯࡯ࡩ࡬ࡸࡺࡪࡥࠡࡖࡏ࡚࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡨ࡯ࡳࡦࡺ࠺ࠡ࡮ࡲࡲ࡬࡯ࡴࡶࡦࡨ࠾࡚ࠥࡨࡦࠢ࡯ࡳࡳ࡭ࡩࡵࡷࡧࡩࠥࡺ࡯ࠡࡧࡱࡧࡴࡪࡥ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷࡧࡩࡴࡧࡶࠤ࡙ࡿࡰࡦࡇࡵࡶࡴࡸ࠺ࠡࡋࡩࠤࡥࡦ࡬ࡰࡰࡪ࡭ࡹࡻࡤࡦࡢࡣࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡦࠦࡦ࡭ࡱࡤࡸ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥథ")
        if not isinstance(longitude, float):
            raise TypeError(l1l11l_opy_ (u"ࠩࡏࡳࡳ࡭ࡩࡵࡷࡧࡩࠥࡹࡨࡰࡷ࡯ࡨࠥࡨࡥࠡࡣࠣࡪࡱࡵࡡࡵࠩద"))
        self._1lll11ll11_opy_ = longitude
    @classmethod
    def deserialize(cls, value):
        return cls(struct.unpack(l1l11l_opy_ (u"ࠪࠥࡩ࠭ధ"), value)[0])
    def serialize(self):
        return struct.pack(l1l11l_opy_ (u"ࠫࠦࡪࠧన"), self.longitude)
class LocationGPSTimestampTLV(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠧࠨࠢࠡࡃࠣࡘࡑ࡜ࠠࡧࡱࡵࠤ࡭ࡵ࡬ࡥ࡫ࡱ࡫ࠥࡧࠠࡈࡒࡖࠤࡹ࡯࡭ࡦࡵࡷࡥࡲࡶࠊࠡࠢࠣࠤࠧࠨࠢ఩")
    l1l11llll1_opy_ = 19
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __repr__(self):
        return l1l11l_opy_ (u"࠭࠼ࡍࡱࡦࡥࡹ࡯࡯࡯ࡉࡓࡗ࡙࡯࡭ࡦࡵࡷࡥࡲࡶࡔࡍࡘ࠽ࠤࡹ࡯࡭ࡦ࠿ࡾࢁ࡛ࠥࡔࡄࡀࠪప").format(self.timestamp)
    def __eq__(self, other):
        return isinstance(other, LocationGPSTimestampTLV)\
            and other.timestamp == self.timestamp
    @property
    def timestamp(self):
        l1l11l_opy_ (u"ࠢࠣࠤࠣࡘ࡭࡫ࠠ࡯ࡣ࡬ࡺࡪࠦࡕࡕࡅࠣࡸ࡮ࡳࡥࡴࡶࡤࡱࡵࠦࡡࡴࡵࡲࡧ࡮ࡧࡴࡦࡦࠣࡻ࡮ࡺࡨࠡࡶ࡫ࡩ࡚ࠥࡌࡗࠢࠥࠦࠧఫ")
        return self._1lll11111l_opy_
    def __init__(self, timestamp):
        l1l11l_opy_ (u"ࠣࠤࠥࠤࡇࡻࡩ࡭ࡦࠣࡥࠥࡍࡐࡔࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡࡖ࡫࡭ࡸࠦ࡯ࡣ࡬ࡨࡧࡹࠦࡨࡰ࡮ࡧࡷࠥࡺࡨࡦࠢࡷ࡭ࡲ࡫ࠠࡪࡰࡷࡩࡷࡴࡡ࡭࡮ࡼࠤࡦࡹࠠࡢࠢ࠽ࡴࡾࡀࡣ࡭ࡣࡶࡷ࠿ࡦࡤࡢࡶࡨࡸ࡮ࡳࡥ࠯ࡦࡤࡸࡪࡺࡩ࡮ࡧࡣࠤࡴࡨࡪࡦࡥࡷ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡥࡣࡷࡩࡹ࡯࡭ࡦ࠰ࡧࡥࡹ࡫ࡴࡪ࡯ࡨࠤࡹ࡯࡭ࡦࡵࡷࡥࡲࡶ࠺ࠡࡖ࡫ࡩࠥࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࠡࡶࡲࠤ࡭ࡵ࡬ࡥ࠰ࠣࡍ࡫ࠦࡩࡵࠢ࡬ࡷࠥࡴࡡࡪࡸࡨ࠰ࠥ࡯ࡴࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡶࡸࡴࡸࡥࡥࠢࡤࡷࠥ࡯ࡳ࠯ࠢࡌࡪࠥ࡯ࡴࠡ࡫ࡶࠤࡦࡽࡡࡳࡧ࠯ࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡨࡥࠡࡥࡲࡲࡻ࡫ࡲࡵࡧࡧࠤࡹࡵࠠࡖࡖࡆࠤ࡮ࡴࠠࡱࡴࡨࡴࡦࡸࡡࡵ࡫ࡲࡲࠥ࡬࡯ࡳࠢࡶࡩࡷ࡯ࡡ࡭࡫ࡽࡥࡹ࡯࡯࡯࠰ࠣࡅࡱࡲࠠࡥࡧࡶࡩࡷ࡯ࡡ࡭࡫ࡽࡩࡩࠦࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࡵࠣࡥࡷ࡫ࠠࡢࡵࡶࡹࡲ࡫ࡤࠡࡶࡲࠤࡧ࡫ࠠࡖࡖࡆ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠯࠰ࠣࡲࡴࡺࡥࠡ࠼ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡔࡩࡧࠣࡧࡴࡴࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱ࡙࡙ࠣࡉࠠࡪࡵࠣࡨࡴࡴࡥࠡࡰࡤ࡭ࡻ࡫࡬ࡺࠢ࡬ࡲࠥࡵࡲࡥࡧࡵࠤࡹࡵࠠࡢࡸࡲ࡭ࡩࠦࡰࡶ࡮࡯࡭ࡳ࡭ࠠࡪࡰࠣࡥࡳࡵࡴࡩࡧࡵࠤࡪࡾࡴࡦࡴࡱࡥࡱࠦ࡬ࡪࡤࡵࡥࡷࡿ࠮ࠡࡋࡩࠤࡹ࡮ࡥࠡࡲࡤࡷࡸ࡫ࡤ࠮࡫ࡱࠤࡹ࡯࡭ࡦࡵࡷࡥࡲࡶࠠࡩࡣࡶࠤࡦࠦ࠺ࡱࡻ࠽ࡧࡱࡧࡳࡴ࠼ࡣࡨࡦࡺࡥࡵ࡫ࡰࡩ࠳ࡺࡺࡪࡰࡩࡳࡥࠦࡡࡵࡶࡤࡧ࡭࡫ࡤ࠭ࠢࡷ࡬࡮ࡹࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡺ࡭ࡱࡲࠠࡶࡵࡨࠤ࡮ࡺࡳࠡࡢࡣࡹࡹࡩ࡯ࡧࡨࡶࡩࡹ࠮ࠩࡡࡢࠣࡱࡪࡺࡨࡰࡦࠣࡸࡴࠦࡣࡰࡰࡹࡩࡷࡺࠠࡵࡪࡨࠤࡹ࡯࡭ࡦࡵࡷࡥࡲࡶࠠࡵࡱ࡙࡙ࠣࡉࠠࡢࡰࡧࠤࡹ࡮ࡥ࡯ࠢࡧ࡭ࡸࡩࡡࡳࡦࠣࡸ࡭࡫ࠠ࠻ࡲࡼ࠾ࡨࡲࡡࡴࡵ࠽ࡤࡩࡧࡴࡦࡶ࡬ࡱࡪ࠴ࡴࡻ࡫ࡱࡪࡴࡦࠠࡰࡤ࡭ࡩࡨࡺ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧబ")
        self._1lll11111l_opy_ = goTenna.util.l111l11l_opy_(timestamp)
    @classmethod
    def deserialize(cls, value):
        l1lll1l11l1_opy_ = struct.unpack(l1l11l_opy_ (u"ࠩࠤࡍࠬభ"), value)[0]
        return cls(datetime.datetime.utcfromtimestamp(l1lll1l11l1_opy_))
    def serialize(self):
        l1lll111lll_opy_ = int((self.timestamp - datetime.datetime.utcfromtimestamp(0))
                    .total_seconds())
        return struct.pack(l1l11l_opy_ (u"ࠪࠥࡎ࠭మ"), l1lll111lll_opy_)
class LocationTypeTLV(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠦࠧࠨࠠࡂࠢࡗࡐ࡛ࠦࡦࡰࡴࠣ࡬ࡴࡲࡤࡪࡰࡪࠤࡦࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡶࡼࡴࡪࠐࠠࠡࠢࠣࠦࠧࠨయ")
    l1l11llll1_opy_ = 10
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __eq__(self, other):
        return isinstance(other, LocationTypeTLV)\
            and self.location_type == other.location_type
    @property
    def location_type(self):
        l1l11l_opy_ (u"ࠧࠨࠢࠡࡖ࡫ࡩࠥࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠠࡵࡻࡳࡩࠥࡧࡳࡴࡱࡦ࡭ࡦࡺࡥࡥࠢࡺ࡭ࡹ࡮ࠠࡵࡪࡨࠤ࡙ࡒࡖࠡࠤࠥࠦర")
        return self._1lll1l1l11_opy_
    def __init__(self, location_type):
        l1l11l_opy_ (u"ࠨࠢࠣࠢࡅࡹ࡮ࡲࡤࠡࡣࠣࡰࡴࡩࡡࡵ࡫ࡲࡲࠥࡺࡹࡱࡧ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡳࡵࡴࠣࡰࡴࡩࡡࡵ࡫ࡲࡲࡤࡺࡹࡱࡧ࠽ࠤࡆࠦ࡫ࡦࡻࠣࡳ࡫ࠦ࠺ࡱࡻ࠽ࡥࡹࡺࡲ࠻ࡢࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡧࡴࡴࡳࡵࡣࡱࡸࡸ࠴ࡌࡐࡅࡄࡘࡎࡕࡎࡠࡖ࡜ࡔࡊ࡙ࡠࠡࡶࡲࠤࡸ࡫࡮ࡥ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡡࡪࡵࡨࡷࠥࡑࡥࡺࡇࡵࡶࡴࡸ࠺ࠡ࡫ࡩࠤࡥࡦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࡠࡶࡼࡴࡪࡦࡠࠡ࡫ࡶࠤࡳࡵࡴࠡࡣࠣࡺࡦࡲࡩࡥࠢ࡯ࡳࡨࡧࡴࡪࡱࡱࠤࡹࡿࡰࡦ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢఱ")
        _ = goTenna.constants.location_type(location_type)
        #: The location type
        self._1lll1l1l11_opy_ = location_type
    @classmethod
    def deserialize(cls, value):
        l1lll1l11l1_opy_ = goTenna.util.b2s(value)
        loc_type = goTenna.constants.location_type_name(l1lll1l11l1_opy_)
        return cls(loc_type)
    def serialize(self):
        return goTenna.util.s2b(goTenna.constants.location_type(self.location_type))
    def __repr__(self):
        return l1l11l_opy_ (u"ࠧ࠽ࡎࡲࡧࡦࡺࡩࡰࡰࡗࡽࡵ࡫ࡔࡍࡘ࠽ࠤࡹࡿࡰࡦ࠿ࡾࢁࡃ࠭ల").format(self.location_type)
class l1lll111111_opy_(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠣࠤࠥࠤࡆࠦࡔࡍࡘࠣࡸࡴࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡩࡱࡺࠤ࡫ࡸࡥࡲࡷࡨࡲࡹࡲࡹࠡࡣࠣࡰࡴࡩࡡࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡵ࡫ࡥࡷ࡫ࡤࠣࠤࠥళ")
    l1l11llll1_opy_ = 20
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and self.l1lll11l111_opy_ == other.l1lll11l111_opy_
    def __repr__(self):
        return l1l11l_opy_ (u"ࠩ࠿ࡐࡴࡩࡡࡵ࡫ࡲࡲࡘ࡮ࡡࡳ࡫ࡱ࡫ࡋࡸࡥࡲࡷࡨࡲࡨࡿࡔࡍࡘ࠽ࠤ࡫ࡸࡥࡲࡷࡨࡲࡨࡿ࠽ࡼࡿࡁࠫఴ")\
            .format(self.l1lll11l111_opy_)
    @property
    def l1lll11l111_opy_(self):
        l1l11l_opy_ (u"ࠥࠦࠧࠦࡔࡩࡧࠣࡷ࡭ࡧࡲࡪࡰࡪࠤ࡫ࡸࡥࡲࡷࡨࡲࡨࡿࠠࡢࡵࡶࡳࡨ࡯ࡡࡵࡧࡧࠤࡼ࡯ࡴࡩࠢࡷ࡬ࡪࠦࡔࡍࡘࠣࠦࠧࠨవ")
        return self._1lll1l11ll_opy_
    def __init__(self, l1lll11l111_opy_):
        l1l11l_opy_ (u"ࠦࠧࠨࠠࡃࡷ࡬ࡰࡩࠦࡡࠡ࡮ࡲࡧࡦࡺࡩࡰࡰࠣࡷ࡭ࡧࡲࡪࡰࡪࠤ࡫ࡸࡥࡲࡷࡨࡲࡨࡿ࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣ࡭ࡳࡺࠠࡧࡴࡨࡵࡺ࡫࡮ࡤࡻ࠽ࠤ࡙࡮ࡥࠡࡵ࡫ࡥࡷ࡯࡮ࡨࠢࡤࠤ࡫ࡸࡥࡲࡷࡨࡲࡨࡿࠬࠡࡣࠣ࡯ࡪࡿࠠࡰࡨࠣ࠾ࡵࡿ࠺ࡢࡶࡷࡶ࠿ࡦࡧࡰࡖࡨࡲࡳࡧ࠮ࡤࡱࡱࡷࡹࡧ࡮ࡵࡵ࠱ࡗࡍࡇࡒࡊࡐࡊࡣࡋࡘࡅࡒࡗࡈࡒࡈࡏࡅࡔࡢࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡢ࡫ࡶࡩࡸࠦࡋࡦࡻࡈࡶࡷࡵࡲ࠻ࠢࡌࡪࠥࡦࡠࡧࡴࡨࡵࡺ࡫࡮ࡤࡻࡣࡤࠥ࡯ࡳࠡࡰࡲࡸࠥ࡯࡮ࠡ࠼ࡳࡽ࠿ࡧࡴࡵࡴ࠽ࡤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡩ࡯࡯ࡵࡷࡥࡳࡺࡳ࠯ࡕࡋࡅࡗࡏࡎࡈࡡࡉࡖࡊࡗࡕࡆࡐࡆࡍࡊ࡙ࡠࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧశ")
        _ = goTenna.constants.sharing_frequency(l1lll11l111_opy_)
        self._1lll1l11ll_opy_ = l1lll11l111_opy_
    def serialize(self):
        val = goTenna.constants.sharing_frequency(self._1lll1l11ll_opy_)
        return goTenna.util.l1l11ll_opy_(val)
    @classmethod
    def deserialize(cls, value):
        val = goTenna.util.l1lll11_opy_(value[0])
        l1lll1l11l1_opy_ = goTenna.constants.sharing_frequency_name(val)
        return cls(l1lll1l11l1_opy_)
class LocationAccuracyTLV(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠧࠨࠢࠡࡃࠣࡘࡑ࡜ࠠࡧࡱࡵࠤ࡭ࡵ࡬ࡥ࡫ࡱ࡫ࠥࡺࡨࡦࠢࡤࡧࡨࡻࡲࡢࡥࡼࠤࡴ࡬ࠠࡵࡪࡨࠤࡱࡵࡣࡢࡶ࡬ࡳࡳࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠊࠡࠢࠣࠤࠧࠨࠢష")
    l1l11llll1_opy_ = 0x32
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and self.accuracy == other.accuracy
    def __repr__(self):
        return l1l11l_opy_ (u"࠭࠼ࡍࡱࡦࡥࡹ࡯࡯࡯ࡃࡦࡧࡺࡸࡡࡤࡻࡗࡐ࡛ࡀࠠࡢࡥࡦࡹࡷࡧࡣࡺ࠿ࡾࢁࡲࡄࠧస").format(self.accuracy)
    @property
    def accuracy(self):
        l1l11l_opy_ (u"ࠢࠣࠤࠣࡘ࡭࡫ࠠࡢࡥࡦࡹࡷࡧࡣࡺࠢࡹࡥࡱࡻࡥࠡࡪࡨࡰࡩࠦࡢࡺࠢࡷ࡬ࡪࠦࡔࡍࡘ࠯ࠤ࡮ࡴࠠ࡮ࡧࡷࡩࡷࡹࠠࠣࠤࠥహ")
        return self._accuracy
    def __init__(self, accuracy):
        l1l11l_opy_ (u"ࠣࠤࠥࠤࡇࡻࡩ࡭ࡦࠣࡥࠥࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠠࡴࡪࡤࡶ࡮ࡴࡧࠡࡣࡦࡧࡺࡸࡡࡤࡻࠣࡘࡑ࡜ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢ࡬ࡲࡹࠦࡡࡤࡥࡸࡶࡦࡩࡹ࠻ࠢࡗ࡬ࡪࠦࡡࡤࡥࡸࡶࡦࡩࡹࠡࡱࡩࠤࡹ࡮ࡥࠡ࡯ࡨࡥࡸࡻࡲࡦ࡯ࡨࡲࡹ࠲ࠠࡪࡰࠣࡱࡪࡺࡥࡳࡵ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡳࡣ࡬ࡷࡪࡹࠠࡕࡻࡳࡩࡊࡸࡲࡰࡴ࠽ࠤࡎ࡬ࠠࡡࡢࡤࡧࡨࡻࡲࡢࡥࡼࡤࡥࠦࡣࡢࡰࡱࡳࡹࠦࡢࡦࠢࡦࡳࡳࡼࡥࡳࡶࡨࡨࠥࡺ࡯ࠡࡢࡣ࡭ࡳࡺࡠࡡࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷࡧࡩࡴࡧࡶࠤ࡛ࡧ࡬ࡶࡧࡈࡶࡷࡵࡲ࠻ࠢࡌࡪࠥࡦࡠࡢࡥࡦࡹࡷࡧࡣࡺࡢࡣࠤ࡮ࡹࠠ࡭ࡧࡶࡷࠥࡺࡨࡢࡰࠣ࠴ࠥࡵࡲࠡ࡮ࡤࡶ࡬࡫ࡲࠡࡶ࡫ࡥࡳࠦ࠶࠶࠷࠶࠹ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤ఺")
        try:
            self._accuracy = int(accuracy)
        except (ValueError, TypeError):
            raise TypeError(l1l11l_opy_ (u"ࠩࡤࡧࡨࡻࡲࡢࡥࡼࠤࡲࡻࡳࡵࠢࡥࡩࠥ࡯࡮ࡵ࠮ࠣ࡭ࡸࠦࡻࡾࠩ఻").format(type(accuracy)))
        if self._accuracy < 0 or self._accuracy > 65535:
            raise ValueError(l1l11l_opy_ (u"ࠪࡥࡨࡩࡵࡳࡣࡦࡽࠥࡳࡵࡴࡶࠣࡦࡪࠦࡢࡦࡶࡺࡩࡪࡴࠠ࠱ࠢࡤࡲࡩࠦ࠶࠶࠷࠶࠺࠱ࠦࡩࡴࠢࡾࢁ఼ࠬ")
                             .format(self._accuracy))
    @classmethod
    def deserialize(cls, value):
        l1lll1l11l1_opy_ = struct.unpack(l1l11l_opy_ (u"ࠫࠦࡎࠧఽ"), value)[0]
        _MODULE_LOGGER.info(l1l11l_opy_ (u"ࠬࡖࡡࡳࡵࡨࡨࠥࡧࡣࡤࡷࡵࡥࡨࡿࠠࡼࡿࠪా").format(l1lll1l11l1_opy_))
        return cls(l1lll1l11l1_opy_)
    def serialize(self):
        return struct.pack(l1l11l_opy_ (u"࠭ࠡࡉࠩి"), self.accuracy)
class LocationDataTLV(basic_tlv.l1111ll1ll_opy_):
    l1l11l_opy_ (u"ࠢࠣࠤࠣࡅ࡚ࠥࡌࡗࠢࡩࡳࡷࠦࡨࡰ࡮ࡧ࡭ࡳ࡭ࠠ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠢࡧࡥࡹࡧࠊࠡࠢࠣࠤࠧࠨࠢీ")
    l1l11llll1_opy_ = 6
    l111ll1111_opy_ = (LocationNameTLV, LocationLatitudeTLV,
                           LocationLongitudeTLV, LocationGPSTimestampTLV,
                           MapIDTLV, LocationTypeTLV, LocationAccuracyTLV,
                           l1lll111111_opy_)
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    @property
    def l1111l1l11_opy_(self):
        return self.l111ll1111_opy_
class GroupGIDTLV(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠣࠤࠥࠤࡆࠦࡔࡍࡘࠣࡪࡴࡸࠠࡩࡱ࡯ࡨ࡮ࡴࡧࠡࡣࠣ࡫ࡷࡵࡵࡱࠩࡶࠤࡌࡏࡄࠋࠢࠣࠤࠥࠨࠢࠣు")
    l1l11llll1_opy_ = 11
    def __repr__(self):
        return l1l11l_opy_ (u"ࠩ࠿ࡋࡷࡵࡵࡱࡉࡌࡈ࡙ࡒࡖ࠻ࠢࡪ࡭ࡩࡃࡻࡾࡀࠪూ").format(self._gid)
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __eq__(self, other):
        return isinstance(other, GroupGIDTLV) and self.gid == other.gid
    @property
    def gid(self):
        l1l11l_opy_ (u"ࠥࠦࠧࠦࡁࡤࡥࡨࡷࡸࡵࡲࠡࡨࡲࡶࠥࡶࡡࡳࡵࡨࡨ࠴ࡹࡰࡦࡥ࡬ࡪ࡮࡫ࡤࠡࡉࡌࡈࠥࠨࠢࠣృ")
        return self._gid
    def __init__(self, gid):
        l1l11l_opy_ (u"ࠦࠧࠨࠠࡃࡷ࡬ࡰࡩࠦࡴࡩࡧࠣࡘࡑ࡜ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡪ࡭ࡩࡀࠠࡕࡪࡨࠤࡌࡏࡄࠡࡱࡩࠤࡹ࡮ࡥࠡࡩࡵࡳࡺࡶࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡷࡽࡵ࡫ࠠࡨ࡫ࡧ࠾ࠥࡲ࡯࡯ࡩࠣࡳࡷࠦࡧࡰࡖࡨࡲࡳࡧ࠮ࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡍࡉࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥౄ")
        if not isinstance(gid, goTenna.settings.GID):
            raise TypeError(l1l11l_opy_ (u"ࠬ࡭ࡩࡥࠢࡶ࡬ࡴࡻ࡬ࡥࠢࡥࡩࠥࡧࠠࡨ࡫ࡧࠤࡹࡿࡰࡦࠢࡥࡹࡹࠦࡩࡴࠢࡾࢁࠬ౅")
                            .format(type(gid)))
        if gid.gid_type != goTenna.settings.GID.GROUP:
            raise ValueError(l1l11l_opy_ (u"࠭ࡧࡪࡦࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡦࡪࠦࡡࠡࡩࡵࡳࡺࡶࠠࡨ࡫ࡧࠫె"))
        self._gid = gid
    def serialize(self):
        return struct.pack(l1l11l_opy_ (u"ࠧࠢࡓࠪే"), self._gid.gid_val)
    @classmethod
    def deserialize(cls, l111l1llll_opy_):
        (gid,) = struct.unpack(l1l11l_opy_ (u"ࠨࠣࡔࠫై"), l111l1llll_opy_)
        return cls(goTenna.settings.GID(gid, goTenna.settings.GID.GROUP))
class GroupMemberListTLV(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠤࠥࠦࠥࡇࠠࡕࡎ࡙ࠤ࡫ࡵࡲࠡࡪࡲࡰࡩ࡯࡮ࡨࠢࡤࠤ࡬ࡸ࡯ࡶࡲࠣࡱࡪࡳࡢࡦࡴࠣࡰ࡮ࡹࡴࠋࠢࠣࠤࠥࠨࠢࠣ౉")
    l1l11llll1_opy_ = 12
    def __repr__(self):
        return l1l11l_opy_ (u"ࠪࡀࡌࡸ࡯ࡶࡲࡐࡩࡲࡨࡥࡳࡎ࡬ࡷࡹ࡚ࡌࡗ࠼ࠣࡱࡪࡳࡢࡦࡴࡶࡁࢀࢃ࠾ࠨొ").format(self._members)
    def __eq__(self, other):
        return isinstance(other, GroupMemberListTLV)\
            and self.members == other.members
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    @property
    def members(self):
        l1l11l_opy_ (u"ࠦࠧࠨࠠࡕࡪࡨࠤࡲ࡫࡭ࡣࡧࡵࡷࠥࡵࡦࠡࡶ࡫ࡩࠥ࡭ࡲࡰࡷࡳࠤࠧࠨࠢో")
        return self._members
    def __init__(self, members):
        l1l11l_opy_ (u"ࠧࠨࠢࠡࡄࡸ࡭ࡱࡪࠠࡵࡪࡨࠤ࡙ࡒࡖࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡪࡳࡢࡦࡴࡶ࠾࡚ࠥࡨࡦࠢࡰࡩࡲࡨࡥࡳࡵࠣࡳ࡫ࠦࡴࡩࡧࠣ࡫ࡷࡵࡵࡱ࠰ࠣࡓࡷࡪࡥࡳ࡫ࡱ࡫ࠥࡹࡨࡰࡷ࡯ࡨࠥࡨࡥࠡࡲࡵࡩࡸ࡫ࡲࡷࡧࡧࠤࡦࡩࡲࡰࡵࡶࠤ࡮ࡴࡳࡵࡣࡱࡧࡪࡹࠠࡰࡨࠣࡸ࡭࡫ࠠࡨࡴࡲࡹࡵ࠴ࠠࡕࡪ࡬ࡷࠥࡲࡩࡴࡶࠣ࡭ࡸࠦࡡࡴࡵࡸࡱࡪࡪࠠࡵࡱࠣࡷࡹࡧࡲࡵࠢࡤࡸࠥ࡯࡮ࡥࡧࡻࠤ࠶࠲ࠠࡢࡰࡧࠤࡸ࡮࡯ࡶ࡮ࡧࠤࡳࡵࡴࠡ࡫ࡱࡧࡱࡻࡤࡦࠢࡷ࡬ࡪࠦࡣࡳࡧࡤࡸࡴࡸࠠࡰࡨࠣࡸ࡭࡫ࠠࡨࡴࡲࡹࡵ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡷࡽࡵ࡫ࠠ࡮ࡧࡰࡦࡪࡸࡳ࠻ࠢ࡯࡭ࡸࡺ࡛ࡨࡱࡗࡩࡳࡴࡡ࠯ࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌࡏࡄ࡞ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨౌ")
        if len(members) < 2:
            raise ValueError(l1l11l_opy_ (u"࠭ࡍࡶࡵࡷࠤࡧ࡫ࠠࡢࡶࠣࡰࡪࡧࡳࡵࠢ࠵ࠤࡲ࡫࡭ࡣࡧࡵࡷࠥࡵࡴࡩࡧࡵࠤࡹ࡮ࡡ࡯ࠢࡲࡶ࡮࡭ࡩ࡯ࡣࡷࡳࡷ్࠭"))
        if len(members) > goTenna.settings.Group.MAX_MEMBERS:
            raise ValueError(l1l11l_opy_ (u"ࠧࡎࡷࡶࡸࠥࡨࡥࠡࡨࡨࡻࡪࡸࠠࡵࡪࡤࡲࠥࢁࡽࠡ࡯ࡨࡱࡧ࡫ࡲࡴࠩ౎")
                             .format(goTenna.settings.Group.MAX_MEMBERS))
        self._members = []
        for member in members:
            if isinstance(member, goTenna.settings.GID):
                self._members.append(member)
            else:
                raise TypeError(l1l11l_opy_ (u"ࠨ࡯ࡨࡱࡧ࡫ࡲࡴࠢࡶ࡬ࡴࡻ࡬ࡥࠢࡥࡩࠥࡍࡉࡅࠢࡷࡽࡵ࡫ࡳ࠭ࠢࡥࡹࡹࠦ࡭ࡦ࡯ࡥࡩࡷࠦࡩࡴࠢࡾࢁࠬ౏")
                                .format(type(member)))
    def serialize(self):
        l1ll1lll1l1_opy_ = six.b(l1l11l_opy_ (u"ࠩࠪ౐"))
        for idx, gid in enumerate(self._members):
            l1ll1lll1l1_opy_ += struct.pack(l1l11l_opy_ (u"ࠪࠥࡖࡈࠧ౑"), gid.gid_val, idx+1)
        return l1ll1lll1l1_opy_
    @classmethod
    def deserialize(cls, l111l1llll_opy_):
        l1lll1111l1_opy_ = l111l1llll_opy_
        l1lll11l1l1_opy_ = [None] * int(len(l111l1llll_opy_)/9)
        while True:
            if not l1lll1111l1_opy_:
                break
            if len(l1lll1111l1_opy_) < 9:
                raise ValueError(l1l11l_opy_ (u"ࠫࡒࡧ࡬ࡧࡱࡵࡱࡪࡪࠠࡕࡎ࡙ࠥࠬ౒"))
            l1ll1llllll_opy_ = l1lll1111l1_opy_[:9]
            l1lll1111l1_opy_ = l1lll1111l1_opy_[9:]
            (gid, membership) = struct.unpack(l1l11l_opy_ (u"ࠬࠧࡑࡃࠩ౓"), l1ll1llllll_opy_)
            l1lll11l1l1_opy_[membership-1] = goTenna.settings.GID(gid,
                                                      goTenna.settings.GID.PRIVATE)
        return cls(l1lll11l1l1_opy_)
class GroupSharedSecretTLV(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠨࠢࠣࠢࡄࠤ࡙ࡒࡖࠡࡨࡲࡶࠥ࡮࡯࡭ࡦ࡬ࡲ࡬ࠦࡡࠡࡩࡵࡳࡺࡶࠠࡴࡪࡤࡶࡪࡪࠠࡴࡧࡦࡶࡪࡺࠊࠡࠢࠣࠤࠧࠨࠢ౔")
    l1l11llll1_opy_ = 13
    def __repr__(self):
        return l1l11l_opy_ (u"ࠧ࠽ࡉࡵࡳࡺࡶࡓࡩࡣࡵࡩࡩ࡙ࡥࡤࡴࡨࡸ࡙ࡒࡖ࠻ࠢࡖࡩࡨࡸࡥࡵ࠼ࠣࡿࢂࡄౕࠧ")\
            .format(goTenna.util.display_bytestring(self._1ll1lll111_opy_))
    def __eq__(self, other):
        return isinstance(other, GroupSharedSecretTLV)\
            and other.secret == self.secret
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    @property
    def secret(self):
        l1l11l_opy_ (u"ࠣࠤࠥࠤ࡙࡮ࡥࠡࡵࡨࡧࡷ࡫ࡴࠡࡥࡲࡲࡹࡧࡩ࡯ࡧࡧࠤ࡮ࡴࠠࡵࡪࡨࠤ࡙ࡒࡖ࠯ౖࠢࠥࠦࠧ")
        return self._1ll1lll111_opy_
    def __init__(self, secret):
        l1l11l_opy_ (u"ࠤࠥࠦࠥࡈࡵࡪ࡮ࡧࠤࡹ࡮ࡥࠡࡖࡏ࡚࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡤࡼࡸࡪࡹ࡬ࡪ࡭ࡨࠤࡸ࡫ࡣࡳࡧࡷ࠾࡚ࠥࡨࡦࠢࡶ࡬ࡦࡸࡥࡥࠢࡶࡩࡨࡸࡥࡵ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢ౗")
        try:
            _ = struct.pack(l1l11l_opy_ (u"ࠪ࠵ࡸ࠭ౘ"), secret[:1])
        except Exception:
            raise TypeError(l1l11l_opy_ (u"ࠫࡸ࡫ࡣࡳࡧࡷࠤࡸ࡮࡯ࡶ࡮ࡧࠤࡧ࡫ࠠࡣࡻࡷࡩࡸࡲࡩ࡬ࡧ࠯ࠤ࡮ࡹࠠࡼࡿࠪౙ")
                            .format(type(secret)))
        if len(secret) != 32:
            raise ValueError(l1l11l_opy_ (u"ࠬࡹࡥࡤࡴࡨࡸࠥࡹࡨࡰࡷ࡯ࡨࠥࡨࡥࠡࡲࡵࡩࡨ࡯ࡳࡦ࡮ࡼࠤ࠸࠸ࠠࡣࡻࡷࡩࡸ࠲ࠠࡪࡵࠣࡿࢂ࠭ౚ")
                             .format(len(secret)))
        self._1ll1lll111_opy_ = secret
    def serialize(self):
        return self._1ll1lll111_opy_
    @classmethod
    def deserialize(cls, l111l1llll_opy_):
        if len(l111l1llll_opy_) != 32:
            raise ValueError(l111l1llll_opy_)
        return cls(l111l1llll_opy_)
class EncryptionInfoTLV(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠨࠢࠣࠢࡄࠤ࡙ࡒࡖࠡࡨࡲࡶࠥࡧࠠ࡮ࡧࡶࡷࡦ࡭ࡥࠡࡧࡱࡧࡷࡿࡰࡵ࡫ࡲࡲࠥ࡮ࡥࡢࡦࡨࡶࠏࠦࠠࠡࠢࠥࠦࠧ౛")
    l1l11llll1_opy_ = 251
    def __repr__(self):
        return l1l11l_opy_ (u"ࠧ࠽ࡇࡱࡧࡷࡿࡰࡵ࡫ࡲࡲࡎࡴࡦࡰࡖࡏ࡚࠿ࠦࡳࡦࡰࡧࡩࡷࡃࡻࡾࠢࡷ࡭ࡲ࡫࠽ࡼࡿࠣࡩࡳࡩࡲࡺࡲࡷࡩࡩࡃࡻࡾࠢࡦࡳࡺࡴࡴࡦࡴࡀࡿࢂࡄࠧ౜")\
            .format(self.sender.gid_val,
                    self.timestamp,
                    self.encrypted,
                    self.counter)
    def __eq__(self, other):
        return isinstance(other, EncryptionInfoTLV)\
            and self.sender.gid_val == other.sender.gid_val\
            and self.sender.gid_type == other.sender.gid_type\
            and self.timestamp == other.timestamp\
            and self.encrypted == other.encrypted\
            and self.counter == other.counter\
            and self.message_id == other.message_id
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __init__(self, sender, timestamp, encrypted, counter, message_id):
        l1l11l_opy_ (u"ࠣࠤࠥࠤࡈࡸࡥࡢࡶࡨࠤࡦࡴࠠࡆࡰࡦࡶࡾࡶࡴࡪࡱࡱࡍࡳ࡬࡯ࡕࡎ࡙࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡴࡧࡱࡨࡪࡸ࠺ࠡࡖ࡫ࡩࠥࡹࡥ࡯ࡦࡨࡶࠥࡵࡦࠡࡶ࡫ࡩࠥࡳࡥࡴࡵࡤ࡫ࡪ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡷࡽࡵ࡫ࠠࡴࡧࡱࡨࡪࡸ࠺ࠡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌࡏࡄࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴ࠿ࠦࡔࡩࡧࠣࡸ࡮ࡳࡥࠡࡶࡲࠤࡦࡹࡳࡰࡥ࡬ࡥࡹ࡫ࠠࡸ࡫ࡷ࡬ࠥࡺࡨࡦࠢࡰࡩࡸࡹࡡࡨࡧ࠱ࠤ࡚ࡹࡥࡥࠢࡩࡳࡷࠦ࡯ࡳࡦࡨࡶ࡮ࡴࡧ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡹࡿࡰࡦࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴ࠿ࠦࡩ࡯ࡶࠣࡳࡷࠦࡤࡢࡶࡨࡸ࡮ࡳࡥ࠯ࡦࡤࡸࡪࡺࡩ࡮ࡧࠣࡳࡷࠦࡴࡶࡲ࡯ࡩࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡢࡰࡱ࡯ࠤࡪࡴࡣࡳࡻࡳࡸࡪࡪ࠺࡙ࠡ࡫ࡩࡹ࡮ࡥࡳࠢࡷ࡬ࡪࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡪࡵࠣࡩࡳࡩࡲࡺࡲࡷࡩࡩ࠴ࠠࡏࡱࡷࡩ࠿ࠦࡔࡩ࡫ࡶࠤࡻࡧ࡬ࡶࡧࠣ࡭ࡸࠦࡣࡶࡴࡵࡩࡳࡺ࡬ࡺࠢ࡬࡫ࡳࡵࡲࡦࡦࠣࡻ࡭࡫࡮ࠡࡲࡤࡧࡰ࡯࡮ࡨࠢࡤࠤ࡙ࡒࡖ࠭ࠢࡤࡲࡩࠦࡩࡴࠢࡳࡶࡪࡹࡥ࡯ࡶࠣ࡭ࡳࠦࡴࡩ࡫ࡶࠤࡨࡵ࡮ࡴࡶࡵࡹࡨࡺ࡯ࡳࠢࡩࡳࡷࠦࡲࡦࡲࡵࡩࡸ࡫࡮ࡵ࡫ࡱ࡫ࠥࡺࡨࡦࠢࡹࡥࡱࡻࡥࠡࡴࡨࡥࡩࠦࡦࡳࡱࡰࠤࡦࠦࡤࡦࡸ࡬ࡧࡪ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡ࡫ࡱࡸࠥࡩ࡯ࡶࡰࡷࡩࡷࡀࠠࡕࡪࡨࠤ࡮ࡴࡤࡦࡺࠣ࡭ࡳࡺ࡯ࠡࡶ࡫ࡩࠥࡹࡨࡢࡴࡨࡨࠥࡹࡥࡤࡴࡨࡸࠥࡺࡨࡢࡶࠣࡧࡦࡳࡥࠡࡣ࡯ࡳࡳ࡭ࠠࡸ࡫ࡷ࡬ࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨ࠲ࠥࡔ࡯ࡵࡧ࠽ࠤ࡙࡮ࡩࡴࠢࡹࡥࡱࡻࡥࠡ࡫ࡶࠤࡨࡻࡲࡳࡧࡱࡸࡱࡿࠠࡪࡩࡱࡳࡷ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡰࡢࡥ࡮࡭ࡳ࡭ࠠࡢࠢࡗࡐ࡛࠲ࠠࡢࡰࡧࠤ࡮ࡹࠠࡱࡴࡨࡷࡪࡴࡴࠡ࡫ࡱࠤࡹ࡮ࡩࡴࠢࡦࡳࡳࡹࡴࡳࡷࡦࡸࡴࡸࠠࡧࡱࡵࠤࡷ࡫ࡰࡳࡧࡶࡩࡳࡺࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡷࡣ࡯ࡹࡪࠦࡲࡦࡣࡧࠤ࡫ࡸ࡯࡮ࠢࡤࠤࡩ࡫ࡶࡪࡥࡨ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡩ࡯ࡶࠣࡱࡪࡹࡳࡢࡩࡨࡣ࡮ࡪ࠺ࠡࡖ࡫ࡩࠥࡳࡥࡴࡵࡤ࡫ࡪࠦࡉࡅ࠮ࠣࡪࡴࡸࠠࡴࡷࡳࡴࡴࡸࡴࡪࡰࡪࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡸࡥࡴࡧࡱࡨࠥࡪࡥࡥࡷࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠳ࠦࡕ࡯ࡷࡶࡩࡩࠦࡨࡦࡴࡨ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠯࠰ࠣࡲࡴࡺࡥࠡ࠼ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡕࡪ࡬ࡷࠥࡵࡢ࡫ࡧࡦࡸࠥ࡮࡯࡭ࡦࡶࠤࡹ࡮ࡥࠡࡶ࡬ࡱࡪࡹࡴࡢ࡯ࡳࠤ࡮ࡴࡴࡦࡴࡱࡥࡱࡲࡹࠡࡣࡶࠤࡦࠦ࡮ࡢ࡫ࡹࡩࠥࡀࡰࡺ࠼ࡦࡰࡦࡹࡳ࠻ࡢࡧࡥࡹ࡫ࡴࡪ࡯ࡨ࠲ࡩࡧࡴࡦࡶ࡬ࡱࡪࡦࠠࡰࡤ࡭ࡩࡨࡺࠠࡵࡪࡤࡸࠥ࡯ࡳࠡࡣࡶࡷࡺࡳࡥࡥࠢࡷࡳࠥ࡮࡯࡭ࡦ࡙࡙ࠣࡉ࠮ࠡࡋࡩࠤࡹ࡮ࡥࠡࡢࡣࡸ࡮ࡳࡥࡴࡶࡤࡱࡵࡦࡠࠡࡣࡵ࡫ࡺࡳࡥ࡯ࡶࠣ࡭ࡸࠦࡡ࡯ࠢࡤࡻࡦࡸࡥࠡ࠼ࡳࡽ࠿ࡩ࡬ࡢࡵࡶ࠾ࡥࡪࡡࡵࡧࡷ࡭ࡲ࡫࠮ࡥࡣࡷࡩࡹ࡯࡭ࡦࡢࠣ࡭ࡹࠦࡷࡪ࡮࡯ࠤࡧ࡫ࠠࡤࡱࡱࡺࡪࡸࡴࡦࡦࠣࡸࡴࠦࡕࡕࡅ࠱ࠤࡎ࡬ࠠࡵࡪࡨࠤࡥࡦࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࡢࡣࠤࡦࡸࡧࡶ࡯ࡨࡲࡹࠦࡩࡴࠢࡤࠤࡳࡧࡩࡷࡧࠣ࠾ࡵࡿ࠺ࡤ࡮ࡤࡷࡸࡀࡠࡥࡣࡷࡩࡹ࡯࡭ࡦ࠰ࡧࡥࡹ࡫ࡴࡪ࡯ࡨࡤ࠱ࠦࡡ࡯ࠢ࡬ࡲࡹ࠲ࠠࡰࡴࠣࡥࠥࡺࡩ࡮ࡧ࠰ࡸࡺࡶ࡬ࡦࠢ࡬ࡸࠥࡽࡩ࡭࡮ࠣࡦࡪࠦࡡࡴࡵࡸࡱࡪࡪࠠࡵࡱࠣࡦࡪࠦࡡ࡭ࡴࡨࡥࡩࡿࠠࡪࡰ࡙࡙ࠣࡉ࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠲࠳ࠦ࡮ࡰࡶࡨࠤ࠿ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡘ࡭ࡵࡵࡨࡪࠣࡸ࡭࡫ࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠣ࡭ࡸࠦࡨࡦ࡮ࡧࠤ࡮ࡴࡴࡦࡴࡱࡥࡱࡲࡹࠡࡣࡶࠤࡦࠦ࠺ࡱࡻ࠽ࡧࡱࡧࡳࡴ࠼ࡣࡨࡦࡺࡥࡵ࡫ࡰࡩ࠳ࡪࡡࡵࡧࡷ࡭ࡲ࡫ࡠ࠭ࠢ࡬ࡸࡸࠦࡳࡦࡴ࡬ࡥࡱ࡯ࡺࡢࡶ࡬ࡳࡳࠦࡤࡰࡧࡶࠤࡳࡵࡴࠡࡣ࡯ࡰࡴࡽࠠࡪࡶࠣࡸࡴࠦࡰࡳࡧࡶࡩࡷࡼࡥࠡࡶ࡫ࡩࠥ࡬ࡵ࡭࡮ࠣࡴࡷ࡫ࡣࡪࡵ࡬ࡳࡳࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡴࡺࡲࡨ࠲࡚ࠥ࡯ࠡ࡯ࡤ࡯ࡪࠦࡴࡩ࡫ࡶࠤࡲࡵࡲࡦࠢࡲࡦࡻ࡯࡯ࡶࡵ࠯ࠤࡹ࡮ࡥࠡ࡯࡬ࡧࡷࡵࡳࡦࡥࡲࡲࡩࠦࡦࡪࡧ࡯ࡨࠥࡽࡩ࡭࡮ࠣࡦࡪࠦࡳࡵࡴ࡬ࡴࡵ࡫ࡤࠡࡨࡵࡳࡲࠦࡴࡩࡧࠣࡳࡧࡰࡥࡤࡶࠣࡻ࡭࡫࡮ࠡ࡫ࡷࠤ࡮ࡹࠠࡱࡣࡶࡷࡪࡪࠠࡪࡰࡷࡳࠥࡺࡨࡪࡵࠣࡪࡺࡴࡣࡵ࡫ࡲࡲ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠰࠱ࠤࡳࡵࡴࡦࠢ࠽ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡋࡩࠤࡦࠦ࠺ࡱࡻ࠽ࡧࡱࡧࡳࡴ࠼ࡣࡸ࡮ࡳࡥ࠯ࡵࡷࡶࡺࡩࡴࡠࡶ࡬ࡱࡪࡦࠠࡰࡴࠣࡤࡥࡺࡵࡱ࡮ࡨࡤࡥࠦࡥࡲࡷ࡬ࡺࡦࡲࡥ࡯ࡶࠣ࡭ࡸࠦࡰࡢࡵࡶࡩࡩࠦࡩ࡯ࠢࡷࡳࠥࡺࡨࡪࡵࠣࡪࡺࡴࡣࡵ࡫ࡲࡲ࠱ࠦࡥ࡯ࡵࡸࡶࡪࠦࡴࡩࡣࡷࠤ࡮ࡺࠠࡪࡵࠣ࡭ࡳࠦࡕࡕࡅࠣࡪ࡮ࡸࡳࡵ࠰ࠣࡘ࡭࡫ࠠࡤࡱࡱࡷࡹࡸࡵࡤࡶࡲࡶࠥࡩ࡯࡯ࡸࡨࡶࡹࡹࠠࡪࡶࠣࡸࡴࠦࡡࠡ࠼ࡳࡽ࠿ࡩ࡬ࡢࡵࡶ࠾ࡥࡪࡡࡵࡧࡷ࡭ࡲ࡫࠮ࡥࡣࡷࡩࡹ࡯࡭ࡦࡢࠣࡦࡾࠦࡰࡢࡵࡶ࡭ࡳ࡭ࠠࡪࡶࠣࡸ࡭ࡸ࡯ࡶࡩ࡫ࠤ࠿ࡶࡹ࠻࡯ࡨࡸ࡭ࡀࡠࡵ࡫ࡰࡩ࠳ࡳ࡫ࡵ࡫ࡰࡩࡥࠦࡡ࡯ࡦࠣ࠾ࡵࡿ࠺࡮ࡧࡷ࡬࠿ࡦࡤࡢࡶࡨࡸ࡮ࡳࡥ࠯ࡦࡤࡸࡪࡺࡩ࡮ࡧ࠱ࡹࡹࡩࡦࡳࡱࡰࡸ࡮ࡳࡥࡴࡶࡤࡱࡵࡦࠬࠡࡹ࡫࡭ࡨ࡮ࠠ࡮ࡧࡤࡲࡸࠦࡴࡩࡣࡷࠤࡹ࡮ࡥࠡࡸࡤࡰࡺ࡫ࠠ࡮ࡣࡼࠤࡨ࡮ࡡ࡯ࡩࡨࠤࡸࡻࡲࡱࡴ࡬ࡷ࡮ࡴࡧ࡭ࡻ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣౝ")
        if isinstance(sender, goTenna.settings.GID):
            self.sender = sender
        else:
            raise TypeError(sender)
        self._1lll11111l_opy_ = goTenna.util.time_from_various(timestamp)
        l1lll111l1l_opy_ = datetime.timedelta(microseconds=self._1lll11111l_opy_.microsecond)
        self._1lll11111l_opy_ = self._1lll11111l_opy_ - l1lll111l1l_opy_
        self.encrypted = bool(encrypted)
        self.counter = int(counter)
        self.message_id = int(message_id)
    @property
    def time(self):
        l1l11l_opy_ (u"ࠤࠥࠦࠥࡇࠠࡱࡴࡲࡴࡪࡸࡴࡺࠢࡵࡩࡹࡻࡲ࡯࡫ࡱ࡫ࠥࡺࡨࡦࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠥࡧࡳࠡࡣࠣࡴࡷࡵࡰࡦࡴࠣࡨࡦࡺࡥࡵ࡫ࡰࡩ࠳ࡪࡡࡵࡧࡷ࡭ࡲ࡫࠮ࠡࠤࠥࠦ౞")
        return self._1lll11111l_opy_
    @property
    def timestamp(self):
        l1l11l_opy_ (u"ࠥࠦࠧࠦࡁࠡࡲࡵࡳࡵ࡫ࡲࡵࡻࠣࡶࡪࡺࡵࡳࡰ࡬ࡲ࡬ࠦࡴࡩࡧࠣࡸ࡮ࡳࡥࡴࡶࡤࡱࡵࠦࡡࡴࠢࡤࠤࡕࡵࡳࡪࡺࠣࡩࡵࡵࡣࡩࠢࡷ࡭ࡲ࡫ࡣࡰࡦࡨ࠲ࠥࠨࠢࠣ౟")
        return int((self._1lll11111l_opy_\
                    - datetime.datetime.utcfromtimestamp(0)).total_seconds())
    @classmethod
    def deserialize(cls, l111l1llll_opy_):
        if len(l111l1llll_opy_) == 15:
            fields = struct.unpack(l1l11l_opy_ (u"ࠫࠦࡈࡑࡊࡊࠪౠ"), l111l1llll_opy_)
        elif len(l111l1llll_opy_) == 16:
            fields = struct.unpack(l1l11l_opy_ (u"ࠬࠧࡂࡒࡋࡋࡆࠬౡ"), l111l1llll_opy_)
        else:
            err = l1l11l_opy_ (u"࠭ࡉ࡯ࡸࡤࡰ࡮ࡪࠠࡕࡎ࡙ࠤࡱ࡫࡮ࡨࡶ࡫ࠤࢀࢃࠠࡧࡱࡵࠤࡪࡴࡣࡳࡻࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࡪࡴ࠲ࠠࡥࡣࡷࡥࠥࢁࡽࠨౢ")\
                  .format(len(l111l1llll_opy_),
                          goTenna.util.display_bytestring(l111l1llll_opy_))
            cls.l111l1lll1_opy_().warning(err)
            raise IndexError(err)
        return cls(goTenna.settings.GID(fields[1],
                                        goTenna.settings.GID.PRIVATE),
                   fields[2], fields[0], fields[3],
                   fields[4] if len(fields) > 4 else 0)
    def serialize(self):
        return struct.pack(l1l11l_opy_ (u"ࠧࠢࡄࡔࡍࡍࡈࠧౣ"), self.encrypted,
                           self.sender.gid_val,
                           self.timestamp, self.counter, self.message_id)
class FrequencySlotDataBandwidthTLV(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠣࠤࠥࠤࡆࠦࡔࡍࡘࠣࡪࡴࡸࠠࡴࡧࡱࡨ࡮ࡴࡧࠡࡨࡵࡩࡶࡻࡥ࡯ࡥࡼࠤࡸࡲ࡯ࡵࡵ࠱ࠎࠏࠦࠠࠡࠢࡆࡹࡷࡸࡥ࡯ࡶ࡯ࡽࠥࡺࡨࡪࡵࠣࡳࡳࡲࡹࠡࡪࡲࡰࡩࡹࠠࡵࡪࡨࠤࡨ࡮ࡡ࡯ࡰࡨࡰࠥࡳࡡࡴ࡭ࠣࡻ࡮ࡪࡴࡩ࠮ࠣࡥࡳࡪࠠࡥࡱࡨࡷࠥࡴ࡯ࡵࠢࡶࡴࡪࡩࡩࡧࡻࠣࡥࠥࡨࡩࡵࡴࡤࡸࡪ࠴ࠠࡘࡪࡨࡲࠥࡺࡨࡦࠢࡖࡈࡐࠦࡰࡢࡴࡶࡩࡸࠦ࡯࡯ࡧࠣࡳ࡫ࠦࡴࡩࡧࡶࡩ࡚ࠥࡌࡗࡵࠣࡪࡷࡵ࡭ࠡࡶ࡫ࡩࠥࡳࡥࡴࡵࡤ࡫ࡪ࠲ࠠࡪࡶࠣࡻ࡮ࡲ࡬ࠡࡦࡨࡪࡦࡻ࡬ࡵࠢࡷࡳࠥࡻࡳࡪࡰࡪࠤࡹ࡮ࡥࠡࡪ࡬࡫࡭࡫ࡲࠡࡤ࡬ࡸࡷࡧࡴࡦࠢࡤࡷࡸࡵࡣࡪࡣࡷࡩࡩࠦࡷࡪࡶ࡫ࠤࡹ࡮ࡥࠡ࡯ࡤࡷࡰ࠴ࠊࠡࠢࠣࠤࠧࠨࠢ౤")
    l1l11llll1_opy_ = 29
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __init__(self, l1lll11l11l_opy_):
        if isinstance(l1lll11l11l_opy_, goTenna.constants.Bandwidth):
            self._1lll1l111l_opy_ = l1lll11l11l_opy_
        elif isinstance(l1lll11l11l_opy_, int):
            self._1lll1l111l_opy_ = goTenna.constants.BANDWIDTH_KHZ[l1lll11l11l_opy_]
        else:
            raise TypeError(l1l11l_opy_ (u"ࠩࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠥࡳࡵࡴࡶࠣࡦࡪࠦࡥࡪࡶ࡫ࡩࡷࠦࡧࡰࡖࡨࡲࡳࡧ࠮ࡤࡱࡱࡷࡹࡧ࡮ࡵࡵ࠱ࡆࡦࡴࡤࡸ࡫ࡧࡸ࡭ࠦ࡯ࡳࠢࡤࡲࠥ࡯࡮ࡵࠢ࡬ࡲࡩ࡫ࡸࠡ࡫ࡱࡸࡴࠦࡧࡰࡖࡨࡲࡳࡧ࠮ࡤࡱࡱࡷࡹࡧ࡮ࡵࡵ࠱ࡆࡦࡴࡤࡸ࡫ࡧࡸ࡭࠲ࠠࡪࡵࠣࡿࢂ࠭౥")
                            .format(type(l1lll11l11l_opy_)))
    @property
    def bandwidth(self):
        return self._1lll1l111l_opy_
    def serialize(self):
        return struct.pack(l1l11l_opy_ (u"ࠪࠥࡎ࠭౦"), self._1lll1l111l_opy_.index)
    @classmethod
    def deserialize(cls, value):
        return cls(struct.unpack(l1l11l_opy_ (u"ࠫࠦࡏࠧ౧"), value)[0])
    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and self.bandwidth == other.bandwidth
    def __repr__(self):
        return l1l11l_opy_ (u"ࠬࡂࡻࡾ࠼ࠣࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭ࡃࡻࡾࡀࠪ౨").format(self.__class__.__name__, self.bandwidth)
class FrequencySlotMaxPowerTLV(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠨࠢࠣࠢࡄࠤ࡙ࡒࡖࠡࡨࡲࡶࠥ࡬ࡲࡦࡳࡸࡩࡳࡩࡹࠡࡵ࡯ࡳࡹࠦࡰࡰࡹࡨࡶࠏࠦࠠࠡࠢࠥࠦࠧ౩")
    l1l11llll1_opy_ = 25
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __init__(self, power):
        if not goTenna.constants.POWERLEVELS.valid(power):
            raise ValueError(l1l11l_opy_ (u"ࠧࡱࡱࡺࡩࡷࠦࡳࡩࡱࡸࡰࡩࠦࡢࡦࠢࡤࠤࡲ࡫࡭ࡣࡧࡵࠤࡴ࡬ࠠࡨࡱࡗࡩࡳࡴࡡ࠯ࡥࡲࡲࡸࡺࡡ࡯ࡶࡶ࠲ࡕࡕࡗࡆࡔࡏࡉ࡛ࡋࡌࡔ࠮ࠣ࡭ࡸࠦࡻࡾࠩ౪")
                             .format(power))
        self._1lll11ll1l_opy_ = power
    @property
    def power(self):
        return self._1lll11ll1l_opy_
    def serialize(self):
        value = {goTenna.constants.POWERLEVELS.HALF_W: 0.5,
                 goTenna.constants.POWERLEVELS.ONE_W: 1.0,
                 goTenna.constants.POWERLEVELS.TWO_W: 2.0,
                 goTenna.constants.POWERLEVELS.FIVE_W: 5.0}[self._1lll11ll1l_opy_]
        return struct.pack(l1l11l_opy_ (u"ࠨࠣࡧࠫ౫"), value)
    @classmethod
    def deserialize(cls, value):
        l1llllll1ll_opy_ = struct.unpack(l1l11l_opy_ (u"ࠩࠤࡨࠬ౬"), value)[0]
        l1lll1l11l1_opy_ = 0
        if l1llllll1ll_opy_ < 0.0:
            raise ValueError(l1l11l_opy_ (u"ࠪࡦࡦࡪࠠࡱࡱࡺࡩࡷࠦࡵ࡯ࡲࡤࡧࡰ࡫ࡤࠡࡨࡵࡳࡲࠦࡴ࡭ࡸࠣࠬࡳ࡫ࡧࡢࡶ࡬ࡺࡪ࠯࠺ࠡࡽࢀࠫ౭")
                             .format(l1llllll1ll_opy_))
        elif l1llllll1ll_opy_ < 0.75:
            l1lll1l11l1_opy_ = goTenna.constants.POWERLEVELS.HALF_W
        elif l1llllll1ll_opy_ < 1.5:
            l1lll1l11l1_opy_ = goTenna.constants.POWERLEVELS.ONE_W
        elif l1llllll1ll_opy_ < 3.5:
            l1lll1l11l1_opy_ = goTenna.constants.POWERLEVELS.TWO_W
        elif l1llllll1ll_opy_ < 6:
            l1lll1l11l1_opy_ = goTenna.constants.POWERLEVELS.FIVE_W
        else:
            raise ValueError(l1l11l_opy_ (u"ࠫࡧࡧࡤࠡࡲࡲࡻࡪࡸࠠࡶࡰࡳࡥࡨࡱࡥࡥࠢࡩࡶࡴࡳࠠࡵ࡮ࡹࠤ࠭ࡺ࡯ࡰࠢ࡯ࡥࡷ࡭ࡥࠪ࠼ࠣࡿࢂ࠭౮")
                             .format(value))
        return cls(l1lll1l11l1_opy_)
    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and self.power == other.power
    def __repr__(self):
        return l1l11l_opy_ (u"ࠬࡂࡻࡾ࠼ࠣࡴࡴࡽࡥࡳ࠿ࡾࢁࡃ࠭౯")\
            .format(self.__class__.__name__,
                    goTenna.constants.POWERLEVELS.name(self.power))
class FrequencySlotFrequencyListTLV(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠨࠢࠣࠢࡄࠤ࡙ࡒࡖࠡࡪࡲࡰࡩ࡯࡮ࡨࠢࡦ࡬ࡦࡴ࡮ࡦ࡮ࠣࡪࡷ࡫ࡱࡶࡧࡱࡧ࡮࡫ࡳࠋࠢࠣࠤࠥࠨࠢࠣ౰")
    l1l11llll1_opy_ = 26
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __init__(self, control_freqs, data_freqs):
        l1l11l_opy_ (u"ࠢࠣࠤࠣࡆࡺ࡯࡬ࡥࠢࡷ࡬ࡪࠦࡦࡳࡧࡴࡹࡪࡴࡣࡺࠢ࡯࡭ࡸࡺ࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡰ࡮ࡹࡴ࡜࡫ࡱࡸࡢࠦࡣࡰࡰࡷࡶࡴࡲ࡟ࡧࡴࡨࡵࡸࡀࠠࡂࠢ࡯࡭ࡸࡺࠠࡰࡨࠣࡧࡴࡴࡴࡳࡱ࡯ࠤ࡫ࡸࡥࡲࡷࡨࡲࡨ࡯ࡥࡴ࠰ࠣࡉࡦࡩࡨࠡ࡯ࡸࡷࡹࠦࡰࡢࡵࡶࠤ࠿ࡶࡹ࠻࡯ࡨࡸ࡭ࡀࡠࡨࡱࡗࡩࡳࡴࡡ࠯ࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡖࡋ࡙ࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡷࡣ࡯࡭ࡩࡧࡴࡦࡡࡩࡶࡪࡷࡠ࠯ࠢࡗ࡬ࡪࡸࡥࠡࡵ࡫ࡳࡺࡲࡤࠡࡤࡨࠤࡦࡺࠠ࡭ࡧࡤࡷࡹࠦ࡯࡯ࡧࠣࡥࡳࡪࠠࡧࡧࡺࡩࡷࠦࡴࡩࡣࡱࠤࡹ࡮ࡲࡦࡧ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡲࡩࡴࡶ࡞࡭ࡳࡺ࡝ࠡࡦࡤࡸࡦࡥࡦࡳࡧࡴࡷ࠿ࠦࡁࠡ࡮࡬ࡷࡹࠦ࡯ࡧࠢࡧࡥࡹࡧࠠࡧࡴࡨࡵࡺ࡫࡮ࡤ࡫ࡨࡷ࠳ࠦࡅࡢࡥ࡫ࠤࡲࡻࡳࡵࠢࡳࡥࡸࡹࠠ࠻ࡲࡼ࠾ࡲ࡫ࡴࡩ࠼ࡣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡒࡇࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡺࡦࡲࡩࡥࡣࡷࡩࡤ࡬ࡲࡦࡳࡣ࠲࡚ࠥࡨࡦࡴࡨࠤࡸ࡮࡯ࡶ࡮ࡧࠤࡧ࡫ࠠࡢࡶࠣࡰࡪࡧࡳࡵࠢࡲࡲࡪࠦࡡ࡯ࡦࠣࡰࡪࡹࡳࠡࡶ࡫ࡥࡳࠦ࠱࠶࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡢ࡫ࡶࡩࡸࠦࡔࡺࡲࡨࡉࡷࡸ࡯ࡳ࠼ࠣࡍ࡫ࠦࡡ࡯ࡻࠣࡪࡷ࡫ࡱࡶࡧࡱࡧࡾࠦ࡯ࡳࠢ࡯࡭ࡸࡺࠠࡰࡨࠣࡪࡷ࡫ࡱࡶࡧࡱࡧ࡮࡫ࡳࠡ࡫ࡶࠤࡹ࡮ࡥࠡࡹࡵࡳࡳ࡭ࠠࡵࡻࡳࡩ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡤ࡭ࡸ࡫ࡳࠡࡘࡤࡰࡺ࡫ࡅࡳࡴࡲࡶ࠿ࠦࡉࡧࠢࡤࡲࡾࠦࡦࡳࡧࡴࡹࡪࡴࡣࡺࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡹࡥࡱ࡯ࡤ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨ౱")
        control_freqs = list(map(int, control_freqs))
        data_freqs = list(map(int, data_freqs))
        def l1ll1llll1l_opy_(l1l11l111_opy_):
            l1lll1l1l1l_opy_ = []
            for f in l1l11l111_opy_:
                if not goTenna.settings.RFSettings.validate_freq(f):
                    l1lll1l1l1l_opy_.append(f)
            return l1lll1l1l1l_opy_
        l1lll1l1lll_opy_ = l1ll1llll1l_opy_(control_freqs)
        if l1lll1l1lll_opy_:
            raise ValueError(l1l11l_opy_ (u"ࠨࡥࡲࡲࡹࡸ࡯࡭ࠢࡩࡶࡪࡷࡳࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡹࡥࡱ࡯ࡤ࠭ࠢࡾࢁࠥࡧࡲࡦࠢࡱࡳࡹ࠭౲")
                             .format(l1lll1l1lll_opy_))
        l1lll111l11_opy_ = l1ll1llll1l_opy_(data_freqs)
        if l1lll111l11_opy_:
            raise ValueError(l1l11l_opy_ (u"ࠩࡧࡥࡹࡧࠠࡧࡴࡨࡵࡸࠦ࡭ࡶࡵࡷࠤࡧ࡫ࠠࡷࡣ࡯࡭ࡩ࠲ࠠࡼࡿࠣࡥࡷ࡫ࠠ࡯ࡱࡷࠫ౳")
                             .format(l1lll111l11_opy_))
        self._1ll1lllll1_opy_ = control_freqs
        self._1lll111ll1_opy_ = data_freqs
    @property
    def data_freqs(self):
        l1l11l_opy_ (u"ࠥࠦࠧࠦࡔࡩࡧࠣࡨࡦࡺࡡࠡࡨࡵࡩࡶࡻࡥ࡯ࡥ࡬ࡩࡸ࠴ࠠࡡࡢ࡯࡭ࡸࡺ࡛ࡪࡰࡷࡡࡥࡦ࠮ࠡࠤࠥࠦ౴")
        return self._1lll111ll1_opy_
    @property
    def control_freqs(self):
        l1l11l_opy_ (u"ࠦࠧࠨࠠࡕࡪࡨࠤࡨࡵ࡮ࡵࡴࡲࡰࠥ࡬ࡲࡦࡳࡸࡩࡳࡩࡩࡦࡵ࠱ࠤࡥࡦ࡬ࡪࡵࡷ࡟࡮ࡴࡴ࡞ࡢࡣ࠲ࠥࠨࠢࠣ౵")
        return self._1ll1lllll1_opy_
    def serialize(self):
        to_return = six.b(l1l11l_opy_ (u"ࠬ࠭౶"))
        for freq in self._1ll1lllll1_opy_:
            to_return += struct.pack(l1l11l_opy_ (u"࠭ࠡࡃࡄࡌࠫ౷"), 1, 1, freq)
        for freq in self._1lll111ll1_opy_:
            to_return += struct.pack(l1l11l_opy_ (u"ࠧࠢࡄࡅࡍࠬ౸"), 0, 1, freq)
        return to_return
    @classmethod
    def deserialize(cls, value):
        l1ll1llll11_opy_ = int(len(value) / 6)
        control_freqs = []
        data_freqs = []
        for chan in range(l1ll1llll11_opy_):
            l1ll1lll11l_opy_, _, freq = struct.unpack(l1l11l_opy_ (u"ࠨࠣࡅࡆࡎ࠭౹"),
                                             value[chan*6:(chan+1)*6])
            if l1ll1lll11l_opy_:
                control_freqs.append(freq)
            else:
                data_freqs.append(freq)
        return cls(control_freqs, data_freqs)
    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and self.control_freqs == other.control_freqs\
            and self.data_freqs == other.data_freqs
    def __repr__(self):
        return l1l11l_opy_ (u"ࠩ࠿ࡿࢂࡀࠠࡤࡱࡱࡸࡷࡵ࡬ࡠࡨࡵࡩࡶࡹ࠽ࡼࡿ࠯ࠤࡩࡧࡴࡢࡡࡩࡶࡪࡷࡳ࠾ࡽࢀࡂࠬ౺")\
            .format(self.__class__.__name__,
                    self.control_freqs,
                    self.data_freqs)
class FrequencySlotNameTLV(basic_tlv.l1111lll1l_opy_):
    l1l11l_opy_ (u"ࠥࠦࠧࠦࡁࠡࡖࡏ࡚ࠥ࡮࡯࡭ࡦ࡬ࡲ࡬ࠦࡴࡩࡧࠣࡲࡦࡳࡥࠡࡱࡩࠤࡦࠦࡳ࡭ࡱࡷࠤࡸ࡫ࡴ࠯ࠌࠣࠤࠥࠦࠢࠣࠤ౻")
    l1l11llll1_opy_ = 27
    MAX_LENGTH = 32
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    @property
    def l1111llll1_opy_(self):
        return self.MAX_LENGTH
    @property
    def name(self):
        l1l11l_opy_ (u"ࠦࠧࠨࠠࡕࡪࡨࠤࡹ࡯ࡴ࡭ࡧࠣࡥࡸࡹ࡯ࡤ࡫ࡤࡸࡪࡪࠠࡸ࡫ࡷ࡬ࠥࡺࡨࡦࠢࡗࡐ࡛ࠦࠢࠣࠤ౼")
        return self.contents
class FrequencySlotIDTLV(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠧࠨࠢࠡࡃࠣࡘࡑ࡜ࠠࡩࡱ࡯ࡨ࡮ࡴࡧࠡࡣࡱࠤࡎࡊࠠࡧࡱࡵࠤࡦࠦࡳ࡭ࡱࡷࠤࡸ࡫ࡴ࠯ࠌࠍࠤࠥࠦࠠࡕࡪࡨࠤࡎࡊࠠࡪࡵࠣ࡭ࡳࡺࡥ࡯ࡦࡨࡨࠥࡺ࡯ࠡࡤࡨࠤࡦࠦࡕࡖࡋࡇࠤࡦࡴࡤࠡࡶ࡫ࡹࡸࠦࡳࡩࡱࡸࡰࡩࠦࡢࡦࠢࡥࡽࡹ࡫ࡳ࡭࡫࡮ࡩ࠳ࠐࠠࠡࠢࠣࠦࠧࠨ౽")
    l1l11llll1_opy_ = 28
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __init__(self, id_bytes):
        l1l11l_opy_ (u"ࠨࠢࠣࠢࡅࡹ࡮ࡲࡤࠡࡶ࡫ࡩࠥ࡬ࡲࡦࡳࡸࡩࡳࡩࡹࠡࡵ࡯ࡳࡹࠦࡉࡅ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡨࡹࡵࡧࡶࡰ࡮ࡱࡥࠡ࡫ࡧࡣࡧࡿࡴࡦࡵ࠽ࠤ࡙࡮ࡥࠡࡤࡼࡸࡪࡹ࡬ࡪ࡭ࡨࠤࡎࡊࠠࠩࡧ࠱࡫࠳ࠦࡡࠡࡗࡘࡍࡉ࠯࠮ࠡ࠵࠹ࠤࡧࡿࡴࡦࡵࠣࡱࡦࡾ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡦ࡯ࡳࡦࡵࠣࡘࡾࡶࡥࡆࡴࡵࡳࡷࡀࠠࡊࡨࠣࡤࡥ࡯ࡤࡠࡤࡼࡸࡪࡹࡠࡡࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡥࡽࡹ࡫ࡳ࡭࡫࡮ࡩ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡤ࡭ࡸ࡫ࡳࠡࡘࡤࡰࡺ࡫ࡅࡳࡴࡲࡶ࠿ࠦࡉࡧࠢࡣࡤ࡮ࡪ࡟ࡣࡻࡷࡩࡸࡦࡠࠡ࡫ࡶࠤࡲࡵࡲࡦࠢࡷ࡬ࡦࡴࠠ࠴࠸ࠣࡦࡾࡺࡥࡴࠢ࡯ࡳࡳ࡭ࠬࠡࡱࡵࠤࡪࡳࡰࡵࡻࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢ౾")
        try:
            _ = struct.pack(l1l11l_opy_ (u"ࠧ࠲ࡵࠪ౿"), id_bytes[:1])
        except Exception:
            raise TypeError(l1l11l_opy_ (u"ࠨ࡫ࡧࡣࡧࡿࡴࡦࡵࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡦࡪࠦࡢࡺࡶࡨࡷࡱ࡯࡫ࡦ࠮ࠣ࡭ࡸࠦࡻࡾࠩಀ")
                            .format(type(id_bytes)))
        if not id_bytes or len(id_bytes) > 36:
            raise ValueError(l1l11l_opy_ (u"ࠩ࡬ࡨࡤࡨࡹࡵࡧࡶࠤࡸ࡮࡯ࡶ࡮ࡧࠤࡧ࡫ࠠࡣࡧࡷࡻࡪ࡫࡮ࠡ࠲ࠣࡥࡳࡪࠠ࠴࠸ࠣࡦࡾࡺࡥࡴ࠮ࠣ࡭ࡸࠦࡻࡾࠩಁ")
                             .format(len(id_bytes)))
        self._id = id_bytes
    @property
    def id_bytes(self):
        return self._id
    def serialize(self):
        return self._id
    @classmethod
    def deserialize(cls, value):
        return cls(value)
    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and other.id_bytes == self.id_bytes
    def __repr__(self):
        return l1l11l_opy_ (u"ࠪࡀࢀࢃ࠺ࠡ࡫ࡧࡣࡧࡿࡴࡦࡵࡀࡿࢂࡄࠧಂ").format(self.__class__.__name__,
                                          goTenna.util.display_bytestring(self.id_bytes))
class FrequencySlotCallSignTLV(basic_tlv.l1111lll1l_opy_):
    l1l11l_opy_ (u"ࠦࠧࠨࠠࡂࠢࡗࡐ࡛ࠦࡦࡰࡴࠣࡥࠥ࡬ࡲࡦࡳࡸࡩࡳࡩࡹࠡࡵ࡯ࡳࡹࡹࠠࡴࡪࡲࡶࡹࠦࡣࡢ࡮࡯ࠤࡸ࡯ࡧ࡯࠰ࠍࠤࠥࠦࠠࠣࠤࠥಃ")
    l1l11llll1_opy_ = 48
    MAX_LENGTH = 32
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    @property
    def l1111llll1_opy_(self):
        return self.MAX_LENGTH
    @property
    def callsign(self):
        l1l11l_opy_ (u"ࠧࠨࠢࠡࡖ࡫ࡩࠥࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠣࡪࡴࡸࠠࡵࡪࡨࠤ࡫ࡸࡥࡲࡷࡨࡲࡨࡿࠠࡴ࡮ࡲࡸࡸ࠴ࠠࠣࠤࠥ಄")
        return self.contents
class FrequencySlotDataTLV(basic_tlv.l1111ll1ll_opy_):
    l1l11l_opy_ (u"ࠨࠢࠣࠢࡗ࡬ࡪࠦࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠢࡗࡐ࡛ࠦࡦࡰࡴࠣࡪࡷ࡫ࡱࡶࡧࡱࡧࡾࠦࡳ࡭ࡱࡷࡷ࠳ࠦࠢࠣࠤಅ")
    l1l11llll1_opy_ = 24
    l111ll1111_opy_ = (FrequencySlotMaxPowerTLV,
                           FrequencySlotFrequencyListTLV,
                           FrequencySlotNameTLV,
                           FrequencySlotIDTLV,
                           FrequencySlotDataBandwidthTLV,
                           FrequencySlotCallSignTLV)
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    @property
    def l1111l1l11_opy_(self):
        return self.l111ll1111_opy_
class PerimeterTitleTLV(basic_tlv.l1111lll1l_opy_):
    l1l11l_opy_ (u"ࠢࠣࠤࠣࡅ࡚ࠥࡌࡗࠢࡩࡳࡷࠦࡨࡶ࡯ࡤࡲࠥࡸࡥࡢࡦࡤࡦࡱ࡫ࠠࡱࡧࡵ࡭ࡲ࡫ࡴࡦࡴࠣࡸ࡮ࡺ࡬ࡦࡵࠍࠤࠥࠦࠠࠣࠤࠥಆ")
    l1l11llll1_opy_ = 31
    MAX_LENGTH = 32
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    @property
    def l1111llll1_opy_(self):
        return self.MAX_LENGTH
    @property
    def title(self):
        l1l11l_opy_ (u"ࠣࠤࠥࠤ࡙࡮ࡥࠡࡶ࡬ࡸࡱ࡫ࠠࡢࡵࡶࡳࡨ࡯ࡡࡵࡧࡧࠤࡼ࡯ࡴࡩࠢࡷ࡬ࡪࠦࡔࡍࡘࠣࠦࠧࠨಇ")
        return self.contents
class PerimeterPointsTLV(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠤࠥࠦࠥࡇࠠࡕࡎ࡙ࠤ࡫ࡵࡲࠡࡶ࡫ࡩࠥࡶ࡯ࡪࡰࡷࡷࠥࡳࡡ࡬࡫ࡱ࡫ࠥࡻࡰࠡࡣࠣࡴࡪࡸࡩ࡮ࡧࡷࡩࡷࠐࠠࠡࠢࠣࠦࠧࠨಈ")
    l1l11llll1_opy_ = 32
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    @property
    def points(self):
        l1l11l_opy_ (u"ࠥࠦࠧࠦࡔࡩࡧࠣࡷࡪࡷࡵࡦࡰࡦࡩࠥࡵࡦࠡ࡯ࡤࡴࠥࡶ࡯ࡪࡰࡷࡷࠥ࡮ࡥ࡭ࡦࠣࡦࡾࠦࡴࡩࡧࠣࡸࡱࡼࠠࠣࠤࠥಉ")
        return self._points
    def __eq__(self, other):
        return isinstance(other, PerimeterPointsTLV)\
            and self.points == other.points
    def __repr__(self):
        return l1l11l_opy_ (u"ࠫࡁࢁࡽࠡࡲࡲ࡭ࡳࡺࡳ࠾ࡽࢀࡂࠬಊ").format(self.__class__.__name__, self.points)
    def __init__(self, points):
        l1l11l_opy_ (u"ࠧࠨࠢࠡࡄࡸ࡭ࡱࡪࠠࡵࡪࡨࠤࡕ࡫ࡲࡪ࡯ࡨࡸࡪࡸࡐࡰ࡫ࡱࡸࡸ࡚ࡌࡗ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤ࡚ࠥࡨࡪࡵࠣࡘࡑ࡜ࠠࡦࡰࡦࡳࡲࡶࡡࡴࡵࡨࡷࠥࡧࠠ࡭࡫ࡶࡸࠥࡵࡦࠡࡲࡲ࡭ࡳࡺࡳࠡࡣࡶࠤ࠭ࡲࡡࡵ࡫ࡷࡹࡩ࡫ࠬࠡ࡮ࡲࡲ࡬࡯ࡴࡶࡦࡨ࠭ࠥࡶ࡯ࡪࡰࡷࡷࠥࡏࡴࠡࡥࡤࡲࠥ࡮࡯࡭ࡦࠣࡹࡵࠦࡴࡰࠢ࠻ࠤࡸࡻࡣࡩࠢࡳࡳ࡮ࡴࡴࡴ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡶ࡯ࡪࡰࡷࡷ࠿ࠦࡔࡩࡧࠣࡴࡴ࡯࡮ࡵࡵࠣࡥࡸࠦࡡࠡ࡮࡬ࡷࡹࠦ࡯ࡧࠢࠫࡰࡦࡺࠬࠡ࡮ࡲࡲ࡬࠯ࠠࡱࡣ࡬ࡶࡸ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡷࡽࡵ࡫ࠠࡱࡱ࡬ࡲࡹࡹ࠺ࠡ࡮࡬ࡷࡹࡡࡴࡶࡲ࡯ࡩࡠ࡬࡬ࡰࡣࡷ࠰ࠥ࡬࡬ࡰࡣࡷࡡࡢࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡤ࡭ࡸ࡫ࡳࠡࡘࡤࡰࡺ࡫ࡅࡳࡴࡲࡶ࠿ࠦࡉࡧࠢࡷ࡬ࡪࡸࡥࠡࡣࡵࡩࠥࡺ࡯ࡰࠢࡰࡥࡳࡿࠠࡱࡱ࡬ࡲࡹࡹࠠࡰࡴࠣ࡭࡫ࠦࡴࡩࡧࠣࡴࡴ࡯࡮ࡵࡵࠣࡥࡷ࡫ࠠ࡮ࡣ࡯ࡪࡴࡸ࡭ࡦࡦ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣಋ")
        if len(points) > 8:
            raise ValueError
        for p in points:
            if len(p) != 2:
                raise ValueError
            if not all([isinstance(pi, float) for pi in p]):
                raise TypeError
        self._points = points
    @classmethod
    def deserialize(cls, value):
        points = []
        for i in range(0, len(value), 16):
            points.append(struct.unpack(l1l11l_opy_ (u"࠭ࠡࡥࡦࠪಌ"), value[i:i+16]))
        return cls(points)
    def serialize(self):
        l1lll1l1ll1_opy_ = l1l11l_opy_ (u"ࠧࠢࠩ಍") + l1l11l_opy_ (u"ࠨࡦࡧࠫಎ")*len(self._points)
        l1lll1111ll_opy_ = [p for l1llllll1l_opy_ in self._points for p in l1llllll1l_opy_]
        return struct.pack(l1lll1l1ll1_opy_, *l1lll1111ll_opy_)
class TextTLV(basic_tlv.l1111lll1l_opy_):
    l1l11l_opy_ (u"ࠤࠥࠦࠥࡇࠠࡕࡎ࡙ࠤ࡫ࡵࡲࠡࡪࡲࡰࡩ࡯࡮ࡨࠢࡰࡩࡸࡹࡡࡨࡧࠣࡸࡪࡾࡴࠋࠢࠣࠤࠥࠨࠢࠣಏ")
    l1l11llll1_opy_ = 4
    MAX_LENGTH = goTenna.constants.MAXLENGTH
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    @property
    def l1111llll1_opy_(self):
        return self.MAX_LENGTH
class PerimeterColorTLV(basic_tlv.l111l1ll11_opy_):
    l1l11llll1_opy_ = 33
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
class PerimeterDataTLV(basic_tlv.l1111ll1ll_opy_):
    l1l11l_opy_ (u"ࠥࠦࠧࠦࡁࠡࡖࡏ࡚ࠥ࡫࡮ࡤࡣࡳࡷࡺࡲࡡࡵ࡫ࡱ࡫ࠥࡶࡥࡳ࡫ࡰࡩࡹ࡫ࡲࠡࡦࡤࡸࡦ࠴ࠊࠋࠢࠣࠤ࡚ࠥࡨࡪࡵࠣ࡭ࡸࠦࡵࡴࡧࡧࠤࡦࡹࠠࡢࠢࡦࡳࡳࡺࡡࡪࡰࡨࡶࠥ࡬࡯ࡳࠢࡲࡸ࡭࡫ࡲࠡࡲࡨࡶ࡮ࡳࡥࡵࡧࡵ࠱ࡷ࡫࡬ࡢࡶࡨࡨ࡚ࠥࡌࡗࡵ࠱ࠤࡔࡴ࡬ࡺࠢࡦࡩࡷࡺࡡࡪࡰࠣࡘࡑ࡜ࡳࠡࡣࡵࡩࠥࡧ࡬࡭ࡱࡺࡩࡩࠦࡴࡰࠢࡥࡩࠥࡶࡲࡦࡵࡨࡲࡹࠦࡩ࡯ࠢࡓࡩࡷ࡯࡭ࡦࡶࡨࡶࡉࡧࡴࡢ࠽ࠣࡸ࡭࡫ࡹࠡࡣࡵࡩࠥࡺࡨࡦࠢࡦࡰࡦࡹࡳࡦࡵࠣࡰ࡮ࡹࡴࡦࡦࠣ࡭ࡳࠦ࠺ࡱࡻ࠽ࡥࡹࡺࡲ࠻ࡢࡓࡩࡷ࡯࡭ࡦࡶࡨࡶࡉࡧࡴࡢࡖࡏ࡚࠳ࡇࡃࡄࡇࡓࡘࡆࡈࡌࡆࡡࡆࡓࡓ࡚ࡅࡏࡖࡖࡤ࠳ࠐࠠࠡࠢࠣࠦࠧࠨಐ")
    l1l11llll1_opy_ = 30
    l111ll1111_opy_ = (PerimeterTitleTLV, MapIDTLV,
                           PerimeterColorTLV, PerimeterPointsTLV)
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    @property
    def l1111l1l11_opy_(self):
        return self.l111ll1111_opy_
class RouteTitleTLV(basic_tlv.l1111lll1l_opy_):
    l1l11l_opy_ (u"ࠦࠧࠨࠠࡂࠢࡗࡐ࡛ࠦࡦࡰࡴࠣ࡬ࡺࡳࡡ࡯ࠢࡵࡩࡦࡪࡡࡣ࡮ࡨࠤࡷࡵࡵࡵࡧࠣࡸ࡮ࡺ࡬ࡦࡵࠍࠤࠥࠦࠠࠣࠤࠥ಑")
    l1l11llll1_opy_ = 35
    MAX_LENGTH = 32
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    @property
    def l1111llll1_opy_(self):
        return self.MAX_LENGTH
    @property
    def title(self):
        l1l11l_opy_ (u"ࠧࠨࠢࠡࡖ࡫ࡩࠥࡺࡩࡵ࡮ࡨࠤࡴ࡬ࠠࡵࡪࡨࠤࡷࡵࡵࡵࡧࠣࠦࠧࠨಒ")
        return self.contents
class RoutePointsTLV(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠨࠢࠣࠢࡄࠤ࡙ࡒࡖࠡࡨࡲࡶࠥࡺࡨࡦࠢࡳࡳ࡮ࡴࡴࡴࠢࡰࡥࡰ࡯࡮ࡨࠢࡸࡴࠥࡧࠠࡳࡱࡸࡸࡪࠐࠠࠡࠢࠣࠦࠧࠨಓ")
    l1l11llll1_opy_ = 36
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __repr__(self):
        return l1l11l_opy_ (u"ࠧ࠽ࡽࢀࠤࡵࡵࡩ࡯ࡶࡶࡁࢀࢃ࠾ࠨಔ").format(self.__class__.__name__, self.points)
    def __eq__(self, other):
        return isinstance(other, RoutePointsTLV) and self.points == other.points
    @property
    def points(self):
        l1l11l_opy_ (u"ࠣࠤࠥࠤ࡙࡮ࡥࠡࡲࡲ࡭ࡳࡺࡳࠡࡥࡲࡲࡹࡧࡩ࡯ࡧࡧࠤ࡮ࡴࠠࡵࡪࡨࠤ࡙ࡒࡖࠡࠤࠥࠦಕ")
        return self._points
    def __init__(self, points):
        l1l11l_opy_ (u"ࠤࠥࠦࠥࡈࡵࡪ࡮ࡧࠤࡦࠦࡒࡰࡷࡷࡩࡕࡵࡩ࡯ࡶࡶࠤ࡙ࡒࡖ࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡱ࡯ࡳࡵ࡝ࡷࡹࡵࡲࡥ࡜ࡨ࡯ࡳࡦࡺࠬࠡࡨ࡯ࡳࡦࡺ࡝࡞ࠢࡳࡳ࡮ࡴࡴࡴ࠼ࠣࡘ࡭࡫ࠠࡱࡱ࡬ࡲࡹࡹࠬࠡࡣࡶࠤ࠭ࡲࡡࡵ࡫ࡷࡹࡩ࡫ࠬࠡ࡮ࡲࡲ࡬࡯ࡴࡶࡦࡨ࠭ࠥࡶࡡࡪࡴࡶ࠲ࠥࡓࡡࡹ࡫ࡰࡹࡲࠦ࠸࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷࡧࡩࡴࡧࡶࠤ࡛ࡧ࡬ࡶࡧࡈࡶࡷࡵࡲ࠻ࠢࡌࡪࠥࡺࡨࡦࡴࡨࠤࡦࡸࡥࠡࡶࡲࡳࠥࡳࡡ࡯ࡻࠣࡴࡴ࡯࡮ࡵࡵࠣࡳࡷࠦࡩࡧࠢࡤࡲࡾࠦࡰࡰ࡫ࡱࡸࡸࠦࡡࡳࡧࠣࡱࡦࡲࡦࡰࡴࡰࡩࡩ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥࡴࠢࡗࡽࡵ࡫ࡅࡳࡴࡲࡶ࠿ࠦࡉࡧࠢࡤࡲࡾࡺࡨࡪࡰࡪࠤ࡮ࡹࠠࡵࡪࡨࠤࡼࡸ࡯࡯ࡩࠣࡸࡾࡶࡥ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨಖ")
        if len(points) > 8:
            raise ValueError
        for p in points:
            if len(p) != 2:
                raise ValueError
            if not all([isinstance(pi, float) for pi in p]):
                raise TypeError
        self._points = points
    @classmethod
    def deserialize(cls, value):
        points = []
        for i in range(0, len(value), 16):
            points.append(struct.unpack(l1l11l_opy_ (u"ࠪࠥࡩࡪࠧಗ"), value[i:i+16]))
        return cls(points)
    def serialize(self):
        l1ll1ll1lll_opy_ = l1l11l_opy_ (u"ࠫࠦ࠭ಘ") + l1l11l_opy_ (u"ࠬࡪࡤࠨಙ") * len(self.points)
        return struct.pack(l1ll1ll1lll_opy_,
                           *[p for l1llllll1l_opy_ in self.points for p in l1llllll1l_opy_])
class RouteColorTLV(basic_tlv.l111l1ll11_opy_):
    l1l11l_opy_ (u"ࠨࠢࠣࠢࡄࠤ࡙ࡒࡖࠡࡨࡲࡶࠥࡺࡨࡦࠢࡦࡳࡱࡵࡲࠡࡶ࡫ࡩࠥࡸ࡯ࡶࡶࡨࠤࡸ࡮࡯ࡶ࡮ࡧࠤࡧ࡫ࠠࡥ࡫ࡶࡴࡱࡧࡹࡦࡦࠣࡻ࡮ࡺࡨࠋࠢࠣࠤࠥࠨࠢࠣಚ")
    l1l11llll1_opy_ = 37
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
class RouteDataTLV(basic_tlv.l1111ll1ll_opy_):
    l1l11l_opy_ (u"ࠢࠣࠤࠣࡅ࡚ࠥࡌࡗࠢࡨࡲࡨࡧࡰࡴࡷ࡯ࡥࡹ࡯࡮ࡨࠢࡵࡳࡺࡺࡥࠡࡦࡤࡸࡦࠐࠠࠡࠢࠣࠦࠧࠨಛ")
    l1l11llll1_opy_ = 34
    l111ll1111_opy_=(MapIDTLV, RouteTitleTLV, RoutePointsTLV, RouteColorTLV)
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    @property
    def l1111l1l11_opy_(self):
        l1l11l_opy_ (u"ࠣࠤࠥࠤ࡙࡮ࡥࠡࡥࡲࡲࡹ࡫࡮ࡵࡵࠣࡳ࡫ࠦࡴࡩࡧࠣࡘࡑ࡜࠮ࠡࠤࠥࠦಜ")
        return self.l111ll1111_opy_
class CircleTitleTLV(basic_tlv.l1111lll1l_opy_):
    l1l11l_opy_ (u"ࠤࠥࠦࠥࡇࠠࡕࡎ࡙ࠤࡨࡵ࡮ࡵࡣ࡬ࡲ࡮ࡴࡧࠡࡶ࡫ࡩࠥࡴࡡ࡮ࡧࠣࡳ࡫ࠦࡡࠡࡥ࡬ࡶࡨࡲࡥ࠯ࠢࠥࠦࠧಝ")
    l1l11llll1_opy_ = 0x28
    MAX_LENGTH = 32
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    @property
    def l1111llll1_opy_(self):
        return self.MAX_LENGTH
    @property
    def title(self):
        l1l11l_opy_ (u"ࠥࠦࠧࠦࡔࡩࡧࠣࡸ࡮ࡺ࡬ࡦࠢࡲࡪࠥࡺࡨࡦࠢࡵࡳࡺࡺࡥࠡࠤࠥࠦಞ")
        return self.contents
class CircleCenterTLV(l1ll1ll1ll1_opy_):
    l1l11l_opy_ (u"ࠦࠧࠨࠠࡂࠢࡊࡔࡘࠦࡰࡰ࡫ࡱࡸࠥࡳࡡࡳ࡭࡬ࡲ࡬ࠦࡴࡩࡧࠣࡧࡪࡴࡴࡦࡴࠣࡳ࡫ࠦࡡࠡࡥ࡬ࡶࡨࡲࡥ࠯ࠢࠥࠦࠧಟ")
    l1l11llll1_opy_ = 0x29
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __init__(self, latitude, longitude):
        l1l11l_opy_ (u"ࠧࠨࠢࠡࡄࡸ࡭ࡱࡪࠠࡵࡪࡨࠤࡈ࡯ࡲࡤ࡮ࡨࡇࡪࡴࡴࡦࡴࡗࡐ࡛࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡩࡰࡴࡧࡴࠡ࡮ࡤࡸ࡮ࡺࡵࡥࡧ࠽ࠤ࡙࡮ࡥࠡ࡮ࡤࡸ࡮ࡺࡵࡥࡧࠣࡳ࡫ࠦࡴࡩࡧࠣࡧࡪࡴࡴࡦࡴ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥ࡬࡬ࡰࡣࡷࠤࡱࡵ࡮ࡨ࡫ࡷࡹࡩ࡫࠺ࠡࡖ࡫ࡩࠥࡲ࡯࡯ࡩ࡬ࡸࡺࡪࡥࠡࡱࡩࠤࡹ࡮ࡥࠡࡥࡨࡲࡹ࡫ࡲ࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡡࡪࡵࡨࡷ࡚ࠥࡹࡱࡧࡈࡶࡷࡵࡲ࠻ࠢࡌࡪࠥࡵ࡮ࡦࠢࡲࡪࠥࡺࡨࡦࠢࡳࡥࡷࡧ࡭ࡴࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡦࡳࡳࡼࡥࡳࡶ࡬ࡦࡱ࡫ࠠࡵࡱࠣࡪࡱࡵࡡࡵ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢಠ")
        l1ll1ll1ll1_opy_.__init__(self, latitude, longitude)
class CircleRadiusTLV(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠨࠢࠣࠢࡗ࡬ࡪࠦࡲࡢࡦ࡬ࡹࡸࠦ࡯ࡧࠢࡤࠤࡨ࡯ࡲࡤ࡮ࡨ࠰ࠥ࡯࡮ࠡ࡯ࡨࡸࡪࡸࡳࠡࠤࠥࠦಡ")
    l1l11llll1_opy_ = 0x2a
    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and self.radius == other.radius
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __init__(self, radius):
        l1l11l_opy_ (u"ࠢࠣࠤࠣࡆࡺ࡯࡬ࡥࠢࡷ࡬ࡪࠦࡲࡢࡦ࡬ࡹࡸࠦࡔࡍࡘ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡦ࡭ࡱࡤࡸࠥࡸࡡࡥ࡫ࡸࡷ࠿ࠦࡔࡩࡧࠣࡶࡦࡪࡩࡶࡵ࠯ࠤ࡮ࡴࠠ࡮ࡧࡷࡩࡷࡹ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡦ࡯ࡳࡦࡵࠣࡘࡾࡶࡥࡆࡴࡵࡳࡷࡀࠠࡊࡨࠣࡸ࡭࡫ࠠࡳࡣࡧ࡭ࡺࡹࠠࡪࡵࠣࡲࡴࡺࠠࡤࡱࡱࡺࡪࡸࡴࡪࡤ࡯ࡩࠥࡺ࡯ࠡࡢࡣࡪࡱࡵࡡࡵࡢࡣ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤಢ")
        try:
            self._radius = int(radius)
        except (ValueError, TypeError):
            raise TypeError(l1l11l_opy_ (u"ࠨࡴࡤࡨ࡮ࡻࡳࠡ࡯ࡸࡷࡹࠦࡢࡦࠢ࡬ࡲࡹ࡫ࡧࡳࡣ࡯࠰ࠥ࡯ࡳࠡࡽࢀࠫಣ")
                            .format(type(radius)))
        self._radius = radius
    @property
    def radius(self):
        l1l11l_opy_ (u"ࠤ࡚ࠥࠦࠥࡨࡦࠢࡵࡥࡩ࡯ࡵࡴࠢࡲࡪࠥࡺࡨࡦࠢࡦ࡭ࡷࡩ࡬ࡦ࠮ࠣ࡭ࡳࠦ࡭ࡦࡶࡨࡶࡸ࠴ࠠࠣࠤࠥತ")
        return self._radius
    def serialize(self):
        return struct.pack(l1l11l_opy_ (u"ࠪࠥࡎ࠭ಥ"), self._radius)
    @classmethod
    def deserialize(cls, value):
        return cls(struct.unpack(l1l11l_opy_ (u"ࠫࠦࡏࠧದ"), value)[0])
class CircleColorTLV(basic_tlv.l111l1ll11_opy_):
    l1l11l_opy_ (u"ࠧࠨࠢࠡࡃࠣࡘࡑ࡜ࠠࡧࡱࡵࠤࡹ࡮ࡥࠡࡥࡲࡰࡴࡸࠠࡢࠢࡦ࡭ࡷࡩ࡬ࡦࠢࡶ࡬ࡴࡻ࡬ࡥࠢࡥࡩࠥࡪࡩࡴࡲ࡯ࡥࡾ࡫ࡤࠡࡣࡶࠤࠧࠨࠢಧ")
    l1l11llll1_opy_ = 0x2B
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
class CircleDataTLV(basic_tlv.l1111ll1ll_opy_):
    l1l11l_opy_ (u"ࠨࠢࠣࠢࡄࠤ࡙ࡒࡖࠡࡧࡱࡧࡦࡶࡳࡶ࡮ࡤࡸ࡮ࡴࡧࠡࡥ࡬ࡶࡨࡲࡥࠡࡦࡤࡸࡦࠐࠠࠡࠢࠣࠦࠧࠨನ")
    l1l11llll1_opy_ = 0x27
    l111ll1111_opy_ = (MapIDTLV,
                           CircleTitleTLV, CircleCenterTLV,
                           CircleRadiusTLV, CircleColorTLV)
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    @property
    def l1111l1l11_opy_(self):
        return self.l111ll1111_opy_
class SquareTitleTLV(basic_tlv.l1111lll1l_opy_):
    l1l11l_opy_ (u"ࠢࠣࠤࠣࡅ࡚ࠥࡌࡗࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡴࡩࡧࠣࡲࡦࡳࡥࠡࡱࡩࠤࡦࠦࡣࡪࡴࡦࡰࡪ࠴ࠠࠣࠤࠥ಩")
    l1l11llll1_opy_ = 0x2D
    MAX_LENGTH = 32
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    @property
    def l1111llll1_opy_(self):
        return self.MAX_LENGTH
    @property
    def title(self):
        l1l11l_opy_ (u"ࠣࠤࠥࠤ࡙࡮ࡥࠡࡶ࡬ࡸࡱ࡫ࠠࡰࡨࠣࡸ࡭࡫ࠠࡳࡱࡸࡸࡪࠦࠢࠣࠤಪ")
        return self.contents
class SquareCornerOneTLV(l1ll1ll1ll1_opy_):
    l1l11l_opy_ (u"ࠤࠥࠦࠥࡇࠠࡈࡒࡖࠤࡵࡵࡩ࡯ࡶࠣࡱࡦࡸ࡫ࡪࡰࡪࠤࡹ࡮ࡥࠡࡨ࡬ࡶࡸࡺࠠࡤࡱࡵࡲࡪࡸࠠࡰࡨࠣࡥࠥࡹࡱࡶࡣࡵࡩ࠳ࠦࠢࠣࠤಫ")
    l1l11llll1_opy_ = 0x2E
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __init__(self, latitude, longitude):
        l1l11l_opy_ (u"ࠥࠦࠧࠦࡂࡶ࡫࡯ࡨࠥࡺࡨࡦࠢࡖࡵࡺࡧࡲࡦࡅࡲࡶࡳ࡫ࡲࡐࡰࡨࡘࡑ࡜࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡪࡱࡵࡡࡵࠢ࡯ࡥࡹ࡯ࡴࡶࡦࡨ࠾࡚ࠥࡨࡦࠢ࡯ࡥࡹ࡯ࡴࡶࡦࡨࠤࡴ࡬ࠠࡵࡪࡨࠤࡨࡵࡲ࡯ࡧࡵࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥ࡬࡬ࡰࡣࡷࠤࡱࡵ࡮ࡨ࡫ࡷࡹࡩ࡫࠺ࠡࡖ࡫ࡩࠥࡲ࡯࡯ࡩ࡬ࡸࡺࡪࡥࠡࡱࡩࠤࡹ࡮ࡥࠡࡥࡲࡶࡳ࡫ࡲࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷࡧࡩࡴࡧࡶࠤ࡙ࡿࡰࡦࡇࡵࡶࡴࡸ࠺ࠡࡋࡩࠤࡴࡴࡥࠡࡱࡩࠤࡹ࡮ࡥࠡࡲࡤࡶࡦࡳࡳࠡ࡫ࡶࠤࡳࡵࡴࠡࡥࡲࡲࡻ࡫ࡲࡵ࡫ࡥࡰࡪࠦࡴࡰࠢࡩࡰࡴࡧࡴ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨಬ")
        l1ll1ll1ll1_opy_.__init__(self, latitude, longitude)
class SquareCornerTwoTLV(l1ll1ll1ll1_opy_):
    l1l11l_opy_ (u"ࠦࠧࠨࠠࡂࠢࡊࡔࡘࠦࡰࡰ࡫ࡱࡸࠥࡳࡡࡳ࡭࡬ࡲ࡬ࠦࡴࡩࡧࠣࡷࡪࡩ࡯࡯ࡦࠣࡧࡴࡸ࡮ࡦࡴࠣࡳ࡫ࠦࡡࠡࡵࡴࡹࡦࡸࡥ࠯ࠢࠥࠦࠧಭ")
    l1l11llll1_opy_ = 0x2F
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __init__(self, latitude, longitude):
        l1l11l_opy_ (u"ࠧࠨࠢࠡࡄࡸ࡭ࡱࡪࠠࡵࡪࡨࠤࡘࡷࡵࡢࡴࡨࡇࡴࡸ࡮ࡦࡴࡗࡻࡴ࡚ࡌࡗ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥ࡬࡬ࡰࡣࡷࠤࡱࡧࡴࡪࡶࡸࡨࡪࡀࠠࡕࡪࡨࠤࡱࡧࡴࡪࡶࡸࡨࡪࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡣࡰࡴࡱࡩࡷࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡧ࡮ࡲࡥࡹࠦ࡬ࡰࡰࡪ࡭ࡹࡻࡤࡦ࠼ࠣࡘ࡭࡫ࠠ࡭ࡱࡱ࡫࡮ࡺࡵࡥࡧࠣࡳ࡫ࠦࡴࡩࡧࠣࡧࡴࡸ࡮ࡦࡴࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡢ࡫ࡶࡩࡸࠦࡔࡺࡲࡨࡉࡷࡸ࡯ࡳ࠼ࠣࡍ࡫ࠦ࡯࡯ࡧࠣࡳ࡫ࠦࡴࡩࡧࠣࡴࡦࡸࡡ࡮ࡵࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡧࡴࡴࡶࡦࡴࡷ࡭ࡧࡲࡥࠡࡶࡲࠤ࡫ࡲ࡯ࡢࡶ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣಮ")
        l1ll1ll1ll1_opy_.__init__(self, latitude, longitude)
class SquareDepthTLV(l1ll1ll1ll1_opy_):
    l1l11l_opy_ (u"ࠨࠢࠣࠢࡄࠤࡌࡖࡓࠡࡲࡲ࡭ࡳࡺࠠ࡮ࡣࡵ࡯࡮ࡴࡧࠡࡣࠣࡴࡴ࡯࡮ࡵࠢࡤࡰࡴࡴࡧࠡࡶ࡫ࡩࠥࡵࡰࡱࡱࡶ࡭ࡹ࡫ࠠࡴ࡫ࡧࡩࠥࡵࡦࠡࡶ࡫ࡩࠥࡹࡱࡶࡣࡵࡩࠥࡧࡳࠡࡥࡲࡶࡳ࡫ࡲࡴࠢ࠴ࠤࡦࡴࡤࠡ࠴ࠣࠦࠧࠨಯ")
    l1l11llll1_opy_ = 0x30
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __init__(self, latitude, longitude):
        l1l11l_opy_ (u"ࠢࠣࠤࠣࡆࡺ࡯࡬ࡥࠢࡷ࡬ࡪࠦࡓࡲࡷࡤࡶࡪࡊࡥࡱࡶ࡫࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡧ࡮ࡲࡥࡹࠦ࡬ࡢࡶ࡬ࡸࡺࡪࡥ࠻ࠢࡗ࡬ࡪࠦ࡬ࡢࡶ࡬ࡸࡺࡪࡥࠡࡱࡩࠤࡹ࡮ࡥࠡࡦࡨࡴࡹ࡮ࠠࡱࡱ࡬ࡲࡹࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡧ࡮ࡲࡥࡹࠦ࡬ࡰࡰࡪ࡭ࡹࡻࡤࡦ࠼ࠣࡘ࡭࡫ࠠ࡭ࡱࡱ࡫࡮ࡺࡵࡥࡧࠣࡳ࡫ࠦࡴࡩࡧࠣࡨࡪࡶࡴࡩࠢࡳࡳ࡮ࡴࡴࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷࡧࡩࡴࡧࡶࠤ࡙ࡿࡰࡦࡇࡵࡶࡴࡸ࠺ࠡࡋࡩࠤࡴࡴࡥࠡࡱࡩࠤࡹ࡮ࡥࠡࡲࡤࡶࡦࡳࡳࠡ࡫ࡶࠤࡳࡵࡴࠡࡥࡲࡲࡻ࡫ࡲࡵ࡫ࡥࡰࡪࠦࡴࡰࠢࡩࡰࡴࡧࡴ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨರ")
        l1ll1ll1ll1_opy_.__init__(self, latitude, longitude)
class SquareColorTLV(basic_tlv.l111l1ll11_opy_):
    l1l11l_opy_ (u"ࠣࠤࠥࠤࡆࠦࡔࡍࡘࠣࡪࡴࡸࠠࡵࡪࡨࠤࡨࡵ࡬ࡰࡴࠣࡥࠥࡹࡱࡶࡣࡵࡩࠥࡹࡨࡰࡷ࡯ࡨࠥࡨࡥࠡࡦ࡬ࡷࡵࡲࡡࡺࡧࡧࠤࡦࡹࠠࠣࠤࠥಱ")
    l1l11llll1_opy_ = 0x31
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
class SquareDataTLV(basic_tlv.l1111ll1ll_opy_):
    l1l11l_opy_ (u"ࠤࠥࠦࠥࡇࠠࡕࡎ࡙ࠤࡪࡴࡣࡢࡲࡶࡹࡱࡧࡴࡪࡰࡪࠤࡸࡷࡵࡢࡴࡨࠤࡩࡧࡴࡢࠌࠣࠤࠥࠦࠢࠣࠤಲ")
    l1l11llll1_opy_ = 0x2C
    l111ll1111_opy_ = (MapIDTLV,
                           SquareTitleTLV, SquareCornerOneTLV,
                           SquareCornerTwoTLV, SquareDepthTLV,
                           SquareColorTLV)
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    @property
    def l1111l1l11_opy_(self):
        return self.l111ll1111_opy_
class PublicKeyDataTLV(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠥࠦࠧࠦࡁࠡࡖࡏ࡚ࠥ࡬࡯ࡳࠢࡳࡹࡧࡲࡩࡤࠢ࡮ࡩࡾࠦࡤࡢࡶࡤࠎࠥࠦࠠࠡࠤࠥࠦಳ")
    l1l11llll1_opy_ = 252
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __eq__(self, other):
        return isinstance(other, PublicKeyDataTLV)\
            and self._key_bytes == other._key_bytes
    def __init__(self, key_bytes):
        l1l11l_opy_ (u"ࠦࠧࠨࠠࡃࡷ࡬ࡰࡩࠦࡡࠡࡒࡸࡦࡱ࡯ࡣࡌࡧࡼࡈࡦࡺࡡࡕࡎ࡙࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡬ࡧࡼࡣࡧࡿࡴࡦࡵ࠽ࠤ࡙࡮ࡥࠡࡥࡲࡲࡹ࡫࡮ࡵࠢࡲࡪࠥࡺࡨࡦࠢ࡮ࡩࡾ࠴ࠠࡔࡪࡲࡹࡱࡪࠠࡣࡧࠣࡰࡪࡹࡳࠡࡶ࡫ࡥࡳࠦࡧࡰࡖࡨࡲࡳࡧ࠮ࡤࡱࡱࡷࡹࡧ࡮ࡵࡵ࠱ࡑࡆ࡞ࡌࡆࡐࡊࡘࡍࠦ࡬ࡰࡰࡪ࠲࡚ࠥࡨࡪࡵࠣࡻ࡮ࡲ࡬ࠡࡤࡨࠤࡸ࡫ࡲࡪࡣ࡯࡭ࡿ࡫ࡤࠡࡦ࡬ࡶࡪࡩࡴ࡭ࡻ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡴࡺࡲࡨࠤࡰ࡫ࡹࡠࡤࡼࡸࡪࡹ࠺ࠡࡤࡼࡸࡪࡧࡲࡳࡣࡼࠤࡴࡸࠠࡣࡻࡷࡩࡸࠦࡤࡦࡲࡨࡲࡩ࡯࡮ࡨࠢࡲࡲࠥࡖࡹࡵࡪࡲࡲࠥࡼࡥࡳࡵ࡬ࡳࡳ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦ಴")
        if len(key_bytes) > goTenna.constants.MAXLENGTH:
            raise ValueError
        self._key_bytes = key_bytes
    @classmethod
    def deserialize(cls, value):
        return cls(value)
    def serialize(self):
        return self.key_bytes
    @property
    def key_bytes(self):
        return self._key_bytes
class SenderInitialsTLV(basic_tlv.l1111lll1l_opy_):
    l1l11l_opy_ (u"ࠧࠨࠢࠡࡃࠣࡘࡑ࡜ࠠࡧࡱࡵࠤ࡭ࡵ࡬ࡥ࡫ࡱ࡫ࠥࡹࡥ࡯ࡦࡨࡶࠥ࡯࡮ࡪࡶ࡬ࡥࡱࡹࠊࠡࠢࠣࠤࠧࠨࠢವ")
    l1l11llll1_opy_ = 3
    MAX_LENGTH = 8
    @property
    def l1111llll1_opy_(self):
        return self.MAX_LENGTH
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
class MessageTypeTLV(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠨࠢࠣࠢࡄࠤ࡙ࡒࡖࠡࡨࡲࡶࠥ࡮࡯࡭ࡦ࡬ࡲ࡬ࠦࡡࠡ࡯ࡨࡷࡸࡧࡧࡦࠢࡷࡽࡵ࡫ࠠࡴࡶࡵ࡭ࡳ࡭ࠊࠡࠢࠣࠤࠧࠨࠢಶ")
    l1l11llll1_opy_ = 1
    def __repr__(self):
        return l1l11l_opy_ (u"ࠧ࠽ࡏࡨࡷࡸࡧࡧࡦࡖࡼࡴࡪ࡚ࡌࡗ࠼ࠣࡸࡾࡶࡥ࠾ࡽࢀࡂࠬಷ").format(self.msgtype)
    def __eq__(self, other):
        return isinstance(other, MessageTypeTLV)\
            and other.msgtype == self.msgtype
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __init__(self, msgtype):
        if not goTenna.constants.LAYER8_MESSAGE_TYPES.valid(msgtype):
            raise ValueError(l1l11l_opy_ (u"ࠨࡋࡱࡺࡦࡲࡩࡥࠢࡰࡩࡸࡹࡡࡨࡧࠣࡸࡾࡶࡥࠡࡽࢀࠫಸ").format(msgtype))
        self.msgtype = msgtype
    @classmethod
    def deserialize(cls, l111l1llll_opy_):
        return cls(goTenna.util.b2s(l111l1llll_opy_))
    def serialize(self):
        return goTenna.util.s2b(self.msgtype)
class ExternalDestinationTLV(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠤࠥࠦࠥࡇࠠࡕࡎ࡙ࠤࡸࡶࡥࡤ࡫ࡩࡽ࡮ࡴࡧࠡࡣࠣࡲࡴࡴ࠭ࡨࡱࡗࡩࡳࡴࡡࠡࡦࡨࡷࡹ࡯࡮ࡢࡶ࡬ࡳࡳࠦࡦࡰࡴࠣࡥࠥࡳࡥࡴࡵࡤ࡫ࡪࠦࠨࡦ࠰ࡪ࠲ࠥࡺࡨࡳࡱࡸ࡫࡭ࠦࡡࠡࡩࡤࡸࡪࡽࡡࡺࠫࠣࠦࠧࠨಹ")
    l1l11llll1_opy_ = 0x41
    def __repr__(self):
        return l1l11l_opy_ (u"ࠪࡀࡊࡾࡴࡦࡴࡱࡥࡱࡊࡥࡴࡶ࡬ࡲࡦࡺࡩࡰࡰࡗࡐ࡛ࡀࠠࡥࡧࡶࡸ࡮ࡴࡡࡵ࡫ࡲࡲࡂࢁࡽ࠿ࠩ಺").format(self.destination)
    def __eq__(self, other):
        return isinstance(other, ExternalDestinationTLV) and self.destination == other.destination
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __init__(self, destination):
        if not isinstance(destination, six.integer_types):
            raise TypeError(l1l11l_opy_ (u"ࠫࡊࡾࡴࡦࡴࡱࡥࡱࠦࡤࡦࡵࡷ࡭ࡳࡧࡴࡪࡱࡱࠤࡦࡸࡥࠡ࡫ࡱࡸࡪ࡭ࡥࡳࡵ࠯ࠤࡧࡻࡴࠡࡦࡨࡷࡹ࡯࡮ࡢࡶ࡬ࡳࡳࠦࡩࡴࠢࡾࢁࠬ಻")
                            .format(type(destination)))
        self.destination = destination
    @classmethod
    def deserialize(cls, l111l1llll_opy_):
        (destination,) = struct.unpack(l1l11l_opy_ (u"ࠬࠧࡑࠨ಼"), l111l1llll_opy_)
        return cls(destination)
    def serialize(self):
        return struct.pack(l1l11l_opy_ (u"࠭ࠡࡒࠩಽ"), self.destination)
class ExternalOriginTLV(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠢࠣࠤࠣࡅ࡚ࠥࡌࡗࠢࡶࡴࡪࡩࡩࡧࡻ࡬ࡲ࡬ࠦࡡࠡࡰࡲࡲ࠲࡭࡯ࡕࡧࡱࡲࡦࠦ࡯ࡳ࡫ࡪ࡭ࡳࠦࡦࡰࡴࠣࡥࠥࡳࡥࡴࡵࡤ࡫ࡪࠦࠨࡦ࠰ࡪ࠲ࠥ࡬ࡲࡰ࡯ࠣࡥࠥ࡭ࡡࡵࡧࡺࡥࡾ࠯ࠠࠣࠤࠥಾ")
    l1l11llll1_opy_ = 0x40
    def __repr__(self):
        return l1l11l_opy_ (u"ࠨ࠾ࡈࡼࡹ࡫ࡲ࡯ࡣ࡯ࡓࡷ࡯ࡧࡪࡰࡗࡐ࡛ࡀࠠࡰࡴ࡬࡫࡮ࡴ࠽ࡼࡿࡁࠫಿ").format(self.origin)
    def __eq__(self, other):
        return isinstance(other, ExternalOriginTLV) and self.origin == other.origin
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __init__(self, origin):
        if not isinstance(origin, six.integer_types):
            raise TypeError(l1l11l_opy_ (u"ࠩࡈࡼࡹ࡫ࡲ࡯ࡣ࡯ࠤࡴࡸࡩࡨ࡫ࡱࡷࠥࡧࡲࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࡶ࠰ࠥࡨࡵࡵࠢࡲࡶ࡮࡭ࡩ࡯ࠢ࡬ࡷࠥࢁࡽࠨೀ")
                            .format(type(origin)))
        self.origin = origin
    @classmethod
    def deserialize(cls, l111l1llll_opy_):
        (origin,) = struct.unpack(l1l11l_opy_ (u"ࠪࠥࡖ࠭ು"), l111l1llll_opy_)
        return cls(origin)
    def serialize(self):
        return struct.pack(l1l11l_opy_ (u"ࠫࠦࡗࠧೂ"), self.origin)
class AdvertisedExternalAddressTLV(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠧࠨࠢࠡࡃࠣࡘࡑ࡜ࠠࡴࡲࡨࡧ࡮࡬ࡹࡪࡰࡪࠤࡹ࡮ࡥࠡࡋࡇࠤࡦࡴࡤࠡࡪࡸࡱࡦࡴࠠࡳࡧࡤࡨࡦࡨ࡬ࡦࠢࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠠࡧࡱࡵࠤࡦࠦ࡮ࡰࡦࡨࠤࡪࡾࡴࡦࡴࡱࡥࡱࠦࡴࡰࠢࡷ࡬ࡪࠦࡧࡰࡖࡨࡲࡳࡧࠠ࡯ࡧࡷࡻࡴࡸ࡫࠯ࠌࠍࠤࠥࠦࠠࡕࡪࡨࠤࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠢࡰࡹࡸࡺࠠࡣࡧࠣࡰࡪࡹࡳࠡࡶ࡫ࡥࡳࠦ࠲࠲࠺ࠣࡦࡾࡺࡥࡴࠢࡨࡲࡨࡵࡤࡦࡦ࠯ࠤࡹ࡮࡯ࡶࡩ࡫ࠤ࡮࡬ࠠ࡮ࡱࡵࡩࠥࡺࡨࡢࡰࠣࡳࡳ࡫ࠠࡕࡎ࡙ࠤ࡮ࡹࠠࡵࡱࠣࡪ࡮ࡺࠠࡪࡰࠣࡥࠥࡶࡡࡺ࡮ࡲࡥࡩࠦࡩࡵࠢࡶ࡬ࡴࡻ࡬ࡥࠢࡳࡶࡴࡨࡡࡣ࡮ࡼࠤࡧ࡫ࠠࡴࡪࡲࡶࡹ࡫ࡲࠡࡶ࡫ࡥࡳࠦࡴࡩࡣࡷ࠲ࠏࠦࠠࠡࠢࠥࠦࠧೃ")
    l1l11llll1_opy_ = 0x3f
    def __repr__(self):
        return l1l11l_opy_ (u"࠭࠼ࡂࡦࡹࡩࡷࡺࡩࡴࡧࡧࡉࡽࡺࡥࡳࡰࡤࡰࡆࡪࡤࡳࡧࡶࡷ࡙ࡒࡖ࠻ࠢࡪ࡭ࡩࡃࡻࡾࠢࡧࡩࡸࡩ࠽ࡼࡿࡁࠫೄ")\
            .format(self.gid, self.description)
    def __eq__(self, other):
        return isinstance(other, AdvertisedExternalAddressTLV)\
            and self.gid == other.gid \
            and self.description == other.description
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __init__(self, gid, description):
        l1l11l_opy_ (u"ࠢࠣࠤࠣࡆࡺ࡯࡬ࡥࠢࡷ࡬ࡪࠦࡔࡍࡘ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡧࡪࡦࠣࡥࡩࡪࡲࡦࡵࡶ࠾࡚ࠥࡨࡦࠢࡨࡼࡹ࡫ࡲ࡯ࡣ࡯ࠤࡌࡏࡄ࠯ࠢࡄࡷࡸࡻ࡭ࡦࡦࠣࡸࡴࠦࡢࡦࠢࡨࡼࡹ࡫ࡲ࡯ࡣ࡯࠰ࠥࡹ࡯ࠡ࡫ࡷࠤࡩࡵࡥࡴࠢࡱࡳࡹࠦ࡮ࡦࡧࡧࠤࡹࡵࠠࡩࡣࡹࡩࠥ࡯ࡴࡴࠢࡣࡤࡻ࡯ࡡࡠࡩࡤࡸࡪࡽࡡࡺࡢࡣࠤࡪࡾࡰ࡭࡫ࡦ࡭ࡹࡲࡹࠡࡵࡨࡸ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡴࡶࡵࠤࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯࠼ࠣࡘ࡭࡫ࠠࡩࡷࡰࡥࡳ࠳ࡲࡦࡣࡧࡥࡧࡲࡥࠡࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡡࡥࡦࡵࡩࡸࡹ࠮ࠡࡏࡸࡷࡹࠦࡢࡦࠢ࡯ࡩࡸࡹࠠࡵࡪࡤࡲࠥ࠸࠱࠹ࠢࡥࡽࡹ࡫ࡳࠡࡧࡱࡧࡴࡪࡥࡥ࠮ࠣࡸ࡭ࡵࡵࡨࡪࠣ࡭࡫ࠦ࡭ࡰࡴࡨࠤࡹ࡮ࡡ࡯ࠢࡷ࡬࡮ࡹࠠࡕࡎ࡙ࠤ࡮ࡹࠠࡵࡱࠣ࡫ࡴࠦࡩ࡯ࠢࡤࠤࡲ࡫ࡳࡴࡣࡪࡩࠥ࡯ࡴࠡࡵ࡫ࡳࡺࡲࡤࠡࡲࡵࡳࡧࡧࡢ࡭ࡻࠣࡦࡪࠦ࡬ࡦࡵࡶ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡳࡣ࡬ࡷࡪࡹࠠࡗࡣ࡯ࡹࡪࡋࡲࡳࡱࡵ࠾ࠥࡏࡦࠡࡶ࡫ࡩࠥࡧࡤࡥࡴࡨࡷࡸࠦࡩࡴࠢ࡬ࡲࡻࡧ࡬ࡪࡦ࠯ࠤࡴࡸࠠࡵࡪࡨࠤࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠢ࡬ࡷࠥ࡯࡮ࡷࡣ࡯࡭ࡩ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦ೅")
        if not isinstance(gid, goTenna.settings.GID):
            raise TypeError(l1l11l_opy_ (u"ࠣࡩ࡬ࡨࠥࡹࡨࡰࡷ࡯ࡨࠥࡨࡥࠡࡣࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡊࡆ࠯ࠤ࡮ࡹࠠࡼࡿࠥೆ")
                            .format(type(gid)))
        if not isinstance(description, (str, goTenna.util.UnicodeType)):
            raise TypeError(l1l11l_opy_ (u"ࠩࡥࡥࡩࠦࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠤࡹࡿࡰࡦ࠼ࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡦࡪࠦࡳࡵࡴࠣࡳࡷࠦࡵ࡯࡫ࡦࡳࡩ࡫ࠠࠩࡱࡱࠤࡵࡿ࠲ࠪ࠮ࠣ࡭ࡸࠦࡻࡾࠩೇ").format(type(description)))
        l1111l1l1l_opy_ = goTenna.util.s2b(description)
        if len(l1111l1l1l_opy_) > goTenna.constants.MAXLENGTH - 10:
            raise ValueError(l1l11l_opy_ (u"ࠥࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠡ࡫ࡶࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬ࠦࠨࡼࡿࡅ࠰ࠥࡳࡡࡹࠢࡾࢁࡇ࠯ࠢೈ")
                             .format(len(l1111l1l1l_opy_),
                                     goTenna.constants.MAXLENGTH - 10))
        self.gid = gid
        self.description = description
    def serialize(self):
        l1lll1l1111_opy_ = goTenna.util.s2b(self.description)
        return struct.pack(l1l11l_opy_ (u"ࠫࠦࡗࡻࡾࡵࠪ೉").format(len(l1lll1l1111_opy_)), self.gid.gid_val, l1lll1l1111_opy_)
    @classmethod
    def deserialize(cls, l111l1llll_opy_):
        l1lll11lll1_opy_, l1ll1lll1ll_opy_ = struct.unpack(l1l11l_opy_ (u"ࠬࠧࡑࡼࡿࡶࠫೊ").format(len(l111l1llll_opy_)-8),
                                        l111l1llll_opy_)
        desc = goTenna.util.b2s(l1ll1lll1ll_opy_)
        return cls(goTenna.settings.GID(l1lll11lll1_opy_, goTenna.settings.GID.PRIVATE), desc)
class BinaryTLV(basic_tlv.TLV):
    l1l11l_opy_ (u"ࠨࠢࠣࠢࡄࠤ࡙ࡒࡖࠡࡵࡳࡩࡨ࡯ࡦࡺ࡫ࡱ࡫ࠥࡺࡨࡦࠢࡌࡈࠥࡧ࡮ࡥࠢ࡫ࡹࡲࡧ࡮ࠡࡴࡨࡥࡩࡧࡢ࡭ࡧࠣࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠡࡨࡲࡶࠥࡧࠠ࡯ࡱࡧࡩࠥ࡫ࡸࡵࡧࡵࡲࡦࡲࠠࡵࡱࠣࡸ࡭࡫ࠠࡨࡱࡗࡩࡳࡴࡡࠡࡰࡨࡸࡼࡵࡲ࡬࠰ࠍࠎࠥࠦࠠࠡࡖ࡫ࡩࠥࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠣࡱࡺࡹࡴࠡࡤࡨࠤࡱ࡫ࡳࡴࠢࡷ࡬ࡦࡴࠠ࠳࠳࠻ࠤࡧࡿࡴࡦࡵࠣࡩࡳࡩ࡯ࡥࡧࡧ࠰ࠥࡺࡨࡰࡷࡪ࡬ࠥ࡯ࡦࠡ࡯ࡲࡶࡪࠦࡴࡩࡣࡱࠤࡴࡴࡥࠡࡖࡏ࡚ࠥ࡯ࡳࠡࡶࡲࠤ࡫࡯ࡴࠡ࡫ࡱࠤࡦࠦࡰࡢࡻ࡯ࡳࡦࡪࠠࡪࡶࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥࡨࡥࠡࡵ࡫ࡳࡷࡺࡥࡳࠢࡷ࡬ࡦࡴࠠࡵࡪࡤࡸ࠳ࠐࠠࠡࠢࠣࠦࠧࠨೋ")
    l1l11llll1_opy_ = 0x55
    def __repr__(self):
        return l1l11l_opy_ (u"ࠧ࠽ࡄ࡬ࡲࡦࡸࡹࡕࡎ࡙࠾ࠥࡨࡩ࡯ࡣࡵࡽࡂࢁࡽ࠿ࠩೌ").format(self.binary)
    def __eq__(self, other):
        return isinstance(other, BinaryTLV)\
            and self.binary == other.binary
    @property
    def l111l1ll1l_opy_(self):
        return self.l1l11llll1_opy_
    def __init__(self, binary):
        l1l11l_opy_ (u"ࠣࠤࠥࠤࡇࡻࡩ࡭ࡦࠣࡸ࡭࡫ࠠࡕࡎ࡙࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡤ࡭ࡸ࡫ࡳࠡࡘࡤࡰࡺ࡫ࡅࡳࡴࡲࡶ࠿ࠦࡉࡧࠢࡷ࡬ࡪࠦ࡬ࡦࡰࡪࡸ࡭ࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡢࡪࡰࡤࡶࡾࠦࡩࡴࠢࡷࡳࡴࠦ࡬ࡰࡰࡪ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤ್")
        if len(binary) > goTenna.constants.MAXLENGTH - 10:
            raise ValueError(l1l11l_opy_ (u"ࠤࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡷࠥࡺ࡯ࡰࠢ࡯ࡳࡳ࡭ࠠࠩࡽࢀࡆ࠱ࠦ࡭ࡢࡺࠣࡿࢂࡈࠩࠣ೎")
                             .format(len(binary),
                                     goTenna.constants.MAXLENGTH - 10))
        if binary:
            try:
                struct.pack(l1l11l_opy_ (u"ࠪ࠵ࡸ࠭೏"), binary[:1])
            except struct.error:
                raise TypeError(l1l11l_opy_ (u"ࠫࡧ࡯࡮ࡢࡴࡼࠤࡸ࡮࡯ࡶ࡮ࡧࠤࡧ࡫ࠠࡣࡻࡷࡩࡸࡲࡩ࡬ࡧ࠯ࠤ࡮ࡹࠠࡼࡿࠪ೐")
                                .format(type(binary)))
        else:
            binary = six.b(l1l11l_opy_ (u"ࠬ࠭೑"))
        self.binary = binary
    def serialize(self):
        return self.binary
    @classmethod
    def deserialize(cls, l111l1llll_opy_):
        return cls(l111l1llll_opy_)
l1l11l_opy_ (u"ࠨࠢࠣࠢࡄࠤࡱ࡯ࡳࡵࠢࡲࡪࠥࡧ࡬࡭ࠢࡷ࡬ࡪࠦࡔࡍࡘࡶࠤࡪࡾࡰࡦࡥࡷࡩࡩࠦࡩ࡯ࠢࡷ࡬ࡪࠦࡴࡰࡲࠣࡰࡪࡼࡥ࡭ࠢࡲࡪࠥࡧࠠࡱࡣࡼࡰࡴࡧࡤࠡࠤࠥࠦ೒")
ALL = [l1lllllll11_opy_ for l1lllllll11_opy_ in vars().values()
       if isinstance(l1lllllll11_opy_, type)
       and issubclass(l1lllllll11_opy_, basic_tlv.TLV)
       and l1lllllll11_opy_.__name__.endswith(l1l11l_opy_ (u"ࠧࡕࡎ࡙ࠫ೓"))]