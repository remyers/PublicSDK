# coding: utf8
import sys
ll_opy_ = sys.version_info [0] == 2
l1llll_opy_ = 2048
l11l1_opy_ = 7
def l1l11l_opy_ (l1l111_opy_):
    global l1_opy_
    l11ll1_opy_ = ord (l1l111_opy_ [-1])
    l1l1l1_opy_ = l1l111_opy_ [:-1]
    l11ll_opy_ = l11ll1_opy_ % len (l1l1l1_opy_)
    l1ll_opy_ = l1l1l1_opy_ [:l11ll_opy_] + l1l1l1_opy_ [l11ll_opy_:]
    if ll_opy_:
        l1l11_opy_ = unicode () .join ([unichr (ord (char) - l1llll_opy_ - (l1l1_opy_ + l11ll1_opy_) % l11l1_opy_) for l1l1_opy_, char in enumerate (l1ll_opy_)])
    else:
        l1l11_opy_ = str () .join ([chr (ord (char) - l1llll_opy_ - (l1l1_opy_ + l11ll1_opy_) % l11l1_opy_) for l1l1_opy_, char in enumerate (l1ll_opy_)])
    return eval (l1l11_opy_)
# Copyright (C) 2018 goTenna, Inc. This file is distributed as part of the
# goTenna USB SDK. See the associated license for more information.
# pylint: disable=line-too-long
l1l11l_opy_ (u"ࠦࠧࠨࠠࡨࡱࡗࡩࡳࡴࡡࠡࡖࡏ࡚ࠥࡹࡵࡣࡲࡤࡧࡰࡧࡧࡦࠌࠍࡘ࡭࡫ࡲࡦࠢࡤࡶࡪࠦࡡࠡࡴࡨࡰࡦࡺࡩࡷࡧ࡯ࡽࠥ࡮ࡵࡨࡧࠣࡥࡲࡵࡵ࡯ࡶࠣࡳ࡫ࠦࡔࡍࡘࡶ࠰ࠥࡺࡨࡢࡶࠣࡳࡨࡩࡡࡴ࡫ࡲࡲࡦࡲ࡬ࡺࠢ࡫ࡥࡻ࡫ࠠࡰࡸࡨࡶࡱࡧࡰࡱ࡫ࡱ࡫ࠥࡏࡄࡴ࠮ࠣࡸ࡭ࡧࡴࠡࡣࡵࡩࠥ࡯࡮ࠡࡵࡨࡺࡪࡸࡡ࡭ࠢࡧ࡭࡫࡬ࡥࡳࡧࡱࡸࠥࡩࡡࡵࡧࡪࡳࡷ࡯ࡥࡴࠢࡥࡳࡹ࡮ࠠࡴࡧࡰࡥࡳࡺࡩࡤࠢࡤࡲࡩࠦࡲࡦ࡮ࡨࡺࡦࡴࡴࠡࡶࡲࠤࡩ࡫ࡶࡦ࡮ࡲࡴࡲ࡫࡮ࡵ࠰ࠣࡘ࡭࡯ࡳࠡࡵࡰࡥࡱࡲࠠࡴࡷࡥࡴࡦࡩ࡫ࡢࡩࡨࠤࡦࡲ࡬ࡰࡹࡶࠤࡺࡹࠠࡵࡱࠣࡨ࡮ࡼࡩࡥࡧࠣࡸ࡭࡫࡭ࠡࡷࡳࠤࡧ࡫ࡴࡸࡧࡨࡲࠥࡧࠠࡤࡱࡸࡴࡱ࡫ࠠࡥ࡫ࡩࡪࡪࡸࡥ࡯ࡶࠣࡴࡱࡧࡣࡦࡵࠣࡷࡴࠦ࡮ࡰࠢ࡬ࡲࡩ࡯ࡶࡪࡦࡸࡥࡱࠦ࡭ࡰࡦࡸࡰࡪࠦࡧࡦࡶࡶࠤࡴࡻࡴࠡࡱࡩࠤ࡭ࡧ࡮ࡥ࠰ࠍࠦࠧࠨૻ")
# pylint: disable=line-too-long
from goTenna.tlv import basic_tlv
from goTenna.tlv import l1l1l11111_opy_
from goTenna.tlv import message_tlv
from goTenna.tlv import payload_tlv