A Python SDK for talking to goTenna hardware connected via USB.


