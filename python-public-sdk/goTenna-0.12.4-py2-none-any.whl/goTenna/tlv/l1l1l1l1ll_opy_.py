# coding: utf8
import sys
l1111_opy_ = sys.version_info [0] == 2
l1lll1_opy_ = 2048
l1ll1_opy_ = 7
def l11ll_opy_ (l1_opy_):
    global l1llll_opy_
    l11l1l_opy_ = ord (l1_opy_ [-1])
    l111l_opy_ = l1_opy_ [:-1]
    l1ll_opy_ = l11l1l_opy_ % len (l111l_opy_)
    l1l1_opy_ = l111l_opy_ [:l1ll_opy_] + l111l_opy_ [l1ll_opy_:]
    if l1111_opy_:
        l1ll1l_opy_ = unicode () .join ([unichr (ord (char) - l1lll1_opy_ - (l1l11_opy_ + l11l1l_opy_) % l1ll1_opy_) for l1l11_opy_, char in enumerate (l1l1_opy_)])
    else:
        l1ll1l_opy_ = str () .join ([chr (ord (char) - l1lll1_opy_ - (l1l11_opy_ + l11l1l_opy_) % l1ll1_opy_) for l1l11_opy_, char in enumerate (l1l1_opy_)])
    return eval (l1ll1l_opy_)
# Copyright (C) 2018 goTenna, Inc. This file is distributed as part of the
# goTenna USB SDK. See the associated license for more information.
# pylint: disable=line-too-long
l11ll_opy_ (u"ࠨࠢࠣࠢࡗ࡬ࡪࠦࡔࡍࡘࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࠦࡴࡰࠢࡦࡳࡳ࡬ࡩࡨࡷࡵࡩࠥࡧࠠࡨࡱࡗࡩࡳࡴࡡࠡࡦࡨࡺ࡮ࡩࡥ࠯ࠌࠍࡘ࡭࡫ࡳࡦࠢࡗࡐ࡛ࡹࠠࡢࡴࡨࠤ࡫ࡵࡲࠡ࡫ࡱࡸࡪࡸ࡮ࡢ࡮ࠣࡹࡸ࡫ࠠࡸࡪࡨࡲࠥࡩ࡯࡯ࡨ࡬࡫ࡺࡸࡩ࡯ࡩࠣࡥࠥࡪࡥࡷ࡫ࡦࡩࡀࠦࡴࡩࡧࡵࡩࠥ࡯ࡳࠡࡰࡲࠤࡳ࡫ࡥࡥࠢࡷࡳࠥࡧࡣࡤࡧࡶࡷࠥࡺࡨࡦ࡯ࠣࡩࡽࡺࡥࡳࡰࡤࡰࡱࡿ࠮ࠡࡖ࡫ࡩࡾࠦࡡࡳࡧࠣࡲࡴࡺࠠࡪࡰࡷࡩࡳࡪࡥࡥࠢࡷࡳࠥࡨࡥࠡࡵࡨࡲࡹࠦࡡࡤࡴࡲࡷࡸࠦࡴࡩࡧࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤࠤࡳ࡫ࡴࡸࡱࡵ࡯࠳ࠦࡔࡰࠢࡶ࡬ࡦࡸࡥࠡࡴࡤࡨ࡮ࡵࠠࡤࡱࡱࡪ࡮࡭ࡵࡳࡣࡷ࡭ࡴࡴࠠࡥࡣࡷࡥ࠱ࠦࡵࡴࡧࠣࡸ࡭࡫ࠠࡢࡲࡳࡶࡴࡶࡲࡪࡣࡷࡩࠥࡳࡥࡴࡵࡤ࡫ࡪ࠴ࠊࠣࠤࠥ૽")
# pylint: enable=line-too-long
import logging
import struct
import itertools
import goTenna.settings
import goTenna.constants
from goTenna.tlv import basic_tlv
_MODULE_LOGGER = logging.getLogger(__name__)
class l1ll111l11_opy_(basic_tlv.TLV):
    l11ll_opy_ (u"ࠢࠣࠤࠣࡘ࡭࡫ࠠࡕࡎ࡙ࠤࡸࡶࡥࡤ࡫ࡩࡽ࡮ࡴࡧࠡࡣࠣࡷࡪࡺࠠࡰࡨࠣࡪࡷ࡫ࡱࡶࡧࡱࡧࡾࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࡹࠠࠣࠤࠥ૾")
    l1l11ll1ll_opy_ = 0x25
    _11111ll11_opy_ = 0x80
    _11111111l_opy_ = 0x01
    def __init__(self, rf_settings):
        l11ll_opy_ (u"ࠣࠤࠥࠤࡇࡻࡩ࡭ࡦࠣࡸ࡭࡫ࠠࡕࡎ࡙ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡧࡰࡖࡨࡲࡳࡧ࠮ࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡕࡊࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸࠦࡲࡧࡡࡶࡩࡹࡺࡩ࡯ࡩࡶ࠾࡚ࠥࡨࡦࠢࡲࡦ࡯࡫ࡣࡵࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡴࡩࡧࠣࡪࡷ࡫ࡱࡶࡧࡱࡧ࡮࡫ࡳࠡࡶࡲࠤࡨࡵ࡮ࡧ࡫ࡪࡹࡷ࡫࠮ࠡࡆࡲࡩࡸࠦ࡮ࡰࡶࠣࡲࡪ࡫ࡤࠡࡶࡲࠤࡧ࡫ࠠࡷࡣ࡯࡭ࡩ࠲ࠠࡴ࡫ࡱࡧࡪࠦࡴࡩ࡫ࡶࠤ࡙ࡒࡖࠡࡦࡲࡩࡸࠦ࡮ࡰࡶࠣࡩࡳࡩ࡯ࡥࡧࠣࡸࡷࡧ࡮ࡴ࡯࡬ࡸࠥࡶ࡯ࡸࡧࡵ࠰ࠥࡨࡵࡵࠢࡰࡹࡸࡺࠠࡤࡱࡱࡸࡦ࡯࡮ࠡࡥࡲࡱࡵࡲࡩࡢࡰࡷࠤ࡫ࡸࡥࡲࡷࡨࡲࡨࡿࠠࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲࠥࡉࡨࡢࡰࡱࡩࡱ࡙ࡰࡦࡥࡗࡐ࡛ࡀࠠࡕࡪࡨࠤࡨࡵ࡮ࡴࡶࡵࡹࡨࡺࡥࡥࠢࡲࡦ࡯࡫ࡣࡵࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨ૿")
        if not isinstance(rf_settings, goTenna.settings.RFSettings):
            raise TypeError(rf_settings)
        if not rf_settings.freqs_valid:
            raise ValueError((rf_settings.control_freqs, rf_settings.data_freqs))
        self.rf_settings = rf_settings
    def __eq__(self, other):
        return isinstance(other, l1ll111l11_opy_)\
            and isinstance(other.rf_settings, goTenna.settings.RFSettings)\
            and self.rf_settings.control_freqs == other.rf_settings.control_freqs\
            and self.rf_settings.data_freqs == other.rf_settings.data_freqs
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        number = int(len(l111l1ll1l_opy_) / 5)
        fmt = l11ll_opy_ (u"ࠩࠤࠫ଀") + l11ll_opy_ (u"ࠪࡍࡇ࠭ଁ")*number
        res = struct.unpack(fmt, l111l1ll1l_opy_)
        l111111ll1_opy_ = itertools.islice(res, 0, len(res), 2)
        flags = itertools.islice(res, 1, len(res), 2)
        l11111l111_opy_ = goTenna.util.izip(l111111ll1_opy_, flags)
        l1111l1111_opy_ = []
        l111111111_opy_ = []
        for l11111l1l1_opy_ in l11111l111_opy_:
            if l11111l1l1_opy_[1] & cls._11111ll11_opy_:
                l1111l1111_opy_.append(l11111l1l1_opy_[0])
            else:
                l111111111_opy_.append(l11111l1l1_opy_[0])
        return cls(goTenna.settings.RFSettings(control_freqs=l1111l1111_opy_,
                                               data_freqs=l111111111_opy_))
    def serialize(self):
        l11111ll1l_opy_ = self.rf_settings.control_freqs + self.rf_settings.data_freqs
        fmt = l11ll_opy_ (u"ࠫࠦ࠭ଂ") + l11ll_opy_ (u"ࠬࡏࡂࠨଃ")*len(l11111ll1l_opy_)
        flags = ([self._11111ll11_opy_ | self._11111111l_opy_]
                 * len(self.rf_settings.control_freqs))\
                + ([self._11111111l_opy_] * len(self.rf_settings.data_freqs))
        args = []
        for elem in goTenna.util.izip(l11111ll1l_opy_, flags):
            args.extend(list(elem))
        return struct.pack(fmt, *args)
class l1ll11111l_opy_(basic_tlv.TLV):
    l11ll_opy_ (u"ࠨࠢࠣࠢࡗࡐ࡛ࠦࡦࡰࡴࠣࡷࡪࡴࡤࡪࡰࡪࠤࡲࡧࡳ࡬ࡵࠣࡥࡳࡪࠠࡣ࡫ࡷࡶࡦࡺࡥࡴࠢࡷࡳࠥࡺࡨࡦࠢࡧࡩࡻ࡯ࡣࡦࠢࡤࡸࠥࡩ࡯࡯ࡨ࡬࡫ࡺࡸࡡࡵ࡫ࡲࡲࠥࡺࡩ࡮ࡧ࠱ࠎࠥࠦࠠࠡࠤࠥࠦ଄")
    l1l11ll1ll_opy_ = 0x26
    def __eq__(self, other):
        return isinstance(other, l1ll11111l_opy_)\
            and self.rate == other.rate and self.mask == other.mask
    def __repr__(self):
        return l11ll_opy_ (u"ࠧ࠽ࡽࢀ࠾ࠥࡳࡡࡴ࡭ࡀࡿࢂࠦࡲࡢࡶࡨࡁࢀࢃ࠾ࠨଅ").format(self.__class__.__name__,
                                              self.mask, self.rate)
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, mask, rate):
        l11ll_opy_ (u"ࠣࠤࠥࠎࠥࠦࠠࠡࠢࠣࠤࠥࡈࡵࡪ࡮ࡧࠤࡦࠦࡓࡦࡶࡐࡥࡸࡱࡒࡢࡶࡨࡘࡑ࡜࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡨࡵ࡮ࡴࡶࡤࡲࡹࡹ࠮ࡎࡣࡶ࡯ࠥࡳࡡࡴ࡭࠽ࠤ࡙࡮ࡥࠡ࡯ࡤࡷࡰࠦࡴࡰࠢࡥࡹ࡮ࡲࡤࠡࡶ࡫ࡩ࡚ࠥࡌࡗࠢࡺ࡭ࡹ࡮࠮ࠡࡏࡸࡷࡹࠦࡢࡦࠢࡤࡲࠥ࡫࡬ࡦ࡯ࡨࡲࡹࠦ࡯ࡧࠢ࠽ࡴࡾࡀࡡࡵࡶࡵ࠾ࡥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡣࡰࡰࡶࡸࡦࡴࡴࡴ࠰ࡐࡅࡘࡑࡓࡡ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡩ࡯࡯ࡵࡷࡥࡳࡺࡳ࠯ࡄ࡬ࡸࡷࡧࡴࡦࠢࡵࡥࡹ࡫࠺ࠡࡖ࡫ࡩࠥࡨࡩࡵࡴࡤࡸࡪࠦࡴࡰࠢࡥࡹ࡮ࡲࡤࠡࡶ࡫ࡩ࡚ࠥࡌࡗࠢࡺ࡭ࡹ࡮࠮ࠡࡏࡸࡷࡹࠦࡢࡦࠢࡤࠤࡻࡧ࡬ࡪࡦࠣࡦ࡮ࡺࡲࡢࡶࡨࠤ࡫ࡵࡲࠡࡶ࡫ࡩࠥ࡭ࡩࡷࡧࡱࠤࡲࡧࡳ࡬࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢଆ")
        if mask not in goTenna.constants.MASKS:
            raise ValueError(l11ll_opy_ (u"ࠩࡐࡥࡸࡱࠠࡼࡿࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡥࠥࡼࡡ࡭࡫ࡧࠤࡲࡧࡳ࡬ࠩଇ").format(mask))
        if not mask.bitrate_allowed(rate):
            raise ValueError(l11ll_opy_ (u"ࠪࡆ࡮ࡺࡲࡢࡶࡨࠤࢀࢃࠠࡪࡵࠣࡲࡴࡺࠠࡢ࡮࡯ࡳࡼ࡫ࡤࠡࡨࡲࡶࠥࡳࡡࡴ࡭ࠣࡿࢂ࠭ଈ")
                             .format(rate, mask))
        self.rate = rate
        self.mask = mask
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        (l11111lll1_opy_, l1111l1ll1_opy_) = struct.unpack(l11ll_opy_ (u"ࠫࠦࡈࡂࠨଉ"), l111l1ll1l_opy_)
        mask = None
        rate = None
        for m in goTenna.constants.MASKS:
            if l11111lll1_opy_ == m.index:
                mask = m
        for b in mask.allowed_bitrates:
            if l1111l1ll1_opy_ == b.index:
                rate = b
        return cls(mask, rate)
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠬࠧࡂࡃࠩଊ"), self.mask.index, self.rate.index)
class l1111111ll_opy_(basic_tlv.TLV):
    l11ll_opy_ (u"ࠨࠢࠣࠢࡗࡐ࡛ࠦࡦࡰࡴࠣ࡭ࡳࡺࡥࡳࡰࡤࡰࠥ࡬ࡡࡶ࡮ࡷࠤ࡮ࡴࡦࡰ࠰ࠍࠤࠥࠦࠠࠣࠤࠥଋ")
    l1l11ll1ll_opy_ = 0x29
    def __repr__(self):
        return l11ll_opy_ (u"ࠧ࠽ࡽࢀ࠾ࠥࢁࡽ࠿ࠩଌ").format(self.__class__.__name__, self.l11111l1ll_opy_)
    def __eq__(self, other):
        return isinstance(other, l1111111ll_opy_)\
            and self.l11111l1ll_opy_ == other.l11111l1ll_opy_
    def __init__(self, l11111l1ll_opy_):
        l11ll_opy_ (u"ࠣࠤࠥࠎࠥࠦࠠࠡࠢࠣࠤࠥࡈࡵࡪ࡮ࡧࠤࡦࠦࡆࡢࡷ࡯ࡸࡎࡴࡦࡰࡖࡏ࡚࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡦ࡬ࡧࡹࠦࡦࡢࡷ࡯ࡸࡤࡧࡴࡵࡴࡶ࠾࡚ࠥࡨࡦࠢࡤࡸࡹࡸࡩࡣࡷࡷࡩࡸࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡦࡢࡷ࡯ࡸ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ଍")
        l1111l111l_opy_ = (l11ll_opy_ (u"ࠩࡩࡥࡺࡲࡴࡠࡲࡦࠫ଎"), l11ll_opy_ (u"ࠪࡪࡦࡻ࡬ࡵࡡ࡯ࡶࠬଏ"), l11ll_opy_ (u"ࠫ࡫ࡧࡵ࡭ࡶࡢࡷࡵ࠭ଐ"), l11ll_opy_ (u"ࠬ࡬ࡡࡶ࡮ࡷࡣࡹࡿࡰࡦࠩ଑"),
                         l11ll_opy_ (u"࠭ࡲ࠱ࠩ଒"), l11ll_opy_ (u"ࠧࡳ࠳ࠪଓ"), l11ll_opy_ (u"ࠨࡴ࠵ࠫଔ"), l11ll_opy_ (u"ࠩࡵ࠷ࠬକ"))
        if not hasattr(l11111l1ll_opy_, l11ll_opy_ (u"ࠪࡣࡤ࡭ࡥࡵ࡫ࡷࡩࡲࡥ࡟ࠨଖ")):
            raise TypeError(l11ll_opy_ (u"ࠫ࡫ࡧࡵ࡭ࡶࡢࡥࡹࡺࡲࡴࠢࡶ࡬ࡴࡻ࡬ࡥࠢࡥࡩࠥࡧࠠࡥ࡫ࡦࡸࡱ࡯࡫ࡦࠩଗ"))
        for key in l1111l111l_opy_:
            if not isinstance(l11111l1ll_opy_[key], int):
                raise TypeError(l11ll_opy_ (u"ࠬࡌࡡࡶ࡮ࡷࠤࡦࡺࡴࡳࡵࠣࡱࡺࡹࡴࠡࡤࡨࠤ࡮ࡴࡴࡴ࠮ࠣࡿࢂࠦࡩࡴࠢࡱࡳࡹ࠭ଘ")
                                .format(key))
            if l11111l1ll_opy_[key] < 0 or l11111l1ll_opy_[key] > 0xffffffff:
                raise ValueError(l11ll_opy_ (u"࠭ࡆࡢࡷ࡯ࡸࠥࡧࡴࡵࡴࡶࠤࡲࡻࡳࡵࠢࡩ࡭ࡹࠦࡩ࡯ࠢ࠶࠶ࠥࡨࡩࡵࡵࠪଙ"))
        self.l11111l1ll_opy_ = l11111l1ll_opy_
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        l1111l1lll_opy_ = struct.unpack(l11ll_opy_ (u"ࠧࠢࡎࡏࡐࡑࡒࡌࡍࡎࠪଚ"), l111l1ll1l_opy_)
        attrs = {
            l11ll_opy_ (u"ࠨࡨࡤࡹࡱࡺ࡟ࡱࡥࠪଛ"): l1111l1lll_opy_[0],
            l11ll_opy_ (u"ࠩࡩࡥࡺࡲࡴࡠ࡮ࡵࠫଜ"): l1111l1lll_opy_[1],
            l11ll_opy_ (u"ࠪࡪࡦࡻ࡬ࡵࡡࡶࡴࠬଝ"): l1111l1lll_opy_[2],
            l11ll_opy_ (u"ࠫ࡫ࡧࡵ࡭ࡶࡢࡸࡾࡶࡥࠨଞ"): l1111l1lll_opy_[3],
            l11ll_opy_ (u"ࠬࡸ࠰ࠨଟ"): l1111l1lll_opy_[4],
            l11ll_opy_ (u"࠭ࡲ࠲ࠩଠ"): l1111l1lll_opy_[5],
            l11ll_opy_ (u"ࠧࡳ࠴ࠪଡ"): l1111l1lll_opy_[6],
            l11ll_opy_ (u"ࠨࡴ࠶ࠫଢ"): l1111l1lll_opy_[7]
        }
        return cls(attrs)
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠩࠤࡐࡑࡒࡌࡍࡎࡏࡐࠬଣ"),
                           self.l11111l1ll_opy_.get(l11ll_opy_ (u"ࠪࡪࡦࡻ࡬ࡵࡡࡳࡧࠬତ"), 0xaaaaaaaa),
                           self.l11111l1ll_opy_.get(l11ll_opy_ (u"ࠫ࡫ࡧࡵ࡭ࡶࡢࡰࡷ࠭ଥ"), 0xaaaaaaaa),
                           self.l11111l1ll_opy_.get(l11ll_opy_ (u"ࠬ࡬ࡡࡶ࡮ࡷࡣࡸࡶࠧଦ"), 0xaaaaaaaa),
                           self.l11111l1ll_opy_.get(l11ll_opy_ (u"࠭ࡦࡢࡷ࡯ࡸࡤࡺࡹࡱࡧࠪଧ"), 0xaaaaaaaa),
                           self.l11111l1ll_opy_.get(l11ll_opy_ (u"ࠧࡳ࠲ࠪନ"), 0xaaaaaaaa),
                           self.l11111l1ll_opy_.get(l11ll_opy_ (u"ࠨࡴ࠴ࠫ଩"), 0xaaaaaaaa),
                           self.l11111l1ll_opy_.get(l11ll_opy_ (u"ࠩࡵ࠶ࠬପ"), 0xaaaaaaaa),
                           self.l11111l1ll_opy_.get(l11ll_opy_ (u"ࠪࡶ࠸࠭ଫ"), 0xaaaaaaaa))
class l11111llll_opy_(basic_tlv.TLV):
    l11ll_opy_ (u"ࠦࠧࠨࠠࡕࡎ࡙ࠤ࡫ࡵࡲࠡ࡮࡬ࡪࡪࡺࡩ࡮ࡧࠣࡷࡹࡧࡴࡪࡵࡷ࡭ࡨࡹ࠮ࠋࠢࠣࠤࠥࠨࠢࠣବ")
    l1l11ll1ll_opy_ = 0x2a
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __repr__(self):
        return l11ll_opy_ (u"ࠬࡂࡻࡾ࠼ࠣࡿࢂࡄࠧଭ").format(self.__class__.__name__,
                                 self.l111111lll_opy_)
    def __eq__(self, other):
        return isinstance(other, l11111llll_opy_)\
            and self.l111111lll_opy_ == other.l111111lll_opy_
    @staticmethod
    def _1111l11ll_opy_():
        return [
            (l11ll_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࡳࡠࡱࡵ࡭࡬࡯࡮ࡢࡶࡨࡨࠬମ"), l11ll_opy_ (u"ࠧࡊࠩଯ")),
            (l11ll_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࡵࡢࡶࡪࡩࡥࡪࡸࡨࡨࠬର"), l11ll_opy_ (u"ࠩࡌࠫ଱")),
            (l11ll_opy_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࡷࡤࡸࡥ࡭ࡣࡼࡩࡩ࠭ଲ"), l11ll_opy_ (u"ࠫࡎ࠭ଳ")),
            (l11ll_opy_ (u"ࠬࡺࡸࡠࡶ࡬ࡱࡪࡥࡶࡩࡨࡢ࠴ࡵ࠻ࠧ଴"), l11ll_opy_ (u"࠭ࡉࠨଵ")),
            (l11ll_opy_ (u"ࠧࡵࡺࡢࡸ࡮ࡳࡥࡠࡸ࡫ࡪࡤ࠷ࠧଶ"), l11ll_opy_ (u"ࠨࡋࠪଷ")),
            (l11ll_opy_ (u"ࠩࡷࡼࡤࡺࡩ࡮ࡧࡢࡺ࡭࡬࡟࠳ࠩସ"), l11ll_opy_ (u"ࠪࡍࠬହ")),
            (l11ll_opy_ (u"ࠫࡹࡾ࡟ࡵ࡫ࡰࡩࡤࡼࡨࡧࡡ࠸ࠫ଺"), l11ll_opy_ (u"ࠬࡏࠧ଻")),
            (l11ll_opy_ (u"࠭ࡴࡹࡡࡷ࡭ࡲ࡫࡟ࡶࡪࡩࡣ࠵ࡶ࠵ࠨ଼"), l11ll_opy_ (u"ࠧࡊࠩଽ")),
            (l11ll_opy_ (u"ࠨࡶࡻࡣࡹ࡯࡭ࡦࡡࡸ࡬࡫ࡥ࠱ࠨା"), l11ll_opy_ (u"ࠩࡌࠫି")),
            (l11ll_opy_ (u"ࠪࡸࡽࡥࡴࡪ࡯ࡨࡣࡺ࡮ࡦࡠ࠴ࠪୀ"), l11ll_opy_ (u"ࠫࡎ࠭ୁ")),
            (l11ll_opy_ (u"ࠬࡺࡸࡠࡶ࡬ࡱࡪࡥࡵࡩࡨࡢ࠹ࠬୂ"), l11ll_opy_ (u"࠭ࡉࠨୃ")),
            (l11ll_opy_ (u"ࠧࡳࡺࡢࡸ࡮ࡳࡥࡠࡸ࡫ࡪࠬୄ"), l11ll_opy_ (u"ࠨࡋࠪ୅")),
            (l11ll_opy_ (u"ࠩࡵࡼࡤࡺࡩ࡮ࡧࡢࡹ࡭࡬ࠧ୆"), l11ll_opy_ (u"ࠪࡍࠬେ")),
            (l11ll_opy_ (u"ࠫࡧࡲࡥࡠࡥࡲࡱࡲࡧ࡮ࡥࡵࡢࡶࡪࡩࡶࡥࠩୈ"), l11ll_opy_ (u"ࠬࡏࠧ୉")),
            (l11ll_opy_ (u"࠭ࡢ࡭ࡧࡢࡱࡪࡹࡳࡢࡩࡨࡷࡤࡹࡥ࡯ࡶࠪ୊"), l11ll_opy_ (u"ࠧࡊࠩୋ")),
            (l11ll_opy_ (u"ࠨࡤ࡯ࡩࡤࡳࡥࡴࡵࡤ࡫ࡪࡥࡥࡳࡴࡲࡶࡸ࠭ୌ"), l11ll_opy_ (u"ࠩࡋ୍ࠫ")),
            (l11ll_opy_ (u"ࠪࡦࡦࡺࡴࡦࡴࡼࡣࡨࡿࡣ࡭ࡧࡶࠫ୎"), l11ll_opy_ (u"ࠫࡍ࠭୏")),
            (l11ll_opy_ (u"ࠬࡻࡰࡵ࡫ࡰࡩࠬ୐"), l11ll_opy_ (u"࠭ࡈࠨ୑")),
            (l11ll_opy_ (u"ࠧࡴࡻࡶࡸࡪࡳ࡟ࡵࡪࡨࡶࡲࡥࡥࡷࡧࡱࡸࡸ࠭୒"), l11ll_opy_ (u"ࠨࡊࠪ୓"))
        ]
    @staticmethod
    def _1111ll111_opy_():
        l1111ll11l_opy_ = l11ll_opy_ (u"ࠩࠤࠫ୔")
        for elem in l11111llll_opy_._1111l11ll_opy_():
            l1111ll11l_opy_ += elem[1]
        return l1111ll11l_opy_
    def __init__(self, l111111lll_opy_):
        l11ll_opy_ (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡃࡷ࡬ࡰࡩࠦࡡࠡࡎ࡬ࡪࡪࡺࡩ࡮ࡧࡌࡲ࡫ࡵࡔࡍࡘ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡤࡪࡥࡷࠤࡱ࡯ࡦࡦࡶ࡬ࡱࡪࡥࡡࡵࡶࡵࡷ࠿ࠦࡔࡩࡧࠣࡥࡹࡺࡲࡴࠢࡩࡳࡷࠦࡴࡩࡧࠣࡰ࡮࡬ࡥࡵ࡫ࡰࡩࠥ࡯࡮ࡧࡱ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣ୕")
        if not hasattr(l111111lll_opy_, l11ll_opy_ (u"ࠫࡤࡥࡧࡦࡶ࡬ࡸࡪࡳ࡟ࡠࠩୖ")):
            raise TypeError(l11ll_opy_ (u"ࠬࡲࡩࡧࡧࡷ࡭ࡲ࡫࡟ࡢࡶࡷࡶࡸࠦ࡭ࡶࡵࡷࠤࡧ࡫ࠠࡢࠢࡧ࡭ࡨࡺ࡬ࡪ࡭ࡨࠫୗ"))
        for key in self._1111l11ll_opy_():
            if not isinstance(l111111lll_opy_[key[0]], int):
                raise TypeError(l11ll_opy_ (u"࠭ࡻࡾࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡤࡲࠥ࡯࡮ࡵࠩ୘").format(key[0]))
            if l111111lll_opy_[key[0]] < 0\
               or l111111lll_opy_[key[0]] > {l11ll_opy_ (u"ࠧࡉࠩ୙"): 0xffff, l11ll_opy_ (u"ࠨࡋࠪ୚"): 0xffffffff}[key[1]]:
                raise ValueError(l111111lll_opy_[key[0]])
        self.l111111lll_opy_ = l111111lll_opy_
    def serialize(self):
        l11111l11l_opy_ = [self.l111111lll_opy_.get(elem[0], 0)
                    for elem in self._1111l11ll_opy_()]
        return struct.pack(self._1111ll111_opy_(), *l11111l11l_opy_)
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        l111111l1l_opy_ = struct.unpack(cls._1111ll111_opy_(), l111l1ll1l_opy_)
        return cls({elem[0]: l111111l1l_opy_[idx]
                    for idx, elem in enumerate(cls._1111l11ll_opy_())})
class l1111111l1_opy_(basic_tlv.TLV):
    l11ll_opy_ (u"ࠤ࡚ࠥࠦࠥࡌࡗࠢࡷࡽࡵ࡫ࠠࡧࡱࡵࠤࡵ࡫ࡲࡪࡱࡧ࡭ࡨࠦࡩ࡯ࡨࡲࠎࠥࠦࠠࠡࠤࠥࠦ୛")
    l1l11ll1ll_opy_ = 0x2b
    def __repr__(self):
        return l11ll_opy_ (u"ࠪࡀࢀࢃ࠺ࠡࡽࢀࡂࠬଡ଼").format(self.__class__.__name__, self.l1111l1l11_opy_)
    def __eq__(self, other):
        return isinstance(other, l1111111l1_opy_)\
            and self.l1111l1l11_opy_ == other.l1111l1l11_opy_
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    @staticmethod
    def _1111l11l1_opy_():
        return [
            (l11ll_opy_ (u"ࠫࡦࡼࡧࡠࡴࡶࡷ࡮ࡥࡶࡩࡨࠪଢ଼"), l11ll_opy_ (u"ࠬࡈࠧ୞")),
            (l11ll_opy_ (u"࠭ࡡࡷࡩࡢࡶࡸࡹࡩࡠࡷ࡫ࡪࠬୟ"), l11ll_opy_ (u"ࠧࡃࠩୠ")),
            (l11ll_opy_ (u"ࠨࡣࡹ࡫ࡤࡸࡥࡧ࡮ࡨࡧࡹ࡫ࡤࡠࡲࡲࡻࡪࡸ࡟ࡷࡪࡩࠫୡ"), l11ll_opy_ (u"ࠩࡅࠫୢ")),
            (l11ll_opy_ (u"ࠪࡥࡻ࡭࡟ࡳࡧࡩࡰࡪࡩࡴࡦࡦࡢࡴࡴࡽࡥࡳࡡࡸ࡬࡫࠭ୣ"), l11ll_opy_ (u"ࠫࡇ࠭୤")),
            (l11ll_opy_ (u"ࠬࡩࡨࡢࡰࡢࡦࡺࡹࡹࡠࡤࡤࡧࡰࡵࡦࡧࡵࠪ୥"), l11ll_opy_ (u"࠭ࡂࠨ୦")),
            (l11ll_opy_ (u"ࠧࡵࡪࡨࡶࡲࡧ࡬ࡠࡤࡤࡧࡰࡵࡦࡧࡵࠪ୧"), l11ll_opy_ (u"ࠨࡄࠪ୨")),
            (l11ll_opy_ (u"ࠩࡤࡺ࡬ࡥࡲࡴࡵ࡬ࡣࡧࡲࡥࠨ୩"), l11ll_opy_ (u"ࠪࡆࠬ୪")),
            (l11ll_opy_ (u"ࠫࡸࡿࡳࡵࡧࡰࡣࡩࡻࡴࡺࡡࡦࡽࡨࡲࡥࠨ୫"), l11ll_opy_ (u"ࠬࡈࠧ୬")),
            (l11ll_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࡳࡠࡵࡨࡲࡹ࠭୭"), l11ll_opy_ (u"ࠧࡃࠩ୮")),
            (l11ll_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࡵࡢࡶࡪࡩࡥࡪࡸࡨࡨࠬ୯"), l11ll_opy_ (u"ࠩࡅࠫ୰")),
            (l11ll_opy_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࡷࡤࡸࡥ࡭ࡣࡼࡩࡩ࠭ୱ"), l11ll_opy_ (u"ࠫࡇ࠭୲")),
            (l11ll_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪࡹ࡟ࡳࡧ࡭ࡩࡨࡺࡥࡥࠩ୳"), l11ll_opy_ (u"࠭ࡂࠨ୴")),
            (l11ll_opy_ (u"ࠧࡶࡲࡷ࡭ࡲ࡫ࠧ୵"), l11ll_opy_ (u"ࠨࡊࠪ୶"))
        ]
    @staticmethod
    def _1111ll111_opy_():
        l1111ll11l_opy_ = l11ll_opy_ (u"ࠩࠤࠫ୷")
        for elem in l1111111l1_opy_._1111l11l1_opy_():
            l1111ll11l_opy_ += elem[1]
        return l1111ll11l_opy_
    def __init__(self, l1111l1l11_opy_):
        if not hasattr(l1111l1l11_opy_, l11ll_opy_ (u"ࠪࡣࡤ࡭ࡥࡵ࡫ࡷࡩࡲࡥ࡟ࠨ୸")):
            raise TypeError(l11ll_opy_ (u"ࠫࡵ࡫ࡲࡪࡱࡧ࡭ࡨࡥࡡࡵࡶࡵࡷࠥࡳࡵࡴࡶࠣࡦࡪࠦࡡࠡࡦ࡬ࡧࡹࡲࡩ࡬ࡧࠪ୹"))
        for key in self._1111l11l1_opy_():
            if not isinstance(l1111l1l11_opy_[key[0]], int):
                raise TypeError(l11ll_opy_ (u"ࠬࢁࡽࠡ࡫ࡶࠤࡳࡵࡴࠡࡣࡱࠤ࡮ࡴࡴࠨ୺").format(key[0]))
            if l1111l1l11_opy_[key[0]] < 0\
               or l1111l1l11_opy_[key[0]] > {l11ll_opy_ (u"࠭ࡈࠨ୻"): 0xffff, l11ll_opy_ (u"ࠧࡃࠩ୼"): 0xff}[key[1]]:
                raise ValueError(l1111l1l11_opy_[key[0]])
        self.l1111l1l11_opy_ = l1111l1l11_opy_
    def serialize(self):
        args = [self.l1111l1l11_opy_.get(elem[0], 0)
                for elem in self._1111l11l1_opy_()]
        return struct.pack(self._1111ll111_opy_(), *args)
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        l111111l1l_opy_ = struct.unpack(cls._1111ll111_opy_(), l111l1ll1l_opy_)
        return cls({elem[0]: l111111l1l_opy_[idx]
                    for idx, elem in enumerate(cls._1111l11l1_opy_())})
class l1ll1l11ll_opy_(basic_tlv.TLV):
    l11ll_opy_ (u"ࠣࠤࠥࠤ࡙ࡒࡖࠡࡶࡲࠤࡸࡶࡥࡤ࡫ࡩࡽࠥࡺࡲࡢࡰࡶࡱ࡮ࡺࠠࡱࡱࡺࡩࡷࠦࡡࡵࠢࡦࡳࡳ࡬ࡩࡨࡷࡵࡥࡹ࡯࡯࡯ࠢࡷ࡭ࡲ࡫࠮ࠋࠢࠣࠤࠥࠨࠢࠣ୽")
    l1l11ll1ll_opy_ = 0x1D
    def __repr__(self):
        return l11ll_opy_ (u"ࠩ࠿ࡿࢂࡀࠠࡱࡱࡺࡩࡷࡃࡻࡾࡀࠪ୾").format(self.__class__.__name__,
                                       goTenna.constants.POWERLEVELS.name(self.power))
    def __eq__(self, other):
        return isinstance(other, l1ll1l11ll_opy_) and self.power == other.power
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, power):
        if not goTenna.constants.POWERLEVELS.valid(power):
            raise TypeError(l11ll_opy_ (u"ࠪࡔࡴࡽࡥࡳࠢࡰࡹࡸࡺࠠࡣࡧࠣࡺࡦࡲࡩࡥࠩ୿"))
        self.power = power
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠫࠦࡈࠧ஀"), self.power)
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        l111111l1l_opy_ = struct.unpack(l11ll_opy_ (u"ࠬࠧࡂࠨ஁"), l111l1ll1l_opy_)
        return cls(l111111l1l_opy_[0])
class l1ll111111_opy_(basic_tlv.TLV):
    l11ll_opy_ (u"ࠨࠢࠣࠢࡗࡐ࡛ࠦࡴࡰࠢࡶࡴࡪࡩࡩࡧࡻࠣࡲࡪࡺࡷࡰࡴ࡮ࠤࡲࡵࡤࡦࠢࡤࡸࠥࡩ࡯࡯ࡨ࡬࡫ࡺࡸࡡࡵ࡫ࡲࡲࠥࡺࡩ࡮ࡧ࠱ࠎࠥࠦࠠࠡࠤࠥࠦஂ")
    l1l11ll1ll_opy_ = 0x2E
    def __repr__(self):
        return l11ll_opy_ (u"ࠧ࠽ࡽࢀ࠾ࠥࡳࡥࡴࡪ࡬ࡲ࡬ࡃࡻࡾ࠮ࠣࡸࡽࡥ࡯ࡳ࡫ࡪ࡭ࡳࡧࡴࡦࡦࡀࡿࢂ࠲ࠠࡧ࡮ࡲࡳࡩࡀࠠࡴࡪࡲࡹࡹࡃࡻࡾ࠮ࠣ࡫ࡷࡵࡵࡱ࠿ࡾࢁ࠱ࠦࠧஃ") \
               l11ll_opy_ (u"ࠨࡲࡵ࡭ࡻࡧࡴࡦ࠿ࡾࢁ࠱ࠦࡥ࡮ࡧࡵ࡫ࡪࡴࡣࡺ࠿ࡾࢁࡃ࠭஄") \
               .format(self.__class__.__name__, self.l1l1l11111_opy_, self.l1l1l111ll_opy_,
                       self.l1l111l11l_opy_, self.l1l1l1llll_opy_, self.l1ll1ll11l_opy_,
                       self.l1l1ll1l1l_opy_)
    def __eq__(self, other):
        return isinstance(other, l1ll111111_opy_) \
               and self.l1l1l11111_opy_ == other.l1l1l11111_opy_ \
               and self.l1l1l111ll_opy_ == other.l1l1l111ll_opy_ \
               and self.l1l111l11l_opy_ == other.l1l111l11l_opy_ \
               and self.l1l1l1llll_opy_ == other.l1l1l1llll_opy_ \
               and self.l1ll1ll11l_opy_ == other.l1ll1ll11l_opy_ \
               and self.l1l1ll1l1l_opy_ == other.l1l1ll1l1l_opy_
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, l1l1l11111_opy_, l1l1l111ll_opy_, l1l111l11l_opy_,
                 l1l1l1llll_opy_, l1ll1ll11l_opy_, l1l1ll1l1l_opy_):
        self.l1l1l11111_opy_ = l1l1l11111_opy_
        self.l1l1l111ll_opy_ = l1l1l111ll_opy_
        self.l1l111l11l_opy_ = l1l111l11l_opy_
        self.l1l1l1llll_opy_ = l1l1l1llll_opy_
        self.l1ll1ll11l_opy_ = l1ll1ll11l_opy_
        self.l1l1ll1l1l_opy_ = l1l1ll1l1l_opy_
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠩࠤࡆࡇࡈࡂࡃࡄࠪஅ"), self.l1l1l11111_opy_, self.l1l1l111ll_opy_,
                           self.l1l111l11l_opy_, self.l1l1l1llll_opy_,
                           self.l1ll1ll11l_opy_, self.l1l1ll1l1l_opy_)
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        (l1l1l11111_opy_, l1l1l111ll_opy_, l1l111l11l_opy_, l1l1l1llll_opy_,
         l1ll1ll11l_opy_, l1l1ll1l1l_opy_) = struct.unpack(l11ll_opy_ (u"ࠪࠥࡇࡈࡂࡃࡄࡅࠫஆ"), l111l1ll1l_opy_)
        return cls(l1l1l11111_opy_, l1l1l111ll_opy_, l1l111l11l_opy_, l1l1l1llll_opy_,
                   l1ll1ll11l_opy_, l1l1ll1l1l_opy_)
class l1l11ll11l_opy_(basic_tlv.TLV):
    l11ll_opy_ (u"ࠦࠧࠨࠠࡕࡎ࡙ࠤࡹࡵࠠࡴࡲࡨࡧ࡮࡬ࡹࠡࡶ࡫ࡩࠥࡵࡰࡦࡴࡤ࡭ࡹࡵ࡮ࠡ࡯ࡲࡨࡪࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡤࡦࡸ࡬ࡧࡪࠐࠠࠡࠢࠣࠦࠧࠨஇ")
    l1l11ll1ll_opy_ = 0x35
    def __repr__(self):
        return l11ll_opy_ (u"ࠬࡂࡻࡾ࠼ࠣࡱࡴࡪࡥ࠾ࡽࢀࡂࠬஈ").format(self.__class__.__name__,
                                      goTenna.constants.OperationModes.name(self.mode))
    def __eq__(self, other):
        return isinstance(other, l1l11ll11l_opy_) and self.mode == other.mode
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, mode):
        l11ll_opy_ (u"ࠨࠢࠣࠢࡅࡹ࡮ࡲࡤࠡࡣࡱࠤࡔࡶࡥࡳࡣࡷ࡭ࡴࡴࡍࡰࡦࡨࡘࡑ࡜࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣ࡭ࡳࡺࠠࡰࡴࠣࡷࡹࡸࠠ࡮ࡱࡧࡩ࠿ࠦࡔࡩࡧࠣࡱࡴࡪࡥ࠭ࠢࡤࡷࠥࡺࡨࡦࠢࡱࡥࡲ࡫ࠠࡰࡴࠣࡺࡦࡲࡵࡦࠢࡲࡪࠥࡧࠠ࡮ࡧࡰࡦࡪࡸࠠࡰࡨࠣ࠾ࡵࡿ࠺ࡤ࡮ࡤࡷࡸࡀࡠࡨࡱࡗࡩࡳࡴࡡ࠯ࡥࡲࡲࡸࡺࡡ࡯ࡶࡶ࠲ࡔࡶࡥࡳࡣࡷ࡭ࡴࡴࡍࡰࡦࡨࡷࡥࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥࡴࠢࡎࡩࡾࡋࡲࡳࡱࡵ࠾ࠥࡏࡦࠡࡢࡣࡱࡴࡪࡥࡡࡢࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡺࡦࡲࡩࡥࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨஉ")
        if mode in (goTenna.constants.OperationModes.OFF,
                    goTenna.constants.OperationModes.NORMAL,
                    goTenna.constants.OperationModes.RELAY):
            self.mode = mode
        else:
            try:
                self.mode = goTenna.constants.OperationModes.mode(mode)
            except Exception:
                raise KeyError(mode)
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠧࠢࡄࠪஊ"), self.mode)
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        l111111l1l_opy_ = struct.unpack(l11ll_opy_ (u"ࠨࠣࡅࠫ஋"), l111l1ll1l_opy_)
        return cls(l111111l1l_opy_[0])
class l1l1l11lll_opy_(basic_tlv.TLV):
    l11ll_opy_ (u"ࠤ࡚ࠥࠦࠥࡌࡗࠢࡷࡳࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡴࡩࡧࠣࡩࡲ࡫ࡲࡨࡧࡱࡧࡾࠦࡢࡦࡣࡦࡳࡳࠦࡳࡵࡣࡷࡩࠏࠦࠠࠡࠢࠥࠦࠧ஌")
    l1l11ll1ll_opy_ = 0x34
    def __repr__(self):
        return l11ll_opy_ (u"ࠪࡀࢀࢃ࠺ࠡࡧࡱࡥࡧࡲࡥࡥ࠿ࡾࢁࡃ࠭஍").format(self.__class__.__name__,
                                         self.enabled)
    def __eq__(self, other):
        return isinstance(other, l1l1l11lll_opy_)\
            and self.enabled == other.enabled
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, enabled):
        l11ll_opy_ (u"ࠦࠧࠨࠠࡃࡷ࡬ࡰࡩࠦࡡ࡯ࠢࡈࡱࡪࡸࡧࡦࡰࡦࡽࡇ࡫ࡡࡤࡱࡱࡘࡑ࡜ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡥࡳࡴࡲࠠࡦࡰࡤࡦࡱ࡫ࡤ࠻࡚ࠢ࡬ࡪࡺࡨࡦࡴࠣࡸࡴࠦࡥ࡯ࡣࡥࡰࡪࠦࠨࡡࡢࡗࡶࡺ࡫ࡠࡡࠫࠣࡳࡷࠦࡤࡪࡵࡤࡦࡱ࡫ࠠࠩࡢࡣࡊࡦࡲࡳࡦࡢࡣ࠭ࠥࡺࡨࡦࠢࡥࡩࡦࡩ࡯࡯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷࡧࡩࡴࡧࡶࠤ࡙ࡿࡰࡦࡇࡵࡶࡴࡸ࠺ࠡࡋࡩࠤࡥࡦࡥ࡯ࡣࡥࡰࡪࡪࡠࡡࠢࡦࡥࡳࡴ࡯ࡵࠢࡥࡩࠥ࡯࡮ࡵࡧࡵࡴࡷ࡫ࡴࡦࡦࠣࡥࡸࠦࡡࠡࡤࡲࡳࡱࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥஎ")
        self.enabled = bool(enabled)
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠬࠧࡂࠨஏ"), self.enabled)
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        (l111111l1l_opy_,) = struct.unpack(l11ll_opy_ (u"࠭ࠡࡃࠩஐ"), l111l1ll1l_opy_)
        return cls(l111111l1l_opy_)
class l1l11l111l_opy_(basic_tlv.TLV):
    l11ll_opy_ (u"ࠢࠣࠤࠣࡘࡑ࡜ࠠࡵࡱࠣࡷࡵ࡫ࡣࡪࡨࡼࠤ࡬࡫࡯ࠡ࡮ࡲࡧࡦࡺࡩࡰࡰࠣࡥࡹࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡴࡪ࡯ࡨ࠲ࠏࠦࠠࠡࠢࠥࠦࠧ஑")
    l1l11ll1ll_opy_ = 0x1F
    def __repr__(self):
        return l11ll_opy_ (u"ࠨ࠾ࡾࢁ࠿ࠦࡲࡦࡩ࡬ࡳࡳࡃࡻࡾࡀࠪஒ").format(self.__class__.__name__,
                                        goTenna.constants.GEO_REGION.name(self.region))
    def __eq__(self, other):
        return isinstance(other, l1l11l111l_opy_) and self.region == other.region
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, region):
        if not goTenna.constants.GEO_REGION.valid(region):
            raise TypeError(l11ll_opy_ (u"ࠩࡓࡳࡼ࡫ࡲࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡹࡥࡱ࡯ࡤࠨஓ"))
        self.region = region
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠪࠥࡇ࠭ஔ"), self.region)
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        l111111l1l_opy_ = struct.unpack(l11ll_opy_ (u"ࠫࠦࡈࠧக"), l111l1ll1l_opy_)
        return cls(l111111l1l_opy_[0])
class l1l111llll_opy_(basic_tlv.TLV):
    l11ll_opy_ (u"ࠧࠨࠢࠡࡖࡏ࡚ࠥࡺ࡯ࠡࡵࡳࡩࡨ࡯ࡦࡺࠢࡷ࡬ࡪࠦࡘ࠮ࡥࡤࡴࡦࡨࡩ࡭࡫ࡷࡽࠥࡹࡴࡢࡶࡨࠎࠥࠦࠠࠡࠤࠥࠦ஖")
    l1l11ll1ll_opy_ = 0x3b
    def __repr__(self):
        return l11ll_opy_ (u"࠭࠼ࡼࡿ࠽ࠤࡪࡴࡡࡣ࡮ࡨࡨࡂࢁࡽ࠿ࠩ஗").format(self.__class__.__name__,
                                         self.enabled)
    def __eq__(self, other):
        return isinstance(other, l1l111llll_opy_)\
            and self.enabled == other.enabled
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, enabled):
        l11ll_opy_ (u"ࠢࠣࠤࠣࡆࡺ࡯࡬ࡥࠢࡤࡲࠥ࡞ࡃࡢࡲࡤࡦࡱ࡫ࡔࡍࡘࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡨ࡯ࡰ࡮ࠣࡩࡳࡧࡢ࡭ࡧࡧ࠾ࠥ࡝ࡨࡦࡶ࡫ࡩࡷࠦࡴࡰࠢࡨࡲࡦࡨ࡬ࡦࠢࠫࡤࡥ࡚ࡲࡶࡧࡣࡤ࠮ࠦ࡯ࡳࠢࡧ࡭ࡸࡧࡢ࡭ࡧࠣࠬࡥࡦࡆࡢ࡮ࡶࡩࡥࡦࠩࠡࡶ࡫ࡩࠥࡾ࠭ࡤࡣࡳࡥࡧ࡯࡬ࡪࡶࡼࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡢ࡫ࡶࡩࡸࠦࡔࡺࡲࡨࡉࡷࡸ࡯ࡳ࠼ࠣࡍ࡫ࠦࡠࡡࡧࡱࡥࡧࡲࡥࡥࡢࡣࠤࡨࡧ࡮࡯ࡱࡷࠤࡧ࡫ࠠࡪࡰࡷࡩࡷࡶࡲࡦࡶࡨࡨࠥࡧࡳࠡࡣࠣࡦࡴࡵ࡬ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ஘")
        self.enabled = bool(enabled)
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠨࠣࡅࠫங"), self.enabled)
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        (l111111l1l_opy_,) = struct.unpack(l11ll_opy_ (u"ࠩࠤࡆࠬச"), l111l1ll1l_opy_)
        return cls(l111111l1l_opy_)
class l1l11ll1l1_opy_(basic_tlv.TLV):
    l11ll_opy_ (u"ࠥࠦࠧࠦࡔࡍࡘࠣࡸࡴࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡢࠢࡶࡽࡸࡺࡥ࡮ࠢࡳࡶࡴࡶࡥࡳࡶࡼࠤࡹࡵࠠࡳࡧࡷࡶ࡮࡫ࡶࡦࠢࠥࠦࠧ஛")
    l1l11ll1ll_opy_ = 0x28
    @staticmethod
    def l1111l1l1l_opy_(prop):
        try:
            for tlv in _1111ll1l1_opy_:
                if isinstance(tlv, basic_tlv.TLV)\
                   and tlv.l1l11ll1ll_opy_ == prop:
                    return tlv.__name__
        except Exception:
            return l11ll_opy_ (u"ࠫࡁࡻ࡮࡬ࡰࡲࡻࡳࡄࠧஜ")
    def __repr__(self):
        return l11ll_opy_ (u"ࠬࡂࡻࡾ࠼ࠣࡴࡷࡵࡰ࠾ࡽࢀࠤ࠭ࢁࡽࠪࡀࠪ஝")\
            .format(self.__class__.__name__,
                    self.prop,
                    self.l1111l1l1l_opy_(self.prop))
    def __eq__(self, other):
        return isinstance(other, l1l11ll1l1_opy_)\
            and self.prop == other.prop
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, prop):
        l11ll_opy_ (u"ࠨࠢࠣࠢࡅࡹ࡮ࡲࡤࠡࡣࠣࡋࡪࡺࡐࡳࡱࡳࡩࡷࡺࡹࡕࡎ࡙ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡩ࡯ࡶࠣࡴࡷࡵࡰ࠻ࠢࡗ࡬ࡪࠦࡰࡳࡱࡳࡩࡷࡺࡹࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧஞ")
        self.prop = prop
        try:
            _ = struct.pack(l11ll_opy_ (u"ࠧࠢࡄࠪட"), self.prop)
        except struct.error:
            raise TypeError(l11ll_opy_ (u"ࠣࡲࡵࡳࡵࠦ࡭ࡶࡵࡷࠤ࡫࡯ࡴࠡ࡫ࡱࠤࡦࠦࡢࡺࡶࡨ࠰ࠥ࡯ࡳࠡࡽࢀࠦ஠")
                            .format(type(self.prop)))
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠩࠤࡆࠬ஡"), self.prop)
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        return cls(struct.unpack(l11ll_opy_ (u"ࠪࠥࡇ࠭஢"), l111l1ll1l_opy_)[0])
_1111ll1l1_opy_ = [l111111l11_opy_ for l111111l11_opy_ in vars().values()
        if isinstance(l111111l11_opy_, type)
        and issubclass(l111111l11_opy_, basic_tlv.TLV)]