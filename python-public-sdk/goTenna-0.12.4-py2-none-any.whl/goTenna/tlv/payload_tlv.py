# coding: utf8
import sys
l1111_opy_ = sys.version_info [0] == 2
l1lll1_opy_ = 2048
l1ll1_opy_ = 7
def l11ll_opy_ (l1_opy_):
    global l1llll_opy_
    l11l1l_opy_ = ord (l1_opy_ [-1])
    l111l_opy_ = l1_opy_ [:-1]
    l1ll_opy_ = l11l1l_opy_ % len (l111l_opy_)
    l1l1_opy_ = l111l_opy_ [:l1ll_opy_] + l111l_opy_ [l1ll_opy_:]
    if l1111_opy_:
        l1ll1l_opy_ = unicode () .join ([unichr (ord (char) - l1lll1_opy_ - (l1l11_opy_ + l11l1l_opy_) % l1ll1_opy_) for l1l11_opy_, char in enumerate (l1l1_opy_)])
    else:
        l1ll1l_opy_ = str () .join ([chr (ord (char) - l1lll1_opy_ - (l1l11_opy_ + l11l1l_opy_) % l1ll1_opy_) for l1l11_opy_, char in enumerate (l1l1_opy_)])
    return eval (l1ll1l_opy_)
# Copyright (C) 2018 goTenna, Inc. This file is distributed as part of the
# goTenna USB SDK. See the associated license for more information.
# pylint: disable=line-too-long
l11ll_opy_ (u"ࠢࠣࠤࠣࡘࡑ࡜ࡳࠡ࡫ࡱࡸࡪࡴࡤࡦࡦࠣࡸࡴࠦࡢࡦࠢࡳࡰࡦࡩࡥࡥࠢ࡬ࡲࠥࡳࡥࡴࡵࡤ࡫ࡪࠦࡰࡢࡻ࡯ࡳࡦࡪࡳࠋࠌࡗ࡬ࡪࠦࡔࡍࡘࡶࠤࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡪࠠࡩࡧࡵࡩࠥࡧࡲࡦࠢࡩࡳࡷࠦࡥ࡯ࡥࡲࡨ࡮ࡴࡧࠡࡦࡤࡸࡦࠦࡴࡰࠢࡶࡩࡳࡪࠠࡷ࡫ࡤࠤࡹ࡮ࡥࠡࡩࡲࡘࡪࡴ࡮ࡢࠢࡱࡩࡹࡽ࡯ࡳ࡭࠱ࠤࡎࡴࠠࡨࡧࡱࡩࡷࡧ࡬࠭ࠢࡷ࡬ࡪࡿࠠࡴࡪࡲࡹࡱࡪࠠ࡯ࡱࡷࠤࡧ࡫ࠠࡶࡵࡨࡨࠥࡪࡩࡳࡧࡦࡸࡱࡿ࠻ࠡࡴࡤࡸ࡭࡫ࡲ࠭ࠢࡰࡩࡸࡹࡡࡨࡧࠣࡴࡦࡿ࡬ࡰࡣࡧࡷࠥࡹࡨࡰࡷ࡯ࡨࠥࡨࡥࠡࡥࡵࡩࡦࡺࡥࡥࠢࡺ࡭ࡹ࡮ࠠࡵࡪࡨࠤ࡭࡯ࡧࡩࠢ࡯ࡩࡻ࡫࡬ࠡࡨࡤࡧࡹࡵࡲࡺࠢࡦࡰࡦࡹࡳ࡮ࡧࡷ࡬ࡴࡪࡳࠡࡱࡱࠤ࠿ࡶࡹ࠻ࡥ࡯ࡥࡸࡹ࠺ࡡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡰࡩࡸࡹࡡࡨࡧ࠱ࡔࡦࡿ࡬ࡰࡣࡧࡤ࠱ࠦࡳࡶࡥ࡫ࠤࡦࡹࠠ࠻ࡲࡼ࠾ࡲ࡫ࡴࡩ࠼ࡣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡲ࡫ࡳࡴࡣࡪࡩ࠳ࡖࡡࡺ࡮ࡲࡥࡩ࠴ࡴࡦࡺࡷࡤ࠳ࠐࠢࠣࠤఁ")
# pylint: enable=line-too-long
import struct
import datetime
import logging
import six
import goTenna.constants
import goTenna.settings
import goTenna.util
from goTenna.tlv import basic_tlv
_MODULE_LOGGER = logging.getLogger(__name__)
class l1lll111ll1_opy_(basic_tlv.TLV):
    l11ll_opy_ (u"ࠣࠤࠥࠤࡆࠦࡔࡍࡘࠣࡦࡦࡹࡥࠡࡥ࡯ࡥࡸࡹࠠࡵࡪࡤࡸࠥࡰࡵࡴࡶࠣ࡬ࡴࡲࡤࡴࠢࡤࠤࡱࡧࡴࡪࡶࡸࡨࡪ࠵࡬ࡰࡰࡪ࡭ࡹࡻࡤࡦࠢࡳࡥ࡮ࡸࠠࠣࠤࠥం")
    def __repr__(self):
        return l11ll_opy_ (u"ࠩ࠿ࡿࢂࡀࠠࡼࡿࡁࠫః").format(self.__class__.__name__,
                                 self._print_contents())
    def _print_contents(self):
        return l11ll_opy_ (u"ࠪࡰࡦࡺࡩࡵࡷࡧࡩࡂࢁࡽ࠭ࠢ࡯ࡳࡳ࡭ࡩࡵࡷࡧࡩࡂࢁࡽࠨఄ").format(self.latitude, self.longitude)
    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and other.position == self.position
    def __init__(self, latitude, longitude):
        l11ll_opy_ (u"ࠦࠧࠨࠠࡃࡷ࡬ࡰࡩࠦࡴࡩࡧࠣࡳࡧࡰࡥࡤࡶ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡦ࡭ࡱࡤࡸࠥࡲࡡࡵ࡫ࡷࡹࡩ࡫࠺ࠡࡖ࡫ࡩࠥࡲࡡࡵ࡫ࡷࡹࡩ࡫ࠠࡵࡱࠣࡷࡹࡵࡲࡦࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡪࡱࡵࡡࡵࠢ࡯ࡳࡳ࡭ࡩࡵࡷࡧࡩ࠿ࠦࡔࡩࡧࠣࡰࡴࡴࡧࡪࡶࡸࡨࡪࠦࡴࡰࠢࡶࡸࡴࡸࡥࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷࡧࡩࡴࡧࡶࠤ࡙ࡿࡰࡦࡇࡵࡶࡴࡸ࠺ࠡࡋࡩࠤࡴࡴࡥࠡࡱࡩࠤࡱࡧࡴࡪࡶࡸࡨࡪࠦ࡯ࡳࠢ࡯ࡳࡳ࡭ࡩࡵࡷࡧࡩࠥ࡯ࡳࠡࡰࡲࡸࠥࡩ࡯࡯ࡸࡨࡶࡹ࡯ࡢ࡭ࡧࠣࡸࡴࠦࡦ࡭ࡱࡤࡸ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥఅ")
        try:
            self._1lll1111ll_opy_ = float(latitude)
        except (ValueError, TypeError):
            raise TypeError(l11ll_opy_ (u"ࠬࡲࡡࡵ࡫ࡷࡹࡩ࡫ࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡥࡲࡲࡻ࡫ࡲࡵ࡫ࡥࡰࡪࠦࡴࡰࠢࡩࡰࡴࡧࡴ࠭ࠢ࡬ࡷࠥࢁࡽࠨఆ")
                            .format(type(latitude)))
        try:
            self._1lll1lll11_opy_ = float(longitude)
        except (ValueError, TypeError):
            raise TypeError(l11ll_opy_ (u"࠭࡬ࡰࡰࡪ࡭ࡹࡻࡤࡦࠢࡰࡹࡸࡺࠠࡣࡧࠣࡧࡴࡴࡶࡦࡴࡷ࡭ࡧࡲࡥࠡࡶࡲࠤ࡫ࡲ࡯ࡢࡶ࠯ࠤ࡮ࡹࠠࡼࡿࠪఇ")
                            .format(type(longitude)))
    @property
    def latitude(self):
        l11ll_opy_ (u"ࠢࠣࠤࠣࡘ࡭࡫ࠠ࡭ࡣࡷ࡭ࡹࡻࡤࡦ࠮ࠣࡥࡸࠦࡡࠡࡨ࡯ࡳࡦࡺࠢࠣࠤఈ")
        return self._1lll1111ll_opy_
    @property
    def longitude(self):
        l11ll_opy_ (u"ࠣࠤࠥࠤ࡙࡮ࡥࠡ࡮ࡲࡲ࡬࡯ࡴࡶࡦࡨ࠰ࠥࡧࡳࠡࡣࠣࡪࡱࡵࡡࡵࠢࠥࠦࠧఉ")
        return self._1lll1lll11_opy_
    @property
    def position(self):
        l11ll_opy_ (u"ࠤ࡚ࠥࠦࠥࡨࡦࠢࡳࡳࡸ࡯ࡴࡪࡱࡱ࠰ࠥࡧࡳࠡࡣࠣࠬࡱࡧࡴࡪࡶࡸࡨࡪ࠲ࠠ࡭ࡱࡱ࡫࡮ࡺࡵࡥࡧࠬࠤࡵࡧࡩࡳࠢࠥࠦࠧఊ")
        return (self._1lll1111ll_opy_, self._1lll1lll11_opy_)
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠪࠥࡩࡪࠧఋ"), self._1lll1111ll_opy_, self._1lll1lll11_opy_)
    @classmethod
    def deserialize(cls, value):
        return cls(*struct.unpack(l11ll_opy_ (u"ࠫࠦࡪࡤࠨఌ"), value))
class RequestGIDTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠧࠨࠢࠡࡃࠣࡘࡑ࡜ࠠࡧࡱࡵࠤ࡭ࡵ࡬ࡥ࡫ࡱ࡫ࠥࡧࠠࡳࡧࡴࡹࡪࡹࡴࠡࡨࡲࡶࠥࡧࠠࡈࡋࡇࠎࠥࠦࠠࠡࠤࠥࠦ఍")
    l1l11ll1ll_opy_ = 5
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __repr__(self):
        return l11ll_opy_ (u"࠭࠼ࡓࡧࡴࡹࡪࡹࡴࡈࡋࡇࡘࡑ࡜࠺ࠡࡉࡌࡈࡂࢁࡽ࠿ࠩఎ").format(self.gid)
    def __eq__(self, other):
        return isinstance(other, RequestGIDTLV) and self._gid == other._gid
    @property
    def gid(self):
        l11ll_opy_ (u"ࠢࠣࠤࠣࡘ࡭࡫ࠠࡈࡋࡇࠤࡦࡹࡳࡰࡥ࡬ࡥࡹ࡫ࡤࠡࡹ࡬ࡸ࡭ࠦࡴࡩࡧࠣࡘࡑ࡜ࠠࠣࠤࠥఏ")
        return self._gid
    def __init__(self, gid):
        l11ll_opy_ (u"ࠣࠤࠥࠤࡇࡻࡩ࡭ࡦࠣࡥࠥࡘࡥࡲࡷࡨࡷࡹࡍࡉࡅࡖࡏ࡚࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡࡖ࡫࡭ࡸࠦࡩࡴࠢࡸࡷࡺࡧ࡬࡭ࡻࠣࡹࡸ࡫ࡤࠡࡣࡶࠤࡹ࡮ࡥࠡࡵࡲࡹࡷࡩࡥࠡࡸࡤࡰࡺ࡫ࠠࡧࡱࡵࠤࡸࡵ࡭ࡦࠢࡶࡳࡷࡺࠠࡰࡨࠣࡶࡪࡷࡵࡦࡵࡷࠤࡲ࡫ࡳࡴࡣࡪࡩ࠳ࠦࡁࡴࠢࡶࡹࡨ࡮ࠬࠡ࡫ࡷࠤࡸ࡮࡯ࡶ࡮ࡧࠤࡧ࡫ࠠࡢࠢࡳࡶ࡮ࡼࡡࡵࡧࠣࡋࡎࡊ࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡊࡆࠣ࡫࡮ࡪ࠺ࠡࡖ࡫ࡩࠥࡍࡉࡅࠢࡷࡳࠥࡶࡡࡤ࡭࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡢ࡫ࡶࡩࡸࠦࡔࡺࡲࡨࡉࡷࡸ࡯ࡳ࠼ࠣࡍ࡫ࠦࡠࡡࡩ࡬ࡨࡥࡦࠠࡪࡵࠣࡲࡴࡺࠠࡢࠢ࠽ࡴࡾࡀࡣ࡭ࡣࡶࡷ࠿ࡦࡧࡰࡖࡨࡲࡳࡧ࠮ࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡍࡉࡦ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡦ࡯ࡳࡦࡵ࡚ࠣࡦࡲࡵࡦࡇࡵࡶࡴࡸ࠺ࠡࡋࡩࠤࡥࡦࡧࡪࡦࡣࡤࠥ࡯ࡳࠡࡰࡲࡸࠥࡧࠠࡱࡴ࡬ࡺࡦࡺࡥࠡࡉࡌࡈ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥఐ")
        if not isinstance(gid, goTenna.settings.GID):
            raise TypeError
        if gid.gid_type != goTenna.settings.GID.PRIVATE:
            raise ValueError
        self._gid = gid
    @classmethod
    def deserialize(cls, value):
        l1lll1lllll_opy_ = struct.unpack(l11ll_opy_ (u"ࠩࠤࡕࠬ఑"), value)[0]
        return cls(goTenna.settings.GID(l1lll1lllll_opy_, goTenna.settings.GID.PRIVATE))
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠪࠥࡖ࠭ఒ"), self.gid.gid_val)
class MapIDTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠦࠧࠨࠠࡂࠢࡗࡐ࡛ࠦࡨࡰ࡮ࡧ࡭ࡳ࡭ࠠࡵࡪࡨࠤࡎࡊࠠࡰࡨࠣࡸ࡭࡫ࠠ࡮ࡣࡳࠤࡦࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡤࡱࡱࡸࡦ࡯࡮ࡴࠌࠣࠤࠥࠦࠢࠣࠤఓ")
    l1l11ll1ll_opy_ = 38
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __repr__(self):
        return l11ll_opy_ (u"ࠬࡂࡻࡾࠢ࡬ࡨࡂࢁࡽ࠿ࠩఔ").format(self.__class__.__name__, self.map_id)
    def __eq__(self, other):
        return isinstance(other, MapIDTLV) and self._id == other._id
    @property
    def map_id(self):
        l11ll_opy_ (u"ࠨࠢࠣࠢࡗ࡬ࡪࠦ࡭ࡢࡲࠣ࡭ࡩࠦࡣࡰࡰࡷࡥ࡮ࡴࡥࡥࠢࡥࡽࠥࡺࡨࡦࠢࡗࡐ࡛ࠦࠢࠣࠤక")
        return self._id
    def __init__(self, map_id):
        l11ll_opy_ (u"ࠢࠣࠤࠣࡆࡺ࡯࡬ࡥࠢࡤࠤࡒࡧࡰࡊࡆࡗࡐ࡛࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢࡐࡥࡵࠦࡉࡅࡵࠣࡥࡷ࡫ࠠ࠷࠶࠰ࡦ࡮ࡺࠠࡪࡰࡷࡩ࡬࡫ࡲࡴࠢ࡬ࡲࡹ࡫࡮ࡥࡧࡧࠤࡹࡵࠠࡶࡰ࡬ࡵࡺ࡫࡬ࡺࠢ࡬ࡨࡪࡴࡴࡪࡨࡼࠤ࡬࡫࡮ࡦࡴ࡬ࡧࠥࡳࡡࡱࠢࡲࡦ࡯࡫ࡣࡵࡵࠣࡷࡺࡩࡨࠡࡣࡶࠤࡷࡵࡵࡵࡧࡶࠤࡴࡸࠠࡤ࡫ࡵࡧࡱ࡫ࡳࠡࡣࡦࡶࡴࡹࡳࠡ࡯ࡸࡰࡹ࡯ࡰ࡭ࡧࠣࡧࡴࡳ࡭ࡶࡰ࡬ࡧࡦࡺࡩ࡯ࡩࠣࡹࡸ࡫ࡲࡴ࠰ࠣࡘ࡭࡫ࡹࠡࡵ࡫ࡳࡺࡲࡤࠡࡤࡨࠤ࡬࡫࡮ࡦࡴࡤࡸࡪࡪࠠࡸ࡫ࡷ࡬ࠥࡀࡰࡺ࠼ࡰࡩࡹ࡮࠺ࡡࡷࡸ࡭ࡩ࠴ࡵࡶ࡫ࡧ࠸ࡥࠦ࡯ࡳࠢ࠽ࡴࡾࡀ࡭ࡦࡶ࡫࠾ࡥࡵࡳ࠯ࡷࡵࡥࡳࡪ࡯࡮ࡢࠣࡸࡴࠦࡥ࡯ࡵࡸࡶࡪࠦࡧ࡭ࡱࡥࡥࡱࠦࡵ࡯࡫ࡴࡹࡪࡴࡥࡴࡵ࠱ࠤࡍࡵࡷࡦࡸࡨࡶ࠱ࠦࡢࡺࠢࡷ࡬ࡪࠦࡴࡪ࡯ࡨࠤࡹ࡮ࡥࡺࠢࡤࡶࡪࠦࡧࡪࡸࡨࡲࠥࡺ࡯ࠡࡶ࡫࡭ࡸࠦࡔࡍࡘ࠯ࠤࡹ࡮ࡥࡺࠢࡶ࡬ࡴࡻ࡬ࡥࠢࡥࡩࠥࡩ࡯ࡢ࡮ࡨࡷࡨ࡫ࡤࠡࡶࡲࠤ࡮ࡴࡴࡦࡩࡨࡶࡸ࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢ࡬ࡲࡹࠦ࡭ࡢࡲࡢ࡭ࡩࡀࠠࡕࡪࡨࠤࡎࡊ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡦ࡯ࡳࡦࡵࠣࡘࡾࡶࡥࡆࡴࡵࡳࡷࡀࠠࡊࡈࠣࡤࡥࡳࡡࡱࡡ࡬ࡨࡥࡦࠠࡪࡵࠣࡲࡴࡺࠠࡢࡰࠣ࡭ࡳࡺ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧఖ")
        if not isinstance(map_id, six.integer_types):
            raise TypeError(l11ll_opy_ (u"ࠨ࡯ࡤࡴࡤ࡯ࡤࠡࡵ࡫ࡳࡺࡲࡤࠡࡤࡨࠤ࡮ࡴࡴࡦࡩࡵࡥࡱ࠲ࠠࡪࡵࠣࡿࢂ࠭గ")
                            .format(type(map_id)))
        self._id = map_id
    @classmethod
    def deserialize(cls, value):
        return cls(struct.unpack(l11ll_opy_ (u"ࠩࠤࡕࠬఘ"), value)[0])
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠪࠥࡖ࠭ఙ"), self._id)
class LocationNameTLV(basic_tlv.l111l11lll_opy_):
    l11ll_opy_ (u"ࠦࠧࠨࠠࡂࠢࡗࡐ࡛ࠦࡦࡰࡴࠣ࡬ࡴࡲࡤࡪࡰࡪࠤࡦࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡰࡤࡱࡪࠐࠠࠡࠢࠣࠦࠧࠨచ")
    l1l11ll1ll_opy_ = 7
    MAX_LENGTH = 32
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    @property
    def name(self):
        l11ll_opy_ (u"ࠧࠨࠢࠡࡖ࡫ࡩࠥࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠠ࡯ࡣࡰࡩࠥࡧࡳࡴࡱࡦ࡭ࡦࡺࡥࡥࠢࡺ࡭ࡹ࡮ࠠࡵࡪࡨࠤ࡙ࡒࡖࠡࠤࠥࠦఛ")
        return self._contents
    @property
    def l111ll11l1_opy_(self):
        l11ll_opy_ (u"ࠨࠢࠣࠢࡗ࡬ࡪࠦ࡭ࡢࡺ࡬ࡱࡺࡳࠠ࡭ࡧࡱ࡫ࡹ࡮ࠠࡰࡨࠣࡸ࡭࡫ࠠࡕࡎ࡙ࠤࠧࠨࠢజ")
        return self.MAX_LENGTH
class LocationLatitudeTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠢࠣࠤࠣࡅ࡚ࠥࡌࡗࠢࡩࡳࡷࠦࡨࡰ࡮ࡧ࡭ࡳ࡭ࠠࡢࠢ࡯ࡥࡹ࡯ࡴࡶࡦࡨࠎࠥࠦࠠࠡࠤࠥࠦఝ")
    l1l11ll1ll_opy_ = 8
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __repr__(self):
        return l11ll_opy_ (u"ࠨ࠾ࡏࡳࡨࡧࡴࡪࡱࡱࡐࡦࡺࡩࡵࡷࡧࡩ࡙ࡒࡖ࠻ࠢ࡯ࡥࡹ࡯ࡴࡶࡦࡨࡁࢀࢃ࠾ࠨఞ").format(self.latitude)
    def __eq__(self, other):
        return isinstance(other, LocationLatitudeTLV)\
            and self._1lll1111ll_opy_ == other._1lll1111ll_opy_
    @property
    def latitude(self):
        l11ll_opy_ (u"ࠤ࡚ࠥࠦࠥࡨࡦࠢ࡯ࡥࡹ࡯ࡴࡶࡦࡨࠤࡦࡹࡳࡰࡥ࡬ࡥࡹ࡫ࡤࠡࡹ࡬ࡸ࡭ࠦࡴࡩࡧࠣࡘࡑ࡜ࠠࠣࠤࠥట")
        return self._1lll1111ll_opy_
    def __init__(self, latitude):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡂࡶ࡫࡯ࡨࠥࡧࠠ࡭ࡣࡷ࡭ࡹࡻࡤࡦࠢࡗࡐ࡛࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡩࡰࡴࡧࡴࠡ࡮ࡤࡸ࡮ࡺࡵࡥࡧ࠽ࠤ࡙࡮ࡥࠡ࡮ࡤࡸ࡮ࡺࡵࡥࡧࠣࡸࡴࠦࡥ࡯ࡥࡲࡨࡪ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥࡴࠢࡗࡽࡵ࡫ࡅࡳࡴࡲࡶ࠿ࠦࡉࡧࠢࡣࡤࡱࡧࡴࡪࡶࡸࡨࡪࡦࡠࠡ࡫ࡶࠤࡳࡵࡴࠡࡣࠣࡪࡱࡵࡡࡵ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢఠ")
        if not isinstance(latitude, float):
            raise TypeError(l11ll_opy_ (u"ࠫࡑࡧࡴࡪࡶࡸࡨࡪࠦࡳࡩࡱࡸࡰࡩࠦࡢࡦࠢࡤࠤ࡫ࡲ࡯ࡢࡶࠪడ"))
        self._1lll1111ll_opy_ = latitude
    @classmethod
    def deserialize(cls, value):
        return cls(struct.unpack(l11ll_opy_ (u"ࠬࠧࡤࠨఢ"), value)[0])
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"࠭ࠡࡥࠩణ"), self.latitude)
class LocationLongitudeTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠢࠣࠤࠣࡅ࡚ࠥࡌࡗࠢࡩࡳࡷࠦࡨࡰ࡮ࡧ࡭ࡳ࡭ࠠ࡭ࡱࡱ࡫࡮ࡺࡵࡥࡧࠍࠤࠥࠦࠠࠣࠤࠥత")
    l1l11ll1ll_opy_ = 9
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __repr__(self):
        return l11ll_opy_ (u"ࠨ࠾ࡏࡳࡨࡧࡴࡪࡱࡱࡐࡴࡴࡧࡪࡶࡸࡨࡪ࡚ࡌࡗ࠼ࠣࡰࡴࡴࡧࡪࡶࡸࡨࡪࡃࡻࡾࡀࠪథ").format(self.longitude)
    def __eq__(self, other):
        return isinstance(other, LocationLongitudeTLV)\
            and self.longitude == other.longitude
    @property
    def longitude(self):
        l11ll_opy_ (u"ࠤ࡚ࠥࠦࠥࡨࡦࠢ࡯ࡳࡳ࡭ࡩࡵࡷࡧࡩࠥࡧࡳࡴࡱࡦ࡭ࡦࡺࡥࡥࠢࡺ࡭ࡹ࡮ࠠࡵࡪࡨࠤ࡙ࡒࡖࠡࠤࠥࠦద")
        return self._1lll1lll11_opy_
    def __init__(self, longitude):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡂࡶ࡫࡯ࡨࠥࡧࠠ࡭ࡱࡱ࡫࡮ࡺࡵࡥࡧࠣࡘࡑ࡜࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡪࡱࡵࡡࡵ࠼ࠣࡰࡴࡴࡧࡪࡶࡸࡨࡪࡀࠠࡕࡪࡨࠤࡱࡵ࡮ࡨ࡫ࡷࡹࡩ࡫ࠠࡵࡱࠣࡩࡳࡩ࡯ࡥࡧ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡢ࡫ࡶࡩࡸࠦࡔࡺࡲࡨࡉࡷࡸ࡯ࡳ࠼ࠣࡍ࡫ࠦࡠࡡ࡮ࡲࡲ࡬࡯ࡴࡶࡦࡨࡤࡥࠦࡩࡴࠢࡱࡳࡹࠦࡡࠡࡨ࡯ࡳࡦࡺ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧధ")
        if not isinstance(longitude, float):
            raise TypeError(l11ll_opy_ (u"ࠫࡑࡵ࡮ࡨ࡫ࡷࡹࡩ࡫ࠠࡴࡪࡲࡹࡱࡪࠠࡣࡧࠣࡥࠥ࡬࡬ࡰࡣࡷࠫన"))
        self._1lll1lll11_opy_ = longitude
    @classmethod
    def deserialize(cls, value):
        return cls(struct.unpack(l11ll_opy_ (u"ࠬࠧࡤࠨ఩"), value)[0])
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"࠭ࠡࡥࠩప"), self.longitude)
class LocationGPSTimestampTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠢࠣࠤࠣࡅ࡚ࠥࡌࡗࠢࡩࡳࡷࠦࡨࡰ࡮ࡧ࡭ࡳ࡭ࠠࡢࠢࡊࡔࡘࠦࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠌࠣࠤࠥࠦࠢࠣࠤఫ")
    l1l11ll1ll_opy_ = 19
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __repr__(self):
        return l11ll_opy_ (u"ࠨ࠾ࡏࡳࡨࡧࡴࡪࡱࡱࡋࡕ࡙ࡔࡪ࡯ࡨࡷࡹࡧ࡭ࡱࡖࡏ࡚࠿ࠦࡴࡪ࡯ࡨࡁࢀࢃࠠࡖࡖࡆࡂࠬబ").format(self.timestamp)
    def __eq__(self, other):
        return isinstance(other, LocationGPSTimestampTLV)\
            and other.timestamp == self.timestamp
    @property
    def timestamp(self):
        l11ll_opy_ (u"ࠤ࡚ࠥࠦࠥࡨࡦࠢࡱࡥ࡮ࡼࡥࠡࡗࡗࡇࠥࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࠡࡣࡶࡷࡴࡩࡩࡢࡶࡨࡨࠥࡽࡩࡵࡪࠣࡸ࡭࡫ࠠࡕࡎ࡙ࠤࠧࠨࠢభ")
        return self._1lll11l1l1_opy_
    def __init__(self, timestamp):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡂࡶ࡫࡯ࡨࠥࡧࠠࡈࡒࡖࠤࡹ࡯࡭ࡦࡵࡷࡥࡲࡶ࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣࡘ࡭࡯ࡳࠡࡱࡥ࡮ࡪࡩࡴࠡࡪࡲࡰࡩࡹࠠࡵࡪࡨࠤࡹ࡯࡭ࡦࠢ࡬ࡲࡹ࡫ࡲ࡯ࡣ࡯ࡰࡾࠦࡡࡴࠢࡤࠤ࠿ࡶࡹ࠻ࡥ࡯ࡥࡸࡹ࠺ࡡࡦࡤࡸࡪࡺࡩ࡮ࡧ࠱ࡨࡦࡺࡥࡵ࡫ࡰࡩࡥࠦ࡯ࡣ࡬ࡨࡧࡹ࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡧࡥࡹ࡫ࡴࡪ࡯ࡨ࠲ࡩࡧࡴࡦࡶ࡬ࡱࡪࠦࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱ࠼ࠣࡘ࡭࡫ࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠣࡸࡴࠦࡨࡰ࡮ࡧ࠲ࠥࡏࡦࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡣ࡬ࡺࡪ࠲ࠠࡪࡶࠣࡻ࡮ࡲ࡬ࠡࡤࡨࠤࡸࡺ࡯ࡳࡧࡧࠤࡦࡹࠠࡪࡵ࠱ࠤࡎ࡬ࠠࡪࡶࠣ࡭ࡸࠦࡡࡸࡣࡵࡩ࠱ࠦࡩࡵࠢࡺ࡭ࡱࡲࠠࡣࡧࠣࡧࡴࡴࡶࡦࡴࡷࡩࡩࠦࡴࡰࠢࡘࡘࡈࠦࡩ࡯ࠢࡳࡶࡪࡶࡡࡳࡣࡷ࡭ࡴࡴࠠࡧࡱࡵࠤࡸ࡫ࡲࡪࡣ࡯࡭ࡿࡧࡴࡪࡱࡱ࠲ࠥࡇ࡬࡭ࠢࡧࡩࡸ࡫ࡲࡪࡣ࡯࡭ࡿ࡫ࡤࠡࡶ࡬ࡱࡪࡹࡴࡢ࡯ࡳࡷࠥࡧࡲࡦࠢࡤࡷࡸࡻ࡭ࡦࡦࠣࡸࡴࠦࡢࡦࠢࡘࡘࡈ࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠱࠲ࠥࡴ࡯ࡵࡧࠣ࠾ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡖ࡫ࡩࠥࡩ࡯࡯ࡸࡨࡶࡸ࡯࡯࡯ࠢࡷࡳ࡛ࠥࡔࡄࠢ࡬ࡷࠥࡪ࡯࡯ࡧࠣࡲࡦ࡯ࡶࡦ࡮ࡼࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢࡤࡺࡴ࡯ࡤࠡࡲࡸࡰࡱ࡯࡮ࡨࠢ࡬ࡲࠥࡧ࡮ࡰࡶ࡫ࡩࡷࠦࡥࡹࡶࡨࡶࡳࡧ࡬ࠡ࡮࡬ࡦࡷࡧࡲࡺ࠰ࠣࡍ࡫ࠦࡴࡩࡧࠣࡴࡦࡹࡳࡦࡦ࠰࡭ࡳࠦࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠢ࡫ࡥࡸࠦࡡࠡ࠼ࡳࡽ࠿ࡩ࡬ࡢࡵࡶ࠾ࡥࡪࡡࡵࡧࡷ࡭ࡲ࡫࠮ࡵࡼ࡬ࡲ࡫ࡵࡠࠡࡣࡷࡸࡦࡩࡨࡦࡦ࠯ࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡼ࡯࡬࡭ࠢࡸࡷࡪࠦࡩࡵࡵࠣࡤࡥࡻࡴࡤࡱࡩࡪࡸ࡫ࡴࠩࠫࡣࡤࠥࡳࡥࡵࡪࡲࡨࠥࡺ࡯ࠡࡥࡲࡲࡻ࡫ࡲࡵࠢࡷ࡬ࡪࠦࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠢࡷࡳ࡛ࠥࡔࡄࠢࡤࡲࡩࠦࡴࡩࡧࡱࠤࡩ࡯ࡳࡤࡣࡵࡨࠥࡺࡨࡦࠢ࠽ࡴࡾࡀࡣ࡭ࡣࡶࡷ࠿ࡦࡤࡢࡶࡨࡸ࡮ࡳࡥ࠯ࡶࡽ࡭ࡳ࡬࡯ࡡࠢࡲࡦ࡯࡫ࡣࡵ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢమ")
        self._1lll11l1l1_opy_ = goTenna.util.l1l1l111_opy_(timestamp)
    @classmethod
    def deserialize(cls, value):
        parsed = struct.unpack(l11ll_opy_ (u"ࠫࠦࡏࠧయ"), value)[0]
        return cls(datetime.datetime.utcfromtimestamp(parsed))
    def serialize(self):
        l1lll1ll11l_opy_ = int((self.timestamp - datetime.datetime.utcfromtimestamp(0))
                    .total_seconds())
        return struct.pack(l11ll_opy_ (u"ࠬࠧࡉࠨర"), l1lll1ll11l_opy_)
class LocationTypeTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠨࠢࠣࠢࡄࠤ࡙ࡒࡖࠡࡨࡲࡶࠥ࡮࡯࡭ࡦ࡬ࡲ࡬ࠦࡡࠡ࡮ࡲࡧࡦࡺࡩࡰࡰࠣࡸࡾࡶࡥࠋࠢࠣࠤࠥࠨࠢࠣఱ")
    l1l11ll1ll_opy_ = 10
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __eq__(self, other):
        return isinstance(other, LocationTypeTLV)\
            and self.location_type == other.location_type
    @property
    def location_type(self):
        l11ll_opy_ (u"ࠢࠣࠤࠣࡘ࡭࡫ࠠ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠢࡷࡽࡵ࡫ࠠࡢࡵࡶࡳࡨ࡯ࡡࡵࡧࡧࠤࡼ࡯ࡴࡩࠢࡷ࡬ࡪࠦࡔࡍࡘࠣࠦࠧࠨల")
        return self._1lll1l111l_opy_
    def __init__(self, location_type):
        l11ll_opy_ (u"ࠣࠤࠥࠤࡇࡻࡩ࡭ࡦࠣࡥࠥࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠠࡵࡻࡳࡩ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡵࡷࡶࠥࡲ࡯ࡤࡣࡷ࡭ࡴࡴ࡟ࡵࡻࡳࡩ࠿ࠦࡁࠡ࡭ࡨࡽࠥࡵࡦࠡ࠼ࡳࡽ࠿ࡧࡴࡵࡴ࠽ࡤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡩ࡯࡯ࡵࡷࡥࡳࡺࡳ࠯ࡎࡒࡇࡆ࡚ࡉࡐࡐࡢࡘ࡞ࡖࡅࡔࡢࠣࡸࡴࠦࡳࡦࡰࡧ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡳࡣ࡬ࡷࡪࡹࠠࡌࡧࡼࡉࡷࡸ࡯ࡳ࠼ࠣ࡭࡫ࠦࡠࡡ࡮ࡲࡧࡦࡺࡩࡰࡰࡢࡸࡾࡶࡥࡡࡢࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡥࠥࡼࡡ࡭࡫ࡧࠤࡱࡵࡣࡢࡶ࡬ࡳࡳࠦࡴࡺࡲࡨ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤళ")
        _ = goTenna.constants.location_type(location_type)
        #: The l1lll1l1l1l_opy_ type
        self._1lll1l111l_opy_ = location_type
    @classmethod
    def deserialize(cls, value):
        parsed = goTenna.util.b2s(value)
        loc_type = goTenna.constants.location_type_name(parsed)
        return cls(loc_type)
    def serialize(self):
        return goTenna.util.s2b(goTenna.constants.location_type(self.location_type))
    def __repr__(self):
        return l11ll_opy_ (u"ࠩ࠿ࡐࡴࡩࡡࡵ࡫ࡲࡲ࡙ࡿࡰࡦࡖࡏ࡚࠿ࠦࡴࡺࡲࡨࡁࢀࢃ࠾ࠨఴ").format(self.location_type)
class l1lll11llll_opy_(basic_tlv.TLV):
    l11ll_opy_ (u"ࠥࠦࠧࠦࡁࠡࡖࡏ࡚ࠥࡺ࡯ࠡࡵࡳࡩࡨ࡯ࡦࡺࠢ࡫ࡳࡼࠦࡦࡳࡧࡴࡹࡪࡴࡴ࡭ࡻࠣࡥࠥࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡷ࡭ࡧࡲࡦࡦࠥࠦࠧవ")
    l1l11ll1ll_opy_ = 20
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and self.l1lll1llll1_opy_ == other.l1lll1llll1_opy_
    def __repr__(self):
        return l11ll_opy_ (u"ࠫࡁࡒ࡯ࡤࡣࡷ࡭ࡴࡴࡓࡩࡣࡵ࡭ࡳ࡭ࡆࡳࡧࡴࡹࡪࡴࡣࡺࡖࡏ࡚࠿ࠦࡦࡳࡧࡴࡹࡪࡴࡣࡺ࠿ࡾࢁࡃ࠭శ")\
            .format(self.l1lll1llll1_opy_)
    @property
    def l1lll1llll1_opy_(self):
        l11ll_opy_ (u"ࠧࠨࠢࠡࡖ࡫ࡩࠥࡹࡨࡢࡴ࡬ࡲ࡬ࠦࡦࡳࡧࡴࡹࡪࡴࡣࡺࠢࡤࡷࡸࡵࡣࡪࡣࡷࡩࡩࠦࡷࡪࡶ࡫ࠤࡹ࡮ࡥࠡࡖࡏ࡚ࠥࠨࠢࠣష")
        return self._1lll1ll111_opy_
    def __init__(self, l1lll1llll1_opy_):
        l11ll_opy_ (u"ࠨࠢࠣࠢࡅࡹ࡮ࡲࡤࠡࡣࠣࡰࡴࡩࡡࡵ࡫ࡲࡲࠥࡹࡨࡢࡴ࡬ࡲ࡬ࠦࡦࡳࡧࡴࡹࡪࡴࡣࡺ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥ࡯࡮ࡵࠢࡩࡶࡪࡷࡵࡦࡰࡦࡽ࠿ࠦࡔࡩࡧࠣࡷ࡭ࡧࡲࡪࡰࡪࠤࡦࠦࡦࡳࡧࡴࡹࡪࡴࡣࡺ࠮ࠣࡥࠥࡱࡥࡺࠢࡲࡪࠥࡀࡰࡺ࠼ࡤࡸࡹࡸ࠺ࡡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡦࡳࡳࡹࡴࡢࡰࡷࡷ࠳࡙ࡈࡂࡔࡌࡒࡌࡥࡆࡓࡇࡔ࡙ࡊࡔࡃࡊࡇࡖࡤࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡤ࡭ࡸ࡫ࡳࠡࡍࡨࡽࡊࡸࡲࡰࡴ࠽ࠤࡎ࡬ࠠࡡࡢࡩࡶࡪࡷࡵࡦࡰࡦࡽࡥࡦࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࠣ࠾ࡵࡿ࠺ࡢࡶࡷࡶ࠿ࡦࡧࡰࡖࡨࡲࡳࡧ࠮ࡤࡱࡱࡷࡹࡧ࡮ࡵࡵ࠱ࡗࡍࡇࡒࡊࡐࡊࡣࡋࡘࡅࡒࡗࡈࡒࡈࡏࡅࡔࡢࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢస")
        _ = goTenna.constants.sharing_frequency(l1lll1llll1_opy_)
        self._1lll1ll111_opy_ = l1lll1llll1_opy_
    def serialize(self):
        val = goTenna.constants.sharing_frequency(self._1lll1ll111_opy_)
        return goTenna.util.l1111l_opy_(val)
    @classmethod
    def deserialize(cls, value):
        val = goTenna.util.l1l11l11_opy_(value[0])
        parsed = goTenna.constants.sharing_frequency_name(val)
        return cls(parsed)
class LocationAccuracyTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠢࠣࠤࠣࡅ࡚ࠥࡌࡗࠢࡩࡳࡷࠦࡨࡰ࡮ࡧ࡭ࡳ࡭ࠠࡵࡪࡨࠤࡦࡩࡣࡶࡴࡤࡧࡾࠦ࡯ࡧࠢࡷ࡬ࡪࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡ࡯ࡨࡷࡸࡧࡧࡦࠌࠣࠤࠥࠦࠢࠣࠤహ")
    l1l11ll1ll_opy_ = 0x32
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and self.accuracy == other.accuracy
    def __repr__(self):
        return l11ll_opy_ (u"ࠨ࠾ࡏࡳࡨࡧࡴࡪࡱࡱࡅࡨࡩࡵࡳࡣࡦࡽ࡙ࡒࡖ࠻ࠢࡤࡧࡨࡻࡲࡢࡥࡼࡁࢀࢃ࡭࠿ࠩ఺").format(self.accuracy)
    @property
    def accuracy(self):
        l11ll_opy_ (u"ࠤ࡚ࠥࠦࠥࡨࡦࠢࡤࡧࡨࡻࡲࡢࡥࡼࠤࡻࡧ࡬ࡶࡧࠣ࡬ࡪࡲࡤࠡࡤࡼࠤࡹ࡮ࡥࠡࡖࡏ࡚࠱ࠦࡩ࡯ࠢࡰࡩࡹ࡫ࡲࡴࠢࠥࠦࠧ఻")
        return self._accuracy
    def __init__(self, accuracy):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡂࡶ࡫࡯ࡨࠥࡧࠠ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠢࡶ࡬ࡦࡸࡩ࡯ࡩࠣࡥࡨࡩࡵࡳࡣࡦࡽ࡚ࠥࡌࡗࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤ࡮ࡴࡴࠡࡣࡦࡧࡺࡸࡡࡤࡻ࠽ࠤ࡙࡮ࡥࠡࡣࡦࡧࡺࡸࡡࡤࡻࠣࡳ࡫ࠦࡴࡩࡧࠣࡱࡪࡧࡳࡶࡴࡨࡱࡪࡴࡴ࠭ࠢ࡬ࡲࠥࡳࡥࡵࡧࡵࡷ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥࡴࠢࡗࡽࡵ࡫ࡅࡳࡴࡲࡶ࠿ࠦࡉࡧࠢࡣࡤࡦࡩࡣࡶࡴࡤࡧࡾࡦࡠࠡࡥࡤࡲࡳࡵࡴࠡࡤࡨࠤࡨࡵ࡮ࡷࡧࡵࡸࡪࡪࠠࡵࡱࠣࡤࡥ࡯࡮ࡵࡢࡣࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡢ࡫ࡶࡩࡸࠦࡖࡢ࡮ࡸࡩࡊࡸࡲࡰࡴ࠽ࠤࡎ࡬ࠠࡡࡢࡤࡧࡨࡻࡲࡢࡥࡼࡤࡥࠦࡩࡴࠢ࡯ࡩࡸࡹࠠࡵࡪࡤࡲࠥ࠶ࠠࡰࡴࠣࡰࡦࡸࡧࡦࡴࠣࡸ࡭ࡧ࡮ࠡ࠸࠸࠹࠸࠻ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤ఼ࠥࠦ")
        try:
            self._accuracy = int(accuracy)
        except (ValueError, TypeError):
            raise TypeError(l11ll_opy_ (u"ࠫࡦࡩࡣࡶࡴࡤࡧࡾࠦ࡭ࡶࡵࡷࠤࡧ࡫ࠠࡪࡰࡷ࠰ࠥ࡯ࡳࠡࡽࢀࠫఽ").format(type(accuracy)))
        if self._accuracy < 0 or self._accuracy > 65535:
            raise ValueError(l11ll_opy_ (u"ࠬࡧࡣࡤࡷࡵࡥࡨࡿࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡤࡨࡸࡼ࡫ࡥ࡯ࠢ࠳ࠤࡦࡴࡤࠡ࠸࠸࠹࠸࠼ࠬࠡ࡫ࡶࠤࢀࢃࠧా")
                             .format(self._accuracy))
    @classmethod
    def deserialize(cls, value):
        parsed = struct.unpack(l11ll_opy_ (u"࠭ࠡࡉࠩి"), value)[0]
        _MODULE_LOGGER.info(l11ll_opy_ (u"ࠧࡑࡣࡵࡷࡪࡪࠠࡢࡥࡦࡹࡷࡧࡣࡺࠢࡾࢁࠬీ").format(parsed))
        return cls(parsed)
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠨࠣࡋࠫు"), self.accuracy)
class LocationDataTLV(basic_tlv.l111llll11_opy_):
    l11ll_opy_ (u"ࠤࠥࠦࠥࡇࠠࡕࡎ࡙ࠤ࡫ࡵࡲࠡࡪࡲࡰࡩ࡯࡮ࡨࠢ࡯ࡳࡨࡧࡴࡪࡱࡱࠤࡩࡧࡴࡢࠌࠣࠤࠥࠦࠢࠣࠤూ")
    l1l11ll1ll_opy_ = 6
    l111l11l1l_opy_ = (LocationNameTLV, LocationLatitudeTLV,
                           LocationLongitudeTLV, LocationGPSTimestampTLV,
                           MapIDTLV, LocationTypeTLV, LocationAccuracyTLV,
                           l1lll11llll_opy_)
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    @property
    def l111l1l1l1_opy_(self):
        return self.l111l11l1l_opy_
class GroupGIDTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠥࠦࠧࠦࡁࠡࡖࡏ࡚ࠥ࡬࡯ࡳࠢ࡫ࡳࡱࡪࡩ࡯ࡩࠣࡥࠥ࡭ࡲࡰࡷࡳࠫࡸࠦࡇࡊࡆࠍࠤࠥࠦࠠࠣࠤࠥృ")
    l1l11ll1ll_opy_ = 11
    def __repr__(self):
        return l11ll_opy_ (u"ࠫࡁࡍࡲࡰࡷࡳࡋࡎࡊࡔࡍࡘ࠽ࠤ࡬࡯ࡤ࠾ࡽࢀࡂࠬౄ").format(self._gid)
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __eq__(self, other):
        return isinstance(other, GroupGIDTLV) and self.gid == other.gid
    @property
    def gid(self):
        l11ll_opy_ (u"ࠧࠨࠢࠡࡃࡦࡧࡪࡹࡳࡰࡴࠣࡪࡴࡸࠠࡱࡣࡵࡷࡪࡪ࠯ࡴࡲࡨࡧ࡮࡬ࡩࡦࡦࠣࡋࡎࡊࠠࠣࠤࠥ౅")
        return self._gid
    def __init__(self, gid):
        l11ll_opy_ (u"ࠨࠢࠣࠢࡅࡹ࡮ࡲࡤࠡࡶ࡫ࡩ࡚ࠥࡌࡗࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤ࡬࡯ࡤ࠻ࠢࡗ࡬ࡪࠦࡇࡊࡆࠣࡳ࡫ࠦࡴࡩࡧࠣ࡫ࡷࡵࡵࡱࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡹࡿࡰࡦࠢࡪ࡭ࡩࡀࠠ࡭ࡱࡱ࡫ࠥࡵࡲࠡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌࡏࡄࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧె")
        if not isinstance(gid, goTenna.settings.GID):
            raise TypeError(l11ll_opy_ (u"ࠧࡨ࡫ࡧࠤࡸ࡮࡯ࡶ࡮ࡧࠤࡧ࡫ࠠࡢࠢࡪ࡭ࡩࠦࡴࡺࡲࡨࠤࡧࡻࡴࠡ࡫ࡶࠤࢀࢃࠧే")
                            .format(type(gid)))
        if gid.gid_type != goTenna.settings.GID.GROUP:
            raise ValueError(l11ll_opy_ (u"ࠨࡩ࡬ࡨࠥࡹࡨࡰࡷ࡯ࡨࠥࡨࡥࠡࡣࠣ࡫ࡷࡵࡵࡱࠢࡪ࡭ࡩ࠭ై"))
        self._gid = gid
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠩࠤࡕࠬ౉"), self._gid.gid_val)
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        (gid,) = struct.unpack(l11ll_opy_ (u"ࠪࠥࡖ࠭ొ"), l111l1ll1l_opy_)
        return cls(goTenna.settings.GID(gid, goTenna.settings.GID.GROUP))
class GroupMemberListTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠦࠧࠨࠠࡂࠢࡗࡐ࡛ࠦࡦࡰࡴࠣ࡬ࡴࡲࡤࡪࡰࡪࠤࡦࠦࡧࡳࡱࡸࡴࠥࡳࡥ࡮ࡤࡨࡶࠥࡲࡩࡴࡶࠍࠤࠥࠦࠠࠣࠤࠥో")
    l1l11ll1ll_opy_ = 12
    def __repr__(self):
        return l11ll_opy_ (u"ࠬࡂࡇࡳࡱࡸࡴࡒ࡫࡭ࡣࡧࡵࡐ࡮ࡹࡴࡕࡎ࡙࠾ࠥࡳࡥ࡮ࡤࡨࡶࡸࡃࡻࡾࡀࠪౌ").format(self._members)
    def __eq__(self, other):
        return isinstance(other, GroupMemberListTLV)\
            and self.members == other.members
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    @property
    def members(self):
        l11ll_opy_ (u"ࠨࠢࠣࠢࡗ࡬ࡪࠦ࡭ࡦ࡯ࡥࡩࡷࡹࠠࡰࡨࠣࡸ࡭࡫ࠠࡨࡴࡲࡹࡵࠦࠢࠣࠤ్")
        return self._members
    def __init__(self, members):
        l11ll_opy_ (u"ࠢࠣࠤࠣࡆࡺ࡯࡬ࡥࠢࡷ࡬ࡪࠦࡔࡍࡘࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳࡥ࡮ࡤࡨࡶࡸࡀࠠࡕࡪࡨࠤࡲ࡫࡭ࡣࡧࡵࡷࠥࡵࡦࠡࡶ࡫ࡩࠥ࡭ࡲࡰࡷࡳ࠲ࠥࡕࡲࡥࡧࡵ࡭ࡳ࡭ࠠࡴࡪࡲࡹࡱࡪࠠࡣࡧࠣࡴࡷ࡫ࡳࡦࡴࡹࡩࡩࠦࡡࡤࡴࡲࡷࡸࠦࡩ࡯ࡵࡷࡥࡳࡩࡥࡴࠢࡲࡪࠥࡺࡨࡦࠢࡪࡶࡴࡻࡰ࠯ࠢࡗ࡬࡮ࡹࠠ࡭࡫ࡶࡸࠥ࡯ࡳࠡࡣࡶࡷࡺࡳࡥࡥࠢࡷࡳࠥࡹࡴࡢࡴࡷࠤࡦࡺࠠࡪࡰࡧࡩࡽࠦ࠱࠭ࠢࡤࡲࡩࠦࡳࡩࡱࡸࡰࡩࠦ࡮ࡰࡶࠣ࡭ࡳࡩ࡬ࡶࡦࡨࠤࡹ࡮ࡥࠡࡥࡵࡩࡦࡺ࡯ࡳࠢࡲࡪࠥࡺࡨࡦࠢࡪࡶࡴࡻࡰ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡹࡿࡰࡦࠢࡰࡩࡲࡨࡥࡳࡵ࠽ࠤࡱ࡯ࡳࡵ࡝ࡪࡳ࡙࡫࡮࡯ࡣ࠱࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡊࡆࡠࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣ౎")
        if len(members) < 2:
            raise ValueError(l11ll_opy_ (u"ࠨࡏࡸࡷࡹࠦࡢࡦࠢࡤࡸࠥࡲࡥࡢࡵࡷࠤ࠷ࠦ࡭ࡦ࡯ࡥࡩࡷࡹࠠࡰࡶ࡫ࡩࡷࠦࡴࡩࡣࡱࠤࡴࡸࡩࡨ࡫ࡱࡥࡹࡵࡲࠨ౏"))
        if len(members) > goTenna.settings.Group.MAX_MEMBERS:
            raise ValueError(l11ll_opy_ (u"ࠩࡐࡹࡸࡺࠠࡣࡧࠣࡪࡪࡽࡥࡳࠢࡷ࡬ࡦࡴࠠࡼࡿࠣࡱࡪࡳࡢࡦࡴࡶࠫ౐")
                             .format(goTenna.settings.Group.MAX_MEMBERS))
        self._members = []
        for member in members:
            if isinstance(member, goTenna.settings.GID):
                self._members.append(member)
            else:
                raise TypeError(l11ll_opy_ (u"ࠪࡱࡪࡳࡢࡦࡴࡶࠤࡸ࡮࡯ࡶ࡮ࡧࠤࡧ࡫ࠠࡈࡋࡇࠤࡹࡿࡰࡦࡵ࠯ࠤࡧࡻࡴࠡ࡯ࡨࡱࡧ࡫ࡲࠡ࡫ࡶࠤࢀࢃࠧ౑")
                                .format(type(member)))
    def serialize(self):
        serialized = six.b(l11ll_opy_ (u"ࠫࠬ౒"))
        for idx, gid in enumerate(self._members):
            serialized += struct.pack(l11ll_opy_ (u"ࠬࠧࡑࡃࠩ౓"), gid.gid_val, idx+1)
        return serialized
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        l1lll1ll1ll_opy_ = l111l1ll1l_opy_
        l1lll11l111_opy_ = [None] * int(len(l111l1ll1l_opy_)/9)
        while True:
            if not l1lll1ll1ll_opy_:
                break
            if len(l1lll1ll1ll_opy_) < 9:
                raise ValueError(l11ll_opy_ (u"࠭ࡍࡢ࡮ࡩࡳࡷࡳࡥࡥࠢࡗࡐ࡛ࠧࠧ౔"))
            l1lll11ll11_opy_ = l1lll1ll1ll_opy_[:9]
            l1lll1ll1ll_opy_ = l1lll1ll1ll_opy_[9:]
            (gid, membership) = struct.unpack(l11ll_opy_ (u"ࠧࠢࡓࡅౕࠫ"), l1lll11ll11_opy_)
            l1lll11l111_opy_[membership-1] = goTenna.settings.GID(gid,
                                                      goTenna.settings.GID.PRIVATE)
        return cls(l1lll11l111_opy_)
class GroupSharedSecretTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠣࠤࠥࠤࡆࠦࡔࡍࡘࠣࡪࡴࡸࠠࡩࡱ࡯ࡨ࡮ࡴࡧࠡࡣࠣ࡫ࡷࡵࡵࡱࠢࡶ࡬ࡦࡸࡥࡥࠢࡶࡩࡨࡸࡥࡵࠌࠣࠤࠥࠦࠢࠣࠤౖ")
    l1l11ll1ll_opy_ = 13
    def __repr__(self):
        return l11ll_opy_ (u"ࠩ࠿ࡋࡷࡵࡵࡱࡕ࡫ࡥࡷ࡫ࡤࡔࡧࡦࡶࡪࡺࡔࡍࡘ࠽ࠤࡘ࡫ࡣࡳࡧࡷ࠾ࠥࢁࡽ࠿ࠩ౗")\
            .format(goTenna.util.display_bytestring(self._1lll11ll1l_opy_))
    def __eq__(self, other):
        return isinstance(other, GroupSharedSecretTLV)\
            and other.secret == self.secret
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    @property
    def secret(self):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡔࡩࡧࠣࡷࡪࡩࡲࡦࡶࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡩࠦࡩ࡯ࠢࡷ࡬ࡪࠦࡔࡍࡘ࠱ࠤࠧࠨࠢౘ")
        return self._1lll11ll1l_opy_
    def __init__(self, secret):
        l11ll_opy_ (u"ࠦࠧࠨࠠࡃࡷ࡬ࡰࡩࠦࡴࡩࡧࠣࡘࡑ࡜࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡦࡾࡺࡥࡴ࡮࡬࡯ࡪࠦࡳࡦࡥࡵࡩࡹࡀࠠࡕࡪࡨࠤࡸ࡮ࡡࡳࡧࡧࠤࡸ࡫ࡣࡳࡧࡷ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤౙ")
        try:
            _ = struct.pack(l11ll_opy_ (u"ࠬ࠷ࡳࠨౚ"), secret[:1])
        except Exception:
            raise TypeError(l11ll_opy_ (u"࠭ࡳࡦࡥࡵࡩࡹࠦࡳࡩࡱࡸࡰࡩࠦࡢࡦࠢࡥࡽࡹ࡫ࡳ࡭࡫࡮ࡩ࠱ࠦࡩࡴࠢࡾࢁࠬ౛")
                            .format(type(secret)))
        if len(secret) != 32:
            raise ValueError(l11ll_opy_ (u"ࠧࡴࡧࡦࡶࡪࡺࠠࡴࡪࡲࡹࡱࡪࠠࡣࡧࠣࡴࡷ࡫ࡣࡪࡵࡨࡰࡾࠦ࠳࠳ࠢࡥࡽࡹ࡫ࡳ࠭ࠢ࡬ࡷࠥࢁࡽࠨ౜")
                             .format(len(secret)))
        self._1lll11ll1l_opy_ = secret
    def serialize(self):
        return self._1lll11ll1l_opy_
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        if len(l111l1ll1l_opy_) != 32:
            raise ValueError(l111l1ll1l_opy_)
        return cls(l111l1ll1l_opy_)
class EncryptionInfoTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠣࠤࠥࠤࡆࠦࡔࡍࡘࠣࡪࡴࡸࠠࡢࠢࡰࡩࡸࡹࡡࡨࡧࠣࡩࡳࡩࡲࡺࡲࡷ࡭ࡴࡴࠠࡩࡧࡤࡨࡪࡸࠊࠡࠢࠣࠤࠧࠨࠢౝ")
    l1l11ll1ll_opy_ = 251
    def __repr__(self):
        return l11ll_opy_ (u"ࠩ࠿ࡉࡳࡩࡲࡺࡲࡷ࡭ࡴࡴࡉ࡯ࡨࡲࡘࡑ࡜࠺ࠡࡵࡨࡲࡩ࡫ࡲ࠾ࡽࢀࠤࡹ࡯࡭ࡦ࠿ࡾࢁࠥ࡫࡮ࡤࡴࡼࡴࡹ࡫ࡤ࠾ࡽࢀࠤࡨࡵࡵ࡯ࡶࡨࡶࡂࢁࡽ࠿ࠩ౞")\
            .format(self.sender.gid_val,
                    self.timestamp,
                    self.encrypted,
                    self.counter)
    def __eq__(self, other):
        return isinstance(other, EncryptionInfoTLV)\
            and self.sender.gid_val == other.sender.gid_val\
            and self.sender.gid_type == other.sender.gid_type\
            and self.timestamp == other.timestamp\
            and self.encrypted == other.encrypted\
            and self.counter == other.counter\
            and self.message_id == other.message_id
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, sender, timestamp, encrypted, counter, message_id):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡃࡳࡧࡤࡸࡪࠦࡡ࡯ࠢࡈࡲࡨࡸࡹࡱࡶ࡬ࡳࡳࡏ࡮ࡧࡱࡗࡐ࡛࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡳࡪࡥࡳ࠼ࠣࡘ࡭࡫ࠠࡴࡧࡱࡨࡪࡸࠠࡰࡨࠣࡸ࡭࡫ࠠ࡮ࡧࡶࡷࡦ࡭ࡥ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡹࡿࡰࡦࠢࡶࡩࡳࡪࡥࡳ࠼ࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡊࡆࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡹ࡯࡭ࡦࡵࡷࡥࡲࡶ࠺ࠡࡖ࡫ࡩࠥࡺࡩ࡮ࡧࠣࡸࡴࠦࡡࡴࡵࡲࡧ࡮ࡧࡴࡦࠢࡺ࡭ࡹ࡮ࠠࡵࡪࡨࠤࡲ࡫ࡳࡴࡣࡪࡩ࠳ࠦࡕࡴࡧࡧࠤ࡫ࡵࡲࠡࡱࡵࡨࡪࡸࡩ࡯ࡩ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡴࡺࡲࡨࠤࡹ࡯࡭ࡦࡵࡷࡥࡲࡶ࠺ࠡ࡫ࡱࡸࠥࡵࡲࠡࡦࡤࡸࡪࡺࡩ࡮ࡧ࠱ࡨࡦࡺࡥࡵ࡫ࡰࡩࠥࡵࡲࠡࡶࡸࡴࡱ࡫ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡤࡲࡳࡱࠦࡥ࡯ࡥࡵࡽࡵࡺࡥࡥ࠼࡛ࠣ࡭࡫ࡴࡩࡧࡵࠤࡹ࡮ࡥࠡ࡯ࡨࡷࡸࡧࡧࡦࠢ࡬ࡷࠥ࡫࡮ࡤࡴࡼࡴࡹ࡫ࡤ࠯ࠢࡑࡳࡹ࡫࠺ࠡࡖ࡫࡭ࡸࠦࡶࡢ࡮ࡸࡩࠥ࡯ࡳࠡࡥࡸࡶࡷ࡫࡮ࡵ࡮ࡼࠤ࡮࡭࡮ࡰࡴࡨࡨࠥࡽࡨࡦࡰࠣࡴࡦࡩ࡫ࡪࡰࡪࠤࡦࠦࡔࡍࡘ࠯ࠤࡦࡴࡤࠡ࡫ࡶࠤࡵࡸࡥࡴࡧࡱࡸࠥ࡯࡮ࠡࡶ࡫࡭ࡸࠦࡣࡰࡰࡶࡸࡷࡻࡣࡵࡱࡵࠤ࡫ࡵࡲࠡࡴࡨࡴࡷ࡫ࡳࡦࡰࡷ࡭ࡳ࡭ࠠࡵࡪࡨࠤࡻࡧ࡬ࡶࡧࠣࡶࡪࡧࡤࠡࡨࡵࡳࡲࠦࡡࠡࡦࡨࡺ࡮ࡩࡥ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣ࡭ࡳࡺࠠࡤࡱࡸࡲࡹ࡫ࡲ࠻ࠢࡗ࡬ࡪࠦࡩ࡯ࡦࡨࡼࠥ࡯࡮ࡵࡱࠣࡸ࡭࡫ࠠࡴࡪࡤࡶࡪࡪࠠࡴࡧࡦࡶࡪࡺࠠࡵࡪࡤࡸࠥࡩࡡ࡮ࡧࠣࡥࡱࡵ࡮ࡨࠢࡺ࡭ࡹ࡮ࠠࡵࡪ࡬ࡷࠥࡳࡥࡴࡵࡤ࡫ࡪ࠴ࠠࡏࡱࡷࡩ࠿ࠦࡔࡩ࡫ࡶࠤࡻࡧ࡬ࡶࡧࠣ࡭ࡸࠦࡣࡶࡴࡵࡩࡳࡺ࡬ࡺࠢ࡬࡫ࡳࡵࡲࡦࡦࠣࡻ࡭࡫࡮ࠡࡲࡤࡧࡰ࡯࡮ࡨࠢࡤࠤ࡙ࡒࡖ࠭ࠢࡤࡲࡩࠦࡩࡴࠢࡳࡶࡪࡹࡥ࡯ࡶࠣ࡭ࡳࠦࡴࡩ࡫ࡶࠤࡨࡵ࡮ࡴࡶࡵࡹࡨࡺ࡯ࡳࠢࡩࡳࡷࠦࡲࡦࡲࡵࡩࡸ࡫࡮ࡵ࡫ࡱ࡫ࠥࡺࡨࡦࠢࡹࡥࡱࡻࡥࠡࡴࡨࡥࡩࠦࡦࡳࡱࡰࠤࡦࠦࡤࡦࡸ࡬ࡧࡪ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡ࡫ࡱࡸࠥࡳࡥࡴࡵࡤ࡫ࡪࡥࡩࡥ࠼ࠣࡘ࡭࡫ࠠ࡮ࡧࡶࡷࡦ࡭ࡥࠡࡋࡇ࠰ࠥ࡬࡯ࡳࠢࡶࡹࡵࡶ࡯ࡳࡶ࡬ࡲ࡬ࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡳࡧࡶࡩࡳࡪࠠࡥࡧࡧࡹࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠮ࠡࡗࡱࡹࡸ࡫ࡤࠡࡪࡨࡶࡪ࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠱࠲ࠥࡴ࡯ࡵࡧࠣ࠾ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡗ࡬࡮ࡹࠠࡰࡤ࡭ࡩࡨࡺࠠࡩࡱ࡯ࡨࡸࠦࡴࡩࡧࠣࡸ࡮ࡳࡥࡴࡶࡤࡱࡵࠦࡩ࡯ࡶࡨࡶࡳࡧ࡬࡭ࡻࠣࡥࡸࠦࡡࠡࡰࡤ࡭ࡻ࡫ࠠ࠻ࡲࡼ࠾ࡨࡲࡡࡴࡵ࠽ࡤࡩࡧࡴࡦࡶ࡬ࡱࡪ࠴ࡤࡢࡶࡨࡸ࡮ࡳࡥࡡࠢࡲࡦ࡯࡫ࡣࡵࠢࡷ࡬ࡦࡺࠠࡪࡵࠣࡥࡸࡹࡵ࡮ࡧࡧࠤࡹࡵࠠࡩࡱ࡯ࡨ࡛ࠥࡔࡄ࠰ࠣࡍ࡫ࠦࡴࡩࡧࠣࡤࡥࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࡡࡢࠣࡥࡷ࡭ࡵ࡮ࡧࡱࡸࠥ࡯ࡳࠡࡣࡱࠤࡦࡽࡡࡳࡧࠣ࠾ࡵࡿ࠺ࡤ࡮ࡤࡷࡸࡀࡠࡥࡣࡷࡩࡹ࡯࡭ࡦ࠰ࡧࡥࡹ࡫ࡴࡪ࡯ࡨࡤࠥ࡯ࡴࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡦࡳࡳࡼࡥࡳࡶࡨࡨࠥࡺ࡯ࠡࡗࡗࡇ࠳ࠦࡉࡧࠢࡷ࡬ࡪࠦࡠࡡࡶ࡬ࡱࡪࡹࡴࡢ࡯ࡳࡤࡥࠦࡡࡳࡩࡸࡱࡪࡴࡴࠡ࡫ࡶࠤࡦࠦ࡮ࡢ࡫ࡹࡩࠥࡀࡰࡺ࠼ࡦࡰࡦࡹࡳ࠻ࡢࡧࡥࡹ࡫ࡴࡪ࡯ࡨ࠲ࡩࡧࡴࡦࡶ࡬ࡱࡪࡦࠬࠡࡣࡱࠤ࡮ࡴࡴ࠭ࠢࡲࡶࠥࡧࠠࡵ࡫ࡰࡩ࠲ࡺࡵࡱ࡮ࡨࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡨࡥࠡࡣࡶࡷࡺࡳࡥࡥࠢࡷࡳࠥࡨࡥࠡࡣ࡯ࡶࡪࡧࡤࡺࠢ࡬ࡲ࡛ࠥࡔࡄ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥ࠴࠮ࠡࡰࡲࡸࡪࠦ࠺ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡚ࠥࡨࡰࡷࡪ࡬ࠥࡺࡨࡦࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠥ࡯ࡳࠡࡪࡨࡰࡩࠦࡩ࡯ࡶࡨࡶࡳࡧ࡬࡭ࡻࠣࡥࡸࠦࡡࠡ࠼ࡳࡽ࠿ࡩ࡬ࡢࡵࡶ࠾ࡥࡪࡡࡵࡧࡷ࡭ࡲ࡫࠮ࡥࡣࡷࡩࡹ࡯࡭ࡦࡢ࠯ࠤ࡮ࡺࡳࠡࡵࡨࡶ࡮ࡧ࡬ࡪࡼࡤࡸ࡮ࡵ࡮ࠡࡦࡲࡩࡸࠦ࡮ࡰࡶࠣࡥࡱࡲ࡯ࡸࠢ࡬ࡸࠥࡺ࡯ࠡࡲࡵࡩࡸ࡫ࡲࡷࡧࠣࡸ࡭࡫ࠠࡧࡷ࡯ࡰࠥࡶࡲࡦࡥ࡬ࡷ࡮ࡵ࡮ࠡࡱࡩࠤࡹ࡮ࡥࠡࡶࡼࡴࡪ࠴ࠠࡕࡱࠣࡱࡦࡱࡥࠡࡶ࡫࡭ࡸࠦ࡭ࡰࡴࡨࠤࡴࡨࡶࡪࡱࡸࡷ࠱ࠦࡴࡩࡧࠣࡱ࡮ࡩࡲࡰࡵࡨࡧࡴࡴࡤࠡࡨ࡬ࡩࡱࡪࠠࡸ࡫࡯ࡰࠥࡨࡥࠡࡵࡷࡶ࡮ࡶࡰࡦࡦࠣࡪࡷࡵ࡭ࠡࡶ࡫ࡩࠥࡵࡢ࡫ࡧࡦࡸࠥࡽࡨࡦࡰࠣ࡭ࡹࠦࡩࡴࠢࡳࡥࡸࡹࡥࡥࠢ࡬ࡲࡹࡵࠠࡵࡪ࡬ࡷࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠲࠳ࠦ࡮ࡰࡶࡨࠤ࠿ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡍ࡫ࠦࡡࠡ࠼ࡳࡽ࠿ࡩ࡬ࡢࡵࡶ࠾ࡥࡺࡩ࡮ࡧ࠱ࡷࡹࡸࡵࡤࡶࡢࡸ࡮ࡳࡥࡡࠢࡲࡶࠥࡦࡠࡵࡷࡳࡰࡪࡦࡠࠡࡧࡴࡹ࡮ࡼࡡ࡭ࡧࡱࡸࠥ࡯ࡳࠡࡲࡤࡷࡸ࡫ࡤࠡ࡫ࡱࠤࡹࡵࠠࡵࡪ࡬ࡷࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠬࠡࡧࡱࡷࡺࡸࡥࠡࡶ࡫ࡥࡹࠦࡩࡵࠢ࡬ࡷࠥ࡯࡮ࠡࡗࡗࡇࠥ࡬ࡩࡳࡵࡷ࠲࡚ࠥࡨࡦࠢࡦࡳࡳࡹࡴࡳࡷࡦࡸࡴࡸࠠࡤࡱࡱࡺࡪࡸࡴࡴࠢ࡬ࡸࠥࡺ࡯ࠡࡣࠣ࠾ࡵࡿ࠺ࡤ࡮ࡤࡷࡸࡀࡠࡥࡣࡷࡩࡹ࡯࡭ࡦ࠰ࡧࡥࡹ࡫ࡴࡪ࡯ࡨࡤࠥࡨࡹࠡࡲࡤࡷࡸ࡯࡮ࡨࠢ࡬ࡸࠥࡺࡨࡳࡱࡸ࡫࡭ࠦ࠺ࡱࡻ࠽ࡱࡪࡺࡨ࠻ࡢࡷ࡭ࡲ࡫࠮࡮࡭ࡷ࡭ࡲ࡫ࡠࠡࡣࡱࡨࠥࡀࡰࡺ࠼ࡰࡩࡹ࡮࠺ࡡࡦࡤࡸࡪࡺࡩ࡮ࡧ࠱ࡨࡦࡺࡥࡵ࡫ࡰࡩ࠳ࡻࡴࡤࡨࡵࡳࡲࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࡡ࠮ࠣࡻ࡭࡯ࡣࡩࠢࡰࡩࡦࡴࡳࠡࡶ࡫ࡥࡹࠦࡴࡩࡧࠣࡺࡦࡲࡵࡦࠢࡰࡥࡾࠦࡣࡩࡣࡱ࡫ࡪࠦࡳࡶࡴࡳࡶ࡮ࡹࡩ࡯ࡩ࡯ࡽ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ౟")
        if isinstance(sender, goTenna.settings.GID):
            self.sender = sender
        else:
            raise TypeError(sender)
        self._1lll11l1l1_opy_ = goTenna.util.time_from_various(timestamp)
        l1lll1l11ll_opy_ = datetime.timedelta(microseconds=self._1lll11l1l1_opy_.microsecond)
        self._1lll11l1l1_opy_ = self._1lll11l1l1_opy_ - l1lll1l11ll_opy_
        self.encrypted = bool(encrypted)
        self.counter = int(counter)
        self.message_id = int(message_id)
    @property
    def time(self):
        l11ll_opy_ (u"ࠦࠧࠨࠠࡂࠢࡳࡶࡴࡶࡥࡳࡶࡼࠤࡷ࡫ࡴࡶࡴࡱ࡭ࡳ࡭ࠠࡵࡪࡨࠤࡹ࡯࡭ࡦࡵࡷࡥࡲࡶࠠࡢࡵࠣࡥࠥࡶࡲࡰࡲࡨࡶࠥࡪࡡࡵࡧࡷ࡭ࡲ࡫࠮ࡥࡣࡷࡩࡹ࡯࡭ࡦ࠰ࠣࠦࠧࠨౠ")
        return self._1lll11l1l1_opy_
    @property
    def timestamp(self):
        l11ll_opy_ (u"ࠧࠨࠢࠡࡃࠣࡴࡷࡵࡰࡦࡴࡷࡽࠥࡸࡥࡵࡷࡵࡲ࡮ࡴࡧࠡࡶ࡫ࡩࠥࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࠡࡣࡶࠤࡦࠦࡐࡰࡵ࡬ࡼࠥ࡫ࡰࡰࡥ࡫ࠤࡹ࡯࡭ࡦࡥࡲࡨࡪ࠴ࠠࠣࠤࠥౡ")
        return int((self._1lll11l1l1_opy_\
                    - datetime.datetime.utcfromtimestamp(0)).total_seconds())
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        if len(l111l1ll1l_opy_) == 15:
            fields = struct.unpack(l11ll_opy_ (u"࠭ࠡࡃࡓࡌࡌࠬౢ"), l111l1ll1l_opy_)
        elif len(l111l1ll1l_opy_) == 16:
            fields = struct.unpack(l11ll_opy_ (u"ࠧࠢࡄࡔࡍࡍࡈࠧౣ"), l111l1ll1l_opy_)
        else:
            err = l11ll_opy_ (u"ࠨࡋࡱࡺࡦࡲࡩࡥࠢࡗࡐ࡛ࠦ࡬ࡦࡰࡪࡸ࡭ࠦࡻࡾࠢࡩࡳࡷࠦࡥ࡯ࡥࡵࡽࡵࡺࡩࡰࡰࠣ࡭ࡳ࡬࡯࠭ࠢࡧࡥࡹࡧࠠࡼࡿࠪ౤")\
                  .format(len(l111l1ll1l_opy_),
                          goTenna.util.display_bytestring(l111l1ll1l_opy_))
            cls.l111ll11ll_opy_().warning(err)
            raise IndexError(err)
        return cls(goTenna.settings.GID(fields[1],
                                        goTenna.settings.GID.PRIVATE),
                   fields[2], fields[0], fields[3],
                   fields[4] if len(fields) > 4 else 0)
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠩࠤࡆࡖࡏࡈࡃࠩ౥"), self.encrypted,
                           self.sender.gid_val,
                           self.timestamp, self.counter, self.message_id)
class FrequencySlotDataBandwidthTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠥࠦࠧࠦࡁࠡࡖࡏ࡚ࠥ࡬࡯ࡳࠢࡶࡩࡳࡪࡩ࡯ࡩࠣࡪࡷ࡫ࡱࡶࡧࡱࡧࡾࠦࡳ࡭ࡱࡷࡷ࠳ࠐࠊࠡࠢࠣࠤࡈࡻࡲࡳࡧࡱࡸࡱࡿࠠࡵࡪ࡬ࡷࠥࡵ࡮࡭ࡻࠣ࡬ࡴࡲࡤࡴࠢࡷ࡬ࡪࠦࡣࡩࡣࡱࡲࡪࡲࠠ࡮ࡣࡶ࡯ࠥࡽࡩࡥࡶ࡫࠰ࠥࡧ࡮ࡥࠢࡧࡳࡪࡹࠠ࡯ࡱࡷࠤࡸࡶࡥࡤ࡫ࡩࡽࠥࡧࠠࡣ࡫ࡷࡶࡦࡺࡥ࠯࡚ࠢ࡬ࡪࡴࠠࡵࡪࡨࠤࡘࡊࡋࠡࡲࡤࡶࡸ࡫ࡳࠡࡱࡱࡩࠥࡵࡦࠡࡶ࡫ࡩࡸ࡫ࠠࡕࡎ࡙ࡷࠥ࡬ࡲࡰ࡯ࠣࡸ࡭࡫ࠠ࡮ࡧࡶࡷࡦ࡭ࡥ࠭ࠢ࡬ࡸࠥࡽࡩ࡭࡮ࠣࡨࡪ࡬ࡡࡶ࡮ࡷࠤࡹࡵࠠࡶࡵ࡬ࡲ࡬ࠦࡴࡩࡧࠣ࡬࡮࡭ࡨࡦࡴࠣࡦ࡮ࡺࡲࡢࡶࡨࠤࡦࡹࡳࡰࡥ࡬ࡥࡹ࡫ࡤࠡࡹ࡬ࡸ࡭ࠦࡴࡩࡧࠣࡱࡦࡹ࡫࠯ࠌࠣࠤࠥࠦࠢࠣࠤ౦")
    l1l11ll1ll_opy_ = 29
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, l1lll11lll1_opy_):
        if isinstance(l1lll11lll1_opy_, goTenna.constants.Bandwidth):
            self._1llll11111_opy_ = l1lll11lll1_opy_
        elif isinstance(l1lll11lll1_opy_, int):
            self._1llll11111_opy_ = goTenna.constants.BANDWIDTH_KHZ[l1lll11lll1_opy_]
        else:
            raise TypeError(l11ll_opy_ (u"ࠫࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮ࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡧ࡬ࡸ࡭࡫ࡲࠡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡦࡳࡳࡹࡴࡢࡰࡷࡷ࠳ࡈࡡ࡯ࡦࡺ࡭ࡩࡺࡨࠡࡱࡵࠤࡦࡴࠠࡪࡰࡷࠤ࡮ࡴࡤࡦࡺࠣ࡭ࡳࡺ࡯ࠡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡦࡳࡳࡹࡴࡢࡰࡷࡷ࠳ࡈࡡ࡯ࡦࡺ࡭ࡩࡺࡨ࠭ࠢ࡬ࡷࠥࢁࡽࠨ౧")
                            .format(type(l1lll11lll1_opy_)))
    @property
    def bandwidth(self):
        return self._1llll11111_opy_
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠬࠧࡉࠨ౨"), self._1llll11111_opy_.index)
    @classmethod
    def deserialize(cls, value):
        return cls(struct.unpack(l11ll_opy_ (u"࠭ࠡࡊࠩ౩"), value)[0])
    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and self.bandwidth == other.bandwidth
    def __repr__(self):
        return l11ll_opy_ (u"ࠧ࠽ࡽࢀ࠾ࠥࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨ࠾ࡽࢀࡂࠬ౪").format(self.__class__.__name__, self.bandwidth)
class FrequencySlotMaxPowerTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠣࠤࠥࠤࡆࠦࡔࡍࡘࠣࡪࡴࡸࠠࡧࡴࡨࡵࡺ࡫࡮ࡤࡻࠣࡷࡱࡵࡴࠡࡲࡲࡻࡪࡸࠊࠡࠢࠣࠤࠧࠨࠢ౫")
    l1l11ll1ll_opy_ = 25
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, power):
        if not goTenna.constants.POWERLEVELS.valid(power):
            raise ValueError(l11ll_opy_ (u"ࠩࡳࡳࡼ࡫ࡲࠡࡵ࡫ࡳࡺࡲࡤࠡࡤࡨࠤࡦࠦ࡭ࡦ࡯ࡥࡩࡷࠦ࡯ࡧࠢࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡧࡴࡴࡳࡵࡣࡱࡸࡸ࠴ࡐࡐ࡙ࡈࡖࡑࡋࡖࡆࡎࡖ࠰ࠥ࡯ࡳࠡࡽࢀࠫ౬")
                             .format(power))
        self._1lll111lll_opy_ = power
    @property
    def power(self):
        return self._1lll111lll_opy_
    def serialize(self):
        value = {goTenna.constants.POWERLEVELS.HALF_W: 0.5,
                 goTenna.constants.POWERLEVELS.ONE_W: 1.0,
                 goTenna.constants.POWERLEVELS.TWO_W: 2.0,
                 goTenna.constants.POWERLEVELS.FIVE_W: 5.0}[self._1lll111lll_opy_]
        return struct.pack(l11ll_opy_ (u"ࠪࠥࡩ࠭౭"), value)
    @classmethod
    def deserialize(cls, value):
        l111111l1l_opy_ = struct.unpack(l11ll_opy_ (u"ࠫࠦࡪࠧ౮"), value)[0]
        parsed = 0
        if l111111l1l_opy_ < 0.0:
            raise ValueError(l11ll_opy_ (u"ࠬࡨࡡࡥࠢࡳࡳࡼ࡫ࡲࠡࡷࡱࡴࡦࡩ࡫ࡦࡦࠣࡪࡷࡵ࡭ࠡࡶ࡯ࡺࠥ࠮࡮ࡦࡩࡤࡸ࡮ࡼࡥࠪ࠼ࠣࡿࢂ࠭౯")
                             .format(l111111l1l_opy_))
        elif l111111l1l_opy_ < 0.75:
            parsed = goTenna.constants.POWERLEVELS.HALF_W
        elif l111111l1l_opy_ < 1.5:
            parsed = goTenna.constants.POWERLEVELS.ONE_W
        elif l111111l1l_opy_ < 3.5:
            parsed = goTenna.constants.POWERLEVELS.TWO_W
        elif l111111l1l_opy_ < 6:
            parsed = goTenna.constants.POWERLEVELS.FIVE_W
        else:
            raise ValueError(l11ll_opy_ (u"࠭ࡢࡢࡦࠣࡴࡴࡽࡥࡳࠢࡸࡲࡵࡧࡣ࡬ࡧࡧࠤ࡫ࡸ࡯࡮ࠢࡷࡰࡻࠦࠨࡵࡱࡲࠤࡱࡧࡲࡨࡧࠬ࠾ࠥࢁࡽࠨ౰")
                             .format(value))
        return cls(parsed)
    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and self.power == other.power
    def __repr__(self):
        return l11ll_opy_ (u"ࠧ࠽ࡽࢀ࠾ࠥࡶ࡯ࡸࡧࡵࡁࢀࢃ࠾ࠨ౱")\
            .format(self.__class__.__name__,
                    goTenna.constants.POWERLEVELS.name(self.power))
class FrequencySlotFrequencyListTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠣࠤࠥࠤࡆࠦࡔࡍࡘࠣ࡬ࡴࡲࡤࡪࡰࡪࠤࡨ࡮ࡡ࡯ࡰࡨࡰࠥ࡬ࡲࡦࡳࡸࡩࡳࡩࡩࡦࡵࠍࠤࠥࠦࠠࠣࠤࠥ౲")
    l1l11ll1ll_opy_ = 26
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, control_freqs, data_freqs):
        l11ll_opy_ (u"ࠤࠥࠦࠥࡈࡵࡪ࡮ࡧࠤࡹ࡮ࡥࠡࡨࡵࡩࡶࡻࡥ࡯ࡥࡼࠤࡱ࡯ࡳࡵ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡲࡩࡴࡶ࡞࡭ࡳࡺ࡝ࠡࡥࡲࡲࡹࡸ࡯࡭ࡡࡩࡶࡪࡷࡳ࠻ࠢࡄࠤࡱ࡯ࡳࡵࠢࡲࡪࠥࡩ࡯࡯ࡶࡵࡳࡱࠦࡦࡳࡧࡴࡹࡪࡴࡣࡪࡧࡶ࠲ࠥࡋࡡࡤࡪࠣࡱࡺࡹࡴࠡࡲࡤࡷࡸࠦ࠺ࡱࡻ࠽ࡱࡪࡺࡨ࠻ࡢࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡘࡆࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡹࡥࡱ࡯ࡤࡢࡶࡨࡣ࡫ࡸࡥࡲࡢ࠱ࠤ࡙࡮ࡥࡳࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡦࡪࠦࡡࡵࠢ࡯ࡩࡦࡹࡴࠡࡱࡱࡩࠥࡧ࡮ࡥࠢࡩࡩࡼ࡫ࡲࠡࡶ࡫ࡥࡳࠦࡴࡩࡴࡨࡩ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭࡫ࡶࡸࡠ࡯࡮ࡵ࡟ࠣࡨࡦࡺࡡࡠࡨࡵࡩࡶࡹ࠺ࠡࡃࠣࡰ࡮ࡹࡴࠡࡱࡩࠤࡩࡧࡴࡢࠢࡩࡶࡪࡷࡵࡦࡰࡦ࡭ࡪࡹ࠮ࠡࡇࡤࡧ࡭ࠦ࡭ࡶࡵࡷࠤࡵࡧࡳࡴࠢ࠽ࡴࡾࡀ࡭ࡦࡶ࡫࠾ࡥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡔࡉࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡼࡡ࡭࡫ࡧࡥࡹ࡫࡟ࡧࡴࡨࡵࡥ࠴ࠠࡕࡪࡨࡶࡪࠦࡳࡩࡱࡸࡰࡩࠦࡢࡦࠢࡤࡸࠥࡲࡥࡢࡵࡷࠤࡴࡴࡥࠡࡣࡱࡨࠥࡲࡥࡴࡵࠣࡸ࡭ࡧ࡮ࠡ࠳࠸࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡤ࡭ࡸ࡫ࡳࠡࡖࡼࡴࡪࡋࡲࡳࡱࡵ࠾ࠥࡏࡦࠡࡣࡱࡽࠥ࡬ࡲࡦࡳࡸࡩࡳࡩࡹࠡࡱࡵࠤࡱ࡯ࡳࡵࠢࡲࡪࠥ࡬ࡲࡦࡳࡸࡩࡳࡩࡩࡦࡵࠣ࡭ࡸࠦࡴࡩࡧࠣࡻࡷࡵ࡮ࡨࠢࡷࡽࡵ࡫࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡦ࡯ࡳࡦࡵ࡚ࠣࡦࡲࡵࡦࡇࡵࡶࡴࡸ࠺ࠡࡋࡩࠤࡦࡴࡹࠡࡨࡵࡩࡶࡻࡥ࡯ࡥࡼࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡻࡧ࡬ࡪࡦ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣ౳")
        control_freqs = list(map(int, control_freqs))
        data_freqs = list(map(int, data_freqs))
        def l1lll1l1l11_opy_(l1l1l11l1_opy_):
            l1lll1lll1l_opy_ = []
            for f in l1l1l11l1_opy_:
                if not goTenna.settings.RFSettings.validate_freq(f):
                    l1lll1lll1l_opy_.append(f)
            return l1lll1lll1l_opy_
        l1lll11l11l_opy_ = l1lll1l1l11_opy_(control_freqs)
        if l1lll11l11l_opy_:
            raise ValueError(l11ll_opy_ (u"ࠪࡧࡴࡴࡴࡳࡱ࡯ࠤ࡫ࡸࡥࡲࡵࠣࡱࡺࡹࡴࠡࡤࡨࠤࡻࡧ࡬ࡪࡦ࠯ࠤࢀࢃࠠࡢࡴࡨࠤࡳࡵࡴࠨ౴")
                             .format(l1lll11l11l_opy_))
        l1lll111l1l_opy_ = l1lll1l1l11_opy_(data_freqs)
        if l1lll111l1l_opy_:
            raise ValueError(l11ll_opy_ (u"ࠫࡩࡧࡴࡢࠢࡩࡶࡪࡷࡳࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡹࡥࡱ࡯ࡤ࠭ࠢࡾࢁࠥࡧࡲࡦࠢࡱࡳࡹ࠭౵")
                             .format(l1lll111l1l_opy_))
        self._1llll111l1_opy_ = control_freqs
        self._1lll11l1ll_opy_ = data_freqs
    @property
    def data_freqs(self):
        l11ll_opy_ (u"ࠧࠨࠢࠡࡖ࡫ࡩࠥࡪࡡࡵࡣࠣࡪࡷ࡫ࡱࡶࡧࡱࡧ࡮࡫ࡳ࠯ࠢࡣࡤࡱ࡯ࡳࡵ࡝࡬ࡲࡹࡣࡠࡡ࠰ࠣࠦࠧࠨ౶")
        return self._1lll11l1ll_opy_
    @property
    def control_freqs(self):
        l11ll_opy_ (u"ࠨࠢࠣࠢࡗ࡬ࡪࠦࡣࡰࡰࡷࡶࡴࡲࠠࡧࡴࡨࡵࡺ࡫࡮ࡤ࡫ࡨࡷ࠳ࠦࡠࡡ࡮࡬ࡷࡹࡡࡩ࡯ࡶࡠࡤࡥ࠴ࠠࠣࠤࠥ౷")
        return self._1llll111l1_opy_
    def serialize(self):
        to_return = six.b(l11ll_opy_ (u"ࠧࠨ౸"))
        for freq in self._1llll111l1_opy_:
            to_return += struct.pack(l11ll_opy_ (u"ࠨࠣࡅࡆࡎ࠭౹"), 1, 1, freq)
        for freq in self._1lll11l1ll_opy_:
            to_return += struct.pack(l11ll_opy_ (u"ࠩࠤࡆࡇࡏࠧ౺"), 0, 1, freq)
        return to_return
    @classmethod
    def deserialize(cls, value):
        l1lll1ll1l1_opy_ = int(len(value) / 6)
        control_freqs = []
        data_freqs = []
        for chan in range(l1lll1ll1l1_opy_):
            l1llll1111l_opy_, _, freq = struct.unpack(l11ll_opy_ (u"ࠪࠥࡇࡈࡉࠨ౻"),
                                             value[chan*6:(chan+1)*6])
            if l1llll1111l_opy_:
                control_freqs.append(freq)
            else:
                data_freqs.append(freq)
        return cls(control_freqs, data_freqs)
    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and self.control_freqs == other.control_freqs\
            and self.data_freqs == other.data_freqs
    def __repr__(self):
        return l11ll_opy_ (u"ࠫࡁࢁࡽ࠻ࠢࡦࡳࡳࡺࡲࡰ࡮ࡢࡪࡷ࡫ࡱࡴ࠿ࡾࢁ࠱ࠦࡤࡢࡶࡤࡣ࡫ࡸࡥࡲࡵࡀࡿࢂࡄࠧ౼")\
            .format(self.__class__.__name__,
                    self.control_freqs,
                    self.data_freqs)
class FrequencySlotNameTLV(basic_tlv.l111l11lll_opy_):
    l11ll_opy_ (u"ࠧࠨࠢࠡࡃࠣࡘࡑ࡜ࠠࡩࡱ࡯ࡨ࡮ࡴࡧࠡࡶ࡫ࡩࠥࡴࡡ࡮ࡧࠣࡳ࡫ࠦࡡࠡࡵ࡯ࡳࡹࠦࡳࡦࡶ࠱ࠎࠥࠦࠠࠡࠤࠥࠦ౽")
    l1l11ll1ll_opy_ = 27
    MAX_LENGTH = 32
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    @property
    def l111ll11l1_opy_(self):
        return self.MAX_LENGTH
    @property
    def name(self):
        l11ll_opy_ (u"ࠨࠢࠣࠢࡗ࡬ࡪࠦࡴࡪࡶ࡯ࡩࠥࡧࡳࡴࡱࡦ࡭ࡦࡺࡥࡥࠢࡺ࡭ࡹ࡮ࠠࡵࡪࡨࠤ࡙ࡒࡖࠡࠤࠥࠦ౾")
        return self.contents
class FrequencySlotIDTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠢࠣࠤࠣࡅ࡚ࠥࡌࡗࠢ࡫ࡳࡱࡪࡩ࡯ࡩࠣࡥࡳࠦࡉࡅࠢࡩࡳࡷࠦࡡࠡࡵ࡯ࡳࡹࠦࡳࡦࡶ࠱ࠎࠏࠦࠠࠡࠢࡗ࡬ࡪࠦࡉࡅࠢ࡬ࡷࠥ࡯࡮ࡵࡧࡱࡨࡪࡪࠠࡵࡱࠣࡦࡪࠦࡡࠡࡗࡘࡍࡉࠦࡡ࡯ࡦࠣࡸ࡭ࡻࡳࠡࡵ࡫ࡳࡺࡲࡤࠡࡤࡨࠤࡧࡿࡴࡦࡵ࡯࡭ࡰ࡫࠮ࠋࠢࠣࠤࠥࠨࠢࠣ౿")
    l1l11ll1ll_opy_ = 28
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, id_bytes):
        l11ll_opy_ (u"ࠣࠤࠥࠤࡇࡻࡩ࡭ࡦࠣࡸ࡭࡫ࠠࡧࡴࡨࡵࡺ࡫࡮ࡤࡻࠣࡷࡱࡵࡴࠡࡋࡇ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡣࡻࡷࡩࡸࡲࡩ࡬ࡧࠣ࡭ࡩࡥࡢࡺࡶࡨࡷ࠿ࠦࡔࡩࡧࠣࡦࡾࡺࡥࡴ࡮࡬࡯ࡪࠦࡉࡅࠢࠫࡩ࠳࡭࠮ࠡࡣ࡙࡚ࠣࡏࡄࠪ࠰ࠣ࠷࠻ࠦࡢࡺࡶࡨࡷࠥࡳࡡࡹ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡡࡪࡵࡨࡷ࡚ࠥࡹࡱࡧࡈࡶࡷࡵࡲ࠻ࠢࡌࡪࠥࡦࡠࡪࡦࡢࡦࡾࡺࡥࡴࡢࡣࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡧࡿࡴࡦࡵ࡯࡭ࡰ࡫࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡦ࡯ࡳࡦࡵ࡚ࠣࡦࡲࡵࡦࡇࡵࡶࡴࡸ࠺ࠡࡋࡩࠤࡥࡦࡩࡥࡡࡥࡽࡹ࡫ࡳࡡࡢࠣ࡭ࡸࠦ࡭ࡰࡴࡨࠤࡹ࡮ࡡ࡯ࠢ࠶࠺ࠥࡨࡹࡵࡧࡶࠤࡱࡵ࡮ࡨ࠮ࠣࡳࡷࠦࡥ࡮ࡲࡷࡽࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤಀ")
        try:
            _ = struct.pack(l11ll_opy_ (u"ࠩ࠴ࡷࠬಁ"), id_bytes[:1])
        except Exception:
            raise TypeError(l11ll_opy_ (u"ࠪ࡭ࡩࡥࡢࡺࡶࡨࡷࠥࡹࡨࡰࡷ࡯ࡨࠥࡨࡥࠡࡤࡼࡸࡪࡹ࡬ࡪ࡭ࡨ࠰ࠥ࡯ࡳࠡࡽࢀࠫಂ")
                            .format(type(id_bytes)))
        if not id_bytes or len(id_bytes) > 36:
            raise ValueError(l11ll_opy_ (u"ࠫ࡮ࡪ࡟ࡣࡻࡷࡩࡸࠦࡳࡩࡱࡸࡰࡩࠦࡢࡦࠢࡥࡩࡹࡽࡥࡦࡰࠣ࠴ࠥࡧ࡮ࡥࠢ࠶࠺ࠥࡨࡹࡵࡧࡶ࠰ࠥ࡯ࡳࠡࡽࢀࠫಃ")
                             .format(len(id_bytes)))
        self._id = id_bytes
    @property
    def id_bytes(self):
        return self._id
    def serialize(self):
        return self._id
    @classmethod
    def deserialize(cls, value):
        return cls(value)
    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and other.id_bytes == self.id_bytes
    def __repr__(self):
        return l11ll_opy_ (u"ࠬࡂࡻࡾ࠼ࠣ࡭ࡩࡥࡢࡺࡶࡨࡷࡂࢁࡽ࠿ࠩ಄").format(self.__class__.__name__,
                                          goTenna.util.display_bytestring(self.id_bytes))
class FrequencySlotCallSignTLV(basic_tlv.l111l11lll_opy_):
    l11ll_opy_ (u"ࠨࠢࠣࠢࡄࠤ࡙ࡒࡖࠡࡨࡲࡶࠥࡧࠠࡧࡴࡨࡵࡺ࡫࡮ࡤࡻࠣࡷࡱࡵࡴࡴࠢࡶ࡬ࡴࡸࡴࠡࡥࡤࡰࡱࠦࡳࡪࡩࡱ࠲ࠏࠦࠠࠡࠢࠥࠦࠧಅ")
    l1l11ll1ll_opy_ = 48
    MAX_LENGTH = 32
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    @property
    def l111ll11l1_opy_(self):
        return self.MAX_LENGTH
    @property
    def callsign(self):
        l11ll_opy_ (u"ࠢࠣࠤࠣࡘ࡭࡫ࠠࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠥ࡬࡯ࡳࠢࡷ࡬ࡪࠦࡦࡳࡧࡴࡹࡪࡴࡣࡺࠢࡶࡰࡴࡺࡳ࠯ࠢࠥࠦࠧಆ")
        return self.contents
class FrequencySlotDataTLV(basic_tlv.l111llll11_opy_):
    l11ll_opy_ (u"ࠣࠤࠥࠤ࡙࡮ࡥࠡࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠤ࡙ࡒࡖࠡࡨࡲࡶࠥ࡬ࡲࡦࡳࡸࡩࡳࡩࡹࠡࡵ࡯ࡳࡹࡹ࠮ࠡࠤࠥࠦಇ")
    l1l11ll1ll_opy_ = 24
    l111l11l1l_opy_ = (FrequencySlotMaxPowerTLV,
                           FrequencySlotFrequencyListTLV,
                           FrequencySlotNameTLV,
                           FrequencySlotIDTLV,
                           FrequencySlotDataBandwidthTLV,
                           FrequencySlotCallSignTLV)
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    @property
    def l111l1l1l1_opy_(self):
        return self.l111l11l1l_opy_
class PerimeterTitleTLV(basic_tlv.l111l11lll_opy_):
    l11ll_opy_ (u"ࠤࠥࠦࠥࡇࠠࡕࡎ࡙ࠤ࡫ࡵࡲࠡࡪࡸࡱࡦࡴࠠࡳࡧࡤࡨࡦࡨ࡬ࡦࠢࡳࡩࡷ࡯࡭ࡦࡶࡨࡶࠥࡺࡩࡵ࡮ࡨࡷࠏࠦࠠࠡࠢࠥࠦࠧಈ")
    l1l11ll1ll_opy_ = 31
    MAX_LENGTH = 32
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    @property
    def l111ll11l1_opy_(self):
        return self.MAX_LENGTH
    @property
    def title(self):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡔࡩࡧࠣࡸ࡮ࡺ࡬ࡦࠢࡤࡷࡸࡵࡣࡪࡣࡷࡩࡩࠦࡷࡪࡶ࡫ࠤࡹ࡮ࡥࠡࡖࡏ࡚ࠥࠨࠢࠣಉ")
        return self.contents
class PerimeterPointsTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠦࠧࠨࠠࡂࠢࡗࡐ࡛ࠦࡦࡰࡴࠣࡸ࡭࡫ࠠࡱࡱ࡬ࡲࡹࡹࠠ࡮ࡣ࡮࡭ࡳ࡭ࠠࡶࡲࠣࡥࠥࡶࡥࡳ࡫ࡰࡩࡹ࡫ࡲࠋࠢࠣࠤࠥࠨࠢࠣಊ")
    l1l11ll1ll_opy_ = 32
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    @property
    def points(self):
        l11ll_opy_ (u"ࠧࠨࠢࠡࡖ࡫ࡩࠥࡹࡥࡲࡷࡨࡲࡨ࡫ࠠࡰࡨࠣࡱࡦࡶࠠࡱࡱ࡬ࡲࡹࡹࠠࡩࡧ࡯ࡨࠥࡨࡹࠡࡶ࡫ࡩࠥࡺ࡬ࡷࠢࠥࠦࠧಋ")
        return self._points
    def __eq__(self, other):
        return isinstance(other, PerimeterPointsTLV)\
            and self.points == other.points
    def __repr__(self):
        return l11ll_opy_ (u"࠭࠼ࡼࡿࠣࡴࡴ࡯࡮ࡵࡵࡀࡿࢂࡄࠧಌ").format(self.__class__.__name__, self.points)
    def __init__(self, points):
        l11ll_opy_ (u"ࠢࠣࠤࠣࡆࡺ࡯࡬ࡥࠢࡷ࡬ࡪࠦࡐࡦࡴ࡬ࡱࡪࡺࡥࡳࡒࡲ࡭ࡳࡺࡳࡕࡎ࡙࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࡕࡪ࡬ࡷ࡚ࠥࡌࡗࠢࡨࡲࡨࡵ࡭ࡱࡣࡶࡷࡪࡹࠠࡢࠢ࡯࡭ࡸࡺࠠࡰࡨࠣࡴࡴ࡯࡮ࡵࡵࠣࡥࡸࠦࠨ࡭ࡣࡷ࡭ࡹࡻࡤࡦ࠮ࠣࡰࡴࡴࡧࡪࡶࡸࡨࡪ࠯ࠠࡱࡱ࡬ࡲࡹࡹࠠࡊࡶࠣࡧࡦࡴࠠࡩࡱ࡯ࡨࠥࡻࡰࠡࡶࡲࠤ࠽ࠦࡳࡶࡥ࡫ࠤࡵࡵࡩ࡯ࡶࡶ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡱࡱ࡬ࡲࡹࡹ࠺ࠡࡖ࡫ࡩࠥࡶ࡯ࡪࡰࡷࡷࠥࡧࡳࠡࡣࠣࡰ࡮ࡹࡴࠡࡱࡩࠤ࠭ࡲࡡࡵ࠮ࠣࡰࡴࡴࡧࠪࠢࡳࡥ࡮ࡸࡳ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡹࡿࡰࡦࠢࡳࡳ࡮ࡴࡴࡴ࠼ࠣࡰ࡮ࡹࡴ࡜ࡶࡸࡴࡱ࡫࡛ࡧ࡮ࡲࡥࡹ࠲ࠠࡧ࡮ࡲࡥࡹࡣ࡝ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡦ࡯ࡳࡦࡵ࡚ࠣࡦࡲࡵࡦࡇࡵࡶࡴࡸ࠺ࠡࡋࡩࠤࡹ࡮ࡥࡳࡧࠣࡥࡷ࡫ࠠࡵࡱࡲࠤࡲࡧ࡮ࡺࠢࡳࡳ࡮ࡴࡴࡴࠢࡲࡶࠥ࡯ࡦࠡࡶ࡫ࡩࠥࡶ࡯ࡪࡰࡷࡷࠥࡧࡲࡦࠢࡰࡥࡱ࡬࡯ࡳ࡯ࡨࡨ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ಍")
        if len(points) > 8:
            raise ValueError
        for p in points:
            if len(p) != 2:
                raise ValueError
            if not all([isinstance(pi, float) for pi in p]):
                raise TypeError
        self._points = points
    @classmethod
    def deserialize(cls, value):
        points = []
        for i in range(0, len(value), 16):
            points.append(struct.unpack(l11ll_opy_ (u"ࠨࠣࡧࡨࠬಎ"), value[i:i+16]))
        return cls(points)
    def serialize(self):
        l1lll1l1lll_opy_ = l11ll_opy_ (u"ࠩࠤࠫಏ") + l11ll_opy_ (u"ࠪࡨࡩ࠭ಐ")*len(self._points)
        l1lll1l11l1_opy_ = [p for point in self._points for p in point]
        return struct.pack(l1lll1l1lll_opy_, *l1lll1l11l1_opy_)
class TextTLV(basic_tlv.l111l11lll_opy_):
    l11ll_opy_ (u"ࠦࠧࠨࠠࡂࠢࡗࡐ࡛ࠦࡦࡰࡴࠣ࡬ࡴࡲࡤࡪࡰࡪࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡺࡥࡹࡶࠍࠤࠥࠦࠠࠣࠤࠥ಑")
    l1l11ll1ll_opy_ = 4
    MAX_LENGTH = goTenna.constants.MAXLENGTH
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    @property
    def l111ll11l1_opy_(self):
        return self.MAX_LENGTH
class PerimeterColorTLV(basic_tlv.l111l1111l_opy_):
    l1l11ll1ll_opy_ = 33
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
class PerimeterDataTLV(basic_tlv.l111llll11_opy_):
    l11ll_opy_ (u"ࠧࠨࠢࠡࡃࠣࡘࡑ࡜ࠠࡦࡰࡦࡥࡵࡹࡵ࡭ࡣࡷ࡭ࡳ࡭ࠠࡱࡧࡵ࡭ࡲ࡫ࡴࡦࡴࠣࡨࡦࡺࡡ࠯ࠌࠍࠤࠥࠦࠠࡕࡪ࡬ࡷࠥ࡯ࡳࠡࡷࡶࡩࡩࠦࡡࡴࠢࡤࠤࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠠࡧࡱࡵࠤࡴࡺࡨࡦࡴࠣࡴࡪࡸࡩ࡮ࡧࡷࡩࡷ࠳ࡲࡦ࡮ࡤࡸࡪࡪࠠࡕࡎ࡙ࡷ࠳ࠦࡏ࡯࡮ࡼࠤࡨ࡫ࡲࡵࡣ࡬ࡲ࡚ࠥࡌࡗࡵࠣࡥࡷ࡫ࠠࡢ࡮࡯ࡳࡼ࡫ࡤࠡࡶࡲࠤࡧ࡫ࠠࡱࡴࡨࡷࡪࡴࡴࠡ࡫ࡱࠤࡕ࡫ࡲࡪ࡯ࡨࡸࡪࡸࡄࡢࡶࡤ࠿ࠥࡺࡨࡦࡻࠣࡥࡷ࡫ࠠࡵࡪࡨࠤࡨࡲࡡࡴࡵࡨࡷࠥࡲࡩࡴࡶࡨࡨࠥ࡯࡮ࠡ࠼ࡳࡽ࠿ࡧࡴࡵࡴ࠽ࡤࡕ࡫ࡲࡪ࡯ࡨࡸࡪࡸࡄࡢࡶࡤࡘࡑ࡜࠮ࡂࡅࡆࡉࡕ࡚ࡁࡃࡎࡈࡣࡈࡕࡎࡕࡇࡑࡘࡘࡦ࠮ࠋࠢࠣࠤࠥࠨࠢࠣಒ")
    l1l11ll1ll_opy_ = 30
    l111l11l1l_opy_ = (PerimeterTitleTLV, MapIDTLV,
                           PerimeterColorTLV, PerimeterPointsTLV)
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    @property
    def l111l1l1l1_opy_(self):
        return self.l111l11l1l_opy_
class RouteTitleTLV(basic_tlv.l111l11lll_opy_):
    l11ll_opy_ (u"ࠨࠢࠣࠢࡄࠤ࡙ࡒࡖࠡࡨࡲࡶࠥ࡮ࡵ࡮ࡣࡱࠤࡷ࡫ࡡࡥࡣࡥࡰࡪࠦࡲࡰࡷࡷࡩࠥࡺࡩࡵ࡮ࡨࡷࠏࠦࠠࠡࠢࠥࠦࠧಓ")
    l1l11ll1ll_opy_ = 35
    MAX_LENGTH = 32
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    @property
    def l111ll11l1_opy_(self):
        return self.MAX_LENGTH
    @property
    def title(self):
        l11ll_opy_ (u"ࠢࠣࠤࠣࡘ࡭࡫ࠠࡵ࡫ࡷࡰࡪࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡲࡰࡷࡷࡩࠥࠨࠢࠣಔ")
        return self.contents
class RoutePointsTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠣࠤࠥࠤࡆࠦࡔࡍࡘࠣࡪࡴࡸࠠࡵࡪࡨࠤࡵࡵࡩ࡯ࡶࡶࠤࡲࡧ࡫ࡪࡰࡪࠤࡺࡶࠠࡢࠢࡵࡳࡺࡺࡥࠋࠢࠣࠤࠥࠨࠢࠣಕ")
    l1l11ll1ll_opy_ = 36
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __repr__(self):
        return l11ll_opy_ (u"ࠩ࠿ࡿࢂࠦࡰࡰ࡫ࡱࡸࡸࡃࡻࡾࡀࠪಖ").format(self.__class__.__name__, self.points)
    def __eq__(self, other):
        return isinstance(other, RoutePointsTLV) and self.points == other.points
    @property
    def points(self):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡔࡩࡧࠣࡴࡴ࡯࡮ࡵࡵࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡩࠦࡩ࡯ࠢࡷ࡬ࡪࠦࡔࡍࡘࠣࠦࠧࠨಗ")
        return self._points
    def __init__(self, points):
        l11ll_opy_ (u"ࠦࠧࠨࠠࡃࡷ࡬ࡰࡩࠦࡡࠡࡔࡲࡹࡹ࡫ࡐࡰ࡫ࡱࡸࡸࠦࡔࡍࡘ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦ࡬ࡪࡵࡷ࡟ࡹࡻࡰ࡭ࡧ࡞ࡪࡱࡵࡡࡵ࠮ࠣࡪࡱࡵࡡࡵ࡟ࡠࠤࡵࡵࡩ࡯ࡶࡶ࠾࡚ࠥࡨࡦࠢࡳࡳ࡮ࡴࡴࡴ࠮ࠣࡥࡸࠦࠨ࡭ࡣࡷ࡭ࡹࡻࡤࡦ࠮ࠣࡰࡴࡴࡧࡪࡶࡸࡨࡪ࠯ࠠࡱࡣ࡬ࡶࡸ࠴ࠠࡎࡣࡻ࡭ࡲࡻ࡭ࠡ࠺࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡢ࡫ࡶࡩࡸࠦࡖࡢ࡮ࡸࡩࡊࡸࡲࡰࡴ࠽ࠤࡎ࡬ࠠࡵࡪࡨࡶࡪࠦࡡࡳࡧࠣࡸࡴࡵࠠ࡮ࡣࡱࡽࠥࡶ࡯ࡪࡰࡷࡷࠥࡵࡲࠡ࡫ࡩࠤࡦࡴࡹࠡࡲࡲ࡭ࡳࡺࡳࠡࡣࡵࡩࠥࡳࡡ࡭ࡨࡲࡶࡲ࡫ࡤ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷࡧࡩࡴࡧࡶࠤ࡙ࡿࡰࡦࡇࡵࡶࡴࡸ࠺ࠡࡋࡩࠤࡦࡴࡹࡵࡪ࡬ࡲ࡬ࠦࡩࡴࠢࡷ࡬ࡪࠦࡷࡳࡱࡱ࡫ࠥࡺࡹࡱࡧ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣಘ")
        if len(points) > 8:
            raise ValueError
        for p in points:
            if len(p) != 2:
                raise ValueError
            if not all([isinstance(pi, float) for pi in p]):
                raise TypeError
        self._points = points
    @classmethod
    def deserialize(cls, value):
        points = []
        for i in range(0, len(value), 16):
            points.append(struct.unpack(l11ll_opy_ (u"ࠬࠧࡤࡥࠩಙ"), value[i:i+16]))
        return cls(points)
    def serialize(self):
        l1lll111l11_opy_ = l11ll_opy_ (u"࠭ࠡࠨಚ") + l11ll_opy_ (u"ࠧࡥࡦࠪಛ") * len(self.points)
        return struct.pack(l1lll111l11_opy_,
                           *[p for point in self.points for p in point])
class RouteColorTLV(basic_tlv.l111l1111l_opy_):
    l11ll_opy_ (u"ࠣࠤࠥࠤࡆࠦࡔࡍࡘࠣࡪࡴࡸࠠࡵࡪࡨࠤࡨࡵ࡬ࡰࡴࠣࡸ࡭࡫ࠠࡳࡱࡸࡸࡪࠦࡳࡩࡱࡸࡰࡩࠦࡢࡦࠢࡧ࡭ࡸࡶ࡬ࡢࡻࡨࡨࠥࡽࡩࡵࡪࠍࠤࠥࠦࠠࠣࠤࠥಜ")
    l1l11ll1ll_opy_ = 37
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
class RouteDataTLV(basic_tlv.l111llll11_opy_):
    l11ll_opy_ (u"ࠤࠥࠦࠥࡇࠠࡕࡎ࡙ࠤࡪࡴࡣࡢࡲࡶࡹࡱࡧࡴࡪࡰࡪࠤࡷࡵࡵࡵࡧࠣࡨࡦࡺࡡࠋࠢࠣࠤࠥࠨࠢࠣಝ")
    l1l11ll1ll_opy_ = 34
    l111l11l1l_opy_=(MapIDTLV, RouteTitleTLV, RoutePointsTLV, RouteColorTLV)
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    @property
    def l111l1l1l1_opy_(self):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡔࡩࡧࠣࡧࡴࡴࡴࡦࡰࡷࡷࠥࡵࡦࠡࡶ࡫ࡩ࡚ࠥࡌࡗ࠰ࠣࠦࠧࠨಞ")
        return self.l111l11l1l_opy_
class CircleTitleTLV(basic_tlv.l111l11lll_opy_):
    l11ll_opy_ (u"ࠦࠧࠨࠠࡂࠢࡗࡐ࡛ࠦࡣࡰࡰࡷࡥ࡮ࡴࡩ࡯ࡩࠣࡸ࡭࡫ࠠ࡯ࡣࡰࡩࠥࡵࡦࠡࡣࠣࡧ࡮ࡸࡣ࡭ࡧ࠱ࠤࠧࠨࠢಟ")
    l1l11ll1ll_opy_ = 0x28
    MAX_LENGTH = 32
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    @property
    def l111ll11l1_opy_(self):
        return self.MAX_LENGTH
    @property
    def title(self):
        l11ll_opy_ (u"ࠧࠨࠢࠡࡖ࡫ࡩࠥࡺࡩࡵ࡮ࡨࠤࡴ࡬ࠠࡵࡪࡨࠤࡷࡵࡵࡵࡧࠣࠦࠧࠨಠ")
        return self.contents
class CircleCenterTLV(l1lll111ll1_opy_):
    l11ll_opy_ (u"ࠨࠢࠣࠢࡄࠤࡌࡖࡓࠡࡲࡲ࡭ࡳࡺࠠ࡮ࡣࡵ࡯࡮ࡴࡧࠡࡶ࡫ࡩࠥࡩࡥ࡯ࡶࡨࡶࠥࡵࡦࠡࡣࠣࡧ࡮ࡸࡣ࡭ࡧ࠱ࠤࠧࠨࠢಡ")
    l1l11ll1ll_opy_ = 0x29
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, latitude, longitude):
        l11ll_opy_ (u"ࠢࠣࠤࠣࡆࡺ࡯࡬ࡥࠢࡷ࡬ࡪࠦࡃࡪࡴࡦࡰࡪࡉࡥ࡯ࡶࡨࡶ࡙ࡒࡖ࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤ࡫ࡲ࡯ࡢࡶࠣࡰࡦࡺࡩࡵࡷࡧࡩ࠿ࠦࡔࡩࡧࠣࡰࡦࡺࡩࡵࡷࡧࡩࠥࡵࡦࠡࡶ࡫ࡩࠥࡩࡥ࡯ࡶࡨࡶ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡧ࡮ࡲࡥࡹࠦ࡬ࡰࡰࡪ࡭ࡹࡻࡤࡦ࠼ࠣࡘ࡭࡫ࠠ࡭ࡱࡱ࡫࡮ࡺࡵࡥࡧࠣࡳ࡫ࠦࡴࡩࡧࠣࡧࡪࡴࡴࡦࡴ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡳࡣ࡬ࡷࡪࡹࠠࡕࡻࡳࡩࡊࡸࡲࡰࡴ࠽ࠤࡎ࡬ࠠࡰࡰࡨࠤࡴ࡬ࠠࡵࡪࡨࠤࡵࡧࡲࡢ࡯ࡶࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡨࡵ࡮ࡷࡧࡵࡸ࡮ࡨ࡬ࡦࠢࡷࡳࠥ࡬࡬ࡰࡣࡷ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤಢ")
        l1lll111ll1_opy_.__init__(self, latitude, longitude)
class CircleRadiusTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠣࠤࠥࠤ࡙࡮ࡥࠡࡴࡤࡨ࡮ࡻࡳࠡࡱࡩࠤࡦࠦࡣࡪࡴࡦࡰࡪ࠲ࠠࡪࡰࠣࡱࡪࡺࡥࡳࡵࠣࠦࠧࠨಣ")
    l1l11ll1ll_opy_ = 0x2a
    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and self.radius == other.radius
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, radius):
        l11ll_opy_ (u"ࠤࠥࠦࠥࡈࡵࡪ࡮ࡧࠤࡹ࡮ࡥࠡࡴࡤࡨ࡮ࡻࡳࠡࡖࡏ࡚࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡨ࡯ࡳࡦࡺࠠࡳࡣࡧ࡭ࡺࡹ࠺ࠡࡖ࡫ࡩࠥࡸࡡࡥ࡫ࡸࡷ࠱ࠦࡩ࡯ࠢࡰࡩࡹ࡫ࡲࡴ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡡࡪࡵࡨࡷ࡚ࠥࡹࡱࡧࡈࡶࡷࡵࡲ࠻ࠢࡌࡪࠥࡺࡨࡦࠢࡵࡥࡩ࡯ࡵࡴࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡦࡳࡳࡼࡥࡳࡶ࡬ࡦࡱ࡫ࠠࡵࡱࠣࡤࡥ࡬࡬ࡰࡣࡷࡤࡥ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦತ")
        try:
            self._radius = int(radius)
        except (ValueError, TypeError):
            raise TypeError(l11ll_opy_ (u"ࠪࡶࡦࡪࡩࡶࡵࠣࡱࡺࡹࡴࠡࡤࡨࠤ࡮ࡴࡴࡦࡩࡵࡥࡱ࠲ࠠࡪࡵࠣࡿࢂ࠭ಥ")
                            .format(type(radius)))
        self._radius = radius
    @property
    def radius(self):
        l11ll_opy_ (u"ࠦࠧࠨࠠࡕࡪࡨࠤࡷࡧࡤࡪࡷࡶࠤࡴ࡬ࠠࡵࡪࡨࠤࡨ࡯ࡲࡤ࡮ࡨ࠰ࠥ࡯࡮ࠡ࡯ࡨࡸࡪࡸࡳ࠯ࠢࠥࠦࠧದ")
        return self._radius
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠬࠧࡉࠨಧ"), self._radius)
    @classmethod
    def deserialize(cls, value):
        return cls(struct.unpack(l11ll_opy_ (u"࠭ࠡࡊࠩನ"), value)[0])
class CircleColorTLV(basic_tlv.l111l1111l_opy_):
    l11ll_opy_ (u"ࠢࠣࠤࠣࡅ࡚ࠥࡌࡗࠢࡩࡳࡷࠦࡴࡩࡧࠣࡧࡴࡲ࡯ࡳࠢࡤࠤࡨ࡯ࡲࡤ࡮ࡨࠤࡸ࡮࡯ࡶ࡮ࡧࠤࡧ࡫ࠠࡥ࡫ࡶࡴࡱࡧࡹࡦࡦࠣࡥࡸࠦࠢࠣࠤ಩")
    l1l11ll1ll_opy_ = 0x2B
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
class CircleDataTLV(basic_tlv.l111llll11_opy_):
    l11ll_opy_ (u"ࠣࠤࠥࠤࡆࠦࡔࡍࡘࠣࡩࡳࡩࡡࡱࡵࡸࡰࡦࡺࡩ࡯ࡩࠣࡧ࡮ࡸࡣ࡭ࡧࠣࡨࡦࡺࡡࠋࠢࠣࠤࠥࠨࠢࠣಪ")
    l1l11ll1ll_opy_ = 0x27
    l111l11l1l_opy_ = (MapIDTLV,
                           CircleTitleTLV, CircleCenterTLV,
                           CircleRadiusTLV, CircleColorTLV)
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    @property
    def l111l1l1l1_opy_(self):
        return self.l111l11l1l_opy_
class SquareTitleTLV(basic_tlv.l111l11lll_opy_):
    l11ll_opy_ (u"ࠤࠥࠦࠥࡇࠠࡕࡎ࡙ࠤࡨࡵ࡮ࡵࡣ࡬ࡲ࡮ࡴࡧࠡࡶ࡫ࡩࠥࡴࡡ࡮ࡧࠣࡳ࡫ࠦࡡࠡࡥ࡬ࡶࡨࡲࡥ࠯ࠢࠥࠦࠧಫ")
    l1l11ll1ll_opy_ = 0x2D
    MAX_LENGTH = 32
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    @property
    def l111ll11l1_opy_(self):
        return self.MAX_LENGTH
    @property
    def title(self):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡔࡩࡧࠣࡸ࡮ࡺ࡬ࡦࠢࡲࡪࠥࡺࡨࡦࠢࡵࡳࡺࡺࡥࠡࠤࠥࠦಬ")
        return self.contents
class SquareCornerOneTLV(l1lll111ll1_opy_):
    l11ll_opy_ (u"ࠦࠧࠨࠠࡂࠢࡊࡔࡘࠦࡰࡰ࡫ࡱࡸࠥࡳࡡࡳ࡭࡬ࡲ࡬ࠦࡴࡩࡧࠣࡪ࡮ࡸࡳࡵࠢࡦࡳࡷࡴࡥࡳࠢࡲࡪࠥࡧࠠࡴࡳࡸࡥࡷ࡫࠮ࠡࠤࠥࠦಭ")
    l1l11ll1ll_opy_ = 0x2E
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, latitude, longitude):
        l11ll_opy_ (u"ࠧࠨࠢࠡࡄࡸ࡭ࡱࡪࠠࡵࡪࡨࠤࡘࡷࡵࡢࡴࡨࡇࡴࡸ࡮ࡦࡴࡒࡲࡪ࡚ࡌࡗ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥ࡬࡬ࡰࡣࡷࠤࡱࡧࡴࡪࡶࡸࡨࡪࡀࠠࡕࡪࡨࠤࡱࡧࡴࡪࡶࡸࡨࡪࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡣࡰࡴࡱࡩࡷࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡧ࡮ࡲࡥࡹࠦ࡬ࡰࡰࡪ࡭ࡹࡻࡤࡦ࠼ࠣࡘ࡭࡫ࠠ࡭ࡱࡱ࡫࡮ࡺࡵࡥࡧࠣࡳ࡫ࠦࡴࡩࡧࠣࡧࡴࡸ࡮ࡦࡴࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡢ࡫ࡶࡩࡸࠦࡔࡺࡲࡨࡉࡷࡸ࡯ࡳ࠼ࠣࡍ࡫ࠦ࡯࡯ࡧࠣࡳ࡫ࠦࡴࡩࡧࠣࡴࡦࡸࡡ࡮ࡵࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡧࡴࡴࡶࡦࡴࡷ࡭ࡧࡲࡥࠡࡶࡲࠤ࡫ࡲ࡯ࡢࡶ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣಮ")
        l1lll111ll1_opy_.__init__(self, latitude, longitude)
class SquareCornerTwoTLV(l1lll111ll1_opy_):
    l11ll_opy_ (u"ࠨࠢࠣࠢࡄࠤࡌࡖࡓࠡࡲࡲ࡭ࡳࡺࠠ࡮ࡣࡵ࡯࡮ࡴࡧࠡࡶ࡫ࡩࠥࡹࡥࡤࡱࡱࡨࠥࡩ࡯ࡳࡰࡨࡶࠥࡵࡦࠡࡣࠣࡷࡶࡻࡡࡳࡧ࠱ࠤࠧࠨࠢಯ")
    l1l11ll1ll_opy_ = 0x2F
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, latitude, longitude):
        l11ll_opy_ (u"ࠢࠣࠤࠣࡆࡺ࡯࡬ࡥࠢࡷ࡬ࡪࠦࡓࡲࡷࡤࡶࡪࡉ࡯ࡳࡰࡨࡶ࡙ࡽ࡯ࡕࡎ࡙࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡧ࡮ࡲࡥࡹࠦ࡬ࡢࡶ࡬ࡸࡺࡪࡥ࠻ࠢࡗ࡬ࡪࠦ࡬ࡢࡶ࡬ࡸࡺࡪࡥࠡࡱࡩࠤࡹ࡮ࡥࠡࡥࡲࡶࡳ࡫ࡲࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡩࡰࡴࡧࡴࠡ࡮ࡲࡲ࡬࡯ࡴࡶࡦࡨ࠾࡚ࠥࡨࡦࠢ࡯ࡳࡳ࡭ࡩࡵࡷࡧࡩࠥࡵࡦࠡࡶ࡫ࡩࠥࡩ࡯ࡳࡰࡨࡶࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡤ࡭ࡸ࡫ࡳࠡࡖࡼࡴࡪࡋࡲࡳࡱࡵ࠾ࠥࡏࡦࠡࡱࡱࡩࠥࡵࡦࠡࡶ࡫ࡩࠥࡶࡡࡳࡣࡰࡷࠥ࡯ࡳࠡࡰࡲࡸࠥࡩ࡯࡯ࡸࡨࡶࡹ࡯ࡢ࡭ࡧࠣࡸࡴࠦࡦ࡭ࡱࡤࡸ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥರ")
        l1lll111ll1_opy_.__init__(self, latitude, longitude)
class SquareDepthTLV(l1lll111ll1_opy_):
    l11ll_opy_ (u"ࠣࠤࠥࠤࡆࠦࡇࡑࡕࠣࡴࡴ࡯࡮ࡵࠢࡰࡥࡷࡱࡩ࡯ࡩࠣࡥࠥࡶ࡯ࡪࡰࡷࠤࡦࡲ࡯࡯ࡩࠣࡸ࡭࡫ࠠࡰࡲࡳࡳࡸ࡯ࡴࡦࠢࡶ࡭ࡩ࡫ࠠࡰࡨࠣࡸ࡭࡫ࠠࡴࡳࡸࡥࡷ࡫ࠠࡢࡵࠣࡧࡴࡸ࡮ࡦࡴࡶࠤ࠶ࠦࡡ࡯ࡦࠣ࠶ࠥࠨࠢࠣಱ")
    l1l11ll1ll_opy_ = 0x30
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, latitude, longitude):
        l11ll_opy_ (u"ࠤࠥࠦࠥࡈࡵࡪ࡮ࡧࠤࡹ࡮ࡥࠡࡕࡴࡹࡦࡸࡥࡅࡧࡳࡸ࡭࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡩࡰࡴࡧࡴࠡ࡮ࡤࡸ࡮ࡺࡵࡥࡧ࠽ࠤ࡙࡮ࡥࠡ࡮ࡤࡸ࡮ࡺࡵࡥࡧࠣࡳ࡫ࠦࡴࡩࡧࠣࡨࡪࡶࡴࡩࠢࡳࡳ࡮ࡴࡴࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡩࡰࡴࡧࡴࠡ࡮ࡲࡲ࡬࡯ࡴࡶࡦࡨ࠾࡚ࠥࡨࡦࠢ࡯ࡳࡳ࡭ࡩࡵࡷࡧࡩࠥࡵࡦࠡࡶ࡫ࡩࠥࡪࡥࡱࡶ࡫ࠤࡵࡵࡩ࡯ࡶࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡢ࡫ࡶࡩࡸࠦࡔࡺࡲࡨࡉࡷࡸ࡯ࡳ࠼ࠣࡍ࡫ࠦ࡯࡯ࡧࠣࡳ࡫ࠦࡴࡩࡧࠣࡴࡦࡸࡡ࡮ࡵࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡧࡴࡴࡶࡦࡴࡷ࡭ࡧࡲࡥࠡࡶࡲࠤ࡫ࡲ࡯ࡢࡶ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣಲ")
        l1lll111ll1_opy_.__init__(self, latitude, longitude)
class SquareColorTLV(basic_tlv.l111l1111l_opy_):
    l11ll_opy_ (u"ࠥࠦࠧࠦࡁࠡࡖࡏ࡚ࠥ࡬࡯ࡳࠢࡷ࡬ࡪࠦࡣࡰ࡮ࡲࡶࠥࡧࠠࡴࡳࡸࡥࡷ࡫ࠠࡴࡪࡲࡹࡱࡪࠠࡣࡧࠣࡨ࡮ࡹࡰ࡭ࡣࡼࡩࡩࠦࡡࡴࠢࠥࠦࠧಳ")
    l1l11ll1ll_opy_ = 0x31
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
class SquareDataTLV(basic_tlv.l111llll11_opy_):
    l11ll_opy_ (u"ࠦࠧࠨࠠࡂࠢࡗࡐ࡛ࠦࡥ࡯ࡥࡤࡴࡸࡻ࡬ࡢࡶ࡬ࡲ࡬ࠦࡳࡲࡷࡤࡶࡪࠦࡤࡢࡶࡤࠎࠥࠦࠠࠡࠤࠥࠦ಴")
    l1l11ll1ll_opy_ = 0x2C
    l111l11l1l_opy_ = (MapIDTLV,
                           SquareTitleTLV, SquareCornerOneTLV,
                           SquareCornerTwoTLV, SquareDepthTLV,
                           SquareColorTLV)
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    @property
    def l111l1l1l1_opy_(self):
        return self.l111l11l1l_opy_
class PublicKeyDataTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠧࠨࠢࠡࡃࠣࡘࡑ࡜ࠠࡧࡱࡵࠤࡵࡻࡢ࡭࡫ࡦࠤࡰ࡫ࡹࠡࡦࡤࡸࡦࠐࠠࠡࠢࠣࠦࠧࠨವ")
    l1l11ll1ll_opy_ = 252
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __eq__(self, other):
        return isinstance(other, PublicKeyDataTLV)\
            and self._key_bytes == other._key_bytes
    def __init__(self, key_bytes):
        l11ll_opy_ (u"ࠨࠢࠣࠢࡅࡹ࡮ࡲࡤࠡࡣࠣࡔࡺࡨ࡬ࡪࡥࡎࡩࡾࡊࡡࡵࡣࡗࡐ࡛࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢ࡮ࡩࡾࡥࡢࡺࡶࡨࡷ࠿ࠦࡔࡩࡧࠣࡧࡴࡴࡴࡦࡰࡷࠤࡴ࡬ࠠࡵࡪࡨࠤࡰ࡫ࡹ࠯ࠢࡖ࡬ࡴࡻ࡬ࡥࠢࡥࡩࠥࡲࡥࡴࡵࠣࡸ࡭ࡧ࡮ࠡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡦࡳࡳࡹࡴࡢࡰࡷࡷ࠳ࡓࡁ࡙ࡎࡈࡒࡌ࡚ࡈࠡ࡮ࡲࡲ࡬࠴ࠠࡕࡪ࡬ࡷࠥࡽࡩ࡭࡮ࠣࡦࡪࠦࡳࡦࡴ࡬ࡥࡱ࡯ࡺࡦࡦࠣࡨ࡮ࡸࡥࡤࡶ࡯ࡽ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡶࡼࡴࡪࠦ࡫ࡦࡻࡢࡦࡾࡺࡥࡴ࠼ࠣࡦࡾࡺࡥࡢࡴࡵࡥࡾࠦ࡯ࡳࠢࡥࡽࡹ࡫ࡳࠡࡦࡨࡴࡪࡴࡤࡪࡰࡪࠤࡴࡴࠠࡑࡻࡷ࡬ࡴࡴࠠࡷࡧࡵࡷ࡮ࡵ࡮࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨಶ")
        if len(key_bytes) > goTenna.constants.MAXLENGTH:
            raise ValueError
        self._key_bytes = key_bytes
    @classmethod
    def deserialize(cls, value):
        return cls(value)
    def serialize(self):
        return self.key_bytes
    @property
    def key_bytes(self):
        return self._key_bytes
class SenderInitialsTLV(basic_tlv.l111l11lll_opy_):
    l11ll_opy_ (u"ࠢࠣࠤࠣࡅ࡚ࠥࡌࡗࠢࡩࡳࡷࠦࡨࡰ࡮ࡧ࡭ࡳ࡭ࠠࡴࡧࡱࡨࡪࡸࠠࡪࡰ࡬ࡸ࡮ࡧ࡬ࡴࠌࠣࠤࠥࠦࠢࠣࠤಷ")
    l1l11ll1ll_opy_ = 3
    MAX_LENGTH = 8
    @property
    def l111ll11l1_opy_(self):
        return self.MAX_LENGTH
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
class MessageTypeTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠣࠤࠥࠤࡆࠦࡔࡍࡘࠣࡪࡴࡸࠠࡩࡱ࡯ࡨ࡮ࡴࡧࠡࡣࠣࡱࡪࡹࡳࡢࡩࡨࠤࡹࡿࡰࡦࠢࡶࡸࡷ࡯࡮ࡨࠌࠣࠤࠥࠦࠢࠣࠤಸ")
    l1l11ll1ll_opy_ = 1
    def __repr__(self):
        return l11ll_opy_ (u"ࠩ࠿ࡑࡪࡹࡳࡢࡩࡨࡘࡾࡶࡥࡕࡎ࡙࠾ࠥࡺࡹࡱࡧࡀࡿࢂࡄࠧಹ").format(self.msgtype)
    def __eq__(self, other):
        return isinstance(other, MessageTypeTLV)\
            and other.msgtype == self.msgtype
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, msgtype):
        if not goTenna.constants.LAYER8_MESSAGE_TYPES.valid(msgtype):
            raise ValueError(l11ll_opy_ (u"ࠪࡍࡳࡼࡡ࡭࡫ࡧࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡺࡹࡱࡧࠣࡿࢂ࠭಺").format(msgtype))
        self.msgtype = msgtype
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        return cls(goTenna.util.b2s(l111l1ll1l_opy_))
    def serialize(self):
        return goTenna.util.s2b(self.msgtype)
class ExternalDestinationTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠦࠧࠨࠠࡂࠢࡗࡐ࡛ࠦࡳࡱࡧࡦ࡭࡫ࡿࡩ࡯ࡩࠣࡥࠥࡴ࡯࡯࠯ࡪࡳ࡙࡫࡮࡯ࡣࠣࡨࡪࡹࡴࡪࡰࡤࡸ࡮ࡵ࡮ࠡࡨࡲࡶࠥࡧࠠ࡮ࡧࡶࡷࡦ࡭ࡥࠡࠪࡨ࠲࡬࠴ࠠࡵࡪࡵࡳࡺ࡭ࡨࠡࡣࠣ࡫ࡦࡺࡥࡸࡣࡼ࠭ࠥࠨࠢࠣ಻")
    l1l11ll1ll_opy_ = 0x41
    def __repr__(self):
        return l11ll_opy_ (u"ࠬࡂࡅࡹࡶࡨࡶࡳࡧ࡬ࡅࡧࡶࡸ࡮ࡴࡡࡵ࡫ࡲࡲ࡙ࡒࡖ࠻ࠢࡧࡩࡸࡺࡩ࡯ࡣࡷ࡭ࡴࡴ࠽ࡼࡿࡁ಼ࠫ").format(self.destination)
    def __eq__(self, other):
        return isinstance(other, ExternalDestinationTLV) and self.destination == other.destination
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, destination):
        if not isinstance(destination, six.integer_types):
            raise TypeError(l11ll_opy_ (u"࠭ࡅࡹࡶࡨࡶࡳࡧ࡬ࠡࡦࡨࡷࡹ࡯࡮ࡢࡶ࡬ࡳࡳࠦࡡࡳࡧࠣ࡭ࡳࡺࡥࡨࡧࡵࡷ࠱ࠦࡢࡶࡶࠣࡨࡪࡹࡴࡪࡰࡤࡸ࡮ࡵ࡮ࠡ࡫ࡶࠤࢀࢃࠧಽ")
                            .format(type(destination)))
        self.destination = destination
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        (destination,) = struct.unpack(l11ll_opy_ (u"ࠧࠢࡓࠪಾ"), l111l1ll1l_opy_)
        return cls(destination)
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠨࠣࡔࠫಿ"), self.destination)
class ExternalOriginTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠤࠥࠦࠥࡇࠠࡕࡎ࡙ࠤࡸࡶࡥࡤ࡫ࡩࡽ࡮ࡴࡧࠡࡣࠣࡲࡴࡴ࠭ࡨࡱࡗࡩࡳࡴࡡࠡࡱࡵ࡭࡬࡯࡮ࠡࡨࡲࡶࠥࡧࠠ࡮ࡧࡶࡷࡦ࡭ࡥࠡࠪࡨ࠲࡬࠴ࠠࡧࡴࡲࡱࠥࡧࠠࡨࡣࡷࡩࡼࡧࡹࠪࠢࠥࠦࠧೀ")
    l1l11ll1ll_opy_ = 0x40
    def __repr__(self):
        return l11ll_opy_ (u"ࠪࡀࡊࡾࡴࡦࡴࡱࡥࡱࡕࡲࡪࡩ࡬ࡲ࡙ࡒࡖ࠻ࠢࡲࡶ࡮࡭ࡩ࡯࠿ࡾࢁࡃ࠭ು").format(self.origin)
    def __eq__(self, other):
        return isinstance(other, ExternalOriginTLV) and self.origin == other.origin
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, origin):
        if not isinstance(origin, six.integer_types):
            raise TypeError(l11ll_opy_ (u"ࠫࡊࡾࡴࡦࡴࡱࡥࡱࠦ࡯ࡳ࡫ࡪ࡭ࡳࡹࠠࡢࡴࡨࠤ࡮ࡴࡴࡦࡩࡨࡶࡸ࠲ࠠࡣࡷࡷࠤࡴࡸࡩࡨ࡫ࡱࠤ࡮ࡹࠠࡼࡿࠪೂ")
                            .format(type(origin)))
        self.origin = origin
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        (origin,) = struct.unpack(l11ll_opy_ (u"ࠬࠧࡑࠨೃ"), l111l1ll1l_opy_)
        return cls(origin)
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"࠭ࠡࡒࠩೄ"), self.origin)
class AdvertisedExternalAddressTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠢࠣࠤࠣࡅ࡚ࠥࡌࡗࠢࡶࡴࡪࡩࡩࡧࡻ࡬ࡲ࡬ࠦࡴࡩࡧࠣࡍࡉࠦࡡ࡯ࡦࠣ࡬ࡺࡳࡡ࡯ࠢࡵࡩࡦࡪࡡࡣ࡮ࡨࠤࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠢࡩࡳࡷࠦࡡࠡࡰࡲࡨࡪࠦࡥࡹࡶࡨࡶࡳࡧ࡬ࠡࡶࡲࠤࡹ࡮ࡥࠡࡩࡲࡘࡪࡴ࡮ࡢࠢࡱࡩࡹࡽ࡯ࡳ࡭࠱ࠎࠏࠦࠠࠡࠢࡗ࡬ࡪࠦࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠤࡲࡻࡳࡵࠢࡥࡩࠥࡲࡥࡴࡵࠣࡸ࡭ࡧ࡮ࠡ࠴࠴࠼ࠥࡨࡹࡵࡧࡶࠤࡪࡴࡣࡰࡦࡨࡨ࠱ࠦࡴࡩࡱࡸ࡫࡭ࠦࡩࡧࠢࡰࡳࡷ࡫ࠠࡵࡪࡤࡲࠥࡵ࡮ࡦࠢࡗࡐ࡛ࠦࡩࡴࠢࡷࡳࠥ࡬ࡩࡵࠢ࡬ࡲࠥࡧࠠࡱࡣࡼࡰࡴࡧࡤࠡ࡫ࡷࠤࡸ࡮࡯ࡶ࡮ࡧࠤࡵࡸ࡯ࡣࡣࡥࡰࡾࠦࡢࡦࠢࡶ࡬ࡴࡸࡴࡦࡴࠣࡸ࡭ࡧ࡮ࠡࡶ࡫ࡥࡹ࠴ࠊࠡࠢࠣࠤࠧࠨࠢ೅")
    l1l11ll1ll_opy_ = 0x3f
    def __repr__(self):
        return l11ll_opy_ (u"ࠨ࠾ࡄࡨࡻ࡫ࡲࡵ࡫ࡶࡩࡩࡋࡸࡵࡧࡵࡲࡦࡲࡁࡥࡦࡵࡩࡸࡹࡔࡍࡘ࠽ࠤ࡬࡯ࡤ࠾ࡽࢀࠤࡩ࡫ࡳࡤ࠿ࡾࢁࡃ࠭ೆ")\
            .format(self.gid, self.description)
    def __eq__(self, other):
        return isinstance(other, AdvertisedExternalAddressTLV)\
            and self.gid == other.gid \
            and self.description == other.description
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, gid, description):
        l11ll_opy_ (u"ࠤࠥࠦࠥࡈࡵࡪ࡮ࡧࠤࡹ࡮ࡥࠡࡖࡏ࡚࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡩ࡬ࡨࠥࡧࡤࡥࡴࡨࡷࡸࡀࠠࡕࡪࡨࠤࡪࡾࡴࡦࡴࡱࡥࡱࠦࡇࡊࡆ࠱ࠤࡆࡹࡳࡶ࡯ࡨࡨࠥࡺ࡯ࠡࡤࡨࠤࡪࡾࡴࡦࡴࡱࡥࡱ࠲ࠠࡴࡱࠣ࡭ࡹࠦࡤࡰࡧࡶࠤࡳࡵࡴࠡࡰࡨࡩࡩࠦࡴࡰࠢ࡫ࡥࡻ࡫ࠠࡪࡶࡶࠤࡥࡦࡶࡪࡣࡢ࡫ࡦࡺࡥࡸࡣࡼࡤࡥࠦࡥࡹࡲ࡯࡭ࡨ࡯ࡴ࡭ࡻࠣࡷࡪࡺ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡸࡷࠦࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱ࠾࡚ࠥࡨࡦࠢ࡫ࡹࡲࡧ࡮࠮ࡴࡨࡥࡩࡧࡢ࡭ࡧࠣࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠡࡱࡩࠤࡹ࡮ࡥࠡࡣࡧࡨࡷ࡫ࡳࡴ࠰ࠣࡑࡺࡹࡴࠡࡤࡨࠤࡱ࡫ࡳࡴࠢࡷ࡬ࡦࡴࠠ࠳࠳࠻ࠤࡧࡿࡴࡦࡵࠣࡩࡳࡩ࡯ࡥࡧࡧ࠰ࠥࡺࡨࡰࡷࡪ࡬ࠥ࡯ࡦࠡ࡯ࡲࡶࡪࠦࡴࡩࡣࡱࠤࡹ࡮ࡩࡴࠢࡗࡐ࡛ࠦࡩࡴࠢࡷࡳࠥ࡭࡯ࠡ࡫ࡱࠤࡦࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡪࡶࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥࡨࡥࠡ࡮ࡨࡷࡸ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥࡴ࡙ࠢࡥࡱࡻࡥࡆࡴࡵࡳࡷࡀࠠࡊࡨࠣࡸ࡭࡫ࠠࡢࡦࡧࡶࡪࡹࡳࠡ࡫ࡶࠤ࡮ࡴࡶࡢ࡮࡬ࡨ࠱ࠦ࡯ࡳࠢࡷ࡬ࡪࠦࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠤ࡮ࡹࠠࡪࡰࡹࡥࡱ࡯ࡤ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨೇ")
        if not isinstance(gid, goTenna.settings.GID):
            raise TypeError(l11ll_opy_ (u"ࠥ࡫࡮ࡪࠠࡴࡪࡲࡹࡱࡪࠠࡣࡧࠣࡥࠥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡌࡈ࠱ࠦࡩࡴࠢࡾࢁࠧೈ")
                            .format(type(gid)))
        if not isinstance(description, (str, goTenna.util.UnicodeType)):
            raise TypeError(l11ll_opy_ (u"ࠫࡧࡧࡤࠡࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠦࡴࡺࡲࡨ࠾ࠥࡹࡨࡰࡷ࡯ࡨࠥࡨࡥࠡࡵࡷࡶࠥࡵࡲࠡࡷࡱ࡭ࡨࡵࡤࡦࠢࠫࡳࡳࠦࡰࡺ࠴ࠬ࠰ࠥ࡯ࡳࠡࡽࢀࠫ೉").format(type(description)))
        l111l111l1_opy_ = goTenna.util.s2b(description)
        if len(l111l111l1_opy_) > goTenna.constants.MAXLENGTH - 10:
            raise ValueError(l11ll_opy_ (u"ࠧࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠣ࡭ࡸࠦࡴࡰࡱࠣࡰࡴࡴࡧࠡࠪࡾࢁࡇ࠲ࠠ࡮ࡣࡻࠤࢀࢃࡂࠪࠤೊ")
                             .format(len(l111l111l1_opy_),
                                     goTenna.constants.MAXLENGTH - 10))
        self.gid = gid
        self.description = description
    def serialize(self):
        l1lll1l1111_opy_ = goTenna.util.s2b(self.description)
        return struct.pack(l11ll_opy_ (u"࠭ࠡࡒࡽࢀࡷࠬೋ").format(len(l1lll1l1111_opy_)), self.gid.gid_val, l1lll1l1111_opy_)
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        addr, l1lll1l1ll1_opy_ = struct.unpack(l11ll_opy_ (u"ࠧࠢࡓࡾࢁࡸ࠭ೌ").format(len(l111l1ll1l_opy_)-8),
                                        l111l1ll1l_opy_)
        desc = goTenna.util.b2s(l1lll1l1ll1_opy_)
        return cls(goTenna.settings.GID(addr, goTenna.settings.GID.PRIVATE), desc)
class BinaryTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠣࠤࠥࠤࡆࠦࡔࡍࡘࠣࡷࡵ࡫ࡣࡪࡨࡼ࡭ࡳ࡭ࠠࡵࡪࡨࠤࡎࡊࠠࡢࡰࡧࠤ࡭ࡻ࡭ࡢࡰࠣࡶࡪࡧࡤࡢࡤ࡯ࡩࠥࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠣࡪࡴࡸࠠࡢࠢࡱࡳࡩ࡫ࠠࡦࡺࡷࡩࡷࡴࡡ࡭ࠢࡷࡳࠥࡺࡨࡦࠢࡪࡳ࡙࡫࡮࡯ࡣࠣࡲࡪࡺࡷࡰࡴ࡮࠲ࠏࠐࠠࠡࠢࠣࡘ࡭࡫ࠠࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠥࡳࡵࡴࡶࠣࡦࡪࠦ࡬ࡦࡵࡶࠤࡹ࡮ࡡ࡯ࠢ࠵࠵࠽ࠦࡢࡺࡶࡨࡷࠥ࡫࡮ࡤࡱࡧࡩࡩ࠲ࠠࡵࡪࡲࡹ࡬࡮ࠠࡪࡨࠣࡱࡴࡸࡥࠡࡶ࡫ࡥࡳࠦ࡯࡯ࡧࠣࡘࡑ࡜ࠠࡪࡵࠣࡸࡴࠦࡦࡪࡶࠣ࡭ࡳࠦࡡࠡࡲࡤࡽࡱࡵࡡࡥࠢ࡬ࡸࠥࡹࡨࡰࡷ࡯ࡨࠥࡶࡲࡰࡤࡤࡦࡱࡿࠠࡣࡧࠣࡷ࡭ࡵࡲࡵࡧࡵࠤࡹ࡮ࡡ࡯ࠢࡷ࡬ࡦࡺ࠮ࠋࠢࠣࠤࠥࠨ್ࠢࠣ")
    l1l11ll1ll_opy_ = 0x55
    def __repr__(self):
        return l11ll_opy_ (u"ࠩ࠿ࡆ࡮ࡴࡡࡳࡻࡗࡐ࡛ࡀࠠࡣ࡫ࡱࡥࡷࡿ࠽ࡼࡿࡁࠫ೎").format(self.binary)
    def __eq__(self, other):
        return isinstance(other, BinaryTLV)\
            and self.binary == other.binary
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, binary):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡂࡶ࡫࡯ࡨࠥࡺࡨࡦࠢࡗࡐ࡛࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡦ࡯ࡳࡦࡵ࡚ࠣࡦࡲࡵࡦࡇࡵࡶࡴࡸ࠺ࠡࡋࡩࠤࡹ࡮ࡥࠡ࡮ࡨࡲ࡬ࡺࡨࠡࡱࡩࠤࡹ࡮ࡥࠡࡤ࡬ࡲࡦࡸࡹࠡ࡫ࡶࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦ೏")
        if len(binary) > goTenna.constants.MAXLENGTH - 10:
            raise ValueError(l11ll_opy_ (u"ࠦࡧ࡯࡮ࡢࡴࡼࠤ࡮ࡹࠠࡵࡱࡲࠤࡱࡵ࡮ࡨࠢࠫࡿࢂࡈࠬࠡ࡯ࡤࡼࠥࢁࡽࡃࠫࠥ೐")
                             .format(len(binary),
                                     goTenna.constants.MAXLENGTH - 10))
        if binary:
            try:
                struct.pack(l11ll_opy_ (u"ࠬ࠷ࡳࠨ೑"), binary[:1])
            except struct.error:
                raise TypeError(l11ll_opy_ (u"࠭ࡢࡪࡰࡤࡶࡾࠦࡳࡩࡱࡸࡰࡩࠦࡢࡦࠢࡥࡽࡹ࡫ࡳ࡭࡫࡮ࡩ࠱ࠦࡩࡴࠢࡾࢁࠬ೒")
                                .format(type(binary)))
        else:
            binary = six.b(l11ll_opy_ (u"ࠧࠨ೓"))
        self.binary = binary
    def serialize(self):
        return self.binary
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        return cls(l111l1ll1l_opy_)
l11ll_opy_ (u"ࠣࠤࠥࠤࡆࠦ࡬ࡪࡵࡷࠤࡴ࡬ࠠࡢ࡮࡯ࠤࡹ࡮ࡥࠡࡖࡏ࡚ࡸࠦࡥࡹࡲࡨࡧࡹ࡫ࡤࠡ࡫ࡱࠤࡹ࡮ࡥࠡࡶࡲࡴࠥࡲࡥࡷࡧ࡯ࠤࡴ࡬ࠠࡢࠢࡳࡥࡾࡲ࡯ࡢࡦࠣࠦࠧࠨ೔")
ALL = [l111111l11_opy_ for l111111l11_opy_ in vars().values()
       if isinstance(l111111l11_opy_, type)
       and issubclass(l111111l11_opy_, basic_tlv.TLV)
       and l111111l11_opy_.__name__.endswith(l11ll_opy_ (u"ࠩࡗࡐ࡛࠭ೕ"))]