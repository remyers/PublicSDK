# coding: utf8
from __future__ import print_function
import sys
l1111_opy_ = sys.version_info [0] == 2
l1lll1_opy_ = 2048
l1ll1_opy_ = 7
def l11ll_opy_ (l1_opy_):
    global l1llll_opy_
    l11l1l_opy_ = ord (l1_opy_ [-1])
    l111l_opy_ = l1_opy_ [:-1]
    l1ll_opy_ = l11l1l_opy_ % len (l111l_opy_)
    l1l1_opy_ = l111l_opy_ [:l1ll_opy_] + l111l_opy_ [l1ll_opy_:]
    if l1111_opy_:
        l1ll1l_opy_ = unicode () .join ([unichr (ord (char) - l1lll1_opy_ - (l1l11_opy_ + l11l1l_opy_) % l1ll1_opy_) for l1l11_opy_, char in enumerate (l1l1_opy_)])
    else:
        l1ll1l_opy_ = str () .join ([chr (ord (char) - l1lll1_opy_ - (l1l11_opy_ + l11l1l_opy_) % l1ll1_opy_) for l1l11_opy_, char in enumerate (l1l1_opy_)])
    return eval (l1ll1l_opy_)
# Copyright (C) 2018 goTenna, Inc. This file is distributed as part of the
# goTenna USB SDK. See the associated license for more information.
l11ll_opy_ (u"ࠧࠨࠢࠡࡏࡨࡸ࡭ࡵࡤࡴࠢࡤࡲࡩࠦࡣ࡭ࡣࡶࡷࡪࡹࠠࡧࡱࡵࠤࡵࡧࡲࡴ࡫ࡱ࡫ࠥ࡭࡯ࡕࡧࡱࡲࡦࠦࡔࡍࡘࠣࡩࡳࡩ࡯ࡥࡧࡧࠤࡩࡧࡴࡢ࠰ࠍࠦࠧࠨૄ")
import struct
import itertools
import logging
import six
import goTenna.constants
import goTenna.settings
import goTenna.util
_MODULE_LOGGER = logging.getLogger(__name__)
class TLV(object):
    l11ll_opy_ (u"ࠨࠢࠣࠢࡄࠤ࡙ࡒࡖࠡࡱࡥ࡮ࡪࡩࡴࠡࡶ࡫ࡥࡹࠦ࡫࡯ࡱࡺࡷࠥ࡮࡯ࡸࠢࡷࡳࠥࡨࡵࡪ࡮ࡧࠤ࡮ࡺࡳࡦ࡮ࡩࠤ࡫ࡸ࡯࡮ࠢࡤࠤࡧ࡯࡮ࡢࡴࡼࠤࡸࡺࡲࡪࡰࡪࠤࡦࡴࡤࠡࡵࡨࡶ࡮ࡧ࡬ࡪࡼࡨࠤ࡮ࡺࡳࡦ࡮ࡩࠤࡹࡵࠠࡢࠢࡥ࡭ࡳࡧࡲࡺࠢࡶࡸࡷ࡯࡮ࡨ࠰ࠍࠎࠥࠦࠠࠡࡕ࡫ࡳࡺࡲࡤࠡࡤࡨࠤࡸࡻࡢࡤ࡮ࡤࡷࡸ࡫ࡤࠡࡤࡼࠤࡨࡲࡡࡴࡵࡨࡷࠥࡺࡨࡢࡶࠣ࡭ࡳࡹࡴࡪࡶࡸࡸࡪࠦࡳࡱࡧࡦ࡭࡫࡯ࡣࠡ࡭࡬ࡲࡩࡹࠠࡰࡨࠣࡘࡑ࡜࠮ࠋࠌࠣࠤࠥࠦࡐࡳࡱࡹ࡭ࡩ࡫ࡳࠡࡵࡷࡥࡹ࡯ࡣࠡ࡯ࡨࡸ࡭ࡵࡤࡴࠢࡩࡳࡷࠦࡳࡦࡴ࡬ࡥࡱ࡯ࡺࡢࡶ࡬ࡳࡳࠦࡡ࡯ࡦࠣࡨࡪࡹࡥࡳ࡫ࡤࡰ࡮ࢀࡡࡵ࡫ࡲࡲ࠳ࠐࠠࠡࠢࠣࠦࠧࠨૅ")
    def __ne__(self, other):
        return not self.__eq__(other)
    def __eq__(self, other):
        return NotImplemented
    @classmethod
    def l111ll11ll_opy_(cls):
        l11ll_opy_ (u"ࠢࠣࠤࠣࡗࡹࡧࡴࡪࡥࠣࡱࡪࡺࡨࡰࡦࠣࡸࡴࠦࡧࡦࡶࠣࡥࠥࡲ࡯ࡨࡩࡨࡶࠥࡴࡡ࡮ࡧࡧࠤ࡫ࡵࡲࠡࡶ࡫ࡩࠥࡩ࡬ࡢࡵࡶ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࡕࡪࡨࠤࡷ࡫ࡳࡶ࡮ࡷࠤ࡮ࡹࠠࡪࡰࡷࡩࡷࡴࡡ࡭࡮ࡼࠤࡨࡧࡣࡩࡧࡧ࠰ࠥࡹ࡯ࠡࡶ࡫࡭ࡸࠦ࡭ࡦࡶ࡫ࡳࡩࠦ࡭ࡢࡻࠣࡦࡪࠦࡣࡢ࡮࡯ࡩࡩࠦࡥࡷࡧࡵࡽࠥࡺࡩ࡮ࡧࠣࡸ࡭࡫ࠠࡤࡣ࡯ࡰࡪࡸࠠࡸࡣࡱࡸࡸࠦࡴࡰࠢࡶࡩࡳࡪࠠࡢࠢ࡯ࡳ࡬ࠦ࡭ࡦࡵࡶࡥ࡬࡫࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣࡊࡴࡸࠠࡦࡺࡤࡱࡵࡲࡥ࠻ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠳࠴ࠠࡤࡱࡧࡩ࠲ࡨ࡬ࡰࡥ࡮࠾࠿ࠦࡰࡺࡶ࡫ࡳࡳࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡩ࡬ࡢࡵࡶࠤࡒࡿࡔࡍࡘࠫࡘࡑ࡜ࠩ࠻ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡩ࡫ࡦࠡ࡯ࡨࡸ࡭ࡵࡤࠩࡵࡨࡰ࡫࠯࠺ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡹࡥ࡭ࡨ࠱࡫ࡪࡺ࡟࡭ࡱࡪ࡫ࡪࡸࠨࠪ࠰ࡺࡥࡷࡴࡩ࡯ࡩࠫࠫࡲࡿࠠࡪࡰࡶࡸࡦࡴࡣࡦࠢࡺࡥࡷࡴࡩ࡯ࡩࠣ࡬ࡪࡸࡥࠨࠫࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡀࡤ࡮ࡤࡷࡸࡳࡥࡵࡪࡲࡨࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡥࡧࡩࠤࡴࡺࡨࡦࡴࡢࡱࡪࡺࡨࡰࡦࠫࡧࡱࡹࠩ࠻ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡣ࡭ࡵ࠱࡫ࡪࡺ࡟࡭ࡱࡪ࡫ࡪࡸࠨࠪ࠰ࡺࡥࡷࡴࡩ࡯ࡩࠫࠫࡲࡿࠠࡤ࡮ࡤࡷࡸࠦࡷࡢࡴࡱ࡭ࡳ࡭ࠠࡩࡧࡵࡩࠬ࠯ࠊࠋࠌࠣࠤ࡙ࠥࠦࠠࠡࠢࠣࡸ࡯࡮ࡨࠢࡷ࡬࡮ࡹࠠ࡮ࡧࡷ࡬ࡴࡪࠠࡦࡰࡶࡹࡷ࡫ࡳࠡࡶ࡫ࡩࠥࡲ࡯ࡨࡩࡨࡶࠥࡽࡩ࡭࡮ࠣࡦࡪࠦࡡࡵࠢࡷ࡬ࡪࠦࡰࡳࡱࡳࡩࡷࠦ࡬ࡰࡩࡪ࡭ࡳ࡭ࠠࡴࡥࡲࡴࡪ࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰࡶࠤࡱࡵࡧࡨ࡫ࡱ࡫࠳ࡒ࡯ࡨࡩࡨࡶ࠿ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ૆")
        if None is getattr(cls, l11ll_opy_ (u"ࠨࡡࡏࡓࡌࡍࡅࡓࠩે"), None):
            cls._LOGGER = _MODULE_LOGGER.getChild(cls.__name__)
        return cls._LOGGER
    def serialize(self):
        l11ll_opy_ (u"ࠤࠥࠦࠥࡇࠠࡥࡱ࠰ࡲࡴࡺࡨࡪࡰࡪࠤࡧࡧࡳࡦࠢࡰࡩࡹ࡮࡯ࡥࠢࡩࡳࡷࠦࡢࡶ࡫࡯ࡨ࡮ࡴࡧࠡࡖࡏ࡚ࠥࡪࡡࡵࡣࠣࡪࡷࡵ࡭ࠡࡣࠣࡘࡑ࡜ࠠࡤ࡮ࡤࡷࡸࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡࡕ࡫ࡳࡺࡲࡤࠡࡤࡨࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡥࡽࠥࡹࡵࡣࡥ࡯ࡥࡸࡹࡥࡴࠢࡷࡳࠥࡨࡵࡪ࡮ࡧࠤࡹ࡮ࡥࠡࡲࡤࡽࡱࡵࡡࡥࠢࡲࡲࡱࡿ࠮ࠡࡖ࡫࡭ࡸࠦ࡭ࡦࡶ࡫ࡳࡩࠦࡳࡩࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡦࡪࠦࡣࡢ࡮࡯ࡩࡩࠦࡤࡪࡴࡨࡧࡹࡲࡹ࠼ࠢ࡬ࡲࡸࡺࡥࡢࡦ࠯ࠤࡺࡹࡥࠡ࠼ࡳࡽ࠿ࡳࡥࡵࡪ࠽ࡤ࡙ࡒࡖ࠯ࡶࡲࡣࡧࡿࡴࡦࡵࡣ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤૈ")
        raise NotImplementedError
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡁࠡࡦࡲ࠱ࡳࡵࡴࡩ࡫ࡱ࡫ࠥࡨࡡࡴࡧࠣࡧࡱࡧࡳࡴ࡯ࡨࡸ࡭ࡵࡤࠡࡨࡲࡶࠥࡶࡡࡳࡵ࡬ࡲ࡬ࠦࡡࠡࡖࡏ࡚ࠥ࡬ࡲࡰ࡯ࠣࡷࡪࡸࡩࡢ࡮࡬ࡾࡪࡪࠠࡥࡣࡷࡥ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡࡕ࡫ࡳࡺࡲࡤࠡࡤࡨࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡥࡽࠥࡹࡵࡣࡥ࡯ࡥࡸࡹࡥࡴࠢࡷࡳࠥࡶࡡࡳࡵࡨࠤࡩࡧࡴࡢࠢࡩࡶࡴࡳࠠࡵࡪࡨࠤࡻࡧ࡬ࡶࡧ࠱ࠤࡘࡻࡢࡤ࡮ࡤࡷࡸ࡫ࡳࠡ࡯ࡤࡽࠥࡧࡳࡴࡷࡰࡩࠥࡺࡨࡢࡶࠣࡸ࡭࡯ࡳࠡ࡯ࡨࡸ࡭ࡵࡤࠡࡹ࡬ࡰࡱࠦ࡯࡯࡮ࡼࠤࡧ࡫ࠠࡤࡣ࡯ࡰࡪࡪࠠࡪࡨࠣ࡭ࡹࠦࡩࡴࠢ࡬ࡲࠥ࡬ࡡࡤࡶࠣࡨࡦࡺࡡࠡࡨࡲࡶࠥࡺࡨࡢࡶࠣࡷࡺࡨࡣ࡭ࡣࡶࡷ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡࡕ࡫ࡳࡺࡲࡤࠡࡰࡲࡸࠥࡨࡥࠡࡥࡤࡰࡱ࡫ࡤࠡࡦ࡬ࡶࡪࡩࡴ࡭ࡻ࠾ࠤ࡮ࡴࡳࡵࡧࡤࡨ࠱ࠦࡵࡴࡧࠣ࠾ࡵࡿ࠺࡮ࡧࡷ࡬࠿ࡦࡦࡳࡱࡰࡣࡧࡿࡴࡦࡵࡣࠤࡴࡸࠠ࠻ࡲࡼ࠾ࡲ࡫ࡴࡩ࠼ࡣࡱࡺࡲࡴࡪࡲ࡯ࡩࡤ࡬ࡲࡰ࡯ࡢࡦࡾࡺࡥࡴࡢࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢૉ")
        cls.l111ll11ll_opy_().warning(l11ll_opy_ (u"࡙ࠦࡒࡖࠡࡽࢀࠤ࡮ࡹࠠࡱࡴࡨࡷࡪࡴࡴࠡࡤࡸࡸࠥࡴ࡯ࡵࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࡪࡪࠢ૊")
                                 .format(cls.__name__))
        obj = cls()
        setattr(obj, l11ll_opy_ (u"ࠬࡥࡤࡦࡨࡤࡹࡱࡺ࡟ࡷࡣ࡯ࡹࡪ࠭ો"), l111l1ll1l_opy_)
        return obj
    @classmethod
    def _111l11111_opy_(cls, l111lll111_opy_, l111l1ll1l_opy_, l111ll1111_opy_):
        l11ll_opy_ (u"ࠨࠢࠣࠢࡅࡹ࡮ࡲࡤࠡࡶ࡫ࡩࠥࡧࡰࡱࡴࡲࡴࡷ࡯ࡡࡵࡧࠣࡧࡱࡧࡳࡴࠢࡩࡶࡴࡳࠠࡢࠢࡶࡳࡲ࡫ࡷࡩࡣࡷࠤࡵࡧࡲࡴࡧࡧࠤ࡙ࡒࡖ࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤࡑࡵ࡯࡬ࡵࠣࡹࡵࠦࡡ࡭࡮ࠣࡷࡺࡨࡣ࡭ࡣࡶࡷࡪࡹࠠࡰࡨࠣࡘࡑ࡜ࠠࡪࡰࠣ࡫ࡱࡵࡢࡢ࡮ࡶࠬ࠮ࠦࡡ࡯ࡦࠣࡧࡷ࡫ࡡࡵࡧࡶࠤࡦࡴࠠࡪࡰࡶࡸࡦࡴࡣࡦࠢࡲࡪࠥࡺࡨࡦࠢࡤࡴࡵࡸ࡯ࡱࡴ࡬ࡥࡹ࡫ࠠࡰࡰࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣૌ")
        l111lll1ll_opy_ = (obj
                    for obj in l111ll1111_opy_
                    if issubclass(obj, cls) and obj is not cls)
        lookup = {obj.l1l11ll1ll_opy_ : obj for obj in l111lll1ll_opy_}
        try:
            return lookup[l111lll111_opy_].deserialize(l111l1ll1l_opy_)
        except KeyError:
            pass
        except:
            cls.l111ll11ll_opy_().exception(l11ll_opy_ (u"ࠢࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡨࡪࡹࡥࡳ࡫ࡤࡰ࡮ࢀࡥࠡࡖࡏ࡚ࠥࢁࡽ્ࠣ")
                                       .format(l111lll111_opy_))
            raise KeyError
    @classmethod
    def l1ll11llll_opy_(cls, bytestring, l111ll1111_opy_):
        l11ll_opy_ (u"ࠣࠤࠥࠤࡕࡧࡲࡴࡧࠣࡥࠥࡹࡩ࡯ࡩ࡯ࡩ࡚ࠥࡌࡗࠢࡩࡶࡴࡳࠠࡢࠢࡥࡽࡹ࡫ࡳࡵࡴࡨࡥࡲࠦࡴࡩࡣࡷࠤ࡮ࡹࠠࡦࡺࡳࡩࡨࡺࡥࡥࠢࡷࡳࠥࡩ࡯࡯ࡶࡤ࡭ࡳࠦ࡭ࡰࡴࡨ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࡕࡪ࡬ࡷࠥ࡯ࡳࠡࡸࡨࡶࡾࠦࡳࡪ࡯࡬ࡰࡦࡸࠠࡵࡱࠣ࠾ࡵࡿ࠺࡮ࡧࡷ࡬࠿ࡦࡦࡳࡱࡰࡣࡧࡿࡴࡦࡵࡣࠤࡧࡻࡴࠡ࡫ࡱࠤࡦࡪࡤࡪࡶ࡬ࡳࡳࠦࡴࡰࠢࡵࡩࡹࡻࡲ࡯࡫ࡱ࡫ࠥࡺࡨࡦࠢࡳࡥࡷࡹࡥࡥࠢࡗࡐ࡛࠲ࠠࡢ࡮ࡶࡳࠥࡸࡥࡵࡷࡵࡲࡸࠦࡴࡩࡧࠣࡶࡪࡳࡡࡪࡰ࡬ࡲ࡬ࠦࡢࡺࡶࡨࡷ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ૎")
        l1111lll11_opy_ = goTenna.util.l1l11l11_opy_(bytestring[0])
        l1111lll1l_opy_ = goTenna.util.l1l11l11_opy_(bytestring[1])
        value = bytestring[2:l1111lll1l_opy_+2]
        return (cls._111l11111_opy_(l1111lll11_opy_, value, l111ll1111_opy_),
                bytestring[l1111lll1l_opy_+2:])
    @classmethod
    def from_bytes(cls, bytestring, l111ll1111_opy_):
        l11ll_opy_ (u"ࠤࠥࠦࠥࡉࡲࡦࡣࡷࡩࠥࡧࠠࡴ࡫ࡱ࡫ࡱ࡫ࠠࡕࡎ࡙ࠤ࡫ࡸ࡯࡮ࠢࡤࠤࡧࡿࡴࡦࡵࡷࡶࡪࡧ࡭࠯ࠢࡌࡪࠥࡳࡵ࡭ࡶ࡬ࡴࡱ࡫ࠠࡕࡎ࡙ࡷࠥࡧࡲࡦࠢࡧࡩࡸࡩࡲࡪࡤࡨࡨࠥ࡯࡮ࠡࡶ࡫ࡩࠥࡨࡹࡵࡧࡶࡸࡷ࡫ࡡ࡮࠮ࠣࡧࡷ࡫ࡡࡵࡧࠣࡳࡳࡲࡹࠡࡶ࡫ࡩࠥ࡬ࡩࡳࡵࡷࠤࡴࡴࡥ࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡧࡿࡴࡦࡵࠣࡦࡾࡺࡥࡴࡶࡵ࡭ࡳ࡭࠺ࠡࡖ࡫ࡩࠥࡼࡡ࡭ࡷࡨࠤࡹࡵࠠࡥࡧࡦࡳࡩ࡫ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥࡴࠢࡨࡼࡨ࡫ࡰࡵ࡫ࡲࡲ࠳ࡏ࡮ࡥࡧࡻࡉࡷࡸ࡯ࡳ࠼ࠣࡍ࡫ࠦࡴࡩࡧࠣࡦࡾࡺࡥࡴࡶࡵࡩࡦࡳࠠࡪࡵࠣࡸࡴࡵࠠࡴࡪࡲࡶࡹࠦࡦࡰࡴࠣࡸ࡭࡫ࠠࡦࡰࡦࡳࡩ࡫ࡤࠡࡖࡏ࡚ࠥ࡯࡮ࡧࡱࡵࡱࡦࡺࡩࡰࡰ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥ࡯ࡴࡦࡴࡤࡦࡱ࡫࡛ࡵࡻࡳࡩࡸࡣࠠࡦࡺࡳࡩࡨࡺࡥࡥࡡࡷࡽࡵ࡫ࡳ࠻ࠢࡄࡲࠥ࡯ࡴࡦࡴࡤࡦࡱ࡫ࠠࡤࡱࡱࡸࡦ࡯࡮ࡪࡰࡪࠤ࡙ࡒࡖࠡࡵࡸࡦࡨࡲࡡࡴࡵࡨࡷࠥࡺࡨࡢࡶࠣࡻࡪࠦࡥࡹࡲࡨࡧࡹࠦ࡭ࡪࡩ࡫ࡸࠥࡨࡥࠡ࡫ࡱࠤࡹ࡮ࡩࡴࠢࡥࡽࡹ࡫ࡳࡵࡴ࡬ࡲ࡬ࠦࠨࡢࡶࠣࡸ࡭࡫ࠠࡵࡱࡳࠤࡱ࡫ࡶࡦ࡮ࠬ࠲࡚ࠥࡨࡪࡵࠣ࡭ࡸࠦ࡮ࡦࡥࡨࡷࡸࡧࡲࡺࠢࡥࡩࡨࡧࡵࡴࡧࠣࡨ࡮࡬ࡦࡦࡴࡨࡲࡹࠦࡔࡍࡘࡶࠤࡦࡺࠠࡥ࡫ࡩࡪࡪࡸࡥ࡯ࡶࠣࡰࡪࡼࡥ࡭ࡵࠣࡱ࡮࡭ࡨࡵࠢ࡫ࡥࡻ࡫ࠠࡰࡸࡨࡶࡱࡧࡰࡱ࡫ࡱ࡫ࠥࡺࡹࡱࡧࡶ࠾ࠥ࡬࡯ࡳࠢ࡬ࡲࡸࡺࡡ࡯ࡥࡨ࠰ࠥࡺࡨࡦࠢࡰࡩࡸࡹࡡࡨࡧࠣࡸࡾࡶࡥࠡࡖࡏ࡚ࠥࡧ࡮ࡥࠢࡰࡩࡸࡹࡡࡨࡧࠣࡴࡦࡿ࡬ࡰࡣࡧࠤ࡙ࡒࡖࡴࠢࡤࡶࡪࠦࡢࡰࡶ࡫ࠤࡹࡿࡰࡦࠢ࠸࠲࡚ࠥࡨࡪࡵࠣࡱࡴࡪࡵ࡭ࡧࠣࡨࡪ࡬ࡩ࡯ࡧࡶࠤࡸࡵ࡭ࡦࠢࡤࡸࡹࡸࡩࡣࡷࡷࡩࡸࠦࡣࡰࡰࡷࡥ࡮ࡴࡩ࡯ࡩࠣࡲࡦࡺࡵࡳࡣ࡯ࠤ࡬ࡸ࡯ࡶࡲ࡬ࡲ࡬ࡹࠠࡰࡨࠣࡸࡾࡶࡥࡴ࠮ࠣࡥࡳࡪࠠࡵࡪࡲࡷࡪࠦࡧࡳࡱࡸࡴ࡮ࡴࡧࡴࠢࡤࡶࡪࠦࡣࡰ࡯ࡰࡳࡳࠦࡶࡢࡴ࡬ࡥࡧࡲࡥࡴࠢࡩࡳࡷࠦࡴࡩ࡫ࡶࠤࡦࡸࡧࡶ࡯ࡨࡲࡹ࠴ࠠࡔࡧࡨࠤ࠿ࡶࡹ࠻ࡣࡷࡸࡷࡀࡠࡎࡇࡖࡗࡆࡍࡅࡠࡖࡏ࡚ࡘࡦࠠࡢࡰࡧࠤ࠿ࡶࡹ࠻ࡣࡷࡸࡷࡀࡠࡑࡃ࡜ࡐࡔࡇࡄࡠࡖࡏ࡚ࡘࡦ࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱࡷ࡚ࠥࡌࡗ࠼ࠣࡘ࡭࡫ࠠࡱࡣࡵࡷࡪࡪࠠࡕࡎ࡙ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡢ࡫ࡶࡩࡸࠦࡥࡹࡥࡨࡴࡹ࡯࡯࡯࠰ࡌࡲࡩ࡫ࡸࡆࡴࡵࡳࡷࡀࠠࡊࡨࠣࡸ࡭࡫ࡲࡦࠢࡺࡥࡸࠦࡡࠡࡸࡤࡰ࡮ࡪࠠࡕࡎ࡙ࠤࡧࡻࡴࠡࡰࡲࡸࠥ࡫࡮ࡰࡷࡪ࡬ࠥࡪࡡࡵࡣࠣࡪࡴࡸࠠࡵࡪࡨࠤࡱ࡫࡮ࡨࡶ࡫ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡢ࡫ࡶࡩࡸࠦࡥࡹࡥࡨࡴࡹ࡯࡯࡯࠰ࡎࡩࡾࡋࡲࡳࡱࡵ࠾ࠥࡏࡦࠡࡶ࡫ࡩ࡚ࠥࡌࡗࠢࡸࡲࡰࡴ࡯ࡸࡰࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢ૏")
        return cls.l1ll11llll_opy_(bytestring, l111ll1111_opy_)[0]
    @staticmethod
    def l111l1l111_opy_(bytestring, l111ll1111_opy_):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡃࡳࡧࡤࡸࡪࠦ࠰ࠡࡱࡵࠤࡲࡵࡲࡦࠢࡗࡐ࡛ࡹࠠࡧࡴࡲࡱࠥࡧࠠࡣࡻࡷࡩࡸࡺࡲࡦࡣࡰ࠲ࠥࡏࡦࠡ࡯ࡸࡰࡹ࡯ࡰ࡭ࡧࠣࡘࡑ࡜ࡳࠡࡣࡵࡩࠥࡪࡥࡴࡥࡵ࡭ࡧ࡫ࡤࠡ࡫ࡱࠤࡹ࡮ࡥࠡࡤࡼࡸࡪࡹࡴࡳࡧࡤࡱ࠱ࠦࡴࡩࡧࡼࠤࡼ࡯࡬࡭ࠢࡥࡩࠥࡶࡡࡳࡵࡨࡨࠥࡹࡥࡳ࡫ࡤࡰࡱࡿ࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡦࡾࡺࡥࡴࠢࡥࡽࡹ࡫ࡳࡵࡴ࡬ࡲ࡬ࡀࠠࡕࡪࡨࠤࡻࡧ࡬ࡶࡧࠣࡸࡴࠦࡤࡦࡥࡲࡨࡪࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡ࡫ࡷࡩࡷࡧࡢ࡭ࡧ࡞ࡸࡾࡶࡥࡴ࡟ࠣࡩࡽࡶࡥࡤࡶࡨࡨࡤࡺࡹࡱࡧࡶ࠾ࠥࡇ࡮ࠡ࡫ࡷࡩࡷࡧࡢ࡭ࡧࠣࡧࡴࡴࡴࡢ࡫ࡱ࡭ࡳ࡭ࠠࡕࡎ࡙ࠤࡸࡻࡢࡤ࡮ࡤࡷࡸ࡫ࡳࠡࡶ࡫ࡥࡹࠦࡷࡦࠢࡨࡼࡵ࡫ࡣࡵࠢࡰ࡭࡬࡮ࡴࠡࡤࡨࠤ࡮ࡴࠠࡵࡪ࡬ࡷࠥࡨࡹࡵࡧࡶࡸࡷ࡯࡮ࡨࠢࠫࡥࡹࠦࡴࡩࡧࠣࡸࡴࡶࠠ࡭ࡧࡹࡩࡱ࠯࠮ࠡࡖ࡫࡭ࡸࠦࡩࡴࠢࡱࡩࡨ࡫ࡳࡴࡣࡵࡽࠥࡨࡥࡤࡣࡸࡷࡪࠦࡤࡪࡨࡩࡩࡷ࡫࡮ࡵࠢࡗࡐ࡛ࡹࠠࡢࡶࠣࡨ࡮࡬ࡦࡦࡴࡨࡲࡹࠦ࡬ࡦࡸࡨࡰࡸࠦ࡭ࡪࡩ࡫ࡸࠥ࡮ࡡࡷࡧࠣࡳࡻ࡫ࡲ࡭ࡣࡳࡴ࡮ࡴࡧࠡࡶࡼࡴࡪࡹ࠺ࠡࡨࡲࡶࠥ࡯࡮ࡴࡶࡤࡲࡨ࡫ࠬࠡࡶ࡫ࡩࠥࡳࡥࡴࡵࡤ࡫ࡪࠦࡴࡺࡲࡨࠤ࡙ࡒࡖࠡࡣࡱࡨࠥࡳࡥࡴࡵࡤ࡫ࡪࠦࡰࡢࡻ࡯ࡳࡦࡪࠠࡕࡎ࡙ࡷࠥࡧࡲࡦࠢࡥࡳࡹ࡮ࠠࡵࡻࡳࡩࠥ࠻࠮ࠡࡖ࡫࡭ࡸࠦ࡭ࡰࡦࡸࡰࡪࠦࡤࡦࡨ࡬ࡲࡪࡹࠠࡴࡱࡰࡩࠥࡧࡴࡵࡴ࡬ࡦࡺࡺࡥࡴࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦ࡮ࡢࡶࡸࡶࡦࡲࠠࡨࡴࡲࡹࡵ࡯࡮ࡨࡵࠣࡳ࡫ࠦࡴࡺࡲࡨࡷ࠱ࠦࡡ࡯ࡦࠣࡸ࡭ࡵࡳࡦࠢࡪࡶࡴࡻࡰࡪࡰࡪࡷࠥࡧࡲࡦࠢࡦࡳࡲࡳ࡯࡯ࠢࡹࡥࡷ࡯ࡡࡣ࡮ࡨࡷࠥ࡬࡯ࡳࠢࡷ࡬࡮ࡹࠠࡢࡴࡪࡹࡲ࡫࡮ࡵ࠰ࠣࡗࡪ࡫ࠠ࠻ࡲࡼ࠾ࡦࡺࡴࡳ࠼ࡣࡸࡱࡼ࠮ࡂࡎࡏࡣ࡙ࡒࡖࡔࡢ࠯ࠤ࠿ࡶࡹ࠻ࡣࡷࡸࡷࡀࡠࡵ࡮ࡹ࠲ࡒࡋࡓࡔࡃࡊࡉࡤ࡚ࡌࡗࡕࡣ࠰ࠥࡀࡰࡺ࠼ࡤࡸࡹࡸ࠺ࡡࡶ࡯ࡺ࠳ࡖࡁ࡚ࡎࡒࡅࡉࡥࡔࡍࡘࡖࡤࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡨࡸࡺࡸ࡮ࡴࠢ࡯࡭ࡸࡺ࡛ࡕࡎ࡙ࡡ࠿ࠦࡔࡩࡧࠣࡴࡦࡸࡳࡦࡦࠣࡘࡑ࡜ࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧૐ")
        return [it for it in TLV.iterator_from_bytes(bytestring, l111ll1111_opy_)]
    @staticmethod
    def l111ll1l11_opy_(bytestring, l111l1llll_opy_):
        l11ll_opy_ (u"ࠦࠧࠨࠠࡍ࡫࡮ࡩࠥࡀࡰࡺ࠼ࡰࡩࡹ࡮࠺ࡡ࡯ࡸࡰࡹ࡯ࡰ࡭ࡧࡢࡪࡷࡵ࡭ࡠࡤࡼࡸࡪࡹࡠࠡࡤࡸࡸࠥࡸࡥࡵࡷࡵࡲࡸࠦࡵ࡯ࡲࡤࡶࡸ࡫ࡤࠡࡦࡤࡸࡦࠦࡡࡴࠢࡺࡩࡱࡲࠠࡢࡵࠣࡸ࡭࡫ࠠࡱࡣࡵࡷࡪࡪࠠࡕࡎ࡙ࡷ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ૑")
        class l111lll11l_opy_(object):
            def __init__(self):
                self.remaining = six.b(l11ll_opy_ (u"ࠬ࠭૒"))
            def __call__(self, l111ll111l_opy_):
                self.remaining = l111ll111l_opy_
        l11ll11l_opy_ = l111lll11l_opy_()
        tlvs = []
        try:
            for tlv in TLV.iterator_from_bytes(bytestring, l111l1llll_opy_, l11ll11l_opy_):
                tlvs.append(tlv)
        except Exception:
            _MODULE_LOGGER.exception(l11ll_opy_ (u"ࠨࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡳࡥࡷࡹࡥࠡࡣ࡯ࡰ࡚ࠥࡌࡗࡕ࠯ࠤࢀࢃࠠࠩࡽࢀࡆ࠮ࠦࡲࡦ࡯ࡤ࡭ࡳ࡯࡮ࡨࠤ૓")
                                     .format(goTenna.util.display_bytestring(l11ll11l_opy_.remaining),
                                             len(l11ll11l_opy_.remaining)))
        return (tlvs, l11ll11l_opy_.remaining)
    @staticmethod
    def iterator_from_bytes(bytestring, l111ll1111_opy_, l111l1l11l_opy_=None):
        l11ll_opy_ (u"ࠢࠣࠤࠣࡐࡦࢀࡩ࡭ࡻࠣࡴࡦࡸࡳࡦࡵࠣࡘࡑ࡜ࡳࠡࡨࡵࡳࡲࠦࡡࠡࡤࡼࡸࡪࡹࡴࡳࡧࡤࡱ࠱ࠦࡲࡦࡶࡸࡶࡳ࡯࡮ࡨࠢࡤࡲࠥ࡯ࡴࡦࡴࡤࡸࡴࡸࠠࡵࡪࡤࡸࠥࡽࡩ࡭࡮ࠣࡽ࡮࡫࡬ࡥࠢࡳࡥࡷࡹࡥࡥࠢࡗࡐ࡛ࡹ࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡦࡾࡺࡥࡴࠢࡥࡽࡹ࡫ࡳࡵࡴ࡬ࡲ࡬ࡀࠠࡕࡪࡨࠤࡻࡧ࡬ࡶࡧࠣࡸࡴࠦࡤࡦࡥࡲࡨࡪࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡ࡫ࡷࡩࡷࡧࡢ࡭ࡧ࡞ࡸࡾࡶࡥࡴ࡟ࠣࡩࡽࡶࡥࡤࡶࡨࡨࡤࡺࡹࡱࡧࡶ࠾ࠥࡇ࡮ࠡ࡫ࡷࡩࡷࡧࡢ࡭ࡧࠣࡧࡴࡴࡴࡢ࡫ࡱ࡭ࡳ࡭ࠠࡕࡎ࡙ࠤࡸࡻࡢࡤ࡮ࡤࡷࡸ࡫ࡳࠡࡶ࡫ࡥࡹࠦࡷࡦࠢࡨࡼࡵ࡫ࡣࡵࠢࡰ࡭࡬࡮ࡴࠡࡤࡨࠤ࡮ࡴࠠࡵࡪ࡬ࡷࠥࡨࡹࡵࡧࡶࡸࡷ࡯࡮ࡨࠢࠫࡥࡹࠦࡴࡩࡧࠣࡸࡴࡶࠠ࡭ࡧࡹࡩࡱ࠯࠮ࠡࡖ࡫࡭ࡸࠦࡩࡴࠢࡱࡩࡨ࡫ࡳࡴࡣࡵࡽࠥࡨࡥࡤࡣࡸࡷࡪࠦࡤࡪࡨࡩࡩࡷ࡫࡮ࡵࠢࡗࡐ࡛ࡹࠠࡢࡶࠣࡨ࡮࡬ࡦࡦࡴࡨࡲࡹࠦ࡬ࡦࡸࡨࡰࡸࠦ࡭ࡪࡩ࡫ࡸࠥ࡮ࡡࡷࡧࠣࡳࡻ࡫ࡲ࡭ࡣࡳࡴ࡮ࡴࡧࠡࡶࡼࡴࡪࡹ࠺ࠡࡨࡲࡶࠥ࡯࡮ࡴࡶࡤࡲࡨ࡫ࠬࠡࡶ࡫ࡩࠥࡳࡥࡴࡵࡤ࡫ࡪࠦࡴࡺࡲࡨࠤ࡙ࡒࡖࠡࡣࡱࡨࠥࡳࡥࡴࡵࡤ࡫ࡪࠦࡰࡢࡻ࡯ࡳࡦࡪࠠࡕࡎ࡙ࡷࠥࡧࡲࡦࠢࡥࡳࡹ࡮ࠠࡵࡻࡳࡩࠥ࠻࠮ࠡࡖ࡫࡭ࡸࠦ࡭ࡰࡦࡸࡰࡪࠦࡤࡦࡨ࡬ࡲࡪࡹࠠࡴࡱࡰࡩࠥࡧࡴࡵࡴ࡬ࡦࡺࡺࡥࡴࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦ࡮ࡢࡶࡸࡶࡦࡲࠠࡨࡴࡲࡹࡵ࡯࡮ࡨࡵࠣࡳ࡫ࠦࡴࡺࡲࡨࡷ࠱ࠦࡡ࡯ࡦࠣࡸ࡭ࡵࡳࡦࠢࡪࡶࡴࡻࡰࡪࡰࡪࡷࠥࡧࡲࡦࠢࡦࡳࡲࡳ࡯࡯ࠢࡹࡥࡷ࡯ࡡࡣ࡮ࡨࡷࠥ࡬࡯ࡳࠢࡷ࡬࡮ࡹࠠࡢࡴࡪࡹࡲ࡫࡮ࡵ࠰ࠣࡗࡪ࡫ࠠ࠻ࡲࡼ࠾ࡦࡺࡴࡳ࠼ࡣࡑࡊ࡙ࡓࡂࡉࡈࡣ࡙ࡒࡖࡔࡢ࠯ࠤࡦࡴࡤࠡ࠼ࡳࡽ࠿ࡧࡴࡵࡴ࠽ࡤࡕࡇ࡙ࡍࡑࡄࡈࡤ࡚ࡌࡗࡕࡣࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡸࡥ࡮ࡣ࡬ࡲ࡮ࡴࡧࡠࡥࡥ࠾ࠥࡇࠠࡤࡣ࡯ࡰࡦࡨ࡬ࡦࠢࡲࡪࠥࡺࡨࡦࠢࡩࡳࡷࡳࠠࡡࡢࡵࡩࡲࡧࡩ࡯࡫ࡱ࡫ࡤࡩࡢࠩࡴࡨࡱࡦ࡯࡮ࡪࡰࡪ࠭ࡥࡦࠬࠡࠢࡺ࡬ࡪࡸࡥࠡࡴࡨࡱࡦ࡯࡮ࡪࡰࡪࠤ࡮ࡹࠠࡵࡪࡨࠤࡺࡴࡰࡢࡴࡶࡩࡩࠦࡢࡺࡶࡨࡷࠥࡧࡦࡵࡧࡵࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤ࡮ࡹࠠࡥࡱࡱࡩ࠱ࠦ࡯ࡳࠢࡣࡤࡓࡵ࡮ࡦࡢࡣ࠲ࠥࡏࡦࠡࡵࡳࡩࡨ࡯ࡦࡪࡧࡧ࠰ࠥࡦࡠࡳࡧࡰࡥ࡮ࡴࡩ࡯ࡩࡢࡧࡧࡦࡠࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡦࡥࡱࡲࡥࡥࠢࡶ࡬ࡴࡸࡴ࡭ࡻࠣࡦࡪ࡬࡯ࡳࡧࠣࡸ࡭࡫ࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡩ࡭ࡳ࡯ࡳࡩࡧࡶࠤࡼ࡯ࡴࡩࠢࡤࡲࡾࠦࡤࡢࡶࡤࠤࡹ࡮ࡡࡵࠢ࡫ࡥࡸࠦ࡮ࡰࡶࠣࡽࡪࡺࠠࡣࡧࡨࡲࠥࡶࡡࡳࡵࡨࡨ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡩࡹࡻࡲ࡯ࡵࠣ࡭ࡹ࡫ࡲࡢࡶࡲࡶࡠ࡚ࡌࡗ࡟࠽ࠤࡆࡴࠠࡪࡶࡨࡶࡦࡺ࡯ࡳࠢࡷ࡬ࡦࡺࠠࡺ࡫ࡨࡰࡩࡹࠠࡢࠢࡷࡹࡵࡲࡥࠡࡱࡩࠤ࠭ࡶࡡࡳࡵࡨࡨ࡚ࠥࡌࡗࡵ࠯ࠤࡷ࡫࡭ࡢ࡫ࡱࡨࡪࡸࠩ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨ૔")
        l1111ll1ll_opy_ = goTenna.util.l1111l1l_opy_(bytestring)
        while True:
            try:
                l111ll1ll1_opy_ = goTenna.util.l1l11l11_opy_(next(l1111ll1ll_opy_))
                l111lll1l1_opy_ = goTenna.util.l1l11l11_opy_(next(l1111ll1ll_opy_))
                l1111lllll_opy_ = goTenna.util.l1l1l1ll_opy_(itertools.islice(l1111ll1ll_opy_,
                                                                l111lll1l1_opy_))
            except StopIteration:
                break
            if len(l1111lllll_opy_) != l111lll1l1_opy_:
                remaining = goTenna.util.l1111l_opy_(l111ll1ll1_opy_)\
                            + goTenna.util.l1111l_opy_(l111lll1l1_opy_)\
                            + l1111lllll_opy_
                TLV.l111ll11ll_opy_().error(l11ll_opy_ (u"ࠣࡖࡏ࡚ࠥࢁࡽࠡࡲࡤࡶࡸ࡫ࡤࠡ࡮ࡨࡲ࡬ࡺࡨࠡࡤࡤࡨ࠱ࠦࡻࡾࠢࡺ࡭ࡹ࡮ࠠࡰࡰ࡯ࡽࠥࢁࡽࠡࡴࡨࡱࡦ࡯࡮ࡪࡰࡪࠦ૕")
                                       .format(l111ll1ll1_opy_,
                                               l111lll1l1_opy_, len(l1111lllll_opy_)))
                if l111l1l11l_opy_:
                    l111l1l11l_opy_(remaining)
                break
            try:
                yield TLV._111l11111_opy_(l111ll1ll1_opy_, l1111lllll_opy_,
                                           l111ll1111_opy_)
            except (IndexError, struct.error, KeyError):
                TLV.l111ll11ll_opy_().error(l11ll_opy_ (u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠣࡘࡑ࡜ࠠࡵࡻࡳࡩࠥࢁࡽ࠭ࠢࡱࡳࡹࠦࡩ࡯ࠢࡾࢁࠬ૖")
                                       .format(hex(l111ll1ll1_opy_),
                                               l111ll1111_opy_))
                remaining = goTenna.util.l1111l_opy_(l111ll1ll1_opy_)\
                            + goTenna.util.l1111l_opy_(l111lll1l1_opy_)\
                            + l1111lllll_opy_\
                            + goTenna.util.l1l1l1ll_opy_(l1111ll1ll_opy_)
                if l111l1l11l_opy_:
                    l111l1l11l_opy_(remaining)
                break
    def to_bytes(self):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡓࡦࡴ࡬ࡥࡱ࡯ࡺࡦࠢࡤࠤ࡙ࡒࡖࠡࡶࡲࠤࡦࠦࡢࡺࡶࡨࡷࡹࡸࡩ࡯ࡩࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡦࡶࡸࡶࡳࡹࠠࡣࡻࡷࡩࡸࡀࠠࡕࡪࡨࠤࡪࡴࡣࡰࡦࡨࡨ࡚ࠥࡌࡗࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨ૗")
        payload = self.serialize()
        return struct.pack(l11ll_opy_ (u"ࠫࠦࡈࡂࡼࡿࡶࠫ૘").format(len(payload)),
                           self.l111lll111_opy_, len(payload),
                           payload)
    @property
    def l111lll111_opy_(self):
        l11ll_opy_ (u"ࠧࠨࠢࠡࡒࡵࡳࡵ࡫ࡲࡵࡻࠣࡪࡴࡸࠠࡨࡧࡷࡸ࡮ࡴࡧࠡࡶ࡫ࡩ࡚ࠥࡌࡗࠢࡷࡽࡵ࡫࠮ࠡࡕ࡫ࡳࡺࡲࡤࠡࡤࡨࠤࡴࡼࡥࡳࡴ࡬ࡨࡩ࡫࡮ࠡࡤࡼࠤࡨ࡮ࡩ࡭ࡦࡵࡩࡳ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦ૙")
        raise NotImplementedError()
class l111l11lll_opy_(TLV):
    l11ll_opy_ (u"ࠨࠢࠣࠢࡄࠤ࡙ࡒࡖࠡࡤࡤࡷࡪࠦࡴࡩࡣࡷࠤ࡭ࡵ࡬ࡥࡵࠣࡳࡳࡲࡹࠡࡶࡨࡼࡹ࠴ࠊࠋࠢࠣࠤ࡚ࠥࡨࡪࡵࠣࡧࡦࡴࠠࡣࡧࠣ࡭ࡳ࡮ࡥࡳ࡫ࡷࡩࡩࠦࡴࡰࠢࡳࡶࡴࡼࡩࡥࡧࠣࡦࡦࡹࡩࡤࠢࡷࡩࡽࡺࠠࡤࡣࡳࡥࡧ࡯࡬ࡪࡶ࡬ࡩࡸ࠴ࠠࡊࡰࠣࡥࡩࡪࡩࡵ࡫ࡲࡲࠥࡺ࡯ࠡࡶ࡫ࡩࠥࡴ࡯ࡳ࡯ࡤࡰࠥࡸࡥࡲࡷ࡬ࡶࡪࡳࡥ࡯ࡶࡶࠤ࡫ࡵࡲࠡࡱࡹࡩࡷࡸࡩࡥ࡫ࡱ࡫ࠥࡀࡰࡺ࠼ࡦࡰࡦࡹࡳ࠻ࡢࡗࡐ࡛ࡦࠬࠡࡥ࡫࡭ࡱࡪࡲࡦࡰࠣࡷ࡭ࡵࡵ࡭ࡦࠣ࡬ࡦࡼࡥࠋࠢࠣࠤࠥ࠳ࠠࡂࠢࡦࡰࡦࡹࡳࠡࡣࡷࡸࡷ࡯ࡢࡶࡶࡨࠤࡥࡦࡍࡂ࡚ࡢࡐࡊࡔࡇࡕࡊࡣࡤࠥࡪࡥ࡯ࡱࡷ࡭ࡳ࡭ࠠࡵࡪࡨࠤࡲࡧࡸࠡ࡮ࡨࡲ࡬ࡺࡨࠡࡵࡷ࡬ࡪࡿࠠࡤࡣࡱࠤ࡭ࡵ࡬ࡥࠌࠣࠤࠥࠦ࠭ࠡࡃࠣࡴࡷࡵࡰࡦࡴࡷࡽࠥࡦࡠ࡮ࡣࡻࡣࡱ࡫࡮ࡨࡶ࡫ࡤࡥࠦࡲࡦࡶࡸࡶࡳ࡯࡮ࡨࠢࡷ࡬ࡦࡺࠠࡢࡶࡷࡶ࡮ࡨࡵࡵࡧࠍࠤࠥࠦࠠࠣࠤࠥ૚")
    def __repr__(self):
        return l11ll_opy_ (u"ࠧ࠽ࡽࢀ࠾ࠥࡺࡥࡹࡶࡀࡠࠬࢁࡽ࡝ࠩࡁࠫ૛").format(self.__class__.__name__,
                                          self.contents)
    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and other.contents == self.contents
    @property
    def l111lll111_opy_(self):
        l11ll_opy_ (u"ࠣࠤࠥࠤࡕࡸ࡯ࡱࡧࡵࡸࡾࠦࡦࡰࡴࠣ࡫ࡪࡺࡴࡪࡰࡪࠤࡹ࡮ࡥࠡࡖࡏ࡚ࠥࡺࡹࡱࡧ࠱ࠤࡘ࡮࡯ࡶ࡮ࡧࠤࡧ࡫ࠠࡰࡸࡨࡶࡷ࡯ࡤࡥࡧࡱࠤࡧࡿࠠࡤࡪ࡬ࡰࡩࡸࡥ࡯࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢ૜")
        raise NotImplementedError()
    @property
    def contents(self):
        l11ll_opy_ (u"ࠤ࡚ࠥࠦࠥࡨࡦࠢࡷࡩࡽࡺࠠࡤࡱࡱࡸࡪࡴࡴࡴࠢࡲࡪࠥࡺࡨࡦࠢࡗࡐ࡛࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰࡶࠤࡸࡺࡲ࠻ࠢࡗ࡬ࡪࠦࡣࡰࡰࡷࡩࡳࡺࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ૝")
        return self._contents
    def __init__(self, text):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡂࡶ࡫࡯ࡨࠥࡧࠠࡣࡣࡶ࡭ࡨࠦࡴࡦࡺࡷࠤ࡙ࡒࡖࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡸࡪࡾࡴ࠻ࠢࡗ࡬ࡪࠦࡴࡦࡺࡷࠤ࡫ࡵࡲࠡࡶ࡫ࡩࠥࡳࡥࡴࡵࡤ࡫ࡪ࠴ࠠࡘ࡫࡯ࡰࠥࡨࡥࠡࡧࡱࡧࡴࡪࡥࡥࠢࡤࡷ࡛ࠥࡔࡇ࠯࠻࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤ૞")
        if not isinstance(text, (str, goTenna.util.UnicodeType)):
            raise TypeError
        l111l111l1_opy_ = goTenna.util.s2b(text)
        if len(l111l111l1_opy_) > self.l111ll11l1_opy_:
            raise ValueError(l11ll_opy_ (u"ࠦࡊࡴࡣࡰࡦࡨࡨࠥࡓࡥࡴࡵࡤ࡫ࡪࠦࡴࡰࡱࠣࡰࡴࡴࡧࠢࠤ૟"))
        self._contents = text
    @property
    def l111ll11l1_opy_(self):
        l11ll_opy_ (u"ࠧࠨࠢࠡࡖ࡫ࡩࠥࡳࡡࡹ࡫ࡰࡹࡲࠦ࡬ࡦࡰࡪࡸ࡭ࠦ࡯ࡧࠢࡨࡲࡨࡵࡤࡦࡦࠣࡸࡪࡾࡴࠡࡶ࡫ࡩ࡚ࠥࡌࡗࠢࡦࡥࡳࠦࡣࡰࡰࡷࡥ࡮ࡴࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰࡶࠤ࡮ࡴࡴ࠻ࠢࡗ࡬ࡪࠦ࡬ࡦࡰࡪࡸ࡭࠲ࠠࡪࡰࠣࡦࡾࡺࡥࡴ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢૠ")
        raise NotImplementedError()
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        return cls(goTenna.util.b2s(l111l1ll1l_opy_))
    def serialize(self):
        return goTenna.util.s2b(self.contents)
class l111l1111l_opy_(TLV):
    l11ll_opy_ (u"ࠨࠢࠣࠢࡄࠤࡧࡧࡳࡪࡥࠣࡘࡑ࡜ࠠࡵࡪࡤࡸࠥࡩ࡯࡯ࡶࡤ࡭ࡳࡹࠠࡢࠢࡦࡳࡱࡵࡲࠡࡥࡲࡱࡵࡧࡴࡪࡤ࡯ࡩࠥࡽࡩࡵࡪࠣࡸ࡭࡫ࠠࡰࡶ࡫ࡩࡷࠦࡓࡅࡍࡶ࠲ࠏࠐࠠࠡࠢࠣࡘ࡭࡯ࡳࠡࡥ࡯ࡥࡸࡹࠠࡦࡰࡦࡳࡲࡶࡡࡴࡵࡨࡷࠥࡩ࡯࡯ࡵࡷࡶࡺࡩࡴࡪࡱࡱ࠰ࠥࡧࡣࡤࡧࡶࡷ࠱ࠦࡡ࡯ࡦࠣࡷࡪࡸ࠯ࡥࡧࡶࠤࡲ࡫ࡴࡩࡱࡧࡷࠥ࡬࡯ࡳࠢࡷ࡬ࡪࠦࡣࡰ࡮ࡲࡶࡸ࠲ࠠࡣࡷࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡺࡳࡦ࡮ࡩࠤࡦࠦࡔࡍࡘࠣࡻࡪࠦࡰࡢࡵࡶࠤࡦࡸ࡯ࡶࡰࡧ࠲ࠥࡏࡴࠡࡪࡤࡷࠥࡴ࡯ࠡࡶࡼࡴࡪࠦࡡ࡯ࡦࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡲࡴࡺࠠࡣࡧࠣ࡭ࡳࡹࡴࡢࡰࡷ࡭ࡦࡺࡥࡥࠢࡧ࡭ࡷ࡫ࡣࡵ࡮ࡼ࠲ࠥࡏ࡮ࡴࡶࡨࡥࡩ࠲ࠠࡪࡰࡶࡸࡦࡴࡴࡪࡣࡷࡩࠥࡺࡨࡦࠢࡳࡶࡴࡶࡥࡳࠢࡦ࡬࡮ࡲࡤࠡࡨࡲࡶࠥࡧࠠࡨ࡫ࡹࡩࡳࠦࡵࡴࡧ࠱ࠎࠥࠦࠠࠡࠤࠥࠦૡ")
    def __repr__(self):
        return l11ll_opy_ (u"ࠧ࠽ࡽࢀ࠾ࠥࡸ࠽ࡼࡿ࠯ࠤ࡬ࡃࡻࡾ࠮ࠣࡦࡂࢁࡽ࠭ࠢࡤࡁࢀࢃ࠾ࠨૢ")\
            .format(self.__class__.__name__,
                    self.l111l1ll11_opy_, self.l1111llll1_opy_, self.l111ll1lll_opy_, self.alpha)
    @property
    def l111lll111_opy_(self):
        raise NotImplementedError()
    @property
    def color(self):
        l11ll_opy_ (u"ࠣࠤࠥࠤ࡙࡮ࡥࠡࡥࡲࡰࡴࡸࠠࡢࡵࡶࡳࡨ࡯ࡡࡵࡧࡧࠤࡼ࡯ࡴࡩࠢࡷ࡬ࡪࠦࡔࡍࡘ࠯ࠤࡦࡹࠠࡢࠢ࠷࠱ࡧࡿࡴࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࡔࡩࡧࠣࡪ࡮ࡸࡳࡵࠢࡥࡽࡹ࡫ࠠࡪࡵࠣࡥࡱࡶࡨࡢࠌࠣࠤࠥࠦࠠࠡࠢࠣࡘ࡭࡫ࠠࡴࡧࡦࡳࡳࡪࠠࡣࡻࡷࡩࠥ࡯ࡳࠡࡴࡨࡨࠏࠦࠠࠡࠢࠣࠤࠥࠦࡔࡩࡧࠣࡸ࡭࡯ࡲࡥࠢࡥࡽࡹ࡫ࠠࡪࡵࠣ࡫ࡷ࡫ࡥ࡯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࡘ࡭࡫ࠠࡧࡱࡸࡶࡹ࡮ࠠࡣࡻࡷࡩࠥ࡯ࡳࠡࡤ࡯ࡹࡪࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡࡖ࡫ࡩࡸ࡫ࠠࡢࡴࡨࠤࡦࡩࡣࡦࡵࡶ࡭ࡧࡲࡥࠡ࡫ࡱࡨ࡮ࡼࡩࡥࡷࡤࡰࡱࡿࠠࡸ࡫ࡷ࡬ࠥࡺࡨࡦࠢ࠽ࡴࡾࡀࡡࡵࡶࡵ࠾ࡥࡧ࡬ࡱࡪࡤࡤ࠱ࠦ࠺ࡱࡻ࠽ࡥࡹࡺࡲ࠻ࡢࡵࡩࡩࡦࠬࠡ࠼ࡳࡽ࠿ࡧࡴࡵࡴ࠽ࡤ࡬ࡸࡥࡦࡰࡣ࠰ࠥࡧ࡮ࡥࠢ࠽ࡴࡾࡀࡡࡵࡶࡵ࠾ࡥࡨ࡬ࡶࡧࡣࠤࡵࡸ࡯ࡱࡧࡵࡸ࡮࡫ࡳࠡࡱࡩࠤࡹ࡮ࡩࡴࠢࡦࡰࡦࡹࡳ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨૣ")
        return self._color
    @property
    def alpha(self):
        l11ll_opy_ (u"ࠤ࡚ࠥࠦࠥࡨࡦࠢࡤࡰࡵ࡮ࡡࠡࡸࡤࡰࡺ࡫ࠠࡢࡵࡶࡳࡨ࡯ࡡࡵࡧࡧࠤࡼ࡯ࡴࡩࠢࡷ࡬ࡪࠦࡔࡍࡘࠣࠦࠧࠨ૤")
        return (self._color & 0xff000000) >> 24
    @property
    def l111l1ll11_opy_(self):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡔࡩࡧࠣࡶࡪࡪࠠࡷࡣ࡯ࡹࡪࠦࡡࡴࡵࡲࡧ࡮ࡧࡴࡦࡦࠣࡻ࡮ࡺࡨࠡࡶ࡫ࡩ࡚ࠥࡌࡗࠢࠥࠦࠧ૥")
        return (self._color & 0x00ff0000) >> 16
    @property
    def l1111llll1_opy_(self):
        l11ll_opy_ (u"ࠦࠧࠨࠠࡕࡪࡨࠤ࡬ࡸࡥࡦࡰࠣࡺࡦࡲࡵࡦࠢࡤࡷࡸࡵࡣࡪࡣࡷࡩࡩࠦࡷࡪࡶ࡫ࠤࡹ࡮ࡥࠡࡖࡏ࡚ࠥࠨࠢࠣ૦")
        return (self._color & 0x0000ff00) >> 8
    @property
    def l111ll1lll_opy_(self):
        l11ll_opy_ (u"ࠧࠨࠢࠡࡖ࡫ࡩࠥࡨ࡬ࡶࡧࠣࡺࡦࡲࡵࡦࠢࡤࡷࡸࡵࡣࡪࡣࡷࡩࡩࠦࡷࡪࡶ࡫ࠤࡹ࡮ࡥࠡࡖࡏ࡚ࠥࠨࠢࠣ૧")
        return self._color & 0x000000ff
    @property
    def color_tuple(self):
        l11ll_opy_ (u"ࠨࠢࠣࠢࡗ࡬ࡪࠦࡣࡰ࡮ࡲࡶࠥࡧࡳࠡࡣࠣࡸࡺࡶ࡬ࡦࠪࡵ࠰࡬࠲ࡢ࠭ࡣࠬࠦࠧࠨ૨")
        return (self.l111l1ll11_opy_, self.l1111llll1_opy_, self.l111ll1lll_opy_, self.alpha)
    def __init__(self, l111l1ll11_opy_=None, l1111llll1_opy_=None, l111ll1lll_opy_=None, alpha=None,
                 l111l11ll1_opy_=None, color_tuple=None):
        l11ll_opy_ (u"ࠢࠣࠤࠣࡆࡺ࡯࡬ࡥࠢࡤࠤࡇࡧࡳࡪࡥࡆࡳࡱࡵࡲࡕࡎ࡙࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࡕࡪࡨࡶࡪࠦࡡࡳࡧࠣࡥࠥࡩ࡯ࡶࡲ࡯ࡩࠥࡪࡩࡧࡨࡨࡶࡪࡴࡴࠡࡹࡤࡽࡸࠦࡴࡰࠢࡥࡹ࡮ࡲࡤࠡࡶ࡫࡭ࡸࠦࡔࡍࡘࠣࡦࡦࡹࡥࡥࠢࡲࡲࠥࡪࡩࡧࡨࡨࡶࡪࡴࡴࠡ࡫ࡱࡴࡺࡺࠠࡥࡣࡷࡥ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡࡖ࡫ࡩࠥ࡬ࡩࡳࡵࡷࠤࡼࡧࡹࠡ࡫ࡶࠤࡹࡵࠠࡴࡲࡨࡧ࡮࡬ࡹࠡࡵࡲࡱࡪࠦ࡯ࡳࠢࡤࡰࡱࠦ࡯ࡧࠢࡣࡤࡷ࡫ࡤࡡࡢ࠯ࠤࡥࡦࡧࡳࡧࡨࡲࡥࡦࠬࠡࡢࡣࡦࡱࡻࡥࡡࡢ࠯ࠤࡦࡴࡤࠡࡢࡣࡥࡱࡶࡨࡢࡢࡣ࠲ࠥࡏࡦࠡࡣࡱࡽࠥࡵࡦࠡࡶ࡫ࡩࡸ࡫ࠠࡢࡴࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠬࠡࡶ࡫ࡩࠥࡵࡴࡩࡧࡵࡷࠥࡧࡲࡦࠢࡤࡷࡸࡻ࡭ࡦࡦࠣࡸࡴࠦࡢࡦࠢ࠳࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࡕࡪࡨࠤࡸ࡫ࡣࡰࡰࡧࠤࡼࡧࡹࠡ࡫ࡶࠤࡹࡵࠠࡴࡲࡨࡧ࡮࡬ࡹࠡࡢࡣࡧࡴࡲ࡯ࡳࡡ࡬ࡲࡹࡦࡠࠡࡣࡶࠤࡦࡴࠠࡪࡰࡷࡩ࡬࡫ࡲࠡࡶ࡫ࡥࡹࠦࡷࡪ࡮࡯ࠤࡧ࡫ࠠࡪࡰࡷࡩࡷࡶࡲࡦࡶࡨࡨࠥࡧࡳࠡࡣࠣࡧࡴࡲ࡯ࡳࠢࡳࡥࡨࡱࡥࡥࠢ࡬ࡲࡹࡵࠠࠩࡣ࡯ࡴ࡭ࡧࠬࠡࡴࡨࡨ࠱ࠦࡧࡳࡧࡨࡲ࠱ࠦࡢ࡭ࡷࡨ࠭ࠥࡽࡩࡵࡪࠣࡥࠥࡨࡹࡵࡧࠣࡪࡴࡸࠠࡦࡣࡦ࡬ࠥ࠮ࡴࡩ࡫ࡶࠤ࡮ࡹࠠࡶࡵࡨࡨࠥࡶࡲࡪ࡯ࡤࡶ࡮ࡲࡹࠡࡨࡲࡶࠥࡪࡥࡴࡧࡵ࡭ࡦࡲࡩࡻࡣࡷ࡭ࡴࡴࠩ࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࡙࡮ࡥࠡࡶ࡫࡭ࡷࡪࠠࡸࡣࡼࠤ࡮ࡹࠠࡵࡱࠣࡷࡵ࡫ࡣࡪࡨࡼࠤࡥࡦࡣࡰ࡮ࡲࡶࡤࡺࡵࡱ࡮ࡨࡤࡥࠦࡡࡴࠢࡤࠤࡹࡻࡰ࡭ࡧࠣࡳ࡫ࠦࠨࡳࡧࡧ࠰ࠥ࡭ࡲࡦࡧࡱ࠰ࠥࡨ࡬ࡶࡧ࠯ࠤࡦࡲࡰࡩࡣࠬ࠲ࠥࡏࡦࠡࡶ࡫࡭ࡸࠦࡩࡴࠢࡸࡷࡪࡪࠬࠡ࡫ࡷࠤࡲࡻࡳࡵࠢࡥࡩࠥ࠺ࠠࡦ࡮ࡨࡱࡪࡴࡴࡴࠢ࡯ࡳࡳ࡭ࠠࡢࡰࡧࠤࡦࡲ࡬ࠡࡧ࡯ࡩࡲ࡫࡮ࡵࡵࠣࡱࡺࡹࡴࠡࡤࡨࠤࡳࡻ࡭ࡦࡴ࡬ࡧ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡࡋࡩࠤࡦࡴࡹࠡࡵࡳࡩࡨ࡯ࡦࡪࡧࡧࠤࡪࡲࡥ࡮ࡧࡱࡸࠥ࡯ࡳࠡࡣࠣࡪࡱࡵࡡࡵࠢ࡬ࡸࠥࡽࡩ࡭࡮ࠣࡦࡪࠦࡩ࡯ࡶࡨࡶࡵࡸࡥࡵࡧࡧࠤࡦࡹࠠࡪࡨࠣࡪࡺࡲ࡬ࠡ࡫ࡱࡸࡪࡴࡳࡪࡶࡼࠤ࡮ࡹࠠ࠲ࠢࡤࡲࡩࠦ࡮ࡰࠢ࡬ࡲࡹ࡫࡮ࡴ࡫ࡷࡽࠥ࡯ࡳࠡ࠲࠱ࠤࡎ࡬ࠠࡢࡰࡼࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡦ࡮ࡨࡱࡪࡴࡴࠡ࡫ࡶࠤࡦࡴࠠࡪࡰࡷࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡨࡥࠡ࡫ࡱࡸࡪࡸࡰࡳࡧࡷࡩࡩࠦࡡࡴࠢ࡬ࡪࠥ࡬ࡵ࡭࡮ࠣ࡭ࡳࡺࡥ࡯ࡵ࡬ࡸࡾࠦࡩࡴࠢ࠵࠹࠺ࠦࡡ࡯ࡦࠣࡲࡴࠦࡩ࡯ࡶࡨࡲࡸ࡯ࡴࡺࠢ࡬ࡷࠥ࠶࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣࡍ࡫ࠦ࡭ࡰࡴࡨࠤࡹ࡮ࡡ࡯ࠢࡲࡲࡪࠦࡳࡦࡶࠣࡳ࡫ࠦࡡࡳࡩࡸࡱࡪࡴࡴࡴࠢ࡬ࡷࠥࡹࡰࡦࡥ࡬ࡪ࡮࡫ࡤ࠭ࠢ࡬ࡸࠥ࡯ࡳࠡࡰࡲࡸࠥࡹࡰࡦࡥ࡬ࡪ࡮࡫ࡤࠡࡹ࡫࡭ࡨ࡮ࠠࡰࡰࡨࠤࡼ࡯࡬࡭ࠢࡥࡩࠥࡶࡡࡳࡵࡨࡨ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥࡴ࡙ࠢࡥࡱࡻࡥࡆࡴࡵࡳࡷࡀࠠࡊࡨࠣࡲࡴࡴࡥࠡࡱࡩࠤࡹ࡮ࡥࠡࡣࡥࡳࡻ࡫ࠠࡴࡧࡷࡷࠥࡵࡦࠡࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠤ࡮ࡹࠠࡴࡲࡨࡧ࡮࡬ࡩࡦࡦ࠯ࠤ࡮࡬ࠠࡢࡰࠣ࡭ࡳࡺࡥࡨࡴࡤࡰࠥࡧࡲࡨࡷࡰࡩࡳࡺࠠࠩࡱࡷ࡬ࡪࡸࠠࡵࡪࡤࡲࠥࡦࡠࡤࡱ࡯ࡳࡷࡥࡩ࡯ࡶࡣࡤ࠮ࠦࡩࡴࠢࡲࡹࡹࡹࡩࡥࡧࠣ࡟࠵࠲ࠠ࠳࠷࠸ࡡࠥࡵࡲࠡࡣࠣࡪࡱࡵࡡࡵࠢࡤࡶ࡬ࡻ࡭ࡦࡰࡷࠤ࡮ࡹࠠࡰࡷࡷࡷ࡮ࡪࡥࠡ࡝࠳࠲࠵࠲ࠠ࠲࠰࠳ࡡࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡳࡣ࡬ࡷࡪࡹࠠࡕࡻࡳࡩࡊࡸࡲࡰࡴ࠽ࠤࡎ࡬ࠠࡰࡰࡨࠤࡴ࡬ࠠࡵࡪࡨࠤࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࠡࡶࡼࡴࡪࡹࠠࡪࡵࠣࡦࡦࡪࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦ૩")
        if not any([arg is not None
                    for arg
                    in [l111l1ll11_opy_, l1111llll1_opy_, l111ll1lll_opy_, alpha, l111l11ll1_opy_, color_tuple]]):
            raise ValueError(l11ll_opy_ (u"ࠣࡕࡲࡱࡪࠦࡡࡳࡩࡸࡱࡪࡴࡴࡴࠢࡰࡹࡸࡺࠠࡣࡧࠣࡷࡵ࡫ࡣࡪࡨ࡬ࡩࡩࠨ૪"))
        def _111l1l1ll_opy_(pieces):
            color = 0
            for index, arg in enumerate(reversed(pieces)):
                if arg is None:
                    arg = 0
                if isinstance(arg, int):
                    if arg < 0 or arg > 255:
                        raise ValueError(l11ll_opy_ (u"ࠩ࡬ࡲࡩ࡯ࡶࡪࡦࡸࡥࡱࠦࡣࡩࡣࡱࡲࡪࡲࡳࠡࡵࡳࡩࡨ࡯ࡦࡪࡧࡧࠤࡼ࡯ࡴࡩࠢ࡬ࡲࡹࡹࠠ࡮ࡷࡶࡸࠥࡨࡥࠡ࡫ࡱࠤࡠ࠶ࠬࠡ࠴࠸࠹ࡢ࠲ࠠ࡯ࡱࡷࠤࢀࢃࠧ૫")
                                         .format(arg))
                    color += arg << (index*8)
                elif isinstance(arg, float):
                    if arg < 0 or arg > 1.0:
                        raise ValueError(l11ll_opy_ (u"ࠪ࡭ࡳࡪࡩࡷ࡫ࡧࡹࡦࡲࠠࡤࡪࡤࡲࡳ࡫࡬ࡴࠢࡶࡴࡪࡩࡩࡧ࡫ࡨࡨࠥࡽࡩࡵࡪࠣࡪࡱࡵࡡࡵࡵࠣࡱࡺࡹࡴࠡࡤࡨࠤ࡮ࡴࠠ࡜࠲࠱࠴࠱ࠦ࠱࠯࠲ࡠ࠰ࠥࡴ࡯ࡵࠢࡾࢁࠬ૬")
                                         .format(arg))
                    color += int(arg*255) << (index*8)
                else:
                    raise TypeError(l11ll_opy_ (u"ࠫ࡮ࡴࡤࡪࡸ࡬ࡨࡺࡧ࡬ࠡࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠣࡱࡺࡹࡴࠡࡤࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡸ࡫ࡷ࡬ࠥ࡫ࡩࡵࡪࡨࡶࠥ࡯࡮ࡵࡵࠣ࡭ࡳ࡛ࠦ࠱࠮ࠣ࠶࠺࠻࡝ࠡࡱࡵࠤ࡫ࡲ࡯ࡢࡶࡶࠤ࡮ࡴࠠ࡜࠲࠱࠴࠱ࠦ࠱࠯࠲ࡠࠤࡳࡵࡴࠡࡽࢀࠫ૭")
                                    .format(type(arg)))
            return color
        if any([arg is not None for arg in [l111l1ll11_opy_, l1111llll1_opy_, l111ll1lll_opy_, alpha]]):
            self._color = _111l1l1ll_opy_((alpha, l111l1ll11_opy_, l1111llll1_opy_, l111ll1lll_opy_))
        elif l111l11ll1_opy_ is not None:
            if not isinstance(l111l11ll1_opy_, int):
                raise TypeError(l11ll_opy_ (u"ࠬ࡯ࡦࠡࡥࡲࡰࡴࡸ࡟ࡪࡰࡷࠤ࡮ࡹࠠࡴࡲࡨࡧ࡮࡬ࡩࡦࡦࠣ࡭ࡹࠦ࡭ࡶࡵࡷࠤࡧ࡫ࠠࡪࡰࡷࡩ࡬ࡸࡡ࡭࠮ࠣ࡭ࡸࠦࡻࡾࠩ૮").format(type(l111l11ll1_opy_)))
            if l111l11ll1_opy_ < 0 or l111l11ll1_opy_ > (2**32-1):
                raise ValueError(l11ll_opy_ (u"࠭ࡣࡰ࡮ࡲࡶࡤ࡯࡮ࡵࠢࡰࡹࡸࡺࠠࡣࡧࠣࡥࠥࡶ࡯ࡴ࡫ࡷ࡭ࡻ࡫ࠠ࠴࠴࠰ࡦ࡮ࡺࠠࡪࡰࡷࠫ૯"))
            self._color = l111l11ll1_opy_
        elif color_tuple is not None:
            if not isinstance(color_tuple, tuple):
                raise TypeError(l11ll_opy_ (u"ࠧࡪࡨࠣࡷࡵ࡫ࡣࡪࡨ࡬ࡩࡩ࠲ࠠࡤࡱ࡯ࡳࡷࡥࡴࡶࡲ࡯ࡩࠥࡳࡵࡴࡶࠣࡦࡪࠦࡡࠡࡶࡸࡴࡱ࡫ࠠࡣࡷࡷࠤ࡮ࡹࠠࡼࡿࠪ૰")
                                .format(type(color_tuple)))
            if len(color_tuple) != 4:
                raise ValueError
            self._color = _111l1l1ll_opy_((color_tuple[3], color_tuple[0],
                                              color_tuple[1], color_tuple[2]))
        else:
            raise ValueError
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        return cls(l111l11ll1_opy_=struct.unpack(l11ll_opy_ (u"ࠨࠣࡌࠫ૱"), l111l1ll1l_opy_)[0])
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠩࠤࡍࠬ૲"), self._color)
    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.color == other.color
class l111llll11_opy_(TLV):
    l11ll_opy_ (u"ࠥࠦࠧࠦࡁࠡࡖࡏ࡚ࠥࡺࡨࡢࡶࠣࡨࡴ࡫ࡳࠡࡰࡲࡸ࡭࡯࡮ࡨࠢࡥࡹࡹࠦࡥ࡯ࡥࡤࡴࡸࡻ࡬ࡢࡶࡨࠤࡴࡺࡨࡦࡴࠣࡘࡑ࡜ࡳࠋࠌࠣࠤࠥࠦࡔࡩ࡫ࡶࠤ࡮ࡹࠠࡶࡵࡨࡨࠥࡧࡳࠡࡣࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡦࡰࡴࠣࡘࡑ࡜ࡳ࠯ࠢࡌࡱࡵࡲࡥ࡮ࡧࡱࡸࡪࡸࡳࠡࡱࡩࠤ࡙ࡒࡖࡴࠢࡷ࡬ࡦࡺࠠࡤࡱࡱࡸࡦ࡯࡮ࠡࡱࡷ࡬ࡪࡸࠠࡕࡎ࡙ࡷࠥࡩࡡ࡯ࠢ࡬ࡲ࡭࡫ࡲࡪࡶࠣࡪࡷࡵ࡭ࠡࡶ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷ࠱ࠦࡡࡴࠢ࡯ࡳࡳ࡭ࠠࡢࡵࠣࡸ࡭࡫ࡹࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࠤ࠭࡯࡮ࠡࡣࡧࡨ࡮ࡺࡩࡰࡰࠣࡸࡴࠦࡴࡩࡧࠣࡘࡑ࡜ࠠࡵࡻࡳࡩࠥࡸࡥࡲࡷ࡬ࡶࡪࡳࡥ࡯ࡶࡶ࠭࠿ࠐࠊࠡࠢࠣࠤ࠲ࠦࡁࠡࡥ࡯ࡥࡸࡹࠠࡢࡶࡷࡶ࡮ࡨࡵࡵࡧࠣࡅࡈࡉࡅࡑࡖࡄࡆࡑࡋ࡟ࡄࡑࡑࡘࡊࡔࡔࡔࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡡࠡࡶࡸࡴࡱ࡫ࠠࡰࡨࠣࡸ࡭࡫ࠠࡕࡎ࡙ࠤࡨࡲࡡࡴࡵࡨࡷࠥ࡫ࡸࡱࡧࡦࡸࡪࡪࠠࡵࡱࠣࡦࡪࠦࡰࡳࡧࡶࡩࡳࡺࠠࡪࡰࠣࡸ࡭࡫ࠠࡤࡱࡱࡸࡪࡴࡴࡴࠌࠣࠤࠥࠦ࠭ࠡࡃࠣࡴࡷࡵࡰࡦࡴࡷࡽࠥࡦࡠࡢࡥࡦࡩࡵࡺࡡࡣ࡮ࡨࡣࡨࡵ࡮ࡵࡧࡱࡸࡸࡦࡠࠡࡴࡨࡸࡺࡸ࡮ࡪࡰࡪࠤࡹ࡮ࡡࡵࠢࡤࡸࡹࡸࡩࡣࡷࡷࡩࠏࠐࠠࠡࠢࠣࡘ࡭࡯ࡳࠡ࡫ࡶࠤࡦࠦࡨࡦ࡮ࡳࡩࡷࠦࡣ࡭ࡣࡶࡷࠥࡧ࡮ࡥࠢࡶ࡬ࡴࡻ࡬ࡥࠢࡱࡳࡹࠦࡢࡦࠢ࡬ࡲࡸࡺࡡ࡯ࡶ࡬ࡥࡹ࡫ࡤࠡࡦ࡬ࡶࡪࡩࡴ࡭ࡻ࠱ࠎࠥࠦࠠࠡࠤࠥࠦ૳")
    def __repr__(self):
        return l11ll_opy_ (u"ࠫࡁࢁࡽ࠻ࠢࡦࡳࡳࡺࡥ࡯ࡶࡶࡁࢀࢃ࠾ࠨ૴").format(self.__class__.__name__,
                                          self.contents)
    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and other.contents == self.contents
    @property
    def contents(self):
        l11ll_opy_ (u"ࠧࠨࠢࠡࡔࡨࡸࡺࡸ࡮ࠡࡶ࡫ࡩ࡚ࠥࡌࡗࡵࠣ࡭ࡳࠦࡴࡩࡧࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡩࡹࡻࡲ࡯ࡵࠣࡰ࡮ࡹࡴ࡜ࡖࡏ࡚ࡢࡀࠠࡕࡪࡨࠤࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡪࠠࡕࡎ࡙ࡷࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤ૵")
        return self._contents
    @property
    def l111l1l1l1_opy_(self):
        l11ll_opy_ (u"ࠨࠢࠣࠢࡕࡩࡹࡻࡲ࡯ࠢࡤࡲࠥ࡯ࡴࡦࡴࡤࡦࡱ࡫ࠠࡤࡱࡱࡸࡦ࡯࡮ࡪࡰࡪࠤࡹ࡮ࡥࠡࡶࡼࡴࡪࡹࠠࡵࡪ࡬ࡷࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠡ࡯ࡤࡽࠥࡹࡴࡰࡴࡨ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࡕࡪ࡬ࡷࠥ࡯ࡳࠡࡷࡶࡩࡩࠦࡢࡺࠢࡷ࡬ࡪࠦࡤࡦࡵࡨࡶ࡮ࡧ࡬ࡪࡼࡤࡸ࡮ࡵ࡮ࠡ࡯ࡤࡧ࡭࡯࡮ࡦࡴࡼࠤࡹࡵࠠࡥࡧࡷࡩࡷࡳࡩ࡯ࡧࠣ࡭࡫ࠦࡡࠡࡵࡸࡦࡨࡲࡡࡴࡵࠣ࡭ࡸࠦࡡࠡࡸࡤࡰ࡮ࡪࠠࡤࡣࡱࡨ࡮ࡪࡡࡵࡧࠣࡪࡴࡸࠠࡥࡧࡶࡩࡷ࡯ࡡ࡭࡫ࡽࡥࡹ࡯࡯࡯࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡦࡶࡸࡶࡳࡹࠠࡪࡶࡨࡶࡦࡨ࡬ࡦ࡝ࡷࡽࡵ࡫࡝࠻ࠢࡗ࡬ࡪࠦࡴࡺࡲࡨࡷࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤ૶")
        raise NotImplementedError()
    def __init__(self, tlvs):
        l11ll_opy_ (u"ࠢࠣࠤࠣࡆࡺ࡯࡬ࡥࠢࡤࠤࡕ࡫ࡲࡪ࡯ࡨࡸࡪࡸࡄࡢࡶࡤࡘࡑ࡜࠮ࠋࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡹࡲࡶࡴ࠼ࠣࡅࡳࠦࡩࡵࡧࡵࡥࡧࡲࡥࠡࡱࡩࠤ࡮ࡴࡳࡵࡣࡱࡧࡪࡹࠠࡰࡨࠣࡧࡱࡧࡳࡴࡧࡶࠤ࡮ࡴࠠ࠻ࡲࡼ࠾ࡦࡺࡴࡳ࠼ࡣࡅࡈࡉࡅࡑࡖࡄࡆࡑࡋ࡟ࡄࡑࡑࡘࡊࡔࡔࡔࡢ࠱ࠤ࡙࡮ࡥࡳࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡦࡪࠦࡡࡵࠢࡰࡳࡸࡺࠠࡰࡰࡨࠤࡴ࡬ࠠࡦࡣࡦ࡬࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ૷")
        l111ll1l1l_opy_ = set()
        for item in tlvs:
            if not isinstance(item, self.l111l1l1l1_opy_):
                raise TypeError(item)
            if isinstance(item, tuple(l111ll1l1l_opy_)):
                raise ValueError
            l111ll1l1l_opy_.add(type(item))
        self._contents = tuple(tlvs)
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        return cls(TLV.l111l1l111_opy_(l111l1ll1l_opy_, cls.l111l11l1l_opy_))
    def serialize(self):
        return six.b(l11ll_opy_ (u"ࠨࠩ૸")).join([t.to_bytes() for t in self._contents])
class l111l111ll_opy_(TLV):
    l11ll_opy_ (u"ࠤࠥࠦࠥࡇࠠࡕࡎ࡙ࠤ࡫ࡵࡲࠡࡪࡲࡰࡩ࡯࡮ࡨࠢࡤࠤࡃ࠸࠵࠶࠯ࡥࡽࡹ࡫ࠠࡕࡎ࡙ࠎࠥࠦࠠࠡࠤࠥࠦૹ")
    l1l11ll1ll_opy_ = 253
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
class l111l1lll1_opy_(TLV):
    l11ll_opy_ (u"ࠥࠦࠧࠦࡁࠡࡖࡏ࡚ࠥ࡬࡯ࡳࠢ࡫ࡳࡱࡪࡩ࡯ࡩࠣࡥࠥࡄ࠶࠶࠷࠶࠹࠲ࡨࡹࡵࡧࠣࡘࡑ࡜ࠊࠡࠢࠣࠤࠧࠨࠢૺ")
    l1l11ll1ll_opy_ = 254
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
class l111l11l11_opy_(TLV):
    l11ll_opy_ (u"ࠦࠧࠨࠠࡂࠢࡗࡐ࡛ࠦࡦࡰࡴࠣ࡬ࡴࡲࡤࡪࡰࡪࠤࡦࠦ࠾࠳ࠬ࠭࠶࠹࠳ࡢࡺࡶࡨࠤ࡙ࡒࡖࠋࠢࠣࠤࠥࠨࠢࠣૻ")
    l1l11ll1ll_opy_ = 255
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_