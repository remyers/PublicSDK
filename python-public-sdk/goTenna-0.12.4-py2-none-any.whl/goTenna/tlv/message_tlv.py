# coding: utf8
from __future__ import print_function
import sys
l1111_opy_ = sys.version_info [0] == 2
l1lll1_opy_ = 2048
l1ll1_opy_ = 7
def l11ll_opy_ (l1_opy_):
    global l1llll_opy_
    l11l1l_opy_ = ord (l1_opy_ [-1])
    l111l_opy_ = l1_opy_ [:-1]
    l1ll_opy_ = l11l1l_opy_ % len (l111l_opy_)
    l1l1_opy_ = l111l_opy_ [:l1ll_opy_] + l111l_opy_ [l1ll_opy_:]
    if l1111_opy_:
        l1ll1l_opy_ = unicode () .join ([unichr (ord (char) - l1lll1_opy_ - (l1l11_opy_ + l11l1l_opy_) % l1ll1_opy_) for l1l11_opy_, char in enumerate (l1l1_opy_)])
    else:
        l1ll1l_opy_ = str () .join ([chr (ord (char) - l1lll1_opy_ - (l1l11_opy_ + l11l1l_opy_) % l1ll1_opy_) for l1l11_opy_, char in enumerate (l1l1_opy_)])
    return eval (l1ll1l_opy_)
# Copyright (C) 2018 goTenna, Inc. This file is distributed as part of the
# goTenna USB SDK. See the associated license for more information.
# pylint: disable=line-too-long
l11ll_opy_ (u"ࠦࠧࠨࠠࡎࡱࡧࡹࡱ࡫ࠠࡤࡱࡱࡸࡦ࡯࡮ࡪࡰࡪࠤ࡙ࡒࡖࡴࠢࡵࡩࡱ࡫ࡶࡢࡰࡷࠤࡹࡵࠠࡵࡪࡨࠤࡹࡵࡰࠡ࡮ࡨࡺࡪࡲࠠࡰࡨࠣࡱࡪࡹࡳࡢࡩࡨࡷ࠳ࠐࠊࡕࡪࡨࠤ࡙ࡒࡖࡴࠢࡦࡳࡳࡺࡡࡪࡰࡨࡨࠥ࡮ࡥࡳࡧࠣࡥࡷ࡫ࠠࡪࡰࡷࡩࡷࡴࡡ࡭ࠢࡤࡲࡩࠦࡩ࡯ࡶࡨࡲࡩ࡫ࡤࠡࡨࡲࡶࠥࡶࡡࡳࡵ࡬ࡲ࡬ࠦࡴࡩࡧࠣ࡬ࡪࡧࡤࡦࡴࠣࡨࡦࡺࡡࠡࡴࡨࡵࡺ࡯ࡲࡦࡦࠣࡦࡾࠦࡡ࡯ࡦࠣࡩࡲ࡯ࡴࡵࡧࡧࠤࡧࡿࠠࡵࡪࡨࠤ࡫࡯ࡲ࡮ࡹࡤࡶࡪࠦࡷࡩࡧࡱࠤࡵࡧࡳࡴ࡫ࡱ࡫ࠥࡳࡥࡴࡵࡤ࡫ࡪࡹ࠮ࠡࡖ࡫ࡩࡾࠦࡡࡳࡧࠣࡲࡴࡺࠠࡪࡰࡷࡩࡳࡪࡥࡥࠢࡩࡳࡷࠦࡥࡹࡶࡨࡶࡳࡧ࡬ࠡࡷࡶࡩ࠳ࠐࠢࠣࠤண")
# pylint: enable=line-too-long
import struct
import logging
import binascii
import six
import goTenna.settings
from goTenna.tlv import basic_tlv
from goTenna.tlv import payload_tlv
_MODULE_LOGGER = logging.getLogger(__name__)
class MessageAckTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠧࠨࠢࠡࡖ࡫ࡩ࡚ࠥࡌࡗࠢࡶࡩࡳࡺࠠࡣࡻࠣࡸ࡭࡫ࠠࡧ࡫ࡵࡱࡼࡧࡲࡦࠢࡺ࡬ࡪࡴࠠࡢࡥ࡮ࡲࡴࡽ࡬ࡦࡦࡪ࡭ࡳ࡭ࠠࡢࠢࡳࡶ࡮ࡼࡡࡵࡧࠣࡳࡷࠦࡧࡳࡱࡸࡴࠥࡳࡥࡴࡵࡤ࡫ࡪ࠴ࠊࠡࠢࠣࠤࠧࠨࠢத")
    l1l11ll1ll_opy_ = 0x21
    def __repr__(self):
        return l11ll_opy_ (u"࠭࠼ࡎࡧࡶࡷࡦ࡭ࡥࡂࡥ࡮ࡘࡑ࡜࠺ࠡࡶࡷࡰࡂࢁࡽࠡࡪࡤࡷ࡭ࡃࡻࡾࡀࠪ஥").format(self.ttl, self.hash_id)
    def __eq__(self, other):
        return isinstance(other, MessageAckTLV)\
            and self.ttl == other.ttl\
            and self.hash_id == other.hash_id
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, ttl, hash_id):
        l11ll_opy_ (u"ࠢࠣࠤࠣࡆࡺ࡯࡬ࡥࠢࡷ࡬ࡪࠦࡔࡍࡘࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥ࡯࡮ࡵࠢࡷࡸࡱࡀࠠࡕࡪࡨࠤࡷ࡫࡭ࡢ࡫ࡱ࡭ࡳ࡭ࠠࡵ࡫ࡰࡩࠥࡺ࡯ࠡ࡮࡬ࡺࡪࠦࡦࡰࡴࠣࡸ࡭࡫ࠠࡱࡣࡦ࡯ࡪࡺ࠮ࠡࡅࡤࡲࠥࡻࡳࡶࡣ࡯ࡰࡾࠦࡢࡦࠢ࡬࡫ࡳࡵࡲࡦࡦ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥ࡯࡮ࡵࠢ࡫ࡥࡸ࡮࡟ࡪࡦ࠽ࠤ࡙࡮ࡥࠡࡪࡤࡷ࡭ࠦ࡯ࡧࠢࡷ࡬ࡪࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡵࡪ࡬ࡷࠥࡧࡣ࡬ࠢ࡬ࡷࠥ࡬࡯ࡳ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢ஦")
        self.ttl = ttl
        self.hash_id = hash_id
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        (ttl, hash_id) = struct.unpack(l11ll_opy_ (u"ࠨࠣࡅࡌࠬ஧"), l111l1ll1l_opy_)
        return cls(ttl, hash_id)
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠩࠤࡆࡍ࠭ந"), self.ttl, self.hash_id)
class HopCountMaxTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠥࠦࠧࠦࡔࡩࡧࠣࡘࡑ࡜ࠠࡴࡲࡨࡧ࡮࡬ࡹࡪࡰࡪࠤࡹ࡮ࡥࠡ࡯ࡤࡼࠥࡴࡵ࡮ࡤࡨࡶࠥࡵࡦࠡࡶ࡬ࡱࡪࠦࡡࠡ࡯ࡨࡷࡸࡧࡧࡦࠢࡶ࡬ࡴࡻ࡬ࡥࠢ࡫ࡳࡵࠐࠠࠡࠢࠣࠦࠧࠨன")
    l1l11ll1ll_opy_ = 0x22
    def __repr__(self):
        return l11ll_opy_ (u"ࠫࡁࡎ࡯ࡱࡅࡲࡹࡳࡺࡍࡢࡺࡗࡐ࡛ࡀࠠࡤࡱࡸࡲࡹࡃࡻࡾࡀࠪப").format(self.count)
    def __eq__(self, other):
        return isinstance(other, HopCountMaxTLV) and self.count == other.count
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, count):
        l11ll_opy_ (u"ࠧࠨࠢࠡࡄࡸ࡭ࡱࡪࠠࡵࡪࡨࠤ࡙ࡒࡖࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣ࡭ࡳࡺࠠࡤࡱࡸࡲࡹࡀࠠࡕࡪࡨࠤࡳࡻ࡭ࡣࡧࡵࠤࡴ࡬ࠠࡩࡱࡳࡷࠥ࠮ࡡ࡭ࡵࡲࠤࡰࡴ࡯ࡸࡰࠣࡥࡸࠦࡴࡩࡧࠣࡘ࡙ࡒࠩࠡࡨࡲࡶࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨ࠲ࠥࡓࡡࡹ࡫ࡰࡹࡲࠦ࡯ࡧࠢ࠽ࡴࡾࡀ࡯ࡣ࡬࠽࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡨࡵ࡮ࡴࡶࡤࡲࡹࡹ࠮ࡎࡃ࡛ࡣࡍࡕࡐࡔࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱࠤࡍࡵࡰࡄࡱࡸࡲࡹࡓࡡࡹࡖࡏ࡚࠿ࠦࡔࡩࡧࠣࡧࡴࡴࡳࡵࡴࡸࡧࡹ࡫ࡤࠡࡱࡥ࡮ࡪࡩࡴࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ஫")
        self.count = count
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        (count, ) = struct.unpack(l11ll_opy_ (u"࠭ࠡࡃࠩ஬"), l111l1ll1l_opy_)
        return cls(count)
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠧࠢࡄࠪ஭"), self.count)
class MessageHeaderTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠣࠤࠥࠤ࡙࡮ࡥࠡࡖࡏ࡚ࠥ࡬࡯ࡳࠢࡷ࡬ࡪࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡩࡧࡤࡨࡪࡸࠊࠡࠢࠣࠤࠧࠨࠢம")
    l1l11ll1ll_opy_ = 6
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __repr__(self):
        return l11ll_opy_ (u"ࠩ࠿ࡑࡪࡹࡳࡢࡩࡨࡌࡪࡧࡤࡦࡴࡗࡐ࡛ࡀࠠࡢࡲࡳࡣ࡮ࡪ࠽ࡼࡿ࠯ࠤࡹࡿࡰࡦ࠿ࡾࢁ࠱ࠦࡤࡦࡵࡷࡁࢀࢃࠬࠡ࡯ࡨࡱࡧ࡫ࡲࡴࡪ࡬ࡴࡂࢁࡽ࠿ࠩய")\
            .format(self.l11_opy_, self.message_type, self.destination, self.membership)
    def __eq__(self, other):
        return isinstance(other, MessageHeaderTLV)\
            and self.l11_opy_ == other.l11_opy_\
            and self.message_type == other.message_type\
            and self.destination == other.destination\
            and self.membership == other.membership
    def __init__(self, l11_opy_, message_type, destination=None, membership=None):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡂࡶ࡫࡯ࡨࠥࡺࡨࡦࠢࡰࡩࡸࡹࡡࡨࡧ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡩ࡯ࡶࠣࡥࡵࡶ࡟ࡪࡦ࠽ࠤ࡙࡮ࡥࠡࡣࡳࡴࠥࡏࡄࠡࡨࡲࡶࠥࡺࡨࡦࠢࡰࡩࡸࡹࡡࡨࡧ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡴࡳࠢࡰࡩࡸࡹࡡࡨࡧࡢࡸࡾࡶࡥ࠻ࠢࡗ࡬ࡪࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡵࡻࡳࡩࠥ࠳ࠠࡢࠢ࡮ࡩࡾࠦ࡯ࡳࠢࡹࡥࡱࡻࡥࠡࡱࡩࠤ࠿ࡶࡹ࠻ࡣࡷࡸࡷࡀࡠࡨࡱࡗࡩࡳࡴࡡ࠯ࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡦࡳࡳࡹࡴࡢࡰࡷࡷ࠳ࡓࡅࡔࡕࡄࡋࡊࡥࡔ࡚ࡒࡈࡗࡥࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡥࡧࡶࡸ࡮ࡴࡡࡵ࡫ࡲࡲ࠿ࠦࡔࡩࡧࠣࡨࡪࡹࡴࡪࡰࡤࡸ࡮ࡵ࡮ࠡࡱࡩࠤࡹ࡮ࡥࠡ࡯ࡨࡷࡸࡧࡧࡦ࠰ࠣࡍ࡫ࠦࡴࡩ࡫ࡶࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡪ࡯ࡦࡵࠣࡲࡴࡺࠠࡳࡧࡴࡹ࡮ࡸࡥࠡࡣࠣࡨࡪࡹࡴࡪࡰࡤࡸ࡮ࡵ࡮࠭ࠢ࡬ࡸࠥࡳࡡࡺࠢࡥࡩࠥࡔ࡯࡯ࡧ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡴࡺࡲࡨࠤࡩ࡫ࡳࡵ࡫ࡱࡥࡹ࡯࡯࡯࠼ࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲࡬ࡵࡔࡦࡰࡱࡥ࠳ࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡋࡇࠤࡴࡸࠠࡏࡱࡱࡩࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡩ࡯ࡶࠣࡱࡪࡳࡢࡦࡴࡶ࡬࡮ࡶ࠺ࠡࡖ࡫ࡩࠥࡳࡥ࡮ࡤࡨࡶࡸ࡮ࡩࡱࠢ࡬ࡲࡩ࡫ࡸ࠭ࠢ࡬ࡪࠥࡺࡨࡦࠢࡧࡩࡸࡺࡩ࡯ࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡥࠥ࡭ࡲࡰࡷࡳ࠲ࠥࡉࡵࡳࡴࡨࡲࡹࡲࡹࠡ࡫ࡪࡲࡴࡸࡥࡥ࠰ࠣࡍ࡫ࠦࡴࡩ࡫ࡶࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡪ࡯ࡦࡵࠣࡲࡴࡺࠠࡳࡧࡴࡹ࡮ࡸࡥࠡࡣࠣࡨࡪࡹࡴࡪࡰࡤࡸ࡮ࡵ࡮࠭ࠢ࡬ࡸࠥࡳࡡࡺࠢࡥࡩࠥࡔ࡯࡯ࡧ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡢ࡫ࡶࡩࡸࠦࡥࡹࡥࡨࡴࡹ࡯࡯࡯࠰ࡗࡽࡵ࡫ࡅࡳࡴࡲࡶ࠿ࠦࡉࡧࠢࡤࡲࠥࡧࡲࡨࡷࡰࡩࡳࡺࠠࡵࡻࡳࡩࠥ࡯ࡳࠡ࡫ࡱࡺࡦࡲࡩࡥࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷࡧࡩࡴࡧࡶࠤࡪࡾࡣࡦࡲࡷ࡭ࡴࡴ࠮ࡌࡧࡼࡉࡷࡸ࡯ࡳ࠼ࠣࡍ࡫ࠦࡠࡡ࡯ࡨࡷࡸࡧࡧࡦࡡࡷࡽࡵ࡫ࡠࡡࠢ࡬ࡷࠥ࡯࡮ࡷࡣ࡯࡭ࡩࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥர")
        if not isinstance(l11_opy_, int):
            raise TypeError(l11ll_opy_ (u"ࠫࡦࡶࡰࡠ࡫ࡧࠤࡲࡻࡳࡵࠢࡥࡩࠥ࡯࡮ࡵ࠮ࠣ࡭ࡸࠦࡻࡾࠩற").format(type(l11_opy_)))
        self.l11_opy_ = l11_opy_
        if isinstance(message_type, (str, goTenna.util.UnicodeType)):
            self.message_type = goTenna.constants.MESSAGE_TYPES[message_type]
        elif isinstance(message_type, int):
            if message_type not in goTenna.constants.MESSAGE_TYPES.values():
                raise KeyError(message_type)
            self.message_type = message_type
        else:
            raise TypeError(l11ll_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪࡥࡴࡺࡲࡨࠤࡲࡻࡳࡵࠢࡥࡩࠥࡹࡴࡳࠢࡲࡶࠥ࡯࡮ࡵ࠮ࠣ࡭ࡸࠦࡻࡾࠩல")
                            .format(type(message_type)))
        if not isinstance(destination, goTenna.settings.GID)\
           and None is not destination:
            raise TypeError(l11ll_opy_ (u"࠭ࡤࡦࡵࡷ࡭ࡳࡧࡴࡪࡱࡱࠤࡲࡻࡳࡵࠢࡥࡩࠥࡍࡉࡅ࠮ࠣ࡭ࡸࠦࡻࡾࠩள")
                            .format(type(destination)))
        if self.message_type == goTenna.constants.MESSAGE_TYPES[l11ll_opy_ (u"ࠧࡣࡴࡲࡥࡩࡩࡡࡴࡶࠪழ")]:
            self.destination = goTenna.settings.GID.broadcast()
        elif self.message_type == goTenna.constants.MESSAGE_TYPES[l11ll_opy_ (u"ࠨࡧࡰࡩࡷ࡭ࡥ࡯ࡥࡼࠫவ")]:
            self.destination = goTenna.settings.GID.emergency()
        else:
            if None is destination:
                raise TypeError(l11ll_opy_ (u"ࠩࡧࡩࡸࡺࡩ࡯ࡣࡷ࡭ࡴࡴࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡵࡳࡩࡨ࡯ࡦࡪࡧࡧࠤ࡫ࡵࡲࠡࡰࡲࡲ࠲ࡨࡲࡰࡣࡧࡧࡦࡹࡴࠨஶ"))
            self.destination = destination
        if self.message_type in (goTenna.constants.MESSAGE_TYPES[l11ll_opy_ (u"ࠪࡦࡷࡵࡡࡥࡥࡤࡷࡹ࠭ஷ")],
                                 goTenna.constants.MESSAGE_TYPES[l11ll_opy_ (u"ࠫࡪࡳࡥࡳࡩࡨࡲࡨࡿࠧஸ")],
                                 goTenna.constants.MESSAGE_TYPES[l11ll_opy_ (u"ࠬࡶࡲࡪࡸࡤࡸࡪ࠭ஹ")]):
            self.membership = None
        elif None is membership:
            raise TypeError(l11ll_opy_ (u"࠭࡭ࡦ࡯ࡥࡩࡷࡹࡨࡪࡲࠣࡱࡺࡹࡴࠡࡤࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡧࡱࡵࠤ࡬ࡸ࡯ࡶࡲࡶࠫ஺"))
        elif isinstance(membership, int):
            self.membership = membership
        else:
            raise TypeError(l11ll_opy_ (u"ࠧ࡮ࡧࡰࡦࡪࡸࡳࡩ࡫ࡳࠤࡲࡻࡳࡵࠢࡥࡩࠥ࡯࡮ࡵࠢࡲࡶࠥࡔ࡯࡯ࡧ࠯ࠤ࡮ࡹࠠࡼࡿࠪ஻")
                            .format(type(membership)))
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        if len(l111l1ll1l_opy_) < 3:
            raise ValueError(l11ll_opy_ (u"ࠨࡖࡏ࡚ࠥࡳࡵࡴࡶࠣࡦࡪࠦࡡࡵࠢ࡯ࡩࡦࡹࡴࠡ࠵ࠣࡰࡴࡴࡧ࠭ࠢ࡬ࡷࠥࢁࡽࠨ஼")
                             .format(len(l111l1ll1l_opy_)))
        (l1llllllll1_opy_, l11_opy_) = struct.unpack(l11ll_opy_ (u"ࠩࠤࡆࡍ࠭஽"), l111l1ll1l_opy_[:3])
        if len(l111l1ll1l_opy_) > 3:
            l1lllllll1l_opy_ = six.b(l11ll_opy_ (u"ࠪࡠࡽ࠶࠰࡝ࡺ࠳࠴ࠬா")) + l111l1ll1l_opy_[3:]
            (gid, l1llll11ll1_opy_) = struct.unpack(l11ll_opy_ (u"ࠫࠦࡗࡂࠨி"), l1lllllll1l_opy_)
            membership = (l1llll11ll1_opy_ & 0x7f) >> 4
            gid = goTenna.settings.GID(gid, l1llllllll1_opy_)
        else:
            if l1llllllll1_opy_ == goTenna.constants.MESSAGE_TYPES[l11ll_opy_ (u"ࠬࡨࡲࡰࡣࡧࡧࡦࡹࡴࠨீ")]:
                gid = goTenna.settings.GID.broadcast()
            elif l1llllllll1_opy_ == goTenna.constants.MESSAGE_TYPES[l11ll_opy_ (u"࠭ࡥ࡮ࡧࡵ࡫ࡪࡴࡣࡺࠩு")]:
                gid = goTenna.settings.GID.emergency()
            else:
                raise ValueError(l11ll_opy_ (u"ࠧࡏࡱࠣࡋࡎࡊࠠࡴࡲࡨࡧ࡮࡬ࡩࡦࡦࠣࡪࡴࡸࠠ࡮ࡧࡶࡷࡦ࡭ࡥࠡࡶ࡫ࡥࡹࠦࡳࡩࡱࡸࡰࡩࠦࡨࡢࡸࡨࠤࡴࡴࡥࠨூ"))
            membership = None
        return MessageHeaderTLV(l11_opy_, l1llllllll1_opy_, gid, membership)
    def serialize(self):
        prefix = struct.pack(l11ll_opy_ (u"ࠨࠣࡅࡌࠬ௃"), self.message_type, self.l11_opy_)
        if self.message_type in (goTenna.constants.MESSAGE_TYPES[l11ll_opy_ (u"ࠩࡥࡶࡴࡧࡤࡤࡣࡶࡸࠬ௄")],
                                 goTenna.constants.MESSAGE_TYPES[l11ll_opy_ (u"ࠪࡩࡲ࡫ࡲࡨࡧࡱࡧࡾ࠭௅")]):
            return prefix
        l1llllll111_opy_ = self.membership << 4 if self.membership else 0
        suffix = struct.pack(l11ll_opy_ (u"ࠫࠦࡗࡂࠨெ"), self.destination.gid_val,
                             l1llllll111_opy_)
        return prefix + suffix[2:]
class MessagePayloadTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠧࠨࠢࠡࡖ࡫ࡩࠥࡺ࡯ࡱ࠯࡯ࡩࡻ࡫࡬ࠡࡖࡏ࡚ࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡯࡮ࡨࠢࡤࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡶࡡࡺ࡮ࡲࡥࡩ࠴ࠊࠡࠢࠣࠤࠧࠨࠢே")
    l1l11ll1ll_opy_ = 5
    def __repr__(self):
        return l11ll_opy_ (u"࠭࠼ࡎࡧࡶࡷࡦ࡭ࡥࡑࡣࡼࡰࡴࡧࡤࡕࡎ࡙࠾ࠥ࡫࡮ࡤࡴࡀࡿࢂ࠲ࠠࡵ࡮ࡹࡷࡂࢁࡽ࠭ࠢࡵࡥࡼࡃࡻࡾࡀࠪை")\
            .format(self.encryption, self.payload_tlvs,
                    goTenna.util.display_bytestring(self.payload_bytes)
                    if self.payload_bytes else None)
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __eq__(self, other):
        return isinstance(other, MessagePayloadTLV)\
            and self.encryption == other.encryption\
            and self.l1lllll111l_opy_ == other.l1lllll111l_opy_
    l111l11l1l_opy_ = payload_tlv.ALL
    @property
    def l111l1l1l1_opy_(self):
        return self.l111l11l1l_opy_
    @classmethod
    def _1llll1l1ll_opy_(cls, data):
        l11ll_opy_ (u"ࠢࠣࠤࠣࡇ࡭࡫ࡣ࡬ࠢ࡬ࡪࠥࡺࡨࡪࡵࠣ࡭ࡸࠦࡡࠡࡵࡨࡵࡺ࡫࡮ࡤࡧࠣࡳ࡫ࠦࡔࡍࡘࡶࠤࠧࠨࠢ௉")
        for obj in data:
            if type(obj) not in cls.l111l11l1l_opy_:
                return False
        return True
    @classmethod
    def _1lllllll11_opy_(cls, data):
        l11ll_opy_ (u"ࠣࠤࠥࠤࡈ࡮ࡥࡤ࡭ࠣ࡭࡫ࠦࡤࡢࡶࡤࠤ࡮ࡹࠠࡢࠢࡥࡽࡹ࡫ࡳ࡭࡫࡮ࡩࠥࡵࡢ࡫ࡧࡦࡸࠥ࡯࡮ࠡࡣࠣ࠶࠴࠹ࠠࡤࡱࡰࡴࡦࡺࡩࡣ࡮ࡨࠤࡼࡧࡹࠡࠤࠥࠦொ")
        try:
            struct.pack(l11ll_opy_ (u"ࠩ࠴ࡷࠬோ"), data[:1])
        except struct.error:
            return False
        else:
            return True
    @classmethod
    def _1llllll11l_opy_(cls, data):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡃࡩࡧࡦ࡯ࠥ࡯ࡦࠡࡦࡤࡸࡦࠦࡩࡴࠢࡤࡲࠥ࡫࡭ࡱࡶࡼࠤࡸ࡫ࡱࡶࡧࡱࡧࡪࠦࠨࡕࡴࡸࡩ࠮ࠦࡡࠡࡰࡲࡲ࠲࡫࡭ࡱࡶࡼࠤࡸ࡫ࡱࡶࡧࡱࡧࡪࠦࠨࡇࡣ࡯ࡷࡪ࠯ࠠࡰࡴࠣࡲࡴࡺࠠࡢࠢࡶࡩࡶࡻࡥ࡯ࡥࡨࠤ࡚࠭ࡹࡱࡧࡈࡶࡷࡵࡲࠪࠤࠥࠦௌ")
        try:
            _ = data[0]
        except IndexError:
            return True
        else:
            return False
    def __init__(self, encryption, payload_tlvs=None, payload_bytes=None,
                 l1llll11l1l_opy_=None,
                 encrypt_hook=None):
        l11ll_opy_ (u"ࠦࠧࠨࠠࡃࡷ࡬ࡰࡩࠦࡴࡩࡧࠣࡘࡑ࡜࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡘࡑ࡜ࠠࡦࡰࡦࡶࡾࡶࡴࡪࡱࡱ࠾࡚ࠥࡨࡦࠢࡨࡲࡨࡸࡹࡱࡶ࡬ࡳࡳࠦࡔࡍࡘࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡱ࡯ࡳࡵ࡝ࡗࡐ࡛ࡣࠠࡱࡣࡼࡰࡴࡧࡤࡠࡶ࡯ࡺࡸࡀࠠࡕࡎ࡙ࡷࠥࡺ࡯ࠡࡲࡸࡸࠥ࡯࡮ࠡࡶ࡫ࡩࠥࡶࡡࡺ࡮ࡲࡥࡩࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡴࡶࡵࠤࡴࡸࠠࡣࡻࡷࡩࡸࠦࡰࡢࡻ࡯ࡳࡦࡪ࡟ࡣࡻࡷࡩࡸࡀࠠࡖࡰࡧ࡭࡫࡬ࡥࡳࡧࡱࡸ࡮ࡧࡴࡦࡦࠣࡦࡾࡺࡥࡴࠢࡷࡳࠥࡶࡵࡵࠢ࡬ࡲࠥࡺࡨࡦࠢࡳࡥࡾࡲ࡯ࡢࡦࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡸࡺࡲࠡࡱࡵࠤࡧࡿࡴࡦࡵࠣࡹࡳࡪࡥࡤࡴࡼࡴࡹ࡫ࡤࡠࡤࡼࡸࡪࡹ࠺ࠡࡄࡼࡸࡪࡹࠠࡵࡪࡤࡸࠥ࡮ࡡࡷࡧࠣࡲࡴࡺࠠࡺࡧࡷࠤࡧ࡫ࡥ࡯ࠢࡧࡩࡨࡸࡹࡱࡶࡨࡨ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡤࡣ࡯ࡰࡦࡨ࡬ࡦࠢࡨࡲࡨࡸࡹࡱࡶ࡬ࡳࡳࡥࡦࡶࡰࡦ࠾ࠥࡦࡠࡏࡱࡱࡩࡥࡦࠠࡰࡴࠣࡥࠥࡩࡡ࡭࡮ࡤࡦࡱ࡫ࠠࡶࡵࡨࡨࠥࡺ࡯ࠡࡧࡱࡧࡷࡿࡰࡵࠢࡷ࡬ࡪࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡱࡣࡼࡰࡴࡧࡤ࠯ࠢࡌࡪࠥࡺࡨࡦࠢࡨࡲࡨࡸࡹࡱࡶ࡬ࡳࡳࠦࡔࡍࡘࠣࡷࡵ࡫ࡣࡪࡨ࡬ࡩࡸࠦࡴࡩࡣࡷࠤࡹ࡮ࡥࠡ࡯ࡨࡷࡸࡧࡧࡦࠢ࡬ࡷࠥ࡫࡮ࡤࡴࡼࡴࡹ࡫ࡤ࠭ࠢࡷ࡬࡮ࡹࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡣࡱࠤࡪࡴࡣࡳࡻࡳࡸ࡮ࡵ࡮ࠡࡨࡸࡲࡨࡺࡩࡰࡰ࠾ࠤࡴࡺࡨࡦࡴࡺ࡭ࡸ࡫ࠬࠡ࡫ࡷࠤࡲࡧࡹࠡࡤࡨࠤࡥࡦࡎࡰࡰࡨࡤࡥࠦࠨࡢࡰࡧࠤࡼ࡯࡬࡭ࠢࡱࡳࡹࠦࡢࡦࠢࡦࡥࡱࡲࡥࡥࠢࡨࡺࡪࡴࠠࡪࡨࠣࡲࡴࡴ࠭ࡡࡢࡑࡳࡳ࡫ࡠࡡࠫ࠱ࠤࡎ࡬ࠠࡴࡲࡨࡧ࡮࡬ࡩࡦࡦ࠯ࠤࡹ࡮ࡥࠡࡥࡤࡰࡱࡧࡢ࡭ࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡦࡪࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡦࡰࡴࡰࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠱࠲ࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࠺࠻ࠢࡨࡲࡨࡸࡹࡱࡶࡢ࡬ࡴࡵ࡫ࠩࡵࡨࡲࡩ࡫ࡲࡠࡩ࡬ࡨ࠱ࠦࡴࡪ࡯ࡨࡣࡸ࡫࡮ࡵ࠮ࠣࡩࡳࡩࡲࡺࡲࡷ࡭ࡴࡴ࡟ࡤࡱࡸࡲࡹ࡫ࡲ࠭ࠢࡳࡰࡦ࡯࡮ࡵࡧࡻࡸ࠮ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌࡏࡄࠡࡵࡨࡲࡩ࡫ࡲࡠࡩ࡬ࡨ࠿ࠦࡔࡩࡧࠣࡷࡪࡴࡤࡦࡴࠣࡳ࡫ࠦࡴࡩࡧࠣࡱࡪࡹࡳࡢࡩࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡤࡢࡶࡨࡸ࡮ࡳࡥ࠯ࡦࡤࡸࡪࡺࡩ࡮ࡧࠣࡸ࡮ࡳࡥࡠࡵࡨࡲࡹࡀࠠࡕࡪࡨࠤࡹ࡯࡭ࡦࠢࡷ࡬ࡪࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡸࡣࡶࠤࡸ࡫࡮ࡵࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤ࡮ࡴࡴࠡࡧࡱࡧࡷࡿࡰࡵ࡫ࡲࡲࡤࡩ࡯ࡶࡰࡷࡩࡷࡀࠠࡕࡪࡨࠤࡵࡧࡹ࡭ࡱࡤࡨࠥ࡫࡮ࡤࡴࡼࡴࡹ࡯࡯࡯ࡡࡦࡳࡺࡴࡴࡦࡴ࠯ࠤࡦࠦ࠱࠷࠯ࡥ࡭ࡹࠦࡣࡰࡷࡱࡸࡪࡸࠠࡵࡪࡤࡸࠥࡩࡨࡢࡰࡪࡩࡸࠦࡷࡪࡶ࡫ࠤࡪࡼࡥࡳࡻࠣࡱࡪࡧ࡮ࡵ࠯ࡷࡳ࠲ࡨࡥ࠮ࡷࡱ࡭ࡶࡻࡥࠡ࡯ࡨࡷࡸࡧࡧࡦࠢࡶࡩࡳࡺࠠࡧࡴࡲࡱࠥࡧࠠࡴࡲࡨࡧ࡮࡬ࡩࡤࠢࡶࡩࡳࡪࡥࡳࠢࡷࡳࠥࡧࠠࡴࡲࡨࡧ࡮࡬ࡩࡤࠢࡧࡩࡸࡺࡩ࡯ࡣࡷ࡭ࡴࡴࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡥࡽࡹ࡫ࡳ࡭࡫࡮ࡩࠥࡶ࡬ࡢ࡫ࡱࡸࡪࡾࡴ࠻ࠢࡗ࡬ࡪࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡤࡱࡱࡸࡪࡴࡴࠡࡶࡲࠤࡪࡴࡣࡳࡻࡳࡸࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࡕࡪࡨࠤࡕࡧࡹ࡭ࡱࡤࡨ࡚ࠥࡌࡗࠢ࡬ࡷࠥ࡯࡮ࠡࡶ࡫ࡩࠥࡻ࡮ࡧࡱࡵࡸࡺࡴࡡࡵࡧࠣࡴࡴࡹࡩࡵ࡫ࡲࡲࠥࡵࡦࠡࡥࡤࡶࡷࡿࡩ࡯ࡩࠣࡷࡴࡳࡥࠡ࡫ࡱࡪࡴࡸ࡭ࡢࡶ࡬ࡳࡳࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡࡤࡼࠤࡹ࡮ࡥࠡࡵࡼࡷࡹ࡫࡭ࠡࠪࡷ࡬ࡪࠦࡥ࡯ࡥࡵࡽࡵࡺࡩࡰࡰࠣ࡬ࡪࡧࡤࡦࡴ࠯ࠤࡼ࡮ࡩࡤࡪࠣ࡭ࡸࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡࡣࡱࡨࠥࡸࡥࡲࡷ࡬ࡶࡪࡪࠠࡵࡱࠣࡦࡪࠦࡡࠡࡖࡏ࡚࠮ࡁࠠࡴࡱࡰࡩࠥ࡯࡮ࡧࡱࡵࡱࡦࡺࡩࡰࡰࠣࡸ࡭ࡧࡴࠡ࡫ࡶࠤࡨࡻࡳࡵࡱࡰࡥࡷ࡯࡬ࡺࠢࡳࡶࡪࡹࡥ࡯ࡶࠣࡶࡪ࡭ࡡࡳࡦ࡯ࡩࡸࡹࠠࡰࡨࠣࡸ࡭࡫ࠠࡤࡱࡱࡸࡪࡴࡴࠡࡱࡩࠤࡹ࡮ࡥࠡࡲࡤࡽࡱࡵࡡࡥࠢࠫࡷࡪࡴࡤࡦࡴࠣ࡭ࡳ࡯ࡴࡪࡣ࡯ࡷ࠱ࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡵࡻࡳࡩࠥ࡮ࡥࡢࡦࡨࡶ࠮ࡁࠠࡢࡰࡧࠤࡸࡵ࡭ࡦࠢࡳࡥࡾࡲ࡯ࡢࡦࠣ࡭ࡳ࡬࡯ࡳ࡯ࡤࡸ࡮ࡵ࡮ࠡࡹ࡫ࡳࡸ࡫ࠠࡵࡻࡳࡩࠥࡽࡥࠡࡹࡤࡲࡹࠦࡴࡰࠢ࡯ࡩࡦࡼࡥࠡࡷࡳࠤࡹࡵࠠࡵࡪࡨࠤࡨࡧ࡬࡭ࡧࡵ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࡕࡱࠣࡸ࡭ࡧࡴࠡࡧࡱࡨ࠱ࠦࡴࡩࡧࠣࡧࡦࡲ࡬ࡦࡴࠣࡧࡦࡴࠠࡴࡲࡨࡧ࡮࡬ࡹࠡࡤࡲࡸ࡭ࠦࡡࠡ࡮࡬ࡷࡹࠦ࡯ࡧࠢࡗࡐ࡛ࡹࠠࡢࡰࡧࠤࡸࡵ࡭ࡦࠢࡸࡲ࡫ࡵࡲ࡮ࡣࡷࡸࡪࡪࠠࡥࡣࡷࡥ࠳ࠦࡎࡦ࡫ࡷ࡬ࡪࡸࠠࡪࡵࠣࡶࡪࡷࡵࡪࡴࡨࡨࡀࠦࡩࡧࠢࡷ࡬ࡪࠦࡣࡢ࡮࡯ࡩࡷࠦࡷࡢࡰࡷࡷࠥࡧ࡮ࠡࡧࡰࡴࡹࡿࠠࡱࡣࡼࡰࡴࡧࡤ࠭ࠢࡥࡳࡹ࡮ࠠࡤࡣࡱࠤࡧ࡫ࠠࡏࡱࡱࡩ࠳ࠦࡉࡥࡧࡤࡰࡱࡿࠬࠡࡶ࡫ࡩࠥࡹࡥ࡯ࡦࡨࡶࠥ࡯࡮ࡪࡶ࡬ࡥࡱࡹࠠࡢࡰࡧࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡺࡹࡱࡧࠣࡘࡑ࡜ࡳࠡࠪࡤࡸࠥࡲࡥࡢࡵࡷ࠭ࠥࡽࡩ࡭࡮ࠣࡦࡪࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢ࡬ࡲࠥࡦࡠࡱࡣࡼࡰࡴࡧࡤࡠࡶ࡯ࡺࡸࡦࡠࠡࡧࡹࡩࡳࠦࡩࡧࠢࡷ࡬ࡪࠦࡤࡦࡵ࡬ࡶࡪࡪࠠࡤࡱࡱࡸࡪࡴࡴࠡ࡫ࡶࠤࡳࡵࡴࠡࡖࡏ࡚ࡸࡁࠠࡩࡱࡺࡩࡻ࡫ࡲ࠭ࠢࡷ࡬࡮ࡹࠠࡪࡵࠣࡲࡴࡺࠠ࡮ࡣࡱࡨࡦࡺ࡯ࡳࡻ࠱ࠤ࡙ࡒࡖࡴࠢࡤࡶࡪࠦࡳࡦࡴ࡬ࡥࡱ࡯ࡺࡦࡦࠣ࡭ࡳࡺ࡯ࠡࡶ࡫ࡩࠥࡵࡵࡵࡲࡸࡸࠥ࡬ࡩࡳࡵࡷ࠰ࠥࡨࡥࡤࡣࡸࡷࡪࠦࡴࡩࡧࠣ࡭ࡳࡶࡵࡵࠢࡶ࡭ࡩ࡫ࠠࡸ࡫࡯ࡰࠥࡵ࡮࡭ࡻࠣࡶࡪࡧࡤࠡࡖࡏ࡚ࡸࠦࡦࡳࡱࡰࠤࡹ࡮ࡥࠡࡤࡨ࡫࡮ࡴ࡮ࡪࡰࡪࠤࡴ࡬ࠠࡵࡪࡨࠤࡲ࡫ࡳࡴࡣࡪࡩ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡࡖ࡫࡭ࡸࠦࡩࡴࠢࡤࡰࡸࡵࠠࡸࡪࡨࡶࡪࠦࡴࡩࡧࠣࡧࡦࡲ࡬ࡦࡴࠣࡷࡵ࡫ࡣࡪࡨ࡬ࡩࡸࠦࡨࡰࡹࠣࡸ࡭࡫ࠠࡱࡣࡼࡰࡴࡧࡤࠡࡵ࡫ࡳࡺࡲࡤࠡࡤࡨࠤࡪࡴࡣࡳࡻࡳࡸࡪࡪ࠮ࠡࡖ࡫ࡩࠥࡦࡠࡦࡰࡦࡶࡾࡶࡴࡠࡪࡲࡳࡰࡦࡠࠡ࡫ࡶࠤࡦࠦࡣࡢ࡮࡯ࡦࡦࡩ࡫ࠡࡶ࡫ࡥࡹࠦࡩࡴࠢࡪ࡭ࡻ࡫࡮ࠡࡶ࡫ࡩࠥࡳࡥࡵࡣࡧࡥࡹࡧࠠࡢࡰࡧࠤࡵࡲࡡࡪࡰࡷࡩࡽࡺࠠ࡬ࡰࡲࡻࡳࠦࡢࡺࠢࡷ࡬࡮ࡹࠠࡕࡎ࡙ࠤࡦࡴࡤࠡࡧࡻࡴࡪࡩࡴࡦࡦࠣࡸࡴࠦࡲࡦࡶࡸࡶࡳࠦࡴࡩࡧࠣࡩࡳࡩࡲࡺࡲࡷࡩࡩࠦࡰࡢࡴࡷࠤࡴ࡬ࠠࡵࡪࡨࠤࡵࡧࡹ࡭ࡱࡤࡨ࠳ࠦࡔࡩ࡫ࡶࠤࡨࡧ࡮ࠡࡤࡨࠤࡥࡦࡎࡰࡰࡨࡤࡥࠦࡩࡧࠢࡷ࡬ࡪࠦࡰࡢࡻ࡯ࡳࡦࡪࠠࡪࡵࠣࡲࡴࡺࠠࡦࡰࡦࡶࡾࡶࡴࡦࡦࠣࡳࡷࠦࡩࡧࠢࡷ࡬࡮ࡹࠠࡪࡵࠣࡥࠥࡸࡥࡤࡧ࡬ࡺࡪࡪࠠࡱࡣࡼࡰࡴࡧࡤ࠭ࠢࡥࡹࡹࠦࡥࡪࡶ࡫ࡩࡷࠦࡷࡢࡻࠣ࡭࡫ࠦࡴࡩࡧࠣࡴࡦࡿ࡬ࡰࡣࡧࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡪࡴࡣࡳࡻࡳࡸࡪࡪࠠࡪࡶࠣࡻ࡮ࡲ࡬ࠡࡰࡨࡺࡪࡸࠠࡣࡧࠣࡧࡦࡲ࡬ࡦࡦ࠱ࠤ࡙࡮ࡩࡴࠢࡳࡶࡴࡼࡩࡥࡧࡶࠤࡹ࡮ࡥࠡ࡫ࡱࡺࡪࡸࡳࡦࠢࡲࡴࡪࡸࡡࡵ࡫ࡲࡲࠥࡺ࡯ࠡ࠼ࡳࡽ࠿ࡳࡥࡵࡪ࠽ࡤࡩ࡫ࡣࡳࡻࡳࡸࡥ࠴ࠠࡡࡢࡨࡲࡨࡸࡹࡱࡶࡢ࡬ࡴࡵ࡫ࡡࡢࠣࡧࡦࡴࠠࡢ࡮ࡶࡳࠥࡨࡥࠡࡵࡳࡩࡨ࡯ࡦࡪࡧࡧࠤࡼ࡯ࡴࡩࠢ࠽ࡴࡾࡀ࡭ࡦࡶ࡫࠾ࡥࡹࡥࡵࡡࡨࡲࡨࡸࡹࡱࡶࡢ࡬ࡴࡵ࡫ࡡ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨ்ࠢ")
        if not isinstance(encryption, payload_tlv.EncryptionInfoTLV):
            raise TypeError(l11ll_opy_ (u"ࠬ࡫࡮ࡤࡴࡼࡴࡹ࡯࡯࡯ࠢࡰࡹࡸࡺࠠࡣࡧࠣࡉࡳࡩࡲࡺࡲࡷ࡭ࡴࡴࡉ࡯ࡨࡲࡘࡑ࡜ࠬࠡ࡫ࡶࠤࢀࢃࠧ௎")
                            .format(type(encryption)))
        if None is not payload_tlvs\
           and not self._1llllll11l_opy_(payload_tlvs)\
           and not self._1llll1l1ll_opy_(payload_tlvs):
            raise TypeError(l11ll_opy_ (u"࠭ࡰࡢࡻ࡯ࡳࡦࡪ࡟ࡵ࡮ࡹࡷࠥࡳࡵࡴࡶࠣࡦࡪࠦࡡࠡ࡮࡬ࡷࡹࠦ࡯ࡧࠢࡷࡰࡻࡹࠬࠡ࡫ࡶࠤࢀࢃࠧ௏")
                            .format(type(payload_tlvs)))
        if None is not payload_bytes\
           and not self._1llllll11l_opy_(payload_bytes)\
           and not self._1lllllll11_opy_(payload_bytes):
            raise TypeError(l11ll_opy_ (u"ࠧࡱࡣࡼࡰࡴࡧࡤࡠࡤࡼࡸࡪࡹࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡤࡼࡸࡪࡲࡩ࡬ࡧ࠯ࠤ࡮ࡹࠠࡼࡿࠪௐ")
                            .format(type(payload_bytes)))
        self.l1lllll1lll_opy_(encrypt_hook)
        self._1llll1ll11_opy_ = encryption
        if None is payload_tlvs:
            self._1lllll11l1_opy_ = []
        else:
            self._1lllll11l1_opy_ = payload_tlvs
        if None is payload_bytes:
            self._1llllll1l1_opy_ = six.b(l11ll_opy_ (u"ࠨࠩ௑"))
        else:
            self._1llllll1l1_opy_ = payload_bytes
        if None is l1llll11l1l_opy_:
            self._1lllll1111_opy_ = six.b(l11ll_opy_ (u"ࠩࠪ௒"))
        else:
            self._1lllll1111_opy_ = l1llll11l1l_opy_
    def l1lllll1lll_opy_(self, encrypt_hook):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡓࡦࡶࠣࡸ࡭࡫ࠠࡦࡰࡦࡶࡾࡶࡴࡰࡴࠣࡪࡺࡴࡣࡵ࡫ࡲࡲࠥ࡬࡯ࡳࠢࡷ࡬ࡪࠦࡔࡍࡘ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡣࡢ࡮࡯ࡥࡧࡲࡥࠡࡧࡱࡧࡷࡿࡰࡵࡱࡵࡣ࡫ࡻ࡮ࡤ࠼ࠣࡘ࡭࡫ࠠࡦࡰࡦࡶࡾࡶࡴࡰࡴ࠱ࠤࡋࡵࡲࠡࡦࡨࡸࡦ࡯࡬ࡴࠢࡲࡲࠥࡺࡨࡦࠢࡩࡳࡷࡳࠠࡴࡧࡨࠤ࠿ࡶࡹ࠻࡯ࡨࡸ࡭ࡀࡠࡠࡡ࡬ࡲ࡮ࡺ࡟ࡠࡢ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣ௓")
        if encrypt_hook and not hasattr(encrypt_hook, l11ll_opy_ (u"ࠫࡤࡥࡣࡢ࡮࡯ࡣࡤ࠭௔")):
            raise TypeError(l11ll_opy_ (u"ࠬࡏࡦࠡࡵࡳࡩࡨ࡯ࡦࡪࡧࡧ࠰ࠥ࡫࡮ࡤࡴࡼࡴࡹࡥࡨࡰࡱ࡮ࠤࡲࡻࡳࡵࠢࡥࡩࠥࡩࡡ࡭࡮ࡤࡦࡱ࡫ࠠࡣࡷࡷࠤࢀࢃࠠࡪࡵࠣࡲࡴࡺࠧ௕")
                            .format(type(encrypt_hook)))
        self._encrypt_hook = encrypt_hook
    def decrypt(self, l1lllllllll_opy_):
        l11ll_opy_ (u"ࠨࠢࠣࠢࡗࡶࡾࠦࡡ࡯ࡦࠣࡨࡪࡩࡲࡺࡲࡷࠤࡦࡴࡹࠡࡷࡱࡴࡦࡸࡳࡦࡦࠣࡦࡾࡺࡥࡴࠢ࡯ࡩ࡫ࡺࠠࡰࡸࡨࡶࠥ࡬ࡲࡰ࡯ࠣࡨࡪࡹࡥࡳ࡫ࡤࡰ࡮ࢀࡡࡵ࡫ࡲࡲ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡥࡤࡰࡱࡧࡢ࡭ࡧࠣࡨࡪࡩࡲࡺࡲࡷࡳࡷࡥࡦࡶࡰࡦ࠾ࠥࡇࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡷࡳࠥࡩࡡ࡭࡮ࠣࡸࡴࠦࡤࡦࡥࡵࡽࡵࡺࠠࡵࡪࡨࠤࡨࡵ࡮ࡵࡧࡱࡸࡸࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡰࡢࡻ࡯ࡳࡦࡪ࠮ࠡࡖ࡫ࡩࠥ࡮࡯ࡰ࡭ࠣ࡭ࡸࠦࡧࡪࡸࡨࡲࠥࡺࡨࡦࠢࡳࡥࡾࡲ࡯ࡢࡦࠣࡱࡪࡺࡡࡥࡣࡷࡥ࠳ࠦࡔࡩࡧࠣࡪࡴࡸ࡭ࠡ࡫ࡶࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠱࠲ࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࠺࠻ࠢࡧࡩࡨࡸࡹࡱࡶࡢ࡬ࡴࡵ࡫ࠩࡵࡨࡲࡩ࡫ࡲࡠࡩ࡬ࡨ࠱ࠦࡴࡪ࡯ࡨࡣࡸ࡫࡮ࡵ࠮ࠣࡩࡳࡩࡲࡺࡲࡷ࡭ࡴࡴ࡟ࡤࡱࡸࡲࡹ࡫ࡲ࠭ࠢࡳࡰࡦ࡯࡮ࡵࡧࡻࡸ࠮ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌࡏࡄࠡࡵࡨࡲࡩ࡫ࡲࡠࡩ࡬ࡨ࠿ࠦࡔࡩࡧࠣࡷࡪࡴࡤࡦࡴࠣࡳ࡫ࠦࡴࡩࡧࠣࡱࡪࡹࡳࡢࡩࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡤࡢࡶࡨࡸ࡮ࡳࡥ࠯ࡦࡤࡸࡪࡺࡩ࡮ࡧࠣࡸ࡮ࡳࡥࡠࡵࡨࡲࡹࡀࠠࡕࡪࡨࠤࡹ࡯࡭ࡦࠢࡷ࡬ࡪࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡸࡣࡶࠤࡸ࡫࡮ࡵࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤ࡮ࡴࡴࠡࡧࡱࡧࡷࡿࡰࡵ࡫ࡲࡲࡤࡩ࡯ࡶࡰࡷࡩࡷࡀࠠࡕࡪࡨࠤࡵࡧࡹ࡭ࡱࡤࡨࠥ࡫࡮ࡤࡴࡼࡴࡹ࡯࡯࡯ࡡࡦࡳࡺࡴࡴࡦࡴ࠯ࠤࡦࠦ࠱࠷࠯ࡥ࡭ࡹࠦࡣࡰࡷࡱࡸࡪࡸࠠࡵࡪࡤࡸࠥࡩࡨࡢࡰࡪࡩࡸࠦࡷࡪࡶ࡫ࠤࡪࡼࡥࡳࡻࠣࡱࡪࡧ࡮ࡵ࠯ࡷࡳ࠲ࡨࡥ࠮ࡷࡱ࡭ࡶࡻࡥࠡ࡯ࡨࡷࡸࡧࡧࡦࠢࡶࡩࡳࡺࠠࡧࡴࡲࡱࠥࡧࠠࡴࡲࡨࡧ࡮࡬ࡩࡤࠢࡶࡩࡳࡪࡥࡳࠢࡷࡳࠥࡧࠠࡴࡲࡨࡧ࡮࡬ࡩࡤࠢࡧࡩࡸࡺࡩ࡯ࡣࡷ࡭ࡴࡴࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡥࡽࡹ࡫ࡳ࡭࡫࡮ࡩࠥࡩࡩࡱࡪࡨࡶࡹ࡫ࡸࡵ࠼ࠣࡘ࡭࡫ࠠ࡮ࡧࡶࡷࡦ࡭ࡥࠡࡥࡲࡲࡹ࡫࡮ࡵࠢࡷࡳࠥࡪࡥࡤࡴࡼࡴࡹࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࠥࡪࡥࡤࡴࡼࡴࡹ࡯࡯࡯ࠢࡲࡧࡨࡻࡲࡴࠢ࡬ࡪࠥࡧ࡮ࡥࠢࡲࡲࡱࡿࠠࡪࡨ࠽ࠎࠥࠦࠠࠡࠢࠣࠤࠥ࠳ࠠࡕࡪࡨࠤࡩ࡫ࡣࡳࡻࡳࡸࡴࡸࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡧࡳࡪࡹࠠ࡯ࡱࡷࠤࡷࡧࡩࡴࡧࠣࡥࡳࠦࡥࡹࡥࡨࡴࡹ࡯࡯࡯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠱࡚ࠥࡨࡦࠢ࡯ࡥࡸࡺࠠࡵࡹࡲࠤࡧࡿࡴࡦࡵࠣࡳ࡫ࠦࡴࡩࡧࠣࡨࡪࡩࡲࡺࡲࡷࡩࡩࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡢࡴࡨࠤࡦࠦࡶࡢ࡮࡬ࡨࠥࡉࡒࡄࠢࡩࡳࡷࠦࡴࡩࡧࠣࡶࡪࡹࡴࠡࡱࡩࠤࡹ࡮ࡥࠡࡦࡨࡧࡷࡿࡰࡵࡧࡧࠤࡲ࡫ࡳࡴࡣࡪࡩࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࡊࡨࠣࡨࡪࡩࡲࡺࡲࡷ࡭ࡴࡴࠠࡪࡵࠣࡲࡴࡺࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡺࡨࡦࠢࡦࡳࡳࡺࡥ࡯ࡶࠣࡳ࡫ࠦࡴࡩࡧࠣࡴࡦࡿ࡬ࡰࡣࡧࠤࡷ࡫࡭ࡢ࡫ࡱࡷࠥࡧࡳࠡࡷࡱࡴࡦࡸࡳࡦࡦࠣࡦࡾࡺࡥࡴ࠰ࠣࡍ࡫ࠦࡩࡵࠢ࡬ࡷࠥࡹࡵࡤࡥࡨࡷࡸ࡬ࡵ࡭࠮ࠣࡸ࡭࡫ࠠࡤࡱࡱࡸࡪࡴࡴࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡳࡥࡷࡹࡥࡥࠢ࡬ࡲࡹࡵࠠࡢࠢ࡯࡭ࡸࡺࠠࡰࡨࠣࡘࡑ࡜ࡳ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨ௖")
        l1lllll1ll1_opy_ = False
        try:
            decrypted = l1lllllllll_opy_(self.encryption.sender, self.encryption.time,
                                       self.encryption.counter, self._1lllll1111_opy_)
            if decrypted == self._1lllll1111_opy_:
                raise ValueError(l11ll_opy_ (u"ࠧࡃࡣࡧࠤࡩ࡫ࡣࡳࡻࡳࡸ࡮ࡵ࡮ࠡࠪࡱࡳ࠲ࡵࡰࠪࠩௗ"))
            self._1llll111ll_opy_(decrypted)
            self._1lllll1111_opy_ = None
            l1lllll1ll1_opy_ = True
        except Exception: # pylint: disable=broad-except
            _MODULE_LOGGER.getChild(self.__class__.__name__)\
                          .exception(l11ll_opy_ (u"ࠨࡆࡨࡧࡷࡿࡰࡵ࡫ࡲࡲࠥ࡬ࡡࡪ࡮ࡨࡨࠦ࠭௘"))
            decrypted = self._1lllll1111_opy_
        tlvs, l1lllll1l1l_opy_\
            = basic_tlv.TLV.l111ll1l11_opy_(decrypted[:-2],
                                                self.l111l11l1l_opy_)
        if l1lllll1ll1_opy_:
            self._1llll1l111_opy_(tlvs, l1lllll1l1l_opy_, decrypted[-2:])
        else:
            _MODULE_LOGGER.getChild(self.__class__.__name__)\
                          .warning(l11ll_opy_ (u"ࠩࡖ࡯࡮ࡶࡰࡪࡰࡪࠤࡈࡘࡃࠡࡥ࡫ࡩࡨࡱࠠࠩࡦࡨࡧࡷࡿࡰࡵࠢࡩࡥ࡮ࡲࡥࡥࠫࠪ௙"))
        self._1lllll11l1_opy_ = tlvs
        self._1llllll1l1_opy_ = l1lllll1l1l_opy_[:-2]
    @staticmethod
    def _1llll111ll_opy_(plaintext):
        l1llll1lll1_opy_ = plaintext[-2:]
        l1llll1llll_opy_ = struct.unpack(l11ll_opy_ (u"ࠪࠥࡍ࠭௚"), l1llll1lll1_opy_)[0]
        l1lllll11ll_opy_ = binascii.crc_hqx(plaintext[:-2], 0)
        if l1lllll11ll_opy_ != l1llll1llll_opy_:
            raise ValueError(l11ll_opy_ (u"ࠫࡈࡘࡃࠡ࡯࡬ࡷࡲࡧࡴࡤࡪࠣࡥ࡫ࡺࡥࡳࠢࡧࡩࡨࡸࡹࡱࡶ࠽ࠤࡈࡧ࡬ࡤࡷ࡯ࡥࡹ࡫ࡤࠡࡽࢀ࠰ࠥࡶࡡࡳࡵࡨࡨࠥࢁࡽࠡࡨࡵࡳࡲࠦࡻࡾࠩ௛").format(l1lllll11ll_opy_, l1llll1llll_opy_,
                                                                                                   plaintext))
    @staticmethod
    def _1llll1l111_opy_(tlvs, l1lllll1l1l_opy_, l1llll1lll1_opy_):
        l1lllll1l11_opy_ = six.b(l11ll_opy_ (u"ࠬ࠭௜"))
        if tlvs:
            l1lllll1l11_opy_ += goTenna.util.l1ll1ll1_opy_(*[t.to_bytes()
                                                   for t in tlvs])
        if l1lllll1l1l_opy_:
            l1lllll1l11_opy_ += l1lllll1l1l_opy_
        l1llll1llll_opy_ = struct.unpack(l11ll_opy_ (u"࠭ࠡࡉࠩ௝"), l1llll1lll1_opy_)[0]
        l1llll1ll1l_opy_ = binascii.crc_hqx(l1lllll1l11_opy_, 0)
        if l1llll1ll1l_opy_ != l1llll1llll_opy_:
            raise ValueError(l11ll_opy_ (u"ࠧࡄࡔࡆࠤࡲ࡯ࡳ࡮ࡣࡷࡧ࡭ࡀࠠࡼࡿࠣࡧࡦࡲࡣ࠭ࠢࡾࢁࠥࡶࡡࡳࡵࡨ࠰ࠥࢁࡽࠡࡴࡨࡷࡪࡸࠬࠡࡲࡤࡶࡸ࡫ࡤࠡࡽࢀࠤࡼ࡯ࡴࡩࠢࡾࢁࠥࡲࡥࡧࡶࠣࡳࡻ࡫ࡲࠨ௞")
                             .format(hex(l1llll1ll1l_opy_),
                                     hex(l1llll1llll_opy_),
                                     goTenna.util.display_bytestring(l1lllll1l11_opy_),
                                     tlvs,
                                     goTenna.util.display_bytestring(l1lllll1l1l_opy_)))
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        l1llll1lll1_opy_ = l111l1ll1l_opy_[-2:]
        l111l1ll1l_opy_ = l111l1ll1l_opy_[:-2]
        encryption, remaining\
            = basic_tlv.TLV.l1ll11llll_opy_(l111l1ll1l_opy_,
                                           (payload_tlv.EncryptionInfoTLV,))
        if encryption.encrypted: # pylint: disable=no-else-return
            return MessagePayloadTLV(encryption, None, None,
                                     remaining+l1llll1lll1_opy_)
        else:
            tlvs, l1lllll1l1l_opy_\
                = basic_tlv.TLV.l111ll1l11_opy_(remaining,
                                                    cls.l111l11l1l_opy_)
            cls._1llll1l111_opy_(tlvs, l1lllll1l1l_opy_, l1llll1lll1_opy_)
            return MessagePayloadTLV(encryption,
                                     tlvs if tlvs else None,
                                     l1lllll1l1l_opy_ if l1lllll1l1l_opy_ else None)
    def serialize(self):
        l11ll_opy_ (u"ࠣࠤࠥࠤࡎࡳࡰ࡭ࡧࡰࡩࡳࡺࡡࡵ࡫ࡲࡲࠥࡵࡦࠡ࠼ࡳࡽ࠿ࡳࡥࡵࡪ࠽ࡤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡺ࡬ࡷ࠰ࡥࡥࡸ࡯ࡣࡠࡶ࡯ࡺ࠳࡚ࡌࡗ࠰ࡶࡩࡷ࡯ࡡ࡭࡫ࡽࡩࡥࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ௟")
        l1llll1l11l_opy_ = self.encryption.to_bytes()
        rest = self.l1lllll111l_opy_
        rest += struct.pack(l11ll_opy_ (u"ࠩࠤࡌࠬ௠"), binascii.crc_hqx(rest, 0))
        if self.encryption.encrypted:
            if not hasattr(self._encrypt_hook, l11ll_opy_ (u"ࠪࡣࡤࡩࡡ࡭࡮ࡢࡣࠬ௡")):
                raise TypeError(l11ll_opy_ (u"ࠫࡘ࡫ࡲࡪࡣ࡯࡭ࡿ࡯࡮ࡨࠢࡨࡲࡨࡸࡹࡱࡶࡨࡨࠥࡶࡡࡺ࡮ࡲࡥࡩࡹࠠࡳࡧࡴࡹ࡮ࡸࡥࡴࠢࡤࡲࠥ࡫࡮ࡤࡴࡼࡴࡹ࡯࡯࡯ࠢࡩࡹࡳࡩࠠࡣࡷࡷࠤࡪࡴࡣࡳࡻࡳࡸ࡮ࡵ࡮ࡠࡨࡸࡲࡨࠦࡩࡴࠢࡾࢁࠬ௢")
                                .format(type(self._encrypt_hook)))
            rest = self._encrypt_hook(self.encryption.sender,
                                      self.encryption.time,
                                      self.encryption.counter,
                                      rest)
        return l1llll1l11l_opy_ + rest
    @property
    def encryption(self):
        l11ll_opy_ (u"ࠧࠨࠢࠡࡖ࡫ࡩࠥࡳࡡ࡯ࡦࡤࡸࡴࡸࡹࠡࡧࡱࡧࡷࡿࡰࡵ࡫ࡲࡲࠥ࡮ࡥࡢࡦࡨࡶ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡩࡹࡻࡲ࡯ࡵࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡵࡧࡹ࡭ࡱࡤࡨࡤࡺ࡬ࡷ࠰ࡈࡲࡨࡸࡹࡱࡶ࡬ࡳࡳࡏ࡮ࡧࡱࡗࡐ࡛ࡀࠠࡕࡪࡨࠤࡪࡴࡣࡳࡻࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࡪࡴ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦ௣")
        return self._1llll1ll11_opy_
    @property
    def payload_bytes(self):
        l11ll_opy_ (u"ࠨࠢࠣࠢࡗ࡬ࡪࠦࡰࡢࡴࡷࠤࡴ࡬ࠠࡵࡪࡨࠤࡵࡧࡹ࡭ࡱࡤࡨࠥࡺࡨࡢࡶࠣࡻࡦࡹࠠࡴࡲࡨࡧ࡮࡬ࡩࡦࡦࠣࡥࡸࠦࡢࡺࡶࡨࡷࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡨࡸࡺࡸ࡮ࡴࠢࡥࡽࡹ࡫ࡳࠡࡱࡵࠤࡸࡺࡲ࠻ࠢࡗ࡬ࡪࠦࡤࡢࡶࡤࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣ௤")
        return self._1llllll1l1_opy_
    @property
    def payload_tlvs(self):
        l11ll_opy_ (u"ࠢࠣࠤࠣࡘ࡭࡫ࠠࡱࡣࡵࡸࠥࡵࡦࠡࡶ࡫ࡩࠥࡶࡡࡺ࡮ࡲࡥࡩࠦࡴࡩࡣࡷࠤࡼࡧࡳࠡࡵࡳࡩࡨ࡯ࡦࡪࡧࡧࠤࡦࡹࠠࡕࡎ࡙ࡷ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡩࡹࡻࡲ࡯ࡵࠣࡰ࡮ࡹࡴ࡜ࡖࡏ࡚ࡢࡀࠠࡕࡪࡨࠤ࡙ࡒࡖࡴࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨ௥")
        return self._1lllll11l1_opy_
    @property
    def l1lllll111l_opy_(self):
        l11ll_opy_ (u"ࠣࠤࠥࠤ࡙࡮ࡥࠡࡧࡱࡸ࡮ࡸࡥࡵࡻࠣࡳ࡫ࠦࡴࡩࡧࠣࡧࡴࡴࡴࡦࡰࡷࠤࡴ࡬ࠠࡵࡪࡨࠤࡵࡧࡹ࡭ࡱࡤࡨࠥ࠮ࡥ࠯ࡩ࠱ࠤࡪࡼࡥࡳࡻࡷ࡬࡮ࡴࡧࠡࡤࡸࡸࠥࡺࡨࡦࠢࡨࡲࡨࡸࡹࡱࡶ࡬ࡳࡳࠦࡨࡦࡣࡧࡩࡷ࠯ࠠࡢࡵࠣࡦࡾࡺࡥࡴ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤ࡚ࠥࡨࡪࡵࠣࡻ࡮ࡲ࡬ࠡ࡫ࡰࡴࡱ࡯ࡣࡪࡶ࡯ࡽࠥࡹࡥࡳ࡫ࡤࡰ࡮ࢀࡥࠡࡣࡱࡽ࡚ࠥࡌࡗࡵࠣࡷࡹࡵࡲࡦࡦࠣࡦࡾࠦࡴࡩࡧࠣࡷࡾࡹࡴࡦ࡯ࠣࡥࡳࡪࠠࡤࡱࡱࡧࡦࡺࡥ࡯ࡣࡷࡩࠥࡺࡨࡦࠢࡳࡥࡷࡺࠠࡰࡨࠣࡸ࡭࡫ࠠࡱࡣࡼࡰࡴࡧࡤࠡࡵࡳࡩࡨ࡯ࡦࡪࡧࡧࠤࡦࡹࠠࡣࡻࡷࡩࡸࠦࡴࡰࠢࡷ࡬ࡪࠦࡲࡦࡵࡸࡰࡹ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦ௦")
        to_return = goTenna.util.l111ll_opy_()
        if self._1lllll11l1_opy_:
            for tlv in self._1lllll11l1_opy_:
                to_return += tlv.to_bytes()
        if self._1llllll1l1_opy_:
            to_return += self._1llllll1l1_opy_
        return to_return
class PublicKeyHashTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠤ࡚ࠥࠦࠥࡨࡦࠢࡷࡳࡵ࠳࡬ࡦࡸࡨࡰ࡚ࠥࡌࡗࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡡࠡࡲࡸࡦࡱ࡯ࡣࠡ࡭ࡨࡽࠥ࡮ࡡࡴࡪ࠱ࠎࠥࠦࠠࠡࠤࠥࠦ௧")
    l1l11ll1ll_opy_ = 4
    def __repr__(self):
        return l11ll_opy_ (u"ࠪࡀࡕࡻࡢࡌࡧࡼࡌࡦࡹࡨࡕࡎ࡙࠾ࠥ࡯࡮ࡥࡧࡻࡁࢀࢃࠠࡩࡣࡶ࡬ࡂࢁࡽ࠿ࠩ௨").format(self.index,
                                                          self.l1llll11lll_opy_)
    def __eq__(self, other):
        return isinstance(other, PublicKeyHashTLV)\
            and self.index == other.index\
            and self.l1llll11lll_opy_ == other.l1llll11lll_opy_
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, index=None, l1llll11lll_opy_=None):
        l11ll_opy_ (u"ࠦࠧࠨࠠࡃࡷ࡬ࡰࡩࠦࡴࡩࡧࠣࡘࡑ࡜࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣ࡭ࡳࡺࠠࡪࡰࡧࡩࡽࡀࠠࡕࡪࡨࠤ࡮ࡴࡤࡦࡺࠣࡻ࡮ࡺࡨࡪࡰࠣࡸ࡭࡫ࠠ࡬ࡧࡼ࠲ࠥࡏࡧ࡯ࡱࡵࡩࡩࠦࡷࡩࡧࡱࠤࡸ࡫ࡲࡪࡣ࡯࡭ࡿ࡯࡮ࡨ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤ࡮ࡴࡴࠡ࡭ࡨࡽ࡭ࡧࡳࡩ࠼ࠣࡘ࡭࡫ࠠ࠲࠸ࠣࡦ࡮ࡺࡳࠡࡱࡩࠤࡰ࡫ࡹࠡࡣࡷࠤࡹ࡮ࡥࠡࡵࡳࡩࡨ࡯ࡦࡪࡧࡧࠤ࡮ࡴࡤࡦࡺ࠱ࠤࡎ࡭࡮ࡰࡴࡨࡨࠥࡽࡨࡦࡰࠣࡷࡪࡸࡩࡢ࡮࡬ࡾ࡮ࡴࡧ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨ௩")
        if None is index:
            self.index = 255
        elif isinstance(index, int):
            if index > 255 or index < 0:
                raise ValueError(l11ll_opy_ (u"ࠬ࡯࡮ࡥࡧࡻࠤࡲࡻࡳࡵࠢࡥࡩࠥࡽࡩࡵࡪ࡬ࡲࠥ࠶ࠠࡢࡰࡧࠤ࠷࠻࠵࠭ࠢ࡬ࡷࠥࢁࡽࠨ௪")
                                 .format(index))
            self.index = index
        else:
            raise TypeError(l11ll_opy_ (u"࠭ࡩ࡯ࡦࡨࡼࠥࡳࡵࡴࡶࠣࡦࡪࠦࡩ࡯ࡶ࠯ࠤ࡮ࡹࠠࡼࡿࠪ௫").format(type(index)))
        if None is l1llll11lll_opy_:
            self.l1llll11lll_opy_ = 0
        elif isinstance(l1llll11lll_opy_, int):
            if l1llll11lll_opy_ < 0 or l1llll11lll_opy_ > 0xffff:
                raise ValueError(l11ll_opy_ (u"ࠧ࡬ࡧࡼ࡬ࡦࡹࡨࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡺ࡭ࡹ࡮ࡩ࡯ࠢ࠳ࠤࡦࡴࡤࠡ࠲ࡻࡪ࡫࡬ࡦ࠭ࠢ࡬ࡷࠥࢁࡽࠨ௬")
                                 .format(l1llll11lll_opy_))
            self.l1llll11lll_opy_ = l1llll11lll_opy_
        else:
            raise TypeError(l11ll_opy_ (u"ࠨ࡭ࡨࡽ࡭ࡧࡳࡩࠢࡰࡹࡸࡺࠠࡣࡧࠣ࡭ࡳࡺࠬࠡ࡫ࡶࠤࢀࢃࠧ௭").format(type(l1llll11lll_opy_)))
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        (index, l1llll11lll_opy_) = struct.unpack(l11ll_opy_ (u"ࠩࠤࡆࡍ࠭௮"), l111l1ll1l_opy_)
        return cls(index, l1llll11lll_opy_)
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠪࠥࡇࡎࠧ௯"), self.index, self.l1llll11lll_opy_)
class HopCountTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠦࠧࠨࠠࡕࡪࡨࠤ࡙ࡒࡖࠡࡵࡳࡩࡨ࡯ࡦࡺ࡫ࡱ࡫ࠥࡧࠠ࡮ࡧࡶࡷࡦ࡭ࡥࠨࡵࠣ࡬ࡴࡶࠠࡤࡱࡸࡲࡹ࠴ࠊࠡࠢࠣࠤࠧࠨࠢ௰")
    l1l11ll1ll_opy_ = 0x20
    def __repr__(self):
        return l11ll_opy_ (u"ࠬࡂࡈࡰࡲࡆࡳࡺࡴࡴࡕࡎ࡙࠾ࠥࡩ࡯ࡶࡰࡷࡁࢀࢃ࠾ࠨ௱").format(self.count)
    def __eq__(self, other):
        return isinstance(other, HopCountTLV) and self.count == other.count
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, count=None, l1llll11l11_opy_=None):
        l11ll_opy_ (u"ࠨࠢࠣࠢࡅࡹ࡮ࡲࡤࠡࡶ࡫ࡩ࡚ࠥࡌࡗࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤ࡮ࡴࡴࠡࡥࡲࡹࡳࡺ࠺ࠡࡖ࡫ࡩࠥࡴࡵ࡮ࡤࡨࡶࠥࡵࡦࠡࡪࡲࡴࡸࠦࠨࡢ࡮ࡶࡳࠥࡱ࡮ࡰࡹࡱࠤࡦࡹࠠࡵࡪࡨࠤ࡙࡚ࡌࠪࠢࡩࡳࡷࠦࡴࡩ࡫ࡶࠤࡲ࡫ࡳࡴࡣࡪࡩ࠳ࠦࡍࡢࡺ࡬ࡱࡺࡳࠠࡰࡨࠣ࠾ࡵࡿ࠺ࡰࡤ࡭࠾࡬ࡵࡔࡦࡰࡱࡥ࠳ࡩ࡯࡯ࡵࡷࡥࡳࡺࡳ࠯ࡏࡄ࡜ࡤࡎࡏࡑࡕࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲࠥࡎ࡯ࡱࡅࡲࡹࡳࡺࡔࡍࡘ࠽ࠤ࡙࡮ࡥࠡࡥࡲࡲࡸࡺࡲࡶࡥࡷࡩࡩࠦ࡯ࡣ࡬ࡨࡧࡹ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦ௲")
        if None is count:
            count = 0
        if None is l1llll11l11_opy_:
            l1llll11l11_opy_ = 0
        if not isinstance(count, int):
            raise TypeError(l11ll_opy_ (u"ࠧࡤࡱࡸࡲࡹࠦ࡭ࡶࡵࡷࠤࡧ࡫ࠠࡪࡰࡷ࠰ࠥ࡯ࡳࠡࡽࢀࠫ௳").format(type(count)))
        if 0 > count or count > 255:
            raise ValueError(l11ll_opy_ (u"ࠨࡥࡲࡹࡳࡺࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡤࡨࡸࡼ࡫ࡥ࡯ࠢ࠳ࠤࡦࡴࡤࠡ࠴࠸࠺࠱ࠦࡩࡴࠢࡾࢁࠬ௴")
                             .format(count))
        if not isinstance(count, int):
            raise TypeError(l11ll_opy_ (u"ࠩࡵࡷࡸ࡯ࠠ࡮ࡷࡶࡸࠥࡨࡥࠡ࡫ࡱࡸ࠱ࠦࡩࡴࠢࡾࢁࠬ௵").format(type(count)))
        try:
            _ = struct.pack(l11ll_opy_ (u"ࠪࡦࠬ௶"), count)
        except struct.error:
            raise ValueError(l11ll_opy_ (u"ࠫࡷࡹࡳࡪࠢࡰࡹࡸࡺࠠࡧ࡫ࡷࠤ࡮ࡴࠠࡰࡰࡨࠤࡸ࡯ࡧ࡯ࡧࡧࠤࡧࡿࡴࡦࠩ௷"))
        self.count = count
        self.l1llll11l11_opy_ = l1llll11l11_opy_
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        try:
            (count, l1llll11l11_opy_) = struct.unpack(l11ll_opy_ (u"ࠬࠧࡂࡣࠩ௸"), l111l1ll1l_opy_)
        except struct.error:
            (count,) = struct.unpack(l11ll_opy_ (u"࠭ࠡࡃࠩ௹"), l111l1ll1l_opy_)
            l1llll11l11_opy_ = None
        return cls(count, l1llll11l11_opy_)
    def serialize(self):
        if None is self.l1llll11l11_opy_:
            l1llll11l11_opy_ = 0
        else:
            l1llll11l11_opy_ = self.l1llll11l11_opy_
        if None is self.count:
            count = 0
        else:
            count = self.count
        return struct.pack(l11ll_opy_ (u"ࠧࠢࡄࡥࠫ௺"), count, l1llll11l11_opy_)
class PLITLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠣࠤࠥࠤࡆࠦࡔࡍࡘࠣࡷࡵ࡫ࡣࡪࡨࡼ࡭ࡳ࡭ࠠࡸࡪࡨࡸ࡭࡫ࡲࠡࡣࠣࡱࡪࡹࡳࡢࡩࡨࠤ࡮ࡹࠠࡱࡣࡵࡸࠥࡵࡦࠡࡣࠣࡷࡪࡺࠠࡰࡨࠣࡥࡺࡺ࡯࡮ࡣࡷ࡭ࡨࡧ࡬࡭ࡻࠣࡷࡨ࡮ࡥࡥࡷ࡯ࡩࡩࠦࡲࡦࡲࡨࡥࡹ࡯࡮ࡨࠢࡰࡩࡸࡹࡡࡨࡧࡶࠎࠥࠦࠠࠡࠤࠥࠦ௻")
    l1l11ll1ll_opy_ = 0x36
    def __repr__(self):
        return l11ll_opy_ (u"ࠩ࠿ࡔࡑࡏࡔࡍࡘ࠽ࠤ࡮ࡹ࡟ࡱ࡮࡬ࡁࢀࢃ࠾ࠨ௼").format(self.l1llll1l1l1_opy_)
    def __eq__(self, other):
        return isinstance(other, PLITLV) and self.l1llll1l1l1_opy_ == other.l1llll1l1l1_opy_
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, l1llll1l1l1_opy_=False):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡂࡶ࡫࡯ࡨࠥࡺࡨࡦࠢࡗࡐ࡛ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ௽")
        self.l1llll1l1l1_opy_ = l1llll1l1l1_opy_
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        (l1llllll1ll_opy_,) = struct.unpack(l11ll_opy_ (u"ࠫࠦࡈࠧ௾"), l111l1ll1l_opy_)
        return cls(bool(l1llllll1ll_opy_))
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠬࠧࡂࠨ௿"), self.l1llll1l1l1_opy_)
l11ll_opy_ (u"ࠨࠢࠣࠢࡄࠤࡱ࡯ࡳࡵࠢࡲࡪࠥࡧ࡬࡭ࠢࡷ࡬ࡪࠦࡔࡍࡘࡶࠤࡪࡾࡰࡦࡥࡷࡩࡩࠦࡩ࡯ࠢࡷ࡬ࡪࠦࡴࡰࡲࠣࡰࡪࡼࡥ࡭ࠢࡲࡪࠥࡧࠠ࡮ࡧࡶࡷࡦ࡭ࡥࠡࠤࠥࠦఀ")
ALL = [l111111l11_opy_ for l111111l11_opy_ in vars().values()
       if isinstance(l111111l11_opy_, type)
       and issubclass(l111111l11_opy_, basic_tlv.TLV)]