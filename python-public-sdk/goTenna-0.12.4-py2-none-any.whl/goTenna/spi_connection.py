# ~*~ coding: utf-8 ~*~
""" spi_device.py: A SPI interface for an embedded pro to the python driver.

This only works on a Linux device with a spidev interface. It runs a read thread that can select() on incoming data and provides a buffered interface to the driver.

In addition to the modules required by the goTenna SDK, it requires the spidev module.

It is inserted as the connection class used by the device driver and presents the same interface.

Copyright goTenna, Inc 2018
"""

import sys
import time
import select
import tempfile
import re
import threading
import logging
import collections
import subprocess
import io
import os
import ctypes
import array
import struct

import six
from six.moves import queue

import platform
if platform.system() == 'Linux':
    import fcntl
    import spidev
import goTenna

_MODULE_LOGGER = logging.getLogger(__name__)

ListedDevice = collections.namedtuple('ListedDevice',
                                      ('product', 'serial_number', 'identifier'))
#: A named tuple returned from :py:meth:`SpiConnection.list_devices`

class GPIOMonitor(object):
    """ Handler class for monitoring a GPIO on a linux system

    This handler class uses the character device interface described in https://github.com/torvalds/linux/blob/master/include/uapi/linux/gpio.h, rather than the legacy sysfs interface. It therefore may not be available on kernel versions before 4.6.
    """

    ChipInfo = collections.namedtuple('ChipInfo', ('name', 'label', 'lines'))
    #: A named tuple representing information about a GPIO chip
    #: name and label are strings that may be empty; lines is an int, the number
    #: of lines on the GPIO chip.

    LineInfo = collections.namedtuple('LineInfo', ('flags', 'name', 'consumer'))
    #: A named tuple representing information about a GPIO line.
    #: Flags is a list of string flags, name is a string that may be empty,
    #: consumer is a string that if not empty indicates who owns the line

    EventData = collections.namedtuple('EventData', ('timestamp', 'id'))
    #: A named tuple representing an event

    _CONSUMER_STRING = b'gt-embedded-pro-gpio-monitor'
    # These definitions for ioctl magics, flags, and structs are from
    # include/uapi/linux/gpio.h
    # (https://elixir.bootlin.com/linux/latest/source/include/uapi/linux/gpio.h)
    _GPIO_GET_CHIPINFO_IOCTL = 0x8044b401
    _GPIO_GET_LINEINFO_IOCTL = 0xc048b402
    _GPIO_GET_LINEHANDLE_IOCTL = 0xc16cb403
    _GPIO_GET_LINEEVENT_IOCTL = 0xc030b404
    _GPIOHANDLE_GET_LINE_VALUES_IOCTL = 0xc040b408
    _GPIOHANDLE_SET_LINE_VALUES_IOCTL = 0xc040b409

    _GPIOHANDLE_REQUEST_INPUT = 0x1
    _GPIOHANDLE_REQUEST_OUTPUT = 0x2
    _GPIOHANDLE_REQUEST_ACTIVE_LOW = 0x4
    _GPIOHANDLE_REQUEST_OPEN_DRAIN = 0x8
    _GPIOHANDLE_REQUEST_OPEN_SOURCE = 0x10

    handleflags = {'input': 0x1, 'output': 0x2,
                   'active_low': 0x4, 'open_drain': 0x8,
                   'open_source': 0x10}
    #: Names for the _GPIOHANDLE_REQUEST_* flags

    _GPIOEVENT_EVENT_RISING_EDGE = 0x1
    _GPIOEVENT_EVENT_FALLING_EDGE = 0x2

    eventflags = {'rising_edge': 0x1, 'falling_edge': 0x2}
    #: Names for the _GPIOEVENT_EVENT_* flags

    class _GPIOCHIP_INFO(ctypes.Structure):
        """ Used with the GPIO_GET_CHIPINFO_IOCTL to get info about a chip from /dev/gpiochipX"""
        _fields_ = [('name', type(ctypes.create_string_buffer(32))),
                    ('label', type(ctypes.create_string_buffer(32))),
                    ('lines', ctypes.c_uint32)]

    class _GPIOLINE_INFO(ctypes.Structure):
        """ used with the GPIO_GET_LINEINFO_IOCTL to get info about a line from /dev/gpiochipX """
        _fields_ = [('line_offset', ctypes.c_uint32),
                    ('flags', ctypes.c_uint32),
                    ('name', type(ctypes.create_string_buffer(32))),
                    ('consumer', type(ctypes.create_string_buffer(32)))]

    class _GPIOHANDLE_REQUEST(ctypes.Structure):
        """ Used with GPIO_GET_LINEHANDLE_IOCTL to get a GPIO line handle form /dev/gpiochipX """
        _fields_ = [('lineoffsets', ctypes.c_uint32*64),
                    ('flags', ctypes.c_uint32),
                    ('default_values', ctypes.c_uint8*64),
                    ('consumer_label', type(ctypes.create_string_buffer(32))),
                    ('lines', ctypes.c_uint32),
                    ('fd', ctypes.c_int)]

    class _GPIOHANDLE_DATA(ctypes.Structure):
        """ Used with GPIO_GET_LINE_VALUES_IOCTL and GPIO_SET"""
        _fields_ = [('values', ctypes.c_uint8 * 64)]

    class _GPIOEVENT_REQUEST(ctypes.Structure):
        """ Used with GPIO_GET_LINEEVENT_IOCTL """
        _fields_ = [('lineoffset', ctypes.c_uint32),
                    ('handleflags', ctypes.c_uint32),
                    ('eventflags', ctypes.c_uint32),
                    ('consumer_label', type(ctypes.create_string_buffer(32))),
                    ('fd', ctypes.c_int)]

    class _GPIOEVENT_DATA(ctypes.Structure):
        """ The return value when polling a file descriptor from GPIO_GET_LINEEVENT_IOCTL"""
        _fields_ = [('timestamp', ctypes.c_uint64),
                    ('id', ctypes.c_uint32)]

    @staticmethod
    def _buffer_backed_cstruct(ctypes_struct):
        """ Get a ctypes struct instance pair with a :py:class:`array.array` backing it for use with :py:meth:`fcntl.ioctl`

        :param class ctypes_struct: The struct to initialize
        :returns tuple(ctypes_struct, array.array): The struct object and the array backing it.
        """
        arr = array.array('B', [0]*ctypes.sizeof(ctypes_struct))
        obj = ctypes_struct.from_buffer(arr)
        return obj, arr

    @staticmethod
    def _set_line_value(handle, value):
        """ Set the values of the line in ``handle``

        :param handle: Either an open file-like object (as returned by :py:meth:`_get_line_handle`) or file descriptor representing the line handle.
        :type handle: int or io.FileIO
        :param bool value: The new value for the pin, as a logical value
        """
        handlefile = GPIOMonitor._get_chip_file_from_arg(handle)
        req_obj, req_arr\
            = GPIOMonitor._buffer_backed_cstruct(GPIOMonitor._GPIOHANDLE_DATA)
        req_obj.values[0] = int(value)
        fcntl.ioctl(handlefile, GPIOMonitor._GPIOHANDLE_GET_LINE_VALUES_IOCTL, req_arr, True)

    @staticmethod
    def _get_line_value(handle):
        """ Get the value of the line in ``handle``

        :param handle: Either an open file-like object (as returned by :py:meth:`_get_line_handle`) or file descriptor representing the line handle.
        :type handle: int or io.FileIO
        :returns bool: The state of the line, as a logical value
        """
        handlefile = GPIOMonitor._get_chip_file_from_arg(handle)
        req_obj, req_arr\
            = GPIOMonitor._buffer_backed_cstruct(GPIOMonitor._GPIOHANDLE_DATA)
        fcntl.ioctl(handlefile, GPIOMonitor._GPIOHANDLE_GET_LINE_VALUES_IOCTL, req_arr, True)
        return bool(req_obj.values[0])

    @staticmethod
    def _get_line_handle(chip, offset, flags, default=None):
        """ Get a handle fd to a line inside a chip

        :param chip: Either a path to a chip in /dev/ or an open file-lilke object or file descriptor for same.
        :type chip: int or str or io.RawIOBase
        :param list[str] flags: A list of keys of :py:attr:`GPIOMonitor.handleflags`. At least ``input`` or ``output`` must be specified (and both cannot be).
        :param bool default: If this is an output, the default value for the pin. Note that per the kernel conventions, this is a logical value, so if you set 'active_low' in the flags and default=True, the line will go low.

        :returns io.FileIO: The handle
        """
        req_obj, req_arr\
            = GPIOMonitor._buffer_backed_cstruct(GPIOMonitor._GPIOHANDLE_REQUEST)
        if ('input' not in flags and 'output' not in flags)\
           or ('input' in flags and 'output' in flags):
            raise ValueError('Must specify either input or output')
        for flag in flags:
            req_obj.flags |= GPIOMonitor.handleflags[flag]
        req_obj.lineoffsets[0] = offset
        if None is not default:
            req_obj.default_values[0] = int(default)
        req_obj.consumer_label = GPIOMonitor._CONSUMER_STRING
        req_obj.lines = 1
        chipfile = GPIOMonitor._get_chip_file_from_arg(chip)
        fcntl.ioctl(chipfile, GPIOMonitor._GPIO_GET_LINEHANDLE_IOCTL, req_arr, True)
        return io.FileIO(req_obj.fd, 'wb+')

    @staticmethod
    def _get_chipinfo(chip):
        """ Get information about a gpio chip

        :param chip: Either a path to a chip in /dev/ or an open file-lilke object or file descriptor for same.
        :type chip: int or str or io.RawIOBase

        :returns GPIOMonitor.ChipInfo:
        """
        req_obj, req_arr\
            = GPIOMonitor._buffer_backed_cstruct(GPIOMonitor._GPIOCHIP_INFO)
        chipfile = GPIOMonitor._get_chip_file_from_arg(chip)
        fcntl.ioctl(chipfile, GPIOMonitor._GPIO_GET_CHIPINFO_IOCTL, req_arr, True)
        return GPIOMonitor.ChipInfo(name=req_obj.name,
                                    label=req_obj.label,
                                    lines=req_obj.lines)

    @staticmethod
    def _get_lineinfo(chip, offset):
        """ Get information about a line on a chip.

        :param chip: Either a path to a chip in /dev/ or an open file-lilke object or file descriptor for same.
        :type chip: int or str or io.RawIOBase
        :param int offset: The GPIO line offset within the chip

        :returns LineInfo:
        """
        req_obj, req_arr\
            = GPIOMonitor._buffer_backed_cstruct(GPIOMonitor._GPIOLINE_INFO)
        req_obj.line_offset = offset
        chipfile = GPIOMonitor._get_chip_file_from_arg(chip)
        fcntl.ioctl(chipfile, GPIOMonitor._GPIO_GET_LINEINFO_IOCTL, req_arr, True)
        flagnames = []
        for flag_name, flag_val in GPIOMonitor.handleflags.items():
            if req_obj.flags & flag_val:
                flagnames.append(flag_name)
        return GPIOMonitor.LineInfo(flags=flagnames,
                                    name=req_obj.name,
                                    consumer=req_obj.consumer)


    @staticmethod
    def _get_line_event(chip, offset, event):
        """ Get a handle for a line event.

        Note that this handle can also be used with :py:meth:`_get_line_value`.

        :param chip: Either a path to a chip in /dev/ or an open file-like object or file descriptor for same.
        :type chip: int or str or io.RawIOBase
        :param int offset: The GPIO line offset within the chip

        :returns io.FileIO: An IO manager for the event
        """
        req_obj, req_arr\
            = GPIOMonitor._buffer_backed_cstruct(GPIOMonitor._GPIOEVENT_REQUEST)
        req_obj.lineoffset = offset
        req_obj.handleflags = GPIOMonitor._GPIOHANDLE_REQUEST_INPUT
        req_obj.eventflags = GPIOMonitor.eventflags[event]
        req_obj.consumer_label = GPIOMonitor._CONSUMER_STRING
        chipfile = GPIOMonitor._get_chip_file_from_arg(chip)
        fcntl.ioctl(chipfile, GPIOMonitor._GPIO_GET_LINEEVENT_IOCTL, req_arr, True)
        return io.FileIO(req_obj.fd, 'wb+')

    @staticmethod
    def _get_chip_file_from_arg(chip):
        """ Get an open io.FileIO from whatever ``chip`` happens to be

        The only special thing about this function is that if it gets a raw file descriptor, it will build an io.FileIO with closefd=False since it's assumed that the caller handles disposing of the fd.

        :param chip: A file descriptor, an IO, or a path
        :type chip: int or str or io.RawIOBase
        :returns io.FileIO:
        """
        if isinstance(chip, int):
            # If chip is already a fd, wrap it
            chipfile = io.FileIO(chip, closefd=False)
        elif isinstance(chip, io.IOBase):
            # If chip is already an io, that’s all we need
            chipfile = chip
        else:
            # Otherwise, try and open it
            chipfile = io.FileIO(chip, 'wb+')
        return chipfile


    def __init__(self, gpio_spec):
        """ Build the GPIO object.

        The GPIO object can be built from several different styles of input argument that are used depending on the configuration of the system (as defined by the person using this interface).

        :param gpio_spec: The GPIO to use. This should be either an int, in which case it is assumed to be an old-style 0-indexed GPIO number; or a tuple of either (str, int) or (str, str) in which case it is assumed to be a GPIO chip and line specification. This can be parsed several different ways.
        :type gpio_spec: int or tuple[str, int] or tuple[str, str]

        The gpio_spec is parsed depending on its type and the system configuration:
        - If gpio_spec is an int, it is assumed to be a GPIO number that starts at 0 _for the entire chip_, aka what would be passed into /sys/class/gpio/export. The GPIO class will walk the available chips in /dev/gpiochipX, querying how many lines each contains, to find the appropriate chip and line offset to configure.
        - If gpio_spec is a tuple, it is a tuple of ``(chip, line)``.
            - ``chip`` is always a string. If ``chip`` looks like ``'/dev/gpiochipX'`` or ``'gpiochipX'``, that chip is selected from ``/dev/``. If it does not, the available gpio chips are scanned to see if any name matches ``chip`` exactly. If no matching chip is found, :py:class:`OSError` is raised.
            - ``line`` may be either an int or a string. If ``line`` is an ``int``, it is a line offset within ``chip``. If ``line`` is a ``str``, the available lines in ``chip`` are enumerated and searched for a line whose name exactly matches ``line``. If no such line is found, :py:class:`OSError` is raised.
            """
        self._events = {}
        self._last_configured_direction = None
        self._last_configured_level = None
        if isinstance(gpio_spec, tuple):
            self.chip, self.offset = self._get_gpio_from_tuple(gpio_spec)
        elif isinstance(gpio_spec, int):
            self.chip, self.offset = self._get_gpio_from_int(gpio_spec)

    def __str__(self):
        return '<{}: {}-{}>'.format(self.__class__.__name__, self.chip, self.offset)

    @staticmethod
    def _gpio_chips():
        """ Get a sorted (by number) list of gpiochip devices in /dev/ """
        deventries = os.listdir('/dev/')
        return sorted([os.path.join('/dev/', entry)
                       for entry in deventries
                       if entry.startswith('gpiochip')],
                      key=lambda e: int(e.split('gpiochip')[1]))

    @staticmethod
    def _get_gpio_from_int(gpio_num):
        """ Return a (gpiochip path, line offset) tuple from a global GPIO num """
        chips = GPIOMonitor._gpio_chips()
        offset_remaining = gpio_num
        for chip in chips:
            chipinfo = GPIOMonitor._get_chipinfo(chip)
            if chipinfo.lines > offset_remaining:
                return (chip, offset_remaining)
            else:
                offset_remaining -= chipinfo.lines
        raise ValueError('Could not find line')

    @staticmethod
    def _get_chip_from_name(name):
        chips = GPIOMonitor._gpio_chips()
        for chip in chips:
            chipinfo = GPIOMonitor._get_chipinfo(chip)
            if chipinfo.name == name:
                return chip
        raise KeyError('No chip with name {}'.format(name))

    @staticmethod
    def _get_line_from_name(chip, name):
        chipinfo = GPIOMonitor._get_chipinfo(chip)
        for line in range(chipinfo.lines):
            lineinfo = GPIOMonitor._get_lineinfo(chip, line)
            if lineinfo.name == name:
                return line
        raise KeyError('No line with name {} in {}'.format(name, chip))

    @staticmethod
    def _get_gpio_from_tuple(gpio_tuple):
        if 'gpiochip' in gpio_tuple[0]:
            chip = gpio_tuple[0]
        else:
            chip = GPIOMonitor._get_chip_from_name(gpio_tuple[0])
        if isinstance(gpio_tuple[1], int):
            return (chip, gpio_tuple[1])
        else:
            return (chip, GPIOMonitor._get_line_from_name(chip, gpio_tuple[1]))

    def set_direction(self, direction, new_val=None):
        """ Set whether this is an in or out GPIO

        :param str direction: ``'input'`` or ``'output'``
        :param bool new_val: If direction is ``'output'``, the new default value
        """
        if direction not in ('input', 'output'):
            raise KeyError(direction)
        if direction != self._last_configured_direction:
            if direction == 'output':
                del self._events
                self._events = {}
            self._get_line_handle(self.chip, self.offset,
                                  [direction], new_val)
            self._last_configured_direction = direction

    def get_value(self):
        """ Get the value of the GPIO

        If any events are configured, this will use the handle of one of the events to prevent opening up yet another file descriptor.

        :returns bool: The value
        """
        if None is self._last_configured_direction:
            raise ValueError('Configure direction first')
        handle = None
        if self._events:
            for ev in self._events.values():
                if not ev: continue
                else:
                    handle = ev[-1]
                    break
        if not handle:
            handle = self._get_line_handle(self.chip, self.offset,
                                           [self._last_configured_direction],
                                           default=self._last_configured_level)
        return self._get_line_value(handle)

    def set_value(self, value):
        """ Set the value of the GPIO, if an output

        :param bool value: The new value
        """
        if self._last_configured_direction != 'output':
            raise ValueError('Configure direction to output first')
        self._get_line_handle(self.chip, self.offset, ['output'], value)
        self._last_configured_level = value

    def pollable_fd_for_event(self, event, new=False):
        # pylint: disable=line-too-long
        """ Get a file descriptor that can be used with :py:meth:`select.poll` to await an event

        :param str event: 'rising_edge' or 'falling_edge'
        :param bool new: Open a new file descriptor, even if one already exists
        :returns io.FileIO: The open 'file' (really, anonymous file descriptor). This is wrapped in a Python class so that the file descriptor will be closed when the object is destroyed.
        """
        # pylint: enable=line-too-long
        if self._last_configured_direction != 'input':
            raise ValueError('Configure direction to input first')
        if event not in ('rising_edge', 'falling_edge'):
            raise ValueError('Bad event name {}, should be rising_edge or falling_edge'
                             .format(event))
        if event in self._events and self._events[event] and not new:
            return self._events[event][-1]
        if event not in self._events:
            self._events[event] = []
        self._events[event].append(self._get_line_event(self.chip,
                                                        self.offset,
                                                        event))
        return self._events[event][-1]

    def await_event(self, event):
        """ Block until the specified event occurs

        :param str event: 'rising_edge' or 'falling_edge'
        """
        waitfd = self.pollable_fd_for_event(event)
        if (event == 'rising_edge' and self.get_value())\
           or (event == 'falling_edge' and not self.get_value()):
            return
        waitfd.read(ctypes.sizeof(self._GPIOEVENT_DATA))

class OsFifoSynchronizer(object):
    # pylint: disable=line-too-long
    """ A class that provides a basic shared os fifo interface for synchronization

    When built, this will create a fifo in a specified directory and open read and write ends that are available to callers. Its __del__ handles removing the fifo.

    This class is really only to store everything about a fifo in a coordinated way; it doesn't do much on its own beside providing the file like objects (really :py:class:`io.FileIO`) for the read and write sides of the fifo and ensuring that it is initialized and destroyed correctly.
    """
    # pylint: enable=line-too-long
    def __init__(self, directory, name):
        """ Initialize an OsFifoSynchronizer.

        :param str directory: The directory in which to place the fifo.
        :param str name: The name of the fifo (and by extension the synchronizer)
        """
        self._fifo_path = os.path.join(directory, name)
        os.mkfifo(self._fifo_path)
        self._read_side = io.FileIO(os.open(self._fifo_path,
                                            os.O_RDONLY | os.O_NONBLOCK),
                                    'rb')
        self._write_side = io.FileIO(os.open(self._fifo_path,
                                             os.O_WRONLY | os.O_NONBLOCK),
                                     'wb')
        self._name = name

    def __del__(self):
        if hasattr(self, '_read_side') and self._read_side:
            del self._read_side
        if hasattr(self, '_write_side') and self._write_side:
            del self._write_side
        if hasattr(self, '_fifo_path') and os.path.exists(self._fifo_path):
            os.unlink(self._fifo_path)

    def __str__(self):
        return '<{} {}, readfd={}, writefd={}>'.format(self.__class__.__name__,
                                                       self.name,
                                                       self._read_side.fileno(),
                                                       self._write_side.fileno())

    @property
    def name(self):
        """ The name of the fifo, suitable for logging or human consumption

        :returns str: The name
        """
        return self._name

    @property
    def write_side(self):
        """ The write side of the fifo, for signalling the read side to proceed

        :returns io.FileIO: The write fd for the fifo
        """
        return self._write_side

    @property
    def read_side(self):
        """ The read side of the fifo, for awaiting with os interfaces

        :returns io.FileIO: The read fd for the fifo
        """
        return self._read_side

class SpiConnection(threading.Thread):
    # pylint: disable=line-too-long
    """ A class that emulates the USB connection class :py:class:`goTenna.pcb_connection.GoTennaPCB` and connects via SPI to a goTenna Embedded Pro.

    Because this is emulating a _class_, it provides a __call__ method (that for a class would be the method that creates new instances) that returns itself.

    However, necessary system resources are acquired in the initializer because only one SpiConnection can talk to a specific goTenna Embedded Pro.

    The SpiConnection creates a worker thread to handle the asynchronous responses from the remote device, triggered on assertion of its nRDY pin. Writes (through :py:meth:`write_binary`) are put on a :py:class:`queue.Queue` and are serviced as they come in; reads (through :py:meth:`read_binary`) read from a queue that is fed by the worker thread when the remote device sends data.

    This implementation is linux-only because of its requirement on fifo(7) (http://man7.org/linux/man-pages/man7/fifo.7.html), poll(2) (http://man7.org/linux/man-pages/man2/poll.2.html), the spidev userspace interface (https://www.kernel.org/doc/Documentation/spi/spidev), and the character device based userspace GPIO interface (https://elixir.bootlin.com/linux/latest/source/include/uapi/linux/gpio.h, though this can be changed with a different ``gpio_class``, e.g. one that uses the legacy sysfs based userspace GPIO interface).

    Because of the use of the linux userspace gpio interface, which provides 'interrupt' capability through poll(2), the SpiConnection relies on file descriptors that can be used with poll(2) for most of its synchronization primitives. This allows the worker thread to use a single :py:class:`select.poll` object to wait for _any_ of the required events in a single wait, which is otherwise surprisingly hard to do from python.
    """
    # pylint: enable=line-too-long
    CLOCKRATE = 1000000
    _LOGGER = _MODULE_LOGGER.getChild('SpiConnection')

    def __init__(self, bus, chip, req_gpio, rdy_gpio, gpio_class=GPIOMonitor):
        # pylint: disable=line-too-long
        """ Create a SpiConnection and acquire the system resources necessary.

        This init method is used to create a SpiConnection ahead of time that is set as the _connection_class of a goTenna.driver.Driver.

        :param int bus: The bus number (X in /dev/spidevX.Y)
        :param int chip: The chip select number (Y in /dev/spidevX.Y)
        :param req_gpio: The GPIO number for the request pin. This can either be anything that the ``gpio_class`` initializer supports, or an instance of the ``gpio_class``.
        :param rdy_gpio: This can either be anything that the ``gpio_class`` initializer supports, or an instance of the ``gpio_class``.
        :param class gpio_class: An class to instantiate for GPIO handling. This should look like :py:class:`SpiConnection.GPIO`. The argument is provided in case the driver is to be used on a kernel version prior to 4.6 which does not provide the chardev GPIO ABI.
        """
        # pylint: enable=line-too-long
        if not sys.platform.startswith('linux'):
            raise OSError('The SpiConnection driver only works on linux')
        self._seq_id = 0
        self._spi = self._ensure_spidev(bus, chip)
        self._req, self._rdy = self._configure_gpio(req_gpio, rdy_gpio, gpio_class)
        self._LOGGER.info("gpios initialized: rdy={}, req={}"
                          .format(self._rdy, self._req))
        self._write_queue = queue.Queue()
        self._read_queue = queue.Queue()
        self._temp_dir = tempfile.mkdtemp()
        self._LOGGER.info("tempdir for fifos: {}".format(self._temp_dir))
        self._write_fifo = OsFifoSynchronizer(self._temp_dir, 'write')
        self._quit_fifo = OsFifoSynchronizer(self._temp_dir, 'quit')
        self._LOGGER.info("fifos established: {} {}".format(self._write_fifo,
                                                            self._quit_fifo))
        self._poller = select.poll()
        self._poller.register(self._write_fifo.read_side.fileno(),
                              select.POLLIN)
        self._poller.register(self._rdy.pollable_fd_for_event('falling_edge'),
                              select.POLLIN)
        self._poller.register(self._quit_fifo.read_side.fileno(),
                              select.POLLIN)
        self._awaiting_read = False
        self._running = False
        threading.Thread.__init__(self)
        self._LOGGER.info("Initialized")

    def __call__(self, port, timeout=10, force=False):
        self._timeout = timeout
        if not self._running:
            self.start()
            self._LOGGER.info("SPI connection started")
        return self

    def __del__(self):
        """ Custom deleter that handles ordering properly for os resources """
        if hasattr(self, '_poller') and self._poller:
            del self._poller
        if hasattr(self, '_write_fifo') and self._write_fifo:
            del self._write_fifo
        if hasattr(self, '_quit_fifo') and self._quit_fifo:
            del self._quit_fifo
        if hasattr(self, '_temp_dir') and self._temp_dir and os.path.exists(self._temp_dir):
            os.rmdir(self._temp_dir)

    @staticmethod
    def _ensure_spidev(bus, chip):
        # pylint: disable=line-too-long
        """ An initialization helper that builds the SPIdev processor.

        :note: This method also attempts to ensure that spidev is present even if unloaded on system start.
        """
        # pylint: enable=line-too-long
        mods = subprocess.check_output('lsmod')
        if not re.search(six.b('spidev'), mods):
            subprocess.check_call(['modprobe', 'spidev'])
            time.sleep(0.2)
            mods = subprocess.check_output('lsmod')
            if not re.search(six.b('spidev'), mods):
                raise OSError('spidev is not activated and could not be modprobed')
        spi = spidev.SpiDev()
        spi.open(bus, chip)
        spi.max_speed_hz = 1000000
        spi.cshigh = False
        spi.lsbfirst = False
        spi.mode = 3
        return spi

    @staticmethod
    def _configure_gpio(req, rdy, gpio_class):
        """ An initialization helper that parses the GPIO inputs.

        :returns tuple[gpio_class, gpio_class]: The initialized (req, rdy) GPIOs
        """
        if isinstance(req, gpio_class):
            _req = req
        else:
            _req = gpio_class(req)
        _req.set_direction('input')
        if isinstance(rdy, gpio_class):
            _rdy = rdy
        else:
            _rdy = gpio_class(rdy)
        _rdy.set_direction('input')
        return _req, _rdy

    def _await_rdy(self):
        """ Block until the remote is ready to communicate.

        """
        # See if we already are in the right level
        if not self._rdy.get_value():
            return
        # Otherwise await the edge
        self._rdy.await_event('falling_edge')

    def _read(self):
        """ Execute a pending read request from the remote.

        :returns bytes: The data read from the remote
        """
        self._LOGGER.debug("read: awaiting pre-rx-header ready")
        self._await_rdy()
        self._LOGGER.debug("read: sending rx header")
        # Write the zero header
        self._spi.writebytes([0, 0])
        self._LOGGER.debug("read: awaiting pre-rx-header ready")
        self._await_rdy()
        self._LOGGER.debug("read: reading header")
        # Read the number of bytes to read
        read_header = six.b('').join(six.int2byte(b)
                                     for b in self._spi.readbytes(2))
        to_read = struct.unpack('!H', read_header)[0]
        if to_read > 400:
            self._LOGGER.warning("Very large read ({}B)detected, may be interference"
                                 .format(to_read))
        self._LOGGER.debug("read: awaiting pre-data ready")
        self._await_rdy()
        self._LOGGER.debug("read: reading data")
        data = self._spi.readbytes(to_read)
        data_bytestring = six.b('').join([six.int2byte(d) for d in data])
        return data_bytestring


    @staticmethod
    def _bytes_to_intlist(bytes_in):
        return [six.byte2int(b) for b in bytes_in]

    def _write(self, to_write):
        self._LOGGER.debug("write: awaiting pre-header ready")
        self._await_rdy()
        self._LOGGER.debug("write: sending header")
        # Write the tx header
        self._spi.writebytes(self._bytes_to_intlist(struct.pack('!H', len(to_write))))
        self._LOGGER.debug("write: awaiting pre-data ready")
        self._await_rdy()
        self._LOGGER.debug("write: sending data")
        # Write the tx data
        self._spi.writebytes(self._bytes_to_intlist(to_write))
        self._LOGGER.debug("write: done")

    def stop(self):
        """ Stop the worker thread and, if called from a different thread, join() it"""
        self._quit_fifo.write_side.write(six.b('q'))
        self._LOGGER.info("SPI connection stopping")
        try:
            self.join()
        except RuntimeError:
            self._LOGGER.exception("Joining SPI connection from callback")

    def _run(self):
        # pylint: disable=line-too-long
        """ The method that does the work of the SpiConnection.

        This method waits for the various fifos (see :py:class:`SpiConnection` for the reason we rely on OS fifos rather than Python native thread communication constructs) and does whatever events are ready to process.
        """
        # pylint: enable=line-too-long
        while True:
            should_read = not self._req.get_value()
            should_write = False
            if not (should_read or should_write):
                events = self._poller.poll()
                self._LOGGER.debug('Events ready: {}'.format(events))
                for event in events:
                    if event[0] == self._quit_fifo.read_side.fileno():
                        return
                    elif event[0] == self._write_fifo.read_side.fileno():
                        self._write_fifo.read_side.read(1)
                        should_write = True
                    elif event[0] == self._rdy.pollable_fd_for_event('falling_edge'):
                        self._rdy.pollable_fd_for_event('falling_edge').read()
                        should_read = True
            if should_read:
                data = self._read()
                if self._awaiting_read:
                    self._read_queue.put(data)
                    self._awaiting_read = False

            if should_write:
                self._awaiting_read = True
                self._write(self._write_queue.get())

    def run(self):
        # pylint: disable=line-too-long
        """ The main method run in the worker thread.

        This method just calls :py:meth:`_run` and catches exceptions; for more information see :py:meth:`_run`.
        """
        # pylint: enable=line-too-long
        self._running = True
        try:
            self._run()
        # Catch all exceptions so we can log them before python swallows them
        except Exception as caught_except: # pylint: disable=broad-except
            self._LOGGER.exception("Uncaught exception in SpiConnection")
            raise caught_except
        finally:
            self._running = False
            self._LOGGER.info("SPI connection done")

    def write_binary(self, message_bytes):
        """ Write a binary message to the device.

        :param bytes message_bytes: The message to write.
        """
        seqid = six.int2byte(self.next_seqid)
        if len(message_bytes) > 1:
            message_bytes = message_bytes[:1] + seqid + message_bytes[1:]
        else:
            message_bytes = message_bytes + seqid
        self._write_queue.put(message_bytes)
        self._write_fifo.write_side.write(six.b(' '))

    def read_binary_blocking(self, timeout_override=None,
                             interstitial_sleeps=None):
        """ Read a binary message from the device.

        Blocks until a message is available.

        :returns bytes: The message read from the device.
        """
        if timeout_override:
            timeout = timeout_override
        else:
            timeout = self._timeout
        try:
            return self._read_queue.get(True, timeout)
        except six.moves.queue.Empty:
            raise goTenna.constants.TimeoutException('read', timeout)

    @property
    def next_seqid(self):
        self._seq_id += 1
        if self._seq_id > 255:
            self._seq_id = 0
        return self._seq_id

    @staticmethod
    def list_devices():
        return [goTenna.pcb_connection.ListedDevice('pro', 'MXP123456789',
                                                    '/dev/spidev/x.y')]

