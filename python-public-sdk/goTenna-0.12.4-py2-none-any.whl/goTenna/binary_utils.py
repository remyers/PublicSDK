# coding: utf8
import sys
l1111_opy_ = sys.version_info [0] == 2
l1lll1_opy_ = 2048
l1ll1_opy_ = 7
def l11ll_opy_ (l1_opy_):
    global l1llll_opy_
    l11l1l_opy_ = ord (l1_opy_ [-1])
    l111l_opy_ = l1_opy_ [:-1]
    l1ll_opy_ = l11l1l_opy_ % len (l111l_opy_)
    l1l1_opy_ = l111l_opy_ [:l1ll_opy_] + l111l_opy_ [l1ll_opy_:]
    if l1111_opy_:
        l1ll1l_opy_ = unicode () .join ([unichr (ord (char) - l1lll1_opy_ - (l1l11_opy_ + l11l1l_opy_) % l1ll1_opy_) for l1l11_opy_, char in enumerate (l1l1_opy_)])
    else:
        l1ll1l_opy_ = str () .join ([chr (ord (char) - l1lll1_opy_ - (l1l11_opy_ + l11l1l_opy_) % l1ll1_opy_) for l1l11_opy_, char in enumerate (l1l1_opy_)])
    return eval (l1ll1l_opy_)
# Copyright (C) 2018 goTenna, Inc. This file is distributed as part of the
# goTenna USB SDK. See the associated license for more information.
# pylint: disable=line-too-long
l11ll_opy_ (u"ࠦࠧࠨࠊࠡࡤ࡬ࡲࡦࡸࡹࡠࡷࡷ࡭ࡱࡹࠠ࠮ࠢࡄࠤࡲࡵࡤࡶ࡮ࡨࠤࡨࡵ࡬࡭ࡧࡦࡸ࡮ࡴࡧࠡࡷࡶࡩ࡫ࡻ࡬ࠡࡨࡸࡲࡨࡺࡩࡰࡰࡶࠤࡦࡴࡤࠡࡥࡲࡲࡸࡺࡡ࡯ࡶࡶࠤ࡫ࡵࡲࠡࡤ࡬ࡲࡦࡸࡹࠡࡥࡲࡱࡲࡻ࡮ࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡹ࡬ࡸ࡭ࠦࡡࠡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࠍࠎࡈࡵࡰࡺࡴ࡬࡫࡭ࡺࠠ࠳࠲࠴࠻ࠥ࡭࡯ࡕࡧࡱࡲࡦࠦࡉ࡯ࡥ࠱ࠎࠧࠨࠢࠀ")
# pylint: enable=line-too-long
import binascii
import struct
import six
import goTenna.settings
import goTenna.util
l1l1l_opy_ = six.b(l11ll_opy_ (u"ࠬࢄࠧࠁ"))
l11ll_opy_ (u"ࠨࠢࠣࠢࡗ࡬ࡪࠦ࡭ࡢࡩ࡬ࡧࠥࡩࡨࡢࡴࡤࡧࡹ࡫ࡲࠡࡶࡲࠤࡵࡸࡥࡱࡧࡱࡨࠥࡺ࡯ࠡࡤ࡬ࡲࡦࡸࡹࠡ࡯ࡨࡷࡸࡧࡧࡦࡵࠣࠦࠧࠨࠂ")
l1l1l1_opy_ = {
    l11ll_opy_ (u"ࠧࡦࡥ࡫ࡳࠬࠃ"): six.b(l11ll_opy_ (u"ࠨ࡞ࡻ࠴࠵࠭ࠄ")),
    l11ll_opy_ (u"ࠩࡶࡩࡹࡥࡧࡪࡦࠪࠅ"): six.b(l11ll_opy_ (u"ࠪࡠࡽ࠶࠱ࠨࠆ")),
    l11ll_opy_ (u"ࠫࡸ࡫ࡴࡠࡲࡸࡦࡱ࡯ࡣࡠ࡭ࡨࡽࠬࠇ"): six.b(l11ll_opy_ (u"ࠬࡢࡸ࠱࠴ࠪࠈ")),
    l11ll_opy_ (u"࠭ࡳࡦࡰࡧࡣࡲ࡫ࡳࡴࡣࡪࡩࠬࠉ"): six.b(l11ll_opy_ (u"ࠧ࡝ࡺ࠳࠷ࠬࠊ")),
    l11ll_opy_ (u"ࠨࡩࡨࡸࡤࡹࡹࡴࡡ࡬ࡲ࡫ࡵࠧࠋ"): six.b(l11ll_opy_ (u"ࠩ࡟ࡼ࠵࠺ࠧࠌ")),
    l11ll_opy_ (u"ࠪ࡫ࡪࡺ࡟ࡴࡶࡲࡶࡪࡪ࡟ࡪࡰࡩࡳࠬࠍ"): six.b(l11ll_opy_ (u"ࠫࡡࡾ࠰࠶ࠩࠎ")),
    l11ll_opy_ (u"ࠬ࡭ࡥࡵࡡࡩ࡭ࡷࡹࡴࡠࡵࡷࡳࡷ࡫ࡤࡠ࡯ࡨࡷࡸࡧࡧࡦࠩࠏ"): six.b(l11ll_opy_ (u"࠭࡜ࡹ࠲࠹ࠫࠐ")),
    l11ll_opy_ (u"ࠧࡥࡧ࡯ࡩࡹ࡫࡟ࡧ࡫ࡵࡷࡹࡥࡳࡵࡱࡵࡩࡩࡥ࡭ࡦࡵࡶࡥ࡬࡫ࠧࠑ"): six.b(l11ll_opy_ (u"ࠨ࡞ࡻ࠴࠼࠭ࠒ")),
    l11ll_opy_ (u"ࠩ࡬ࡲ࡮ࡺࡩࡢࡶࡨࡣࡳ࡫ࡷࡠࡨࡺࡣ࡮ࡳࡡࡨࡧࠪࠓ"): six.b(l11ll_opy_ (u"ࠪࡠࡽ࠶࠸ࠨࠔ")),
    l11ll_opy_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡥࡦࡸࡡ࡬ࡱࡦ࡭ࡥࠨࠕ"): six.b(l11ll_opy_ (u"ࠬࡢࡸ࠱࠻ࠪࠖ")),
    l11ll_opy_ (u"࠭ࡦࡪࡰࡤࡰ࡮ࢀࡥࡠࡨࡺࡣ࡮ࡳࡡࡨࡧࠪࠗ"): six.b(l11ll_opy_ (u"ࠧ࡝ࡺ࠳ࡥࠬ࠘")),
    l11ll_opy_ (u"ࠨࡴࡨࡷࡪࡺ࡟ࡨ࡫ࡧࠫ࠙"): six.b(l11ll_opy_ (u"ࠩ࡟ࡼ࠵ࡨࠧࠚ")),
    l11ll_opy_ (u"ࠪࡨ࡮ࡹࡣࡰࡰࡱࡩࡨࡺ࡟ࡣ࡮ࡸࡩࡹࡵ࡯ࡵࡪࠪࠛ"): six.b(l11ll_opy_ (u"ࠫࡡࡾ࠰ࡤࠩࠜ")),
    l11ll_opy_ (u"ࠬࡪࡥ࡭ࡧࡷࡩࡤ࡭ࡩࡥࠩࠝ"): six.b(l11ll_opy_ (u"࠭࡜ࡹ࠲ࡧࠫࠞ")),
    l11ll_opy_ (u"ࠧࡢࡰࡷࡩࡳࡴࡡࡠࡵࡺࡩࡪࡶࠧࠟ"): six.b(l11ll_opy_ (u"ࠨ࡞ࡻ࠴ࡪ࠭ࠠ")),
    l11ll_opy_ (u"ࠩࡳࡹࡱࡲ࡟ࡥࡧࡹ࡭ࡨ࡫࡟ࡢ࡮ࡨࡶࡹ࠭ࠡ"): six.b(l11ll_opy_ (u"ࠪࡠࡽ࠶ࡦࠨࠢ")),
    l11ll_opy_ (u"ࠫࡸ࡫ࡴࡠࡣࡳࡴࡤ࡯ࡤࠨࠣ"): six.b(l11ll_opy_ (u"ࠬࡢࡸ࠲࠲ࠪࠤ")),
    l11ll_opy_ (u"࠭ࡳࡦࡶࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡣࡲࡵࡤࡦࠩࠥ"): six.b(l11ll_opy_ (u"ࠧ࡝ࡺ࠴࠵ࠬࠦ")),
    l11ll_opy_ (u"ࠨࡩࡨࡸࡤࡨࡩ࡯ࡣࡵࡽࡤࡲ࡯ࡨࠩࠧ"): six.b(l11ll_opy_ (u"ࠩ࡟ࡼ࠶࠸ࠧࠨ")),
    l11ll_opy_ (u"ࠪࡧࡱ࡫ࡡࡳࡡࡤࡰࡱࡥ࡬ࡰࡩࠪࠩ"): six.b(l11ll_opy_ (u"ࠫࡡࡾ࠱࠴ࠩࠪ")),
    l11ll_opy_ (u"ࠬࡹࡥ࡯ࡦࡢࡴࡦࡩ࡫ࡦࡶࡶࠫࠫ"): six.b(l11ll_opy_ (u"࠭࡜ࡹ࠳࠷ࠫࠬ")),
    l11ll_opy_ (u"ࠧࡣ࡮ࡨࡣࡧ࡫ࡲࠨ࠭"): six.b(l11ll_opy_ (u"ࠨ࡞ࡻ࠵࠺࠭࠮")),
    l11ll_opy_ (u"ࠩࡶࡸࡷࡥࡤࡢࡶࡨࡣࡹ࡯࡭ࡦࠩ࠯"): six.b(l11ll_opy_ (u"ࠪࡠࡽ࠷࠶ࠨ࠰")),
    l11ll_opy_ (u"ࠫࡹࡸࡸࡠࡲࡲࡻࡪࡸࡳࡢࡸ࡬ࡲ࡬࠭࠱"): six.b(l11ll_opy_ (u"ࠬࡢࡸ࠲࠹ࠪ࠲")),
    l11ll_opy_ (u"࠭ࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦࡢࡪࡼࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ࠳"): six.b(l11ll_opy_ (u"ࠧ࡝ࡺ࠴࠼ࠬ࠴")),
    l11ll_opy_ (u"ࠨࡪࡤࡶࡩࡥࡲࡦࡵࡨࡸࠬ࠵"): six.b(l11ll_opy_ (u"ࠩ࡟ࡼ࠶࠿ࠧ࠶")),
    l11ll_opy_ (u"ࠪࡶࡪࡹࡥࡵࡡࡳࡹࡧࡲࡩࡤࡡ࡮ࡩࡾ࠭࠷"): six.b(l11ll_opy_ (u"ࠫࡡࡾ࠱ࡢࠩ࠸")),
    l11ll_opy_ (u"ࠬࡹࡥࡵࡡࡳࡶࡴࡶࡥࡳࡶࡼࠫ࠹"): six.b(l11ll_opy_ (u"࠭࡜ࡹ࠳ࡥࠫ࠺")),
    l11ll_opy_ (u"ࠧࡴࡧࡷࡣࡷࡻ࡮ࡵ࡫ࡰࡩࡤࡶࡲࡰࡲࡨࡶࡹࡿࠧ࠻"): six.b(l11ll_opy_ (u"ࠨ࡞ࡻ࠵ࡨ࠭࠼")),
    l11ll_opy_ (u"ࠩࡪࡩࡹࡥࡲࡶࡰࡷ࡭ࡲ࡫࡟ࡱࡴࡲࡴࡪࡸࡴࡺࠩ࠽"): six.b(l11ll_opy_ (u"ࠪࡠࡽ࠷ࡤࠨ࠾")),
    l11ll_opy_ (u"ࠫࡸࡺࡡࡳࡶࡢࡦࡦࡩ࡫ࡨࡴࡲࡹࡳࡪ࡟ࡧࡹࡢࡹࡵࡪࡡࡵࡧࠪ࠿"): six.b(l11ll_opy_ (u"ࠬࡢࡸ࠲ࡧࠪࡀ")),
    l11ll_opy_ (u"࠭ࡧࡦࡶࡢࡷࡹࡧࡴࡴࠩࡁ"): six.b(l11ll_opy_ (u"ࠧ࡝ࡺ࠴ࡪࠬࡂ")),
    l11ll_opy_ (u"ࠨࡴࡨࡷࡪࡺ࡟ࡴࡶࡤࡸࡸ࠭ࡃ"): six.b(l11ll_opy_ (u"ࠩ࡟ࡼ࠷࠶ࠧࡄ")),
    l11ll_opy_ (u"ࠪࡷࡪࡺ࡟ࡨࡧࡲࡣ࡫࡫࡮ࡤ࡫ࡱ࡫ࠬࡅ"): six.b(l11ll_opy_ (u"ࠫࡡࡾ࠲࠲ࠩࡆ")),
    l11ll_opy_ (u"ࠬ࡭ࡥࡵࡡࡪࡩࡴࡥࡦࡦࡰࡦ࡭ࡳ࡭ࠧࡇ"): six.b(l11ll_opy_ (u"࠭࡜ࡹ࠴࠵ࠫࡈ")),
    l11ll_opy_ (u"ࠧࡳࡵࡶ࡭ࠬࡉ"): six.b(l11ll_opy_ (u"ࠨ࡞ࡻ࠶࠸࠭ࡊ")),
    l11ll_opy_ (u"ࠩࡵࡷࡸ࡯࡟࡭࡫ࡶࡸࡪࡴࠧࡋ"): six.b(l11ll_opy_ (u"ࠪࡠࡽ࠸࠴ࠨࡌ")),
    l11ll_opy_ (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡵ࡫ࡲࡵࡻࠪࡍ"): six.b(l11ll_opy_ (u"ࠬࡢࡸ࠳࠷ࠪࡎ")),
    l11ll_opy_ (u"࠭ࡧࡦࡶࡢࡪࡦࡻ࡬ࡵࡡ࡬ࡲ࡫ࡵࠧࡏ"): six.b(l11ll_opy_ (u"ࠧ࡝ࡺ࠵࠺ࠬࡐ")),
    l11ll_opy_ (u"ࠨࡩࡨࡸࡤࡪࡤࡪࠩࡑ"): six.b(l11ll_opy_ (u"ࠩ࡟ࡼ࠷࠽ࠧࡒ")),
    l11ll_opy_ (u"ࠪࡷࡹࡵࡲࡦࡡࡨࡱࡪࡸࡧࡦࡰࡦࡽࠬࡓ"): six.b(l11ll_opy_ (u"ࠫࡡࡾ࠲ࡤࠩࡔ")),
}
def l111_opy_(l11lll_opy_):
    l11ll_opy_ (u"ࠧࠨࠢࠡࡆࡨࡸࡪࡸ࡭ࡪࡰࡨࠤ࡮࡬ࠠࡢࠢࡥࡽࡹ࡫ࠠࡪࡵࠣࡥࠥࡔࡁࡌࠢࡲࡶࠥࡇࡃࡌࠌࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡪࡰࡷࠤࡨࡳࡤࡠࡤࡼࡸࡪࡀࠠࡂࠢࡥࡽࡹ࡫ࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶ࡬ࡲ࡬ࠦࡴࡩࡧࠣࡧࡴࡳ࡭ࡢࡰࡧࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲࡸࠦࡢࡰࡱ࡯࠾࡚ࠥࡲࡶࡧࠣ࡭࡫ࠦࡴࡩࡧࠣࡥࡷ࡭ࡵ࡮ࡧࡱࡸࠥ࡯ࡳࠡࡣࠣࡒࡆࡑ࠮ࠋࠌࠣࠤࠥࠦࡔࡩࡧࠣࡦࡾࡺࡥࠡ࡫ࡶࠤࡦࠦࡎࡂࡍࠣ࡭࡫ࠦࡢࡪࡶࠣ࠻ࠥ࡯ࡳࠡࡵࡨࡸ࠳ࠐࠠࠡࠢࠣࠦࠧࠨࡕ")
    return (l11lll_opy_ & 0x80) != 0
def ll_opy_(l11lll_opy_):
    l11ll_opy_ (u"ࠨࠢࠣࠢࡇࡩࡹ࡫ࡲ࡮࡫ࡱࡩࠥ࡯ࡦࠡࡣࠣࡦࡾࡺࡥࠡ࡫ࡶࠤࡦࡴࠠࡂࡅࡎࠤࡴࡸࠠࡏࡃࡎࠎࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢ࡬ࡲࡹࠦࡣ࡮ࡦࡢࡦࡾࡺࡥ࠻ࠢࡄࠤࡧࡿࡴࡦࠢࡵࡩࡵࡸࡥࡴࡧࡱࡸ࡮ࡴࡧࠡࡶ࡫ࡩࠥࡩ࡯࡮࡯ࡤࡲࡩࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴࡳࠡࡤࡲࡳࡱࡀࠠࡕࡴࡸࡩࠥ࡯ࡦࠡࡶ࡫ࡩࠥࡧࡲࡨࡷࡰࡩࡳࡺࠠࡪࡵࠣࡥࡳࠦࡁࡄࡍ࠱ࠎࠥࠦࠠࠡࠤࠥࠦࡖ")
    return not l111_opy_(l11lll_opy_)
def l1lll_opy_(l11lll_opy_):
    l11ll_opy_ (u"ࠢࠣࠤࠣࡖࡪࡺࡵࡳࡰࠣࡸ࡭࡫ࠠࡤࡱࡰࡱࡦࡴࡤࠡࡹ࡬ࡸ࡭ࡵࡵࡵࠢࡷ࡬ࡪࠦࡁࡄࡍ࠲ࡒࡆࡑࠠࡣ࡫ࡷࡷࠥࠦࠢࠣࠤࡗ")
    return l11lll_opy_ & 0x3f
def l1l1ll_opy_(text):
    l11ll_opy_ (u"ࠣࠤࠥࠤ࡜ࡸࡡࡱࠢࡤࠤࡵࡧࡹ࡭ࡱࡤࡨࠥ࡯࡮ࠡࡶ࡫ࡩࠥ࡫ࡸࡵࡴࡤࡷࠥࡸࡥࡲࡷ࡬ࡶࡪࡪࠠࡧࡱࡵࠤࡧ࡯࡮ࡢࡴࡼࠤࡨࡵ࡭࡮ࡷࡱ࡭ࡨࡧࡴࡪࡱࡱࠎࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡥࡽࡹ࡫ࡳ࡭࡫࡮ࡩࠥࡺࡥࡹࡶ࠽ࠤࡘࡵ࡭ࡦࡶ࡫࡭ࡳ࡭ࠠࡵࡪࡤࡸࠥࡲ࡯ࡰ࡭ࡶࠤࡱ࡯࡫ࡦࠢࡤࠤࡸ࡫ࡱࡶࡧࡱࡧࡪࠦࡡ࡯ࡦࠣࡻࡴࡴࠧࡵࠢࡨࡼࡵࡲ࡯ࡥࡧࠣࡻ࡭࡫࡮ࠡࡧࡹࡩࡳࡺࡵࡢ࡮࡯ࡽࠥࡹࡥ࡯ࡶࠣࡸࡴࠦࡴࡩࡧࠣࡨࡪࡼࡩࡤࡧࠍࠤࠥࠦࠠࠣࠤࠥࡘ")
    l1l_opy_ = goTenna.util.ensure_bytes(text)
    l1l111_opy_ = l1l1l_opy_ + struct.pack(l11ll_opy_ (u"ࠩࠤࡌ࡙ࠬ"), len(l1l_opy_)+2) + l1l_opy_
    l1l111_opy_ += struct.pack(l11ll_opy_ (u"ࠪࠥࡍ࡚࠭"), binascii.crc_hqx(l1l111_opy_, 0))
    return l1l111_opy_
def l11ll1_opy_(sdk_key, gid, membership=None, l11l1_opy_=False):
    l11ll_opy_ (u"ࠦࠧࠨࠠࡑࡣࡦ࡯ࠥࡧࠠ࠻ࡲࡼ࠾ࡦࡺࡴࡳ࠼ࡣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡊࡆࡣࠤ࡮ࡴࡴࡰࠢࡤࠤࡧࡻࡦࡧࡧࡵࠤࡸࡻࡩࡵࡣࡥࡰࡪࠦࡦࡰࡴࠣࡹࡸ࡯࡮ࡨࠢࡺ࡭ࡹ࡮ࠠࡨ࡫ࡧࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥࡳࡥࡵࡪࡲࡨࡸࠐࠊࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡸࡺࡲࡪࡰࡪࠤࡸࡪ࡫ࡠ࡭ࡨࡽ࠿ࠦࡔࡩࡧࠣࡗࡉࡑࠠ࡬ࡧࡼࠤࡹ࡮ࡥࠡࡉࡌࡈࠥ࡯ࡳࠡࡣࡶࡷࡴࡩࡩࡢࡶࡨࡨࠥࡽࡩࡵࡪ࠱ࠤ࡜࡯࡬࡭ࠢࡥࡩࠥࡩࡨࡦࡥ࡮ࡩࡩࠦࡦࡰࡴࠣࡺࡦࡲࡩࡥ࡫ࡷࡽ࠳ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡊࡆࠣ࡫࡮ࡪ࠺ࠡࡖ࡫ࡩࠥࡍࡉࡅࠢࡷࡳࠥࡶࡡࡤ࡭ࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡮ࡧࡰࡦࡪࡸࡳࡩ࡫ࡳ࠾ࠥࡕࡰࡵ࡫ࡲࡲࡦࡲࠠ࡮ࡧࡰࡦࡪࡸࡳࡩ࡫ࡳࠤࡳࡻ࡭ࡣࡧࡵ࠲ࠥࡏࡦࠡࡰࡲࡸࠥࡶࡲࡦࡵࡨࡲࡹ࠲ࠠࡈࡋࡇࠤ࡮ࡹࠠࡢࡵࡶࡹࡲ࡫ࡤࠡࡶࡲࠤࡵࡸࡩࡷࡣࡷࡩ࠳ࠦࡉࡧࠢࡳࡶࡪࡹࡥ࡯ࡶ࠯ࠤࡌࡏࡄࠡ࡫ࡶࠤࡦࡹࡳࡶ࡯ࡨࡨࠥࡺ࡯ࠡࡤࡨࠤࡦࠦࡧࡳࡱࡸࡴࠥࡍࡉࡅ࠰ࠍࠤࠥࠦࠠ࠻ࡶࡼࡴࡪࠦ࡭ࡦ࡯ࡥࡩࡷࡹࡨࡪࡲ࠽ࠤࡓࡵ࡮ࡦࠢࡲࡶࠥ࡯࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡢࡰࡱ࡯ࠤࡸࡱࡩࡱࡡࡰࡩࡲࡨࡥࡳࡵ࡫࡭ࡵࡀࠠࡡࡢࡗࡶࡺ࡫ࡠࡡࠢ࡬ࡪࠥࡺࡨࡦࠢࡰࡩࡲࡨࡥࡳࡵ࡫࡭ࡵࠦࡳࡩࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡦࡪࠦࡳࡦࡰࡷࠤ࠭ࡧࡳࠡ࡫ࡱࠤࡼ࡮ࡥ࡯ࠢࡧࡩࡱ࡫ࡴࡪࡰࡪࠤࡦࠦࡇࡊࡆࠬ࠿ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡪࡶࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡦࡪࠦࡳࡦࡰࡷ࠲ࠏࠦࠠࠡࠢ࠽ࡶࡦ࡯ࡳࡦࡵࠣࡘࡾࡶࡥࡆࡴࡵࡳࡷࡀࠠࡪࡨࠣ࡫࡮ࡪࠠࡪࡵࠣࡲࡴࡺࠠࡵࡪࡨࠤࡵࡸ࡯ࡱࡧࡵࠤࡹࡿࡰࡦࠌࠣࠤࠥࠦ࠺ࡳࡣ࡬ࡷࡪࡹࠠࡗࡣ࡯ࡹࡪࡋࡲࡳࡱࡵ࠾ࠥ࡯ࡦࠡࡕࡇࡏࠥࡱࡥࡺࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡹࡥࡱ࡯ࡤࠋࠢࠣࠤࠥࡀࡲࡦࡶࡸࡶࡳࡹࠠࡣࡻࡷࡩࡸࡀࠊࠡࠢࠣࠤࠧࠨ࡛ࠢ")
    if not isinstance(gid, goTenna.settings.GID):
        raise TypeError(gid)
    l1l11l_opy_ = six.b(l11ll_opy_ (u"ࠬ࠷ࡶ࠲ࡦࡤ࠸࡯࠾࠳࠺࠵࠴࠴ࡧࡵࡨࡥࡨࡪࡱ࠼ࡰࡱ࠸࠸ࡲ࠻ࡹ࠼࠳ࡥࡳࡶ࡮ࡲ࠹࠷ࡴ࠲ࡹ࠴ࡺࡩࡳ࠱ࡦࡱࡶࠬ࡜"))
    checker = goTenna.encryption.sdk_token_valid(sdk_key)
    _, l11_opy_ = checker(l1l11l_opy_[::-1])
    if None is membership:
        membership = 0
    l11l_opy_ = struct.pack(l11ll_opy_ (u"࠭ࠡࡃࡊࠪ࡝"), gid.gid_type, l11_opy_)
    l1ll11_opy_ = struct.pack(l11ll_opy_ (u"ࠧࠢࡓࠪ࡞"), gid.gid_val)[2:]
    command = l11l_opy_ + l1ll11_opy_
    if not l11l1_opy_:
        command += struct.pack(l11ll_opy_ (u"ࠨࠣࡅࠫ࡟"), membership)
    return command