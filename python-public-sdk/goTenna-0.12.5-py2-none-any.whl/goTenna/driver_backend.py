# coding: utf8
from __future__ import print_function
import sys
l1111_opy_ = sys.version_info [0] == 2
l1lll1_opy_ = 2048
l1ll1_opy_ = 7
def l11ll_opy_ (l1_opy_):
    global l1llll_opy_
    l11l1l_opy_ = ord (l1_opy_ [-1])
    l111l_opy_ = l1_opy_ [:-1]
    l1ll_opy_ = l11l1l_opy_ % len (l111l_opy_)
    l1l1_opy_ = l111l_opy_ [:l1ll_opy_] + l111l_opy_ [l1ll_opy_:]
    if l1111_opy_:
        l1ll1l_opy_ = unicode () .join ([unichr (ord (char) - l1lll1_opy_ - (l1l11_opy_ + l11l1l_opy_) % l1ll1_opy_) for l1l11_opy_, char in enumerate (l1l1_opy_)])
    else:
        l1ll1l_opy_ = str () .join ([chr (ord (char) - l1lll1_opy_ - (l1l11_opy_ + l11l1l_opy_) % l1ll1_opy_) for l1l11_opy_, char in enumerate (l1l1_opy_)])
    return eval (l1ll1l_opy_)
# Copyright (C) 2018 goTenna, Inc. This file is distributed as part of the
# goTenna USB SDK. See the associated license for more information.
# pylint: disable=line-too-long
l11ll_opy_ (u"ࠧࠨࠢࠡࡦࡵ࡭ࡻ࡫ࡲࡠࡤࡤࡧࡰ࡫࡮ࡥࠢ࡬ࡷࠥࡧࠠ࡮ࡱࡧࡹࡱ࡫ࠠࡤࡱࡱࡸࡦ࡯࡮ࡪࡰࡪࠤࡹ࡮ࡥࠡ࠼ࡳࡽ࠿ࡩ࡬ࡢࡵࡶ࠾ࡥࡊࡲࡪࡸࡨࡶࡇࡧࡣ࡬ࡧࡱࡨࡥ࠴ࠊࠋࡖ࡫࡭ࡸࠦࡳࡦࡲࡤࡶࡦࡺࡥࡴࠢࡶࡳࡲ࡫ࠠࡰࡨࠣࡸ࡭࡫ࠠࡣࡣࡦ࡯ࡪࡴࡤࠡ࡮ࡲ࡫࡮ࡩࠠࡰࡨࠣࡸ࡭࡫ࠠࡥࡴ࡬ࡺࡪࡸࠠࡧࡴࡲࡱࠥࡀࡰࡺ࠼ࡰࡳࡩࡀࡠࡨࡱࡗࡩࡳࡴࡡ࠯ࡦࡵ࡭ࡻ࡫ࡲࡡࠢࡷࡳࠥࡩࡵࡵࠢࡧࡳࡼࡴࠠࡰࡰࠣࡸ࡭࡫ࠠࡴࡪࡨࡩࡷࠦࡶࡰ࡮ࡸࡱࡪࠦ࡯ࡧࠢࡦࡳࡩ࡫ࠠࡪࡰࠣࡸ࡭ࡧࡴࠡ࡯ࡲࡨࡺࡲࡥ࠯ࠢࡌࡸࠥ࡯ࡳࠡࡣࠣࡦ࡮ࡺࠠࡰࡨࠣࡥࡳࠦࡡࡸ࡭ࡺࡥࡷࡪࠠࡵࡴࡤࡲࡸ࡯ࡴࡪࡱࡱ࠰ࠥ࡮࡯ࡸࡧࡹࡩࡷࡀࠠ࡮ࡣࡱࡽࠥࡵࡦࠡࡶ࡫ࡩࠥ࡯࡮ࡴࡶࡤࡲࡨ࡫ࠠࡷࡣࡵ࡭ࡦࡨ࡬ࡦࡵࠣࡨࡪ࡬ࡩ࡯ࡧࡧࠤ࡭࡫ࡲࡦࠢࡤࡶࡪࠦ࡯࡯࡮ࡼࠤࡦࡩࡣࡦࡵࡶ࡭ࡧࡲࡥࠡࡶ࡫ࡶࡴࡻࡧࡩࠢࡷ࡬ࡪࠦࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࠣࡨࡪ࡬ࡩ࡯ࡧࡧࠤࡴࡴࠠ࠻ࡲࡼ࠾ࡨࡲࡡࡴࡵ࠽ࡤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡪࡲࡪࡸࡨࡶ࠳ࡊࡲࡪࡸࡨࡶࡥ࠲ࠠࡢࡰࡧࠤࡼ࡮ࡩ࡭ࡧࠣࡸ࡭࡯ࡳࠡࡥ࡯ࡥࡸࡹࠠࡥࡱࡨࡷࠥࡴ࡯ࡵࠢࡨࡺࡪࡸࠠࡤࡣ࡯ࡰࠥࡪ࡯ࡸࡰࠣࡸࡴࠦ࠺ࡱࡻ࠽ࡧࡱࡧࡳࡴ࠼ࡣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡩࡸࡩࡷࡧࡵ࠲ࡉࡸࡩࡷࡧࡵࡤ࠱ࠦࡩࡵࠢࡧࡳࡪࡹࠠࡤࡣ࡯ࡰࠥࡺ࡯ࠡ࠼ࡳࡽ࠿ࡩ࡬ࡢࡵࡶ࠾ࡥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡤࡳ࡫ࡹࡩࡷ࠴ࡅࡷࡧࡱࡸࡥࠦࡷࡩ࡫ࡦ࡬ࠥ࡯ࡳࠡ࡫ࡱࠤࡹ࡮ࡥࠡࡱࡷ࡬ࡪࡸࠠ࡮ࡱࡧࡹࡱ࡫࠮ࠋࠤࠥࠦਕ")
# pylint: enable=line-too-long
import threading
import datetime
import time
import traceback
import logging
import six
import six.moves
import copy
import uuid
import goTenna
_MODULE_LOGGER = logging.getLogger(__name__)
class DriverBackend(threading.Thread):
    l11ll_opy_ (u"ࠨࠢࠣࠢࡓࡶ࡮ࡼࡡࡵࡧࠣࡱࡪࡺࡨࡰࡦࡶࠤࡦࡴࡤࠡࡷࡷ࡭ࡱ࡯ࡴࡪࡧࡶࠤ࡫ࡵࡲࠡ࠼ࡳࡽ࠿ࡩ࡬ࡢࡵࡶ࠾ࡥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡤࡳ࡫ࡹࡩࡷ࠴ࡄࡳ࡫ࡹࡩࡷࡦࠊࠋࠢࠣࠤ࡚ࠥࡨࡦࡵࡨࠤࡦࡲ࡬ࠡ࡮࡬ࡺࡪࠦࡨࡦࡴࡨࠤࡸࡵࠠࡵࡪࡨࠤࡩࡸࡩࡷࡧࡵࠤࡨࡲࡡࡴࡵࠣ࡭ࡸࡴࠧࡵࠢࡨࡼࡹࡸࡥ࡮ࡧ࡯ࡽࠥࡲ࡯࡯ࡩࠣࡥࡳࡪࠠࡪ࡯ࡳࡳࡸࡹࡩࡣ࡮ࡨࠤࡹࡵࠠ࡯ࡣࡹ࡭࡬ࡧࡴࡦ࠰ࠍࠤࠥࠦࠠࠣࠤࠥਖ")
    _LOGGER = _MODULE_LOGGER.getChild(l11ll_opy_ (u"ࠧࡅࡴ࡬ࡺࡪࡸࠧਗ"))
    l11ll11ll1_opy_ = l11ll_opy_ (u"ࠨ࠻࠳࠴ࠬਘ")
    #: The device type for the goTenna 900
    l11l1111l1_opy_ = l11ll_opy_ (u"ࠩࡳࡶࡴ࠭ਙ")
    #: The device type for the goTenna l1ll11ll1l_opy_
    DEVICE_TYPES = (l11ll11ll1_opy_, l11l1111l1_opy_)
    #: The l11l1l1l11_opy_ device types
    def __init__(self, sdk_token, gid, settings, event_callback,
                 poll_frequency=None, do_automatic_connect=True,
                 device_blacklist=tuple(), device_whitelist=tuple(), device_types=tuple(),
                 shortname=l11ll_opy_ (u"ࠪࠫਚ"), storage=None):
        self._connected = False
        goTenna.encryption.sdk_token_valid(sdk_token)
        self.sdk_token = goTenna.util.ensure_bytes(sdk_token)
        self._port = None
        self._device_type = None
        if None is settings:
            self._settings = goTenna.settings.GoTennaSettings(rf_settings=None, geo_settings=None)
        else:
            if not isinstance(settings, goTenna.settings.GoTennaSettings):
                raise TypeError(l11ll_opy_ (u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸࠦ࡭ࡶࡵࡷࠤࡧ࡫ࠠࡨࡱࡗࡩࡳࡴࡡ࠯ࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡴ࡚ࡥ࡯ࡰࡤࡗࡪࡺࡴࡪࡰࡪࡷ࠱ࠦࡩࡴࠢࡾࢁࠬਛ")
                                .format(type(settings)))
            self._settings = settings
        self._encryption_manager = None
        if None is storage:
            self._storage = goTenna.storage.EncryptedFileStorage(sdk_token)
        else:
            if not isinstance(storage, goTenna.storage.StorageInterface):
                raise TypeError(l11ll_opy_ (u"ࠬࡹࡴࡰࡴࡤ࡫ࡪࠦ࡭ࡶࡵࡷࠤࡧ࡫ࠠࡴࡷࡥࡧࡱࡧࡳࡴࠢࡲࡪࠥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡳࡵࡱࡵࡥ࡬࡫࠮ࡔࡶࡲࡶࡦ࡭ࡥࡊࡰࡷࡩࡷ࡬ࡡࡤࡧ࠯ࠤ࡮ࡹࡻࡾࠩਜ")
                                .format(type(storage)))
            self._storage = storage
        if gid:
            if not isinstance(gid, goTenna.settings.GID):
                raise TypeError(l11ll_opy_ (u"࠭ࡧࡪࡦࠣࡱࡺࡹࡴࠡࡤࡨࠤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡋࡇ࠰ࠥ࡯ࡳࠡࡽࢀࠫਝ")
                                .format(type(gid)))
            if gid.gid_type != goTenna.settings.GID.PRIVATE:
                raise ValueError(l11ll_opy_ (u"ࠧࡨ࡫ࡧࠤࡲࡻࡳࡵࠢࡥࡩࠥࡶࡲࡪࡸࡤࡸࡪ࠲ࠠࡪࡵࠣࡿࢂ࠭ਞ")
                                 .format(goTenna.settings.GID.type_name(gid.gid_type)))
        self._gid = None
        self._set_gid(gid)
        self.device = None
        self.quit_event = threading.Event()
        self.l11l11l11l_opy_ = six.moves.queue.Queue()
        if poll_frequency:
            if not isinstance(poll_frequency, datetime.timedelta):
                raise TypeError(poll_frequency)
            self.poll_frequency = poll_frequency
        else:
            self.poll_frequency = datetime.timedelta(seconds=2)
        self.l11l11l1l1_opy_ = datetime.datetime.now()
        self.l11ll1l11l_opy_ = self.l11l11l1l1_opy_
        self.l11l1l1lll_opy_ = datetime.timedelta(seconds=60)
        self.l11l11lll1_opy_ = 999
        self._11l111ll1_opy_(reset=True)
        self._present_devices = set()
        if not device_blacklist:
            device_blacklist = set()
        self._blacklisted_serials = set(device_blacklist)
        if not device_whitelist:
            device_whitelist = set()
        self._whitelisted_serials = set(device_whitelist)
        if not device_types:
            device_types = set((self.l11l1111l1_opy_, self.l11ll11ll1_opy_))
        if not all([dt in self.DEVICE_TYPES for dt in device_types]):
            raise KeyError(l11ll_opy_ (u"ࠣࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡧࡩࡻ࡯ࡣࡦࠢࡷࡽࡵ࡫ࠠࡪࡰࠣࡿࢂࠨਟ").format(device_types))
        self._device_types = set(device_types)
        self._do_automatic_connect = bool(do_automatic_connect)
        self._manual_connect_request = (None, None)
        self._force_device_list_recheck = False
        self._message_counter = 0
        self._shortname = l11ll_opy_ (u"ࠩࠪਠ")
        self.set_shortname(shortname)
        self._device_specifics = {
            self.l11l1111l1_opy_: {
                l11ll_opy_ (u"ࠪࡧࡴࡴ࡮ࡦࡥࡷࠫਡ"): self._11ll1l111_opy_,
                l11ll_opy_ (u"ࠫࡸ࡫ࡴࡶࡲࠪਢ"): self._11ll1l1ll_opy_,
                l11ll_opy_ (u"ࠬࡩࡡ࡯ࡡࡦࡳࡳࡴࡥࡤࡶࠪਣ"): self._11l11l111_opy_,
                l11ll_opy_ (u"࠭ࡡࡤ࡭ࡢ࡬ࡦࡴࡤ࡭ࡧࡵࠫਤ"): self._11l1l1l1l_opy_,
                l11ll_opy_ (u"ࠧࡳࡧࡷࡶࡾࡥࡰࡢࡶࡷࡩࡷࡴࠧਥ"): [1, 3, 6, 6],
                l11ll_opy_ (u"ࠨࡩࡵࡳࡺࡶ࡟ࡩࡱࡳࠫਦ") : 6,
                l11ll_opy_ (u"ࠩࡥࡧࡦࡹࡴࡠࡪࡲࡴࠬਧ") : 6,
                l11ll_opy_ (u"ࠪࡩࡲࡸࡧࡤࡡ࡫ࡳࡵ࠭ਨ") : 6,
            },
            self.l11ll11ll1_opy_: {
                l11ll_opy_ (u"ࠫࡨࡵ࡮࡯ࡧࡦࡸࠬ਩"): self._11l1l1ll1_opy_,
                l11ll_opy_ (u"ࠬࡹࡥࡵࡷࡳࠫਪ"): self._11ll1ll1l_opy_,
                l11ll_opy_ (u"࠭ࡣࡢࡰࡢࡧࡴࡴ࡮ࡦࡥࡷࠫਫ"): self._11l1ll1l1_opy_,
                l11ll_opy_ (u"ࠧࡢࡥ࡮ࡣ࡭ࡧ࡮ࡥ࡮ࡨࡶࠬਬ"): self._11l1l11ll_opy_,
                l11ll_opy_ (u"ࠨࡴࡨࡸࡷࡿ࡟ࡱࡣࡷࡸࡪࡸ࡮ࠨਭ"): [1, 3, 6, 6],
                l11ll_opy_ (u"ࠩࡪࡶࡴࡻࡰࡠࡪࡲࡴࠬਮ") : 6,
                l11ll_opy_ (u"ࠪࡦࡨࡧࡳࡵࡡ࡫ࡳࡵ࠭ਯ") : 6,
                l11ll_opy_ (u"ࠫࡪࡳࡲࡨࡥࡢ࡬ࡴࡶࠧਰ") : 6,
            }
        }
        self._device_info = {l11ll_opy_ (u"ࠬ࡬ࡷࡠࡸࡨࡶࡸ࡯࡯࡯ࠩ਱"): (None, None, None),
                             l11ll_opy_ (u"࠭ࡳࡦࡴ࡬ࡥࡱ࠭ਲ"): None,
                             l11ll_opy_ (u"ࠧࡣ࡮ࡸࡩࡹࡵ࡯ࡵࡪࡢࡩࡳࡧࡢ࡭ࡧࡧࠫਲ਼"): None,
                             l11ll_opy_ (u"ࠨࡤࡤࡸࡹ࡫ࡲࡺࡡࡳࡩࡷࡩࡥ࡯ࡶࡤ࡫ࡪ࠭਴"): None,
                             l11ll_opy_ (u"ࠩࡷࡩࡲࡶࡥࡳࡣࡷࡹࡷ࡫ࠧਵ"): None}
        if not hasattr(event_callback, l11ll_opy_ (u"ࠪࡣࡤࡩࡡ࡭࡮ࡢࡣࠬਸ਼")):
            raise TypeError(l11ll_opy_ (u"ࠫࡪࡼࡥ࡯ࡶࡢࡧࡦࡲ࡬ࡣࡣࡦ࡯ࠥࡳࡵࡴࡶࠣࡦࡪࠦࡣࡢ࡮࡯ࡥࡧࡲࡥ࠭ࠢ࡬ࡷࠥࢁࡽࠨ਷")
                            .format(event_callback))
        self.event_callback = event_callback
        self.device = None
        self._11l1l111l_opy_ = datetime.datetime.now()
        self._11l1lll11_opy_ = {}
        self._device_type = None
        self._1ll1lll_opy_ = None
        threading.Thread.__init__(self, None, l11ll_opy_ (u"ࠬ࡭࡯ࡕࡧࡱࡲࡦࠦࡓࡅࡍࠪਸ"))
    @property
    def _connection_class(self):
        return goTenna.pcb_connection.l11ll1lll_opy_
    @property
    def _11l111l11_opy_(self):
        return {
            #l11ll_opy_ (u"࠭ࡳࡦࡰࡧࡣࡵࡸࡩࡷࡣࡷࡩࠬਹ"): 1.0,
            #l11ll_opy_ (u"ࠧࡴࡧࡱࡨࡤࡨࡲࡰࡣࡧࡧࡦࡹࡴࠨ਺"): 1.0,
            #l11ll_opy_ (u"ࠨࡵࡨࡲࡩࡥࡧࡳࡱࡸࡴࠬ਻"): 1.0
        }
    def _11l111l1l_opy_(self, l1111111_opy_):
        self.l11ll11111_opy_ += 1
        self._11l111111_opy_(l1111111_opy_)
        self._11l1lll11_opy_[l1111111_opy_].l1lll1l1_opy_()
    def _11ll111l1_opy_(self, msg):
        l1111111_opy_ = msg.payload.sender
        self._11l111111_opy_(l1111111_opy_)
        self._11l1lll11_opy_[l1111111_opy_].l111ll1_opy_(msg)
    def _111llll1l_opy_(self, msg):
        l1111111_opy_ = msg.payload.sender
        self._11l111111_opy_(l1111111_opy_)
        self._11l1lll11_opy_[l1111111_opy_].l1l111ll_opy_(msg)
    def _11l111111_opy_(self, l1111111_opy_, start=False):
        if l1111111_opy_ not in self._11l1lll11_opy_:
            def _11ll11l11_opy_(*args, **kwargs):
                if kwargs.get(l11ll_opy_ (u"ࠩࡶࡹࡨࡩࡥࡴࡵ਼ࠪ"), False):
                    self._encryption_manager.l1lll11111_opy_(*kwargs[l11ll_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪ਽")])
                del self._11l1lll11_opy_[l1111111_opy_]
            l11111l11_opy_ = self._encryption_manager.l1llll1l1l_opy_
            context = goTenna.util.l1ll1l1ll_opy_(l1111111_opy_, l11111l11_opy_,
                                                      _11ll11l11_opy_, self)
            self._11l1lll11_opy_[l1111111_opy_] = context
            if start:
                context.l1lll1l1_opy_()
    def _maybe_start_key_exchange(self, l1111111_opy_):
        if l1111111_opy_ not in self._11l1lll11_opy_:
            self._11l111l1l_opy_(l1111111_opy_)
    def _enqueue_message_in_key_exchange(self, l1111111_opy_, retryer):
        self._11l1lll11_opy_[l1111111_opy_].l11lllll_opy_(retryer)
    def _local_disconnect(self, reason):
        if self._connected:
            self._disconnect(goTenna.constants.ErrorCodes.NONE, reason)
        else:
            self._LOGGER.warning(l11ll_opy_ (u"ࠫࡒࡧ࡮ࡶࡣ࡯ࠤࡩ࡯ࡳࡤࡱࡱࡲࡪࡩࡴࠡࡴࡨࡵࡺ࡫ࡳࡵࠢ࡬࡫ࡳࡵࡲࡦࡦ࠽ࠤࡳࡵࡴࠡࡥࡲࡲࡳ࡫ࡣࡵࡧࡧࠫਾ"))
    def _11l11111l_opy_(self):
        try:
            temperature = self._device_info[l11ll_opy_ (u"ࠬࡹࡹࡴࡶࡨࡱࡤࡺࡥ࡮ࡲࡨࡶࡦࡺࡵࡳࡧࠪਿ")]
            battery = self._device_info[l11ll_opy_ (u"࠭ࡢࡢࡶࡷࡩࡷࡿ࡟ࡱࡧࡵࡧࡪࡴࡴࡢࡩࡨࠫੀ")]
        except Exception: # pylint: disable=broad-except
            self._LOGGER.exception(l11ll_opy_ (u"ࠧࡆࡴࡵࡳࡷࠦࡧࡦࡶࡷ࡭ࡳ࡭ࠠࡥࡧࡹ࡭ࡨ࡫ࠠࡴࡶࡤࡸࡺࡹࠡࠨੁ"))
        else:
            event = goTenna.driver.Event(goTenna.driver.Event.STATUS,
                                         status={l11ll_opy_ (u"ࠨࡤࡤࡸࡹ࡫ࡲࡺࠩੂ"): battery,
                                                 l11ll_opy_ (u"ࠩࡷࡩࡲࡶࡥࡳࡣࡷࡹࡷ࡫ࠧ੃"): temperature})
            goTenna.util.l1llll1l1_opy_(self.event_callback,
                                    l11ll_opy_ (u"ࠪࡉࡻ࡫࡮ࡵࠢࡦࡥࡱࡲࡢࡢࡥ࡮ࠤ࡫ࡵࡲࠡࡦࡨࡺ࡮ࡩࡥࠡࡵࡷࡥࡹࡻࡳࠨ੄"),
                                    self._LOGGER,
                                    event)
    def _disconnect(self, code, reason):
        self._connected = False
        del self.device
        self.device = None
        while not self.l11l11l11l_opy_.empty():
            self.l11l11l11l_opy_.get()
            self.l11l11l11l_opy_.task_done()
        self._port = None
        self._device_type = None
        self._1ll1lll_opy_ = None
        self._11ll11l1l_opy_(code, reason)
    def _11ll11l1l_opy_(self, code, reason):
        self._LOGGER.info(l11ll_opy_ (u"ࠫࡉ࡯ࡳࡤࡱࡱࡲࡪࡩࡴࡪࡰࡪࠤ࡫ࡸ࡯࡮ࠢࡧࡩࡻ࡯ࡣࡦ࠼ࠣࡿࢂࡀࠠࡼࡿࠪ੅")
                          .format(code, reason))
        event = goTenna.driver.Event(goTenna.driver.Event.DISCONNECT,
                                     disconnect_code=code,
                                     disconnect_reason=reason)
        goTenna.util.l1llll1l1_opy_(self.event_callback,
                                l11ll_opy_ (u"ࠬࡋࡶࡦࡰࡷࠤࡨࡧ࡬࡭ࡤࡤࡧࡰࠦࡦࡰࡴࠣࡨ࡮ࡹࡣࡰࡰࡱࡩࡨࡺࡩࡰࡰࠪ੆"),
                                self._LOGGER,
                                event)
    def _11l11l111_opy_(self):
        return None is not self._gid\
            and None is not self._settings\
            and self._settings.rf_settings_valid
    def _11l1ll1l1_opy_(self):
        return None is not self._gid \
            and None is not self._settings\
            and self._settings.geo_settings_valid
    def _11ll1l111_opy_(self, port):
        if not self.can_connect:
            return
        return goTenna.device.l1ll11ll1l_opy_(self._gid, self.sdk_token, port,
                                  self._encryption_manager.l11l1l111_opy_)
    def _11l1l1ll1_opy_(self, port):
        if not self.can_connect:
            return
        return goTenna.device.l1ll1l1lll_opy_(self._gid, self.sdk_token, port,
                                   self._encryption_manager.l11l1l111_opy_)
    def _11ll1l1ll_opy_(self):
        self.device.l1l1ll11ll_opy_(self._storage.groups.values(), self._settings.rf_settings)
    def _11ll1ll1l_opy_(self):
        self.device.l1l1ll11ll_opy_(self._storage.groups.values(), self._settings.geo_settings)
    def _11l1l1l1l_opy_(self):
        return goTenna.util.l11llll_opy_(self._settings.rf_settings.bandwidth.bitrate)
    def _11l1l11ll_opy_(self):
        return goTenna.util.l11llll_opy_(goTenna.constants.MESH_BITRATE)
    def _11l111lll_opy_(self, device, force=False):
        if not self.can_connect:
            self._LOGGER.warning(l11ll_opy_ (u"࠭ࡃࡢࡰࡱࡳࡹࠦࡣࡰࡰࡱࡩࡨࡺࠡࠨੇ"))
            return
        if device.product == self.l11l1111l1_opy_:
            device_type = self.l11l1111l1_opy_
        elif device.product == self.l11ll11ll1_opy_:
            device_type = self.l11ll11ll1_opy_
        else:
            self._LOGGER.error(l11ll_opy_ (u"ࠧࡄࡣࡱࡲࡴࡺࠠࡤࡱࡱࡲࡪࡩࡴ࠻ࠢࡸࡲࡰࡴ࡯ࡸࡰࠣࡨࡪࡼࡩࡤࡧࠣࡴࡷࡵࡤࡶࡥࡷࠤࢀࢃࠡࠨੈ").format(device.product))
            return
        l1ll1l1l11_opy_ = self._connection_class(device.identifier, force=force)
        self.device = self._device_specifics[device_type][l11ll_opy_ (u"ࠨࡥࡲࡲࡳ࡫ࡣࡵࠩ੉")](l1ll1l1l11_opy_)
        try:
            self._device_specifics[device_type][l11ll_opy_ (u"ࠩࡶࡩࡹࡻࡰࠨ੊")]()
            if not self.device.device_info[l11ll_opy_ (u"ࠪࡼࡤ࡫࡮ࡢࡤ࡯ࡩࠬੋ")]:
                if device.product == self.l11l1111l1_opy_ and \
                   isinstance(l1ll1l1l11_opy_, goTenna.pcb_connection.l11ll1lll_opy_):
                    self._LOGGER.error(l11ll_opy_ (u"ࠫࡘࡊࡋࠡࡰࡲࡸࠥࡹࡵࡱࡲࡲࡶࡹ࡫ࡤ࠭ࠢࡱࡳࡹࠦࡘ࠮ࡦࡨࡺ࡮ࡩࡥࠡࡲࡵࡳࡩࡻࡣࡵࠢࡾࢁࠦ࠭ੌ")
                                       .format(device.product))
                    del self.device
                    self.device = None
                    self._1ll1lll_opy_ = None
                    return
            l1l11l_opy_ = six.b(l11ll_opy_ (u"ࠬ࠷ࡶ࠲ࡦࡤ࠸࡯࠾࠳࠺࠵࠴࠴ࡧࡵࡨࡥࡨࡪࡱ࠼ࡰࡱ࠸࠸ࡲ࠻ࡹ࠼࠳ࡥࡳࡶ࡮ࡲ࠹࠷ࡴ࠲ࡹ࠴ࡺࡩࡳ࠱ࡦࡱࡶ੍ࠬ"))
            checker = goTenna.encryption.sdk_token_valid(self.sdk_token)
            l111llllll_opy_, _ = checker(l1l11l_opy_[::-1])
            if device.product == self.l11ll11ll1_opy_ and l111llllll_opy_ == goTenna.constants.SDKLevels.NORMAL:
                self._device_specifics[device_type][l11ll_opy_ (u"࠭ࡲࡦࡶࡵࡽࡤࡶࡡࡵࡶࡨࡶࡳ࠭੎")] = [1, 3, 3]
                self._device_specifics[device_type][l11ll_opy_ (u"ࠧࡨࡴࡲࡹࡵࡥࡨࡰࡲࠪ੏")] = 3
                self._device_specifics[device_type][l11ll_opy_ (u"ࠨࡤࡦࡥࡸࡺ࡟ࡩࡱࡳࠫ੐")] = 1
                self.l11l11lll1_opy_ = 5
            self.device.l1l1l1ll11_opy_()
            self._device_info = self.device.l1l1llll1l_opy_()
        except Exception: # pylint: disable=broad-except
            self._LOGGER.exception(l11ll_opy_ (u"ࠩࡈࡶࡷࡵࡲࠡࡦࡸࡶ࡮ࡴࡧࠡࡦࡨࡺ࡮ࡩࡥࠡࡪࡤࡲࡩࡹࡨࡢ࡭ࡨࠥࠬੑ"))
            del self.device
            self.device = None
            self._1ll1lll_opy_ = None
        else:
            self._port = device.identifier
            self._device_type = device_type
            self._1ll1lll_opy_ = self._device_specifics[device_type][l11ll_opy_ (u"ࠪࡥࡨࡱ࡟ࡩࡣࡱࡨࡱ࡫ࡲࠨ੒")]()
            self._connected = True
            self._11ll11lll_opy_()
    def _11ll11lll_opy_(self):
        self._LOGGER.info(l11ll_opy_ (u"ࠫࡈࡵ࡮࡯ࡧࡦࡸࡪࡪࠠࡵࡱࠣࡨࡪࡼࡩࡤࡧࠣࡿࢂࠦ࡯࡯ࠢࡾࢁࠬ੓")
                          .format(self._device_info[l11ll_opy_ (u"ࠬࡹࡥࡳ࡫ࡤࡰࠬ੔")],
                                  self._port))
        details = {l11ll_opy_ (u"࠭ࡦࡸࡡࡹࡩࡷࡹࡩࡰࡰࠪ੕"): self._device_info[l11ll_opy_ (u"ࠧࡧࡹࡢࡺࡪࡸࡳࡪࡱࡱࠫ੖")],
                   l11ll_opy_ (u"ࠨࡵࡨࡶ࡮ࡧ࡬ࠨ੗"): self._device_info[l11ll_opy_ (u"ࠩࡶࡩࡷ࡯ࡡ࡭ࠩ੘")],
                   l11ll_opy_ (u"ࠪࡴࡴࡸࡴࠨਖ਼"): self._port,
                   l11ll_opy_ (u"ࠫࡩ࡫ࡶࡪࡥࡨࡣࡹࡿࡰࡦࠩਗ਼"): self._device_type}
        event = goTenna.driver.Event(goTenna.driver.Event.CONNECT,
                                     device_details=details)
        goTenna.util.l1llll1l1_opy_(self.event_callback,
                                l11ll_opy_ (u"ࠬࡋࡶࡦࡰࡷࠤࡨࡧ࡬࡭ࡤࡤࡧࡰࠦࡦࡰࡴࠣࡨࡪࡼࡩࡤࡧࠣࡧࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴࠧਜ਼"),
                                self._LOGGER,
                                event)
    def _11l1lll1l_opy_(self, msg):
        event = goTenna.driver.Event(goTenna.driver.Event.MESSAGE, message=msg)
        goTenna.util.l1llll1l1_opy_(self.event_callback,
                                l11ll_opy_ (u"࠭ࡅࡷࡧࡱࡸࠥࡩࡡ࡭࡮ࡥࡥࡨࡱࠠࡧࡱࡵࠤ࡮ࡴࡣࡰ࡯࡬ࡲ࡬ࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠧੜ"),
                                self._LOGGER,
                                event)
    def _11l11ll1l_opy_(self, msg):
        l11ll_opy_ (u"ࠢࠣࠤࠣࡆࡺ࡯࡬ࡥࠢࡤࠤࡌࡸ࡯ࡶࡲࠣࡳࡧࡰࡥࡤࡶࠣࡪࡷࡵ࡭ࠡࡶ࡫ࡩࠥࡳࡥࡴࡵࡤ࡫ࡪࠦࡡ࡯ࡦࠣ࡭ࡳࡼ࡯࡬ࡧࠣࡸ࡭࡫ࠠࡦࡸࡨࡲࡹࠦࡣࡢ࡮࡯ࡦࡦࡩ࡫ࠡࡱࡱࠤ࡮ࡺࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦ੝")
        try:
            group = msg.payload.group
        except ValueError:
            self._LOGGER.exception(l11ll_opy_ (u"ࠨࡉࡵࡳࡺࡶࠠࡪࡰࡹ࡭ࡹࡧࡴࡪࡱࡱࠤࡩ࡯ࡤࠡࡰࡲࡸࠥ࡮ࡡࡷࡧࠣࡥࡵࡶࡲࡰࡲࡵ࡭ࡦࡺࡥࠡࡲࡤࡽࡱࡵࡡࡥࠣࠪਫ਼"))
            return
        event = goTenna.driver.Event(goTenna.driver.Event.GROUP_CREATE,
                                     group=group)
        goTenna.util.l1llll1l1_opy_(self.event_callback,
                                l11ll_opy_ (u"ࠩࡈࡺࡪࡴࡴࠡࡥࡤࡰࡱࡨࡡࡤ࡭ࠣࡪࡴࡸࠠࡨࡴࡲࡹࡵࠦࡣࡳࡧࡤࡸ࡮ࡵ࡮ࠨ੟"),
                                self._LOGGER,
                                event)
        try:
            def _11ll1ll11_opy_(*args, **kwargs):
                if not kwargs.get(l11ll_opy_ (u"ࠪࡷࡺࡩࡣࡦࡵࡶࠫ੠"), None):
                    self._LOGGER.error(l11ll_opy_ (u"ࠫࡈࡵࡵ࡭ࡦࠣࡲࡴࡺࠠࡴࡧࡷࠤ࡬ࡸ࡯ࡶࡲࠣࡋࡎࡊ࠺ࠡࡽࢀࠫ੡")
                                       .format(kwargs.get(l11ll_opy_ (u"ࠬࡪࡥࡵࡣ࡬ࡰࡸ࠭੢"), None)))
            self.add_group(group, _11ll1ll11_opy_, False)
        except Exception: # pylint: disable=broad-except
            self._LOGGER.exception(l11ll_opy_ (u"࠭ࡃࡰࡷ࡯ࡨࠥࡴ࡯ࡵࠢ࡬ࡲ࡮ࡺࡩࡢࡶࡨࠤ࡬ࡸ࡯ࡶࡲࠣࡥࡩࡪࠡࠨ੣"))
    def _11ll1l1l1_opy_(self, msg):
        l11ll_opy_ (u"ࠢࠣࠤࠣࡌࡦࡴࡤ࡭ࡧࠣ࡭ࡳࡩ࡯࡮࡫ࡱ࡫ࠥࡳࡥࡴࡵࡤ࡫ࡪࡹࠠࡧࡴࡲࡱࠥࡺࡨࡦࠢࡧࡩࡻ࡯ࡣࡦ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥ࠳ࠠࡊࡨࠣࡸ࡭࡫ࠠ࡮ࡧࡶࡷࡦ࡭ࡥࠡ࡫ࡶࠤ࡮ࡴࡴࡦࡰࡧࡩࡩࠦࡦࡰࡴࠣࡨ࡮ࡹࡰ࡭ࡣࡼࠤࡩ࡯ࡲࡦࡥࡷࡰࡾࠦࠨࡢࠢࡷࡩࡽࡺࠠ࡮ࡧࡶࡷࡦ࡭ࡥࠪ࠮ࠣࡷࡪࡴࡤࠡ࡫ࡷࠤ࡮ࡴࡴࡰࠢࡷ࡬ࡪࠦࡥࡷࡧࡱࡸࠥࡩࡡ࡭࡮ࡥࡥࡨࡱࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠯ࠣࡍ࡫ࠦࡴࡩࡧࠣࡱࡪࡹࡳࡢࡩࡨࠤ࡭ࡧࡳࠡࡵࡲࡱࡪࠦ࡯ࡵࡪࡨࡶࠥࡳࡥࡢࡰ࡬ࡲ࡬ࠦࡴࡩࡣࡷࠤ࡭ࡧࡳࠡࡶࡲࠤࡧ࡫ࠠࡪࡰࡷࡩࡷࡶࡲࡦࡶࡨࡨࠥࡨࡥࡧࡱࡵࡩࠥࡹࡥ࡯ࡦ࡬ࡲ࡬ࠦࡴࡰࠢࡷ࡬ࡪࠦࡵࡴࡧࡵࠤ࠭࡭ࡲࡰࡷࡳࠤ࡮ࡴࡶࡪࡶࡨ࠰ࠥ࡭ࡲࡰࡷࡳࠤ࡮ࡴࡶࡪࡶࡨࠤࡦࡩ࡫࡯ࡱࡺࡰࡪࡪࡧࡦ࡯ࡨࡲࡹ࠯ࠬࠡࡲࡵࡳࡨ࡫ࡳࡴࠢ࡬ࡸࠥ࡯࡮ࡵࡧࡵࡲࡦࡲ࡬ࡺࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨ੤")
        if isinstance(msg.payload, goTenna.payload.GroupGIDPayload):
            self._11l11ll1l_opy_(msg)
        elif isinstance(msg.payload, goTenna.payload.KeyRequestPayload):
            self._11ll111l1_opy_(msg)
        elif isinstance(msg.payload, goTenna.payload.KeyResponsePayload):
            self._111llll1l_opy_(msg)
        else:
            self._11l1lll1l_opy_(msg)
    def _11ll1111l_opy_(self, msg):
        if msg.message_type == goTenna.constants.MESSAGE_TYPES[l11ll_opy_ (u"ࠨࡲࡵ࡭ࡻࡧࡴࡦࠩ੥")]:
            if msg.destination.gid_val != self._gid.gid_val\
               and ((not msg.destination.via_gateway)\
                    or (msg.destination.via_gateway.gid_val != self._gid.gid_val)):
                return False
        elif msg.message_type == goTenna.constants.MESSAGE_TYPES[l11ll_opy_ (u"ࠩࡪࡶࡴࡻࡰࠨ੦")]:
            for group in self._storage.groups.values():
                if msg.destination.gid_val == group.gid.gid_val:
                    return True
            return False
        return True
    def _11l11l1ll_opy_(self):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡐࡰ࡮࡯ࠤ࡫ࡵࡲࠡࡦࡨࡺ࡮ࡩࡥࠡࡵࡷࡥࡹࡻࡳࠡࡷࡳࡨࡦࡺࡥࡴࠢࠫࡦࡦࡺࡴࡦࡴࡼ࠰ࠥ࡫ࡴࡤࠫࠣࡥࡳࡪࠠ࡮ࡧࡶࡷࡦ࡭ࡥࡴ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤ࡛ࠥࡰࠡࡶࡲࠤࡹ࡮ࡥࠡࡥࡤࡰࡱ࡫ࡲ࠭ࠢࡺ࡬࡮ࡩࡨࠡࡵ࡫ࡳࡺࡲࡤࠡࡴࡨࡥࡱࡲࡹࠡࡱࡱࡰࡾࠦࡢࡦࠢࡵࡹࡳ࠮ࠩࠡࡱࡩࠤࡹ࡮ࡩࡴࠢࡦࡰࡦࡹࡳ࠭ࠢࡷࡳࠥ࡫࡮ࡴࡷࡵࡩࠥࡺࡨࡦࡴࡨࠤ࡮ࡹࠠ࡯ࡱࠣࡳࡹ࡮ࡥࡳࠢࡦࡳࡳࡩࡵࡳࡴࡨࡲࡹࠦࡤࡦࡸ࡬ࡧࡪࠦࡣࡰ࡯ࡰࡹࡳ࡯ࡣࡢࡶ࡬ࡳࡳࠦࡧࡰ࡫ࡱ࡫ࠥࡵ࡮࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨ੧")
        try:
            self._device_info = self.device.l1l1llll1l_opy_()
            self._11l11111l_opy_()
            while True:
                (msg, more) = self.device.l1l111l1ll_opy_()
                if msg:
                    if isinstance(msg, goTenna.message._AckMessage):
                        self._LOGGER.debug(l11ll_opy_ (u"ࠫࡗࡾࠠࡂࡥ࡮ࠤࡲ࡫ࡳࡴࡣࡪࡩࠥ࡬࡯ࡳࠢࡰࡷ࡬ࡎࡡࡴࡪࡌࡨࠥࢁ࠺ࡹࡿࠪ੨").format(msg.hash_id))
                        self._1ll1lll_opy_.l1ll1111l_opy_(msg.hash_id)
                    elif self._11ll1111l_opy_(msg):
                        try:
                            self._11ll1l1l1_opy_(msg)
                        except Exception:
                            self._LOGGER.exception(l11ll_opy_ (u"ࠧࡉ࡯ࡶ࡮ࡧࠤࡳࡵࡴࠡࡲࡤࡶࡸ࡫ࠠ࡮ࡧࡶࡷࡦ࡭ࡥࠡࡽࢀࠦ੩")
                                                   .format(msg))
                if not more or not msg:
                    break
            now = datetime.datetime.utcnow()
            self._1ll1lll_opy_.l11ll1ll_opy_(now)
        except goTenna.constants.TimeoutException:
            self._disconnect(goTenna.constants.ErrorCodes.TIMEOUT,
                             l11ll_opy_ (u"࠭ࡔࡪ࡯ࡨࡳࡺࡺࠠࡸࡪ࡬ࡰࡪࠦࡰࡰ࡮࡯࡭ࡳ࡭ࠠࡥࡧࡹ࡭ࡨ࡫ࠧ੪"))
        except goTenna.constants.RemoteError as l111lllll1_opy_:
            self._LOGGER.exception(l11ll_opy_ (u"ࠧࡓࡧࡰࡳࡹ࡫ࠠࡦࡴࡵࡳࡷࠦࡰࡰ࡮࡯࡭ࡳ࡭ࠠࡥࡧࡹ࡭ࡨ࡫ࠡࠨ੫"))
            self._disconnect(l111lllll1_opy_.code,
                             l11ll_opy_ (u"ࠨࡔࡨࡱࡴࡺࡥࠡࡧࡵࡶࡴࡸࠠࡸࡪ࡬ࡰࡪࠦࡰࡰ࡮࡯࡭ࡳ࡭ࠠࡥࡧࡹ࡭ࡨ࡫࠺ࠡࡽࢀ࠾ࠥࢁࡽࠨ੬")
                             .format(l111lllll1_opy_.code, l111lllll1_opy_.msg))
        except Exception as exc: # pylint: disable=broad-except
            self._LOGGER.exception(l11ll_opy_ (u"ࠩࡘࡲࡪࡾࡰࡦࡥࡷࡩࡩࠦࡥࡹࡥࡨࡴࡹ࡯࡯࡯ࠢࡳࡳࡱࡲࡩ࡯ࡩࠣࡨࡪࡼࡩࡤࡧࠤࠫ੭"))
            self._disconnect(goTenna.constants.ErrorCodes.EXCEPTION,
                             l11ll_opy_ (u"ࠪࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡷࡩ࡫࡯ࡩࠥࡶ࡯࡭࡮࡬ࡲ࡬ࠦࡤࡦࡸ࡬ࡧࡪࡀࠠࡼࡿࠪ੮")
                             .format(repr(exc)+ traceback.format_exc()))
            del self.device
            self.device = None
        if not goTenna.constants.version_ok(*self._device_info[l11ll_opy_ (u"ࠫ࡫ࡽ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ੯")]):
            self._LOGGER.error(l11ll_opy_ (u"ࠬࡉ࡯࡯ࡰࡨࡧࡹ࡫ࡤࠡࡦࡨࡺ࡮ࡩࡥࠡࡪࡤࡷࠥࡨࡡࡥࠢࡩ࡭ࡷࡳࡷࡢࡴࡨࠤࡻ࡫ࡲࡴ࡫ࡲࡲࠥࢁࡽࠨੰ")
                               .format(self._device_info[l11ll_opy_ (u"࠭ࡦࡸࡡࡹࡩࡷࡹࡩࡰࡰࠪੱ")]))
            self._disconnect(goTenna.constants.ErrorCodes.VERSION,
                             l11ll_opy_ (u"ࠧࡇ࡫ࡵࡱࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡿࢂࠦࡩࡴࠢࡱࡳࡹࠦࡣࡰ࡯ࡳࡥࡹ࡯ࡢ࡭ࡧࠣࡻ࡮ࡺࡨࠡࡶ࡫࡭ࡸࠦࡓࡅࡍࠣࡨ࡮ࡹࡴࡳ࡫ࡥࡹࡹ࡯࡯࡯࠰ࠣ࡝ࡴࡻࠠ࡮ࡷࡶࡸࠥࡻࡳࡦࠢࡩ࡭ࡷࡳࡷࡢࡴࡨࠤࡃࠦࡻࡾࠢࡤࡲࡩࠦ࠼࠾ࠢࡾࢁࠬੲ")
                             .format(self._device_info[l11ll_opy_ (u"ࠨࡨࡺࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠬੳ")],
                                     goTenna.constants.MINIMUMVERSION,
                                     goTenna.constants.MAXIMUMVERSION))
    def _11l111ll1_opy_(self, reset=False):
        l11ll_opy_ (u"ࠤࠥࠦࠥࡗࡵࡰࡶࡤࠤ࡫ࡵࡲࠡ࡯ࡨࡷࡸࡧࡧࡦࡵ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣੴ")
        if reset:
            self.l11ll11111_opy_ = self.l11l11lll1_opy_
        else:
            if self.l11ll11111_opy_ >= 0:
                self.l11ll11111_opy_ -= 1
        return self.l11ll11111_opy_ >= 0
    def _11l1ll111_opy_(self, command):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡅࡹࡧࡦࡹࡹ࡫ࠠࡢࠢࡦࡳࡲࡳࡡ࡯ࡦࠣ࡫࡮ࡼࡥ࡯ࠢ࡬ࡸࡸࠦࡣࡰ࡯ࡰࡥࡳࡪࠠࡵࡷࡳࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥੵ")
        now = datetime.datetime.now()
        cmd = getattr(command[l11ll_opy_ (u"ࠫࡲ࡫ࡴࡩࡱࡧࠫ੶")], l11ll_opy_ (u"ࠬࡥ࡟࡯ࡣࡰࡩࡤࡥࠧ੷"), l11ll_opy_ (u"࠭࠼ࡥࡧࡹ࡭ࡨ࡫ࠠ࡮ࡧࡷ࡬ࡴࡪ࠾ࠨ੸"))
        if cmd in self._11l111l11_opy_:
            if now < self._11l1l111l_opy_:
                limit = (self._11l1l111l_opy_-now).total_seconds()
                time.sleep(limit)
        corr_id = command[l11ll_opy_ (u"ࠧࡪࡦࠪ੹")]
        args = command.get(l11ll_opy_ (u"ࠨࡣࡵ࡫ࡸ࠭੺"), tuple())
        kwargs = command.get(l11ll_opy_ (u"ࠩ࡮ࡻࡦࡸࡧࡴࠩ੻"), {})
        method = command[l11ll_opy_ (u"ࠪࡱࡪࡺࡨࡰࡦࠪ੼")]
        callback = command[l11ll_opy_ (u"ࠫࡨࡧ࡬࡭ࡤࡤࡧࡰ࠭੽")]
        try:
            res = method(*args, **kwargs)
        except goTenna.constants.TimeoutException:
            code = goTenna.constants.ErrorCodes.TIMEOUT
            kwargs = {l11ll_opy_ (u"ࠬࡩ࡯ࡳࡴࡨࡰࡦࡺࡩࡰࡰࡢ࡭ࡩ࠭੾"): corr_id,
                      l11ll_opy_ (u"࠭ࡥࡳࡴࡲࡶࠬ੿"): True,
                      l11ll_opy_ (u"ࠧࡥࡧࡷࡥ࡮ࡲࡳࠨ઀"): {l11ll_opy_ (u"ࠨࡥࡲࡨࡪ࠭ઁ"): code,
                                  l11ll_opy_ (u"ࠩࡰࡷ࡬࠭ં"): l11ll_opy_ (u"ࠪࡇࡲࡪࠠࡼࡿࠣࡸ࡮ࡳࡥࡥࠢࡲࡹࡹ࠴ࠧઃ")
                                         .format(getattr(method, l11ll_opy_ (u"ࠫࡤࡥ࡮ࡢ࡯ࡨࡣࡤ࠭઄"),
                                                         l11ll_opy_ (u"ࠬࡂࡤࡦࡸ࡬ࡧࡪࠦ࡭ࡦࡶ࡫ࡳࡩࡄࠧઅ")))}}
            goTenna.util.l1llll1l1_opy_(callback,
                                    l11ll_opy_ (u"࠭ࡍࡦࡶ࡫ࡳࡩࠦࡣࡢ࡮࡯ࡦࡦࡩ࡫ࠡࡨࡲࡶ࡚ࠥࡩ࡮ࡧࡲࡹࡹࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࠤࢀࢃࠧઆ")
                                    .format(getattr(method, l11ll_opy_ (u"ࠧࡠࡡࡱࡥࡲ࡫࡟ࡠࠩઇ"),
                                                    l11ll_opy_ (u"ࠨ࠾ࡧࡩࡻ࡯ࡣࡦࠢࡰࡩࡹ࡮࡯ࡥࡀࠪઈ"))),
                                    self._LOGGER,
                                    **kwargs)
        except goTenna.constants.RemoteError as l11l1l1111_opy_:
            kwargs = {l11ll_opy_ (u"ࠩࡦࡳࡷࡸࡥ࡭ࡣࡷ࡭ࡴࡴ࡟ࡪࡦࠪઉ"): corr_id,
                      l11ll_opy_ (u"ࠪࡩࡷࡸ࡯ࡳࠩઊ"): True,
                      l11ll_opy_ (u"ࠫࡩ࡫ࡴࡢ࡫࡯ࡷࠬઋ"): {l11ll_opy_ (u"ࠬࡩ࡯ࡥࡧࠪઌ"): l11l1l1111_opy_.code,
                                  l11ll_opy_ (u"࠭࡭ࡴࡩࠪઍ"): l11l1l1111_opy_.msg}}
            goTenna.util.l1llll1l1_opy_(callback,
                                    l11ll_opy_ (u"ࠧࡎࡧࡷ࡬ࡴࡪࠠࡤࡣ࡯ࡰࡧࡧࡣ࡬ࠢࡩࡳࡷࠦࡒࡦ࡯ࡲࡸࡪࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡼࡿࠪ઎")
                                    .format(getattr(method, l11ll_opy_ (u"ࠨࡡࡢࡲࡦࡳࡥࡠࡡࠪએ"),
                                                    l11ll_opy_ (u"ࠩ࠿ࡨࡪࡼࡩࡤࡧࠣࡱࡪࡺࡨࡰࡦࡁࠫઐ"))),
                                    self._LOGGER,
                                    **kwargs)
        except OSError as l11l1lllll_opy_:
            code = goTenna.constants.ErrorCodes.OSERROR
            kwargs = {l11ll_opy_ (u"ࠪࡧࡴࡸࡲࡦ࡮ࡤࡸ࡮ࡵ࡮ࡠ࡫ࡧࠫઑ"): corr_id,
                      l11ll_opy_ (u"ࠫࡪࡸࡲࡰࡴࠪ઒"): True,
                      l11ll_opy_ (u"ࠬࡪࡥࡵࡣ࡬ࡰࡸ࠭ઓ"): {l11ll_opy_ (u"࠭ࡣࡰࡦࡨࠫઔ"): code,
                                  l11ll_opy_ (u"ࠧ࡮ࡵࡪࠫક"): str(l11l1lllll_opy_)}}
            goTenna.util.l1llll1l1_opy_(callback,
                                    l11ll_opy_ (u"ࠨࡏࡨࡸ࡭ࡵࡤࠡࡥࡤࡰࡱࡨࡡࡤ࡭ࠣࡪࡴࡸࠠࡐࡕࡈࡶࡷࡵࡲࠡ࡫ࡱࠤࢀࢃࠧખ")
                                    .format(getattr(method, l11ll_opy_ (u"ࠩࡢࡣࡳࡧ࡭ࡦࡡࡢࠫગ"),
                                                    l11ll_opy_ (u"ࠪࡀࡩ࡫ࡶࡪࡥࡨࠤࡲ࡫ࡴࡩࡱࡧࡂࠬઘ"))),
                                    self._LOGGER,
                                    **kwargs)
            self._disconnect(l11l1lllll_opy_.errno,
                             l11ll_opy_ (u"ࠫࡔ࡙ࡅࡳࡴࡲࡶࠥࡽࡨࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡷࡱ࡭ࡨࡧࡴࡪࡰࡪࠤࡼ࡯ࡴࡩࠢࡧࡩࡻ࡯ࡣࡦࠩઙ"))
        except Exception: # pylint: disable=broad-except
            code = goTenna.constants.ErrorCodes.EXCEPTION
            kwargs = {l11ll_opy_ (u"ࠬࡩ࡯ࡳࡴࡨࡰࡦࡺࡩࡰࡰࡢ࡭ࡩ࠭ચ"): corr_id,
                      l11ll_opy_ (u"࠭ࡥࡳࡴࡲࡶࠬછ"): True,
                      l11ll_opy_ (u"ࠧࡥࡧࡷࡥ࡮ࡲࡳࠨજ"): {l11ll_opy_ (u"ࠨࡥࡲࡨࡪ࠭ઝ"): code,
                                  l11ll_opy_ (u"ࠩࡰࡷ࡬࠭ઞ"): traceback.format_exc()}}
            goTenna.util.l1llll1l1_opy_(callback,
                                    l11ll_opy_ (u"ࠪࡑࡪࡺࡨࡰࡦࠣࡧࡦࡲ࡬ࡣࡣࡦ࡯ࠥ࡬࡯ࡳࠢࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡽࢀࠫટ")
                                    .format(getattr(method, l11ll_opy_ (u"ࠫࡤࡥ࡮ࡢ࡯ࡨࡣࡤ࠭ઠ"),
                                                    l11ll_opy_ (u"ࠬࡂࡤࡦࡸ࡬ࡧࡪࠦ࡭ࡦࡶ࡫ࡳࡩࡄࠧડ"))),
                                    self._LOGGER,
                                    **kwargs)
        else:
            kwargs = {
                l11ll_opy_ (u"࠭ࡣࡰࡴࡵࡩࡱࡧࡴࡪࡱࡱࡣ࡮ࡪࠧઢ"): corr_id,
                l11ll_opy_ (u"ࠧࡴࡷࡦࡧࡪࡹࡳࠨણ"): True,
                l11ll_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࡴࠩત"): res
            }
            command[l11ll_opy_ (u"ࠩࡦࡥࡱࡲࡢࡢࡥ࡮ࠫથ")](**kwargs)
        finally:
            if command[l11ll_opy_ (u"ࠪࡱࡪࡺࡨࡰࡦࠪદ")] in self._11l111l11_opy_:
                l11l1ll11l_opy_ = self._11l111l11_opy_[command[l11ll_opy_ (u"ࠫࡲ࡫ࡴࡩࡱࡧࠫધ")]]
                self._11l1l111l_opy_\
                    = datetime.datetime.now()\
                    + datetime.timedelta(seconds=l11l1ll11l_opy_)
    def _11ll111ll_opy_(self, l11l11l1l1_opy_):
        l11ll_opy_ (u"ࠧࠨࠢࠡࡖ࡫ࡩࠥࡳࡡࡪࡰࠣࡸࡦࡹ࡫ࠡࡶࡲࠤࡷࡻ࡮ࠡ࡫ࡩࠤࡦࠦࡤࡦࡸ࡬ࡧࡪࠦࡩࡴࠢࡦࡹࡷࡸࡥ࡯ࡶ࡯ࡽࠥࡩ࡯࡯ࡰࡨࡧࡹ࡫ࡤ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨન")
        now = datetime.datetime.now()
        if now-l11l11l1l1_opy_ > self.poll_frequency:
            self._11l11l1ll_opy_()
            l11l11l1l1_opy_ = now
        if now-self.l11ll1l11l_opy_ > self.l11l1l1lll_opy_:
            self._11l111ll1_opy_(reset=True)
            self.l11ll1l11l_opy_ = now
        now = datetime.datetime.now()
        try:
            cmd = self.l11l11l11l_opy_.get(True,
                                         self.poll_frequency.total_seconds())
            self._11l1ll111_opy_(cmd)
            self.l11l11l11l_opy_.task_done()
        except six.moves.queue.Empty:
            time.sleep(0.25)
        except Exception: # pylint: disable=broad-except
            self._LOGGER.exception(l11ll_opy_ (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡨࡼࡪࡩࡵࡵࡧࠣࡧࡴࡳ࡭ࡢࡰࡧࠤ࡫ࡸ࡯࡮ࠢࡴࡹࡪࡻࡥࠢࠩ઩"))
        return l11l11l1l1_opy_
    def _11l1l11l1_opy_(self, l11l1ll1ll_opy_):
        l11l1111ll_opy_ = [{l11ll_opy_ (u"ࠧࡥࡧࡹ࡭ࡨ࡫࡟ࡵࡻࡳࡩࠬપ"): p.product,
                            l11ll_opy_ (u"ࠨࡵࡨࡶ࡮ࡧ࡬ࡠࡰࡸࡱࡧ࡫ࡲࠨફ"): p.serial_number,
                            l11ll_opy_ (u"ࠩࡳࡳࡷࡺࠧબ"): p.identifier}
                           for p in l11l1ll1ll_opy_]
        event = goTenna.driver.Event(goTenna.driver.Event.DEVICE_PRESENT,
                                     device_paths=l11l1111ll_opy_)
        goTenna.util.l1llll1l1_opy_(self.event_callback,
                                l11ll_opy_ (u"ࠪࡉࡻ࡫࡮ࡵࠢࡦࡥࡱࡲࡢࡢࡥ࡮ࠤ࡫ࡵࡲࠡࡦࡨࡺ࡮ࡩࡥࠡࡥࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲࠬભ"),
                                self._LOGGER,
                                event)
    def _11l1llll1_opy_(self, device, force):
        try:
            self._LOGGER.info(l11ll_opy_ (u"࡙ࠫࡸࡹࡪࡰࡪࠤࡹࡵࠠࡤࡱࡱࡲࡪࡩࡴࠡࡶࡲࠤࢀࢃࠧમ").format(device))
            self._11l111lll_opy_(device, force)
            return True
        except RuntimeError:
            self._LOGGER.info(l11ll_opy_ (u"ࠬࡉ࡯ࡶ࡮ࡧࠤࡳࡵࡴࠡࡥࡲࡲࡳ࡫ࡣࡵࠢࡷࡳࠥࢁࡽ࠭ࠢࡳࡶࡴࡨࡡࡣ࡮ࡼࠤࡹࡧ࡫ࡦࡰࠪય")
                              .format(device))
            return False
        except Exception: # pylint: disable=broad-except
            self._LOGGER.exception(l11ll_opy_ (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡦࡳࡳࡴࡥࡤࡶࠣࡸࡴࠦࡤࡦࡸ࡬ࡧࡪࠧࠧર"))
    def _11l11llll_opy_(self):
        devices = set(goTenna.util.l1ll111ll_opy_(self._connection_class.list_devices(),
                                                      self._blacklisted_serials,
                                                      self._whitelisted_serials,
                                                      self._device_types))
        if self._force_device_list_recheck\
           or devices != self._present_devices:
            self._present_devices = devices
            self._force_device_list_recheck = False
            if not self._connected and devices:
                self._11l1l11l1_opy_(devices)
        if not self.can_connect:
            time.sleep(0.25)
            return
        if self._manual_connect_request != (None, None):
            self._LOGGER.info(l11ll_opy_ (u"ࠧࡎࡣࡱࡹࡦࡲࠠࡤࡱࡱࡲࡪࡩࡴࡪࡱࡱࠤࡷ࡫ࡱࡶࡧࡶࡸࠥ࡬࡯ࡳࠢࡾࢁࠬ઱")
                              .format(self._manual_connect_request[0]))
            self._11l1llll1_opy_(*self._manual_connect_request)
            self._manual_connect_request = (None, None)
            return
        for device in devices:
            if not self._do_automatic_connect:
                continue
            if self._11l1llll1_opy_(device, False):
                break
        else:
            time.sleep(0.25)
    def _run(self):
        l11ll_opy_ (u"ࠣࠤࠥࠤ࡙࡮ࡥࠡࡱࡹࡩࡷࡸࡩࡥࡧࠣࡳ࡫ࠦ࠺ࡱࡻ࠽ࡱࡪࡺࡨ࠻ࡢࡷ࡬ࡷ࡫ࡡࡥ࡫ࡱ࡫࠳࡚ࡨࡳࡧࡤࡨ࠳ࡸࡵ࡯ࡢࠣࡸ࡭ࡧࡴࠡ࡫ࡶࠤࡹ࡮ࡥࠡࡦࡵ࡭ࡻ࡫ࡲࠡࡶ࡫ࡶࡪࡧࡤࠨࡵࠣࡱࡦ࡯࡮ࠡ࡯ࡨࡸ࡭ࡵࡤ࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤࡘ࡮࡯ࡶ࡮ࡧࠤࡳࡵࡴࠡࡤࡨࠤࡨࡧ࡬࡭ࡧࡧࠤࡩ࡯ࡲࡦࡥࡷࡰࡾࠦ࠭ࠡࡷࡶࡩࡷࡹࠠࡴࡪࡲࡹࡱࡪࠠࡤࡣ࡯ࡰࠥࡀࡰࡺ࠼ࡰࡩࡹ࡮࠺ࡡࡆࡵ࡭ࡻ࡫ࡲ࠯ࡵࡷࡥࡷࡺࡠ࠭ࠢࡺ࡬࡮ࡩࡨࠡ࡫ࡶࠤ࡮ࡴࡨࡦࡴ࡬ࡸࡪࡪࠠࡧࡴࡲࡱࠥࡀࡰࡺ࠼ࡦࡰࡦࡹࡳ࠻ࡢࡷ࡬ࡷ࡫ࡡࡥ࡫ࡱ࡫࠳࡚ࡨࡳࡧࡤࡨࡥ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦલ")
        l11l11l1l1_opy_ = datetime.datetime.now()
        self._LOGGER.info(l11ll_opy_ (u"ࠩࡇࡶ࡮ࡼࡥࡳࠢࡶࡸࡦࡸࡴࡦࡦࠪળ"))
        while not self.quit_event.is_set():
            if self._connected:
                l11l11l1l1_opy_ = self._11ll111ll_opy_(l11l11l1l1_opy_)
            else:
                self._11l11llll_opy_()
    def _invoke_command(self, method, corr_id, callback, args=None, kwargs=None):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡉ࡯ࡸࡲ࡯ࡪࠦࡡࠡࡥࡲࡱࡲࡧ࡮ࡥࠢࡲࡲࠥࡺࡨࡦࠢࡖࡈࡐࠦࡴࡩࡴࡨࡥࡩ࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡸࡷࠦ࡭ࡦࡶ࡫ࡳࡩࡀࠠࡕࡪࡨࠤࡳࡧ࡭ࡦࠢࡲࡪࠥࡺࡨࡦࠢࡰࡩࡹ࡮࡯ࡥࠢࡲࡲࠥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡰࡳࡱ࠱ࡔࡷࡵࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡥࡤࡰࡱࡧࡢ࡭ࡧࠫࡩࡷࡸ࡯ࡳ࠿ࡑࡳࡳ࡫ࠬࠡࡵࡸࡧࡨ࡫ࡳࡴ࠿ࡑࡳࡳ࡫ࠬࠡࡦࡨࡸࡦ࡯࡬ࡴ࠿ࡑࡳࡳ࡫ࠬࠡࡴࡨࡷࡺࡲࡴࡴ࠿ࡑࡳࡳ࡫ࠩࠡࡥࡤࡰࡱࡨࡡࡤ࡭࠽ࠤࡆࠦࡣࡢ࡮࡯ࡦࡦࡩ࡫ࠡࡶࡲࠤࡧ࡫ࠠࡪࡰࡹࡳࡰ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡴࡩࡧࠣࡧࡴࡳ࡭ࡢࡰࡧࠤ࡮ࡹࠠࡥࡱࡱࡩ࠳ࠦࡉࡧࠢࡷ࡬ࡪࠦࡣࡰ࡯ࡰࡥࡳࡪࠠࡴࡷࡦࡧࡪ࡫ࡤࡦࡦ࠯ࠤࡥࡦࡳࡶࡥࡦࡩࡸࡹࡠࡡࠢࡺ࡭ࡱࡲࠠࡣࡧࠣࡘࡷࡻࡥࠡࡣࡱࡨࠥࡦࡠࡥࡧࡷࡥ࡮ࡲࡳࡡࡢࠣࡻ࡮ࡲ࡬ࠡࡥࡲࡲࡹࡧࡩ࡯ࠢࡷ࡬ࡪࠦࡲࡦࡶࡸࡶࡳࠦࡶࡢ࡮ࡸࡩࠥࡵࡦࠡࡶ࡫ࡩࠥࡩࡡ࡭࡮࠱ࠤࡎ࡬ࠠࡵࡪࡨࠤࡨࡵ࡭࡮ࡣࡱࡨࠥ࡬ࡡࡪ࡮ࡨࡨࠥ࡬࡯ࡳࠢࡤࡲࡾࠦࡲࡦࡣࡶࡳࡳࠦࠨࡪࡰࡦࡰࡺࡪࡩ࡯ࡩࠣࡥࡳࠦࡩ࡯ࡸࡤࡰ࡮ࡪࠠ࡮ࡧࡷ࡬ࡴࡪࠠࡰࡴࠣࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠦ࡯ࡳࠢࡤࠤࡷ࡫࡭ࡰࡶࡨࠤࡪࡸࡲࡰࡴࠬࠤࡥࡦࡥࡳࡴࡲࡶࡥࡦࠠࡸ࡫࡯ࡰࠥࡨࡥࠡࡶࡵࡹࡪ࠲ࠠࡢࡰࡧࠤࡥࡦࡤࡦࡶࡤ࡭ࡱࡹࡠࡡࠢࡺ࡭ࡱࡲࠠࡤࡱࡱࡸࡦ࡯࡮ࠡࡣࡱࠤࡪࡸࡲࡰࡴࠣࡱࡪࡹࡳࡢࡩࡨࠤࡸࡺࡲࡪࡰࡪ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡴࡶࡲ࡯ࡩࠥࡧࡲࡨࡵ࠽ࠤ࡙࡮ࡥࠡࡰࡲࡲ࠲ࡱࡥࡺࡹࡲࡶࡩࠦࡡࡳࡩࡸࡱࡪࡴࡴࡴࠢࡷࡳࠥࡶࡲࡰࡸ࡬ࡨࡪࠦࡴࡰࠢࡷ࡬ࡪࠦࡓࡅࡍࠣࡱࡪࡺࡨࡰࡦࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡩ࡯ࡣࡵࠢ࡮ࡻࡦࡸࡧࡴ࠼ࠣࡘ࡭࡫ࠠ࡬ࡧࡼࡻࡴࡸࡤࠡࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠤࡹࡵࠠࡱࡴࡲࡺ࡮ࡪࡥࠡࡶࡲࠤࡹ࡮ࡥࠡࡕࡇࡏࠥࡳࡥࡵࡪࡲࡨࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤ઴")
        self._LOGGER.debug(l11ll_opy_ (u"ࠫࡤ࡯࡮ࡷࡱ࡮ࡩࡤࡩ࡯࡮࡯ࡤࡲࡩࡀࠠ࡮ࡧࡷ࡬ࡴࡪ࠽ࡼࡿ࠯ࠤࡨࡵࡲࡳࡡ࡬ࡨࡂࢁࡽ࠭ࠢࡦࡥࡱࡲࡢࡢࡥ࡮ࡁࢀࢃࠬࠡࡣࡵ࡫ࡸࡃࡻࡾ࠮ࠣ࡯ࡼࡧࡲࡨࡵࡀࡿࢂ࠭વ")
                           .format(method, corr_id, callback, args, kwargs))
        if None is args:
            args = tuple()
        if None is kwargs:
            kwargs = dict()
        self.l11l11l11l_opy_.put({l11ll_opy_ (u"ࠬࡳࡥࡵࡪࡲࡨࠬશ"): method, l11ll_opy_ (u"࠭ࡩࡥࠩષ"): corr_id,
                                l11ll_opy_ (u"ࠧࡤࡣ࡯ࡰࡧࡧࡣ࡬ࠩસ"): callback, l11ll_opy_ (u"ࠨࡣࡵ࡫ࡸ࠭હ"): args,
                                l11ll_opy_ (u"ࠩ࡮ࡻࡦࡸࡧࡴࠩ઺"): kwargs})
    def _update_payload(self, payload):
        if not self._11l111ll1_opy_():
            self._LOGGER.info(l11ll_opy_ (u"ࠥࡕࡺࡵࡴࡢࠢࡨࡼࡨ࡫ࡥࡥࡧࡧ࠰ࠥࡳࡥࡴࡵࡤ࡫ࡪࠦ࡮ࡰࡶࠣࡷࡪࡴࡴࠢࠤ઻"))
            return False
        if not payload.sender:
            payload.set_sender(self._gid)
        elif self._gid == goTenna.settings.GID.gateway():
            sender = copy.deepcopy(payload.sender)
            sender._via_gateway = self._gid
            payload.set_sender(sender)
        if not payload.time_sent:
            payload.set_time_sent(datetime.datetime.utcnow())
        if not payload.sender_initials:
            payload.set_sender_initials(self._shortname)
        if not payload.counter:
            payload.set_counter(self.next_counter)
        return True
    @staticmethod
    def _firmware_update_callback_shim(device, progress_callback, firmware_file,
                                       version_major, version_minor):
        l11ll_opy_ (u"ࠦࠧࠨࠠࡂࠢࡶ࡬࡮ࡳࠠࡢࡴࡲࡹࡳࡪࠠ࠻ࡲࡼ࠾ࡲ࡫ࡴࡩ࠼ࡣ࡫ࡴ࡚ࡥ࡯ࡰࡤ࠲ࡵࡸ࡯࠯ࡒࡵࡳ࠳ࡻࡰࡥࡣࡷࡩࡤ࡬ࡩࡳ࡯ࡺࡥࡷ࡫ࡠࠡࡶ࡫ࡥࡹࠦࡣࡢ࡮࡯ࡷࠥࡦࡠࡱࡴࡲ࡫ࡷ࡫ࡳࡴࡡࡦࡥࡱࡲࡢࡢࡥ࡮ࡤࡥࠦࡴࡰࠢ࡬ࡲࡩ࡯ࡣࡢࡶࡨࠤࡵࡸ࡯ࡨࡴࡨࡷࡸ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤ઼ࠥࠦ")
        for l11l11ll11_opy_ in device.update_firmware(firmware_file,
                                           version_major, version_minor):
            progress_callback(l11l11ll11_opy_)
    def _set_gid(self, gid):
        l11ll_opy_ (u"ࠧࠨࠢࠡࡕࡨࡸࠥࡺࡨࡦࠢࡊࡍࡉࠦࡡࡴࡵࡲࡧ࡮ࡧࡴࡦࡦࠣࡻ࡮ࡺࡨࠡࡶ࡫ࡩࠥࡩࡵࡳࡴࡨࡲࡹࠦࡵࡴࡧࡵ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡨࡱࡗࡩࡳࡴࡡ࠯ࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡎࡊࠠࡨ࡫ࡧ࠾࡚ࠥࡨࡦࠢࡊࡍࡉࠦࡴࡰࠢࡤࡷࡸࡵࡣࡪࡣࡷࡩ࠳ࠦࡉࡧࠢࡣࡤࡓࡵ࡮ࡦࡢࡣ࠰ࠥࡴ࡯ࠡࡦࡨࡺ࡮ࡩࡥࠡࡹ࡬ࡰࡱࠦࡣࡰࡰࡱࡩࡨࡺ࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡳࡵࡴࡦ࠼࡛ࠣ࡭࡫࡮ࠡࡣࠣࡲࡪࡽࠠࡈࡋࡇࠤ࡮ࡹࠠࡴࡧࡷ࠰ࠥࡧ࡮ࡺࠢࡦࡳࡳࡴࡥࡤࡶࡨࡨࠥ࡭࡯ࡕࡧࡱࡲࡦࠦࡷࡪ࡮࡯ࠤࡩ࡯ࡳࡤࡱࡱࡲࡪࡩࡴࠡࡣࡱࡨࠥࡸࡥࡤࡱࡱࡲࡪࡩࡴ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡳࡵࡴࡦ࠼࡛ࠣ࡭࡫࡮ࠡࡣࠣࡲࡪࡽࠠࡈࡋࡇࠤ࡮ࡹࠠࡴࡧࡷ࠰ࠥࡧ࡮ࡺࠢࡳࡶࡪࡼࡩࡰࡷࡶࡰࡾ࠳ࡣࡰࡰࡩ࡭࡬ࡻࡲࡦࡦࠣ࡫ࡷࡵࡵࡱࡵࠣࡻ࡮ࡲ࡬ࠡࡤࡨࠤࡩ࡫࡬ࡦࡶࡨࡨ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥઽ")
        if None is not gid:
            if not isinstance(gid, goTenna.settings.GID):
                raise TypeError(l11ll_opy_ (u"࠭ࡧࡪࡦࠣࡱࡺࡹࡴࠡࡤࡨࠤ࡬ࡵࡔࡦࡰࡱࡥ࠳ࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡋࡇ࠰ࠥ࡯ࡳࠡࡽࢀࠫા")
                                .format(type(gid)))
            if gid.gid_type != goTenna.settings.GID.PRIVATE:
                raise ValueError(l11ll_opy_ (u"ࠧࡨ࡫ࡧࠤࡲࡻࡳࡵࠢࡥࡩࠥࡶࡲࡪࡸࡤࡸࡪ࠲ࠠࡪࡵࠣࡿࢂ࠭િ")
                                 .format(goTenna.settings.GID.type_name(gid.gid_type)))
        if self._connected:
            def _dummy(*args, **kwargs):
                if l11ll_opy_ (u"ࠨࡧࡵࡶࡴࡸࠧી") in kwargs:
                    self._LOGGER.error(l11ll_opy_ (u"ࠤࡆࡳࡺࡲࡤࠡࡰࡲࡸࠥࡩ࡬ࡦࡣࡵࠤ࡬ࡸ࡯ࡶࡲ࠽ࠤࢀࢃࠢુ")
                                       .format(kwargs))
            self._invoke_command(self._local_disconnect, uuid.uuid4(), _dummy,
                                 (l11ll_opy_ (u"ࠪࡋࡎࡊࠠࡳࡧࡶࡩࡹ࠭ૂ"),))
        self._gid = gid
        if None is not gid:
            self._encryption_manager\
                = goTenna.encryption.l1111ll11_opy_(self._storage,
                                                       self._gid)
        else:
            self._encryption_manager = None
    def set_shortname(self, shortname):
        raise NotImplementedError()
    def can_connect(self):
        raise NotImplementedError()
    def add_group(self, group, method_callback, invite, invite_callback=None):
        raise NotImplementedError()
    def next_counter(self):
        raise NotImplementedError()