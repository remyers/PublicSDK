# coding: utf8
# Copyright (C) 2018 goTenna, Inc. This file is distributed as part of the
# goTenna USB SDK. See the associated license for more information.
""" The place to set the version. loaded using exec() by setup.py to single-source-of-truth the package version without having to import the package. Yes this is somehow the best way:
https://packaging.python.org/guides/single-sourcing-package-version/

Also an importable python module so it can be imported by __init__ and maintain a full binary dist.
"""

__version__ = '0.12.5'

