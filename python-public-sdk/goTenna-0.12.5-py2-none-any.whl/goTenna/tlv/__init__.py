# coding: utf8
import sys
l1111_opy_ = sys.version_info [0] == 2
l1lll1_opy_ = 2048
l1ll1_opy_ = 7
def l11ll_opy_ (l1_opy_):
    global l1llll_opy_
    l11l1l_opy_ = ord (l1_opy_ [-1])
    l111l_opy_ = l1_opy_ [:-1]
    l1ll_opy_ = l11l1l_opy_ % len (l111l_opy_)
    l1l1_opy_ = l111l_opy_ [:l1ll_opy_] + l111l_opy_ [l1ll_opy_:]
    if l1111_opy_:
        l1ll1l_opy_ = unicode () .join ([unichr (ord (char) - l1lll1_opy_ - (l1l11_opy_ + l11l1l_opy_) % l1ll1_opy_) for l1l11_opy_, char in enumerate (l1l1_opy_)])
    else:
        l1ll1l_opy_ = str () .join ([chr (ord (char) - l1lll1_opy_ - (l1l11_opy_ + l11l1l_opy_) % l1ll1_opy_) for l1l11_opy_, char in enumerate (l1l1_opy_)])
    return eval (l1ll1l_opy_)
# Copyright (C) 2018 goTenna, Inc. This file is distributed as part of the
# goTenna USB SDK. See the associated license for more information.
# pylint: disable=line-too-long
l11ll_opy_ (u"ࠦࠧࠨࠠࡨࡱࡗࡩࡳࡴࡡࠡࡖࡏ࡚ࠥࡹࡵࡣࡲࡤࡧࡰࡧࡧࡦࠌࠍࡘ࡭࡫ࡲࡦࠢࡤࡶࡪࠦࡡࠡࡴࡨࡰࡦࡺࡩࡷࡧ࡯ࡽࠥ࡮ࡵࡨࡧࠣࡥࡲࡵࡵ࡯ࡶࠣࡳ࡫ࠦࡔࡍࡘࡶ࠰ࠥࡺࡨࡢࡶࠣࡳࡨࡩࡡࡴ࡫ࡲࡲࡦࡲ࡬ࡺࠢ࡫ࡥࡻ࡫ࠠࡰࡸࡨࡶࡱࡧࡰࡱ࡫ࡱ࡫ࠥࡏࡄࡴ࠮ࠣࡸ࡭ࡧࡴࠡࡣࡵࡩࠥ࡯࡮ࠡࡵࡨࡺࡪࡸࡡ࡭ࠢࡧ࡭࡫࡬ࡥࡳࡧࡱࡸࠥࡩࡡࡵࡧࡪࡳࡷ࡯ࡥࡴࠢࡥࡳࡹ࡮ࠠࡴࡧࡰࡥࡳࡺࡩࡤࠢࡤࡲࡩࠦࡲࡦ࡮ࡨࡺࡦࡴࡴࠡࡶࡲࠤࡩ࡫ࡶࡦ࡮ࡲࡴࡲ࡫࡮ࡵ࠰ࠣࡘ࡭࡯ࡳࠡࡵࡰࡥࡱࡲࠠࡴࡷࡥࡴࡦࡩ࡫ࡢࡩࡨࠤࡦࡲ࡬ࡰࡹࡶࠤࡺࡹࠠࡵࡱࠣࡨ࡮ࡼࡩࡥࡧࠣࡸ࡭࡫࡭ࠡࡷࡳࠤࡧ࡫ࡴࡸࡧࡨࡲࠥࡧࠠࡤࡱࡸࡴࡱ࡫ࠠࡥ࡫ࡩࡪࡪࡸࡥ࡯ࡶࠣࡴࡱࡧࡣࡦࡵࠣࡷࡴࠦ࡮ࡰࠢ࡬ࡲࡩ࡯ࡶࡪࡦࡸࡥࡱࠦ࡭ࡰࡦࡸࡰࡪࠦࡧࡦࡶࡶࠤࡴࡻࡴࠡࡱࡩࠤ࡭ࡧ࡮ࡥ࠰ࠍࠦࠧࠨૻ")
# pylint: disable=line-too-long
from goTenna.tlv import basic_tlv
from goTenna.tlv import l1l1l1l1ll_opy_
from goTenna.tlv import message_tlv
from goTenna.tlv import payload_tlv