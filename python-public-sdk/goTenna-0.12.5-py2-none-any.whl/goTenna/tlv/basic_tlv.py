# coding: utf8
from __future__ import print_function
import sys
l1111_opy_ = sys.version_info [0] == 2
l1lll1_opy_ = 2048
l1ll1_opy_ = 7
def l11ll_opy_ (l1_opy_):
    global l1llll_opy_
    l11l1l_opy_ = ord (l1_opy_ [-1])
    l111l_opy_ = l1_opy_ [:-1]
    l1ll_opy_ = l11l1l_opy_ % len (l111l_opy_)
    l1l1_opy_ = l111l_opy_ [:l1ll_opy_] + l111l_opy_ [l1ll_opy_:]
    if l1111_opy_:
        l1ll1l_opy_ = unicode () .join ([unichr (ord (char) - l1lll1_opy_ - (l1l11_opy_ + l11l1l_opy_) % l1ll1_opy_) for l1l11_opy_, char in enumerate (l1l1_opy_)])
    else:
        l1ll1l_opy_ = str () .join ([chr (ord (char) - l1lll1_opy_ - (l1l11_opy_ + l11l1l_opy_) % l1ll1_opy_) for l1l11_opy_, char in enumerate (l1l1_opy_)])
    return eval (l1ll1l_opy_)
# Copyright (C) 2018 goTenna, Inc. This file is distributed as part of the
# goTenna USB SDK. See the associated license for more information.
l11ll_opy_ (u"ࠦࠧࠨࠠࡎࡧࡷ࡬ࡴࡪࡳࠡࡣࡱࡨࠥࡩ࡬ࡢࡵࡶࡩࡸࠦࡦࡰࡴࠣࡴࡦࡸࡳࡪࡰࡪࠤ࡬ࡵࡔࡦࡰࡱࡥ࡚ࠥࡌࡗࠢࡨࡲࡨࡵࡤࡦࡦࠣࡨࡦࡺࡡ࠯ࠌࠥࠦࠧૃ")
import struct
import itertools
import logging
import six
import goTenna.constants
import goTenna.settings
import goTenna.util
_MODULE_LOGGER = logging.getLogger(__name__)
class TLV(object):
    l11ll_opy_ (u"ࠧࠨࠢࠡࡃࠣࡘࡑ࡜ࠠࡰࡤ࡭ࡩࡨࡺࠠࡵࡪࡤࡸࠥࡱ࡮ࡰࡹࡶࠤ࡭ࡵࡷࠡࡶࡲࠤࡧࡻࡩ࡭ࡦࠣ࡭ࡹࡹࡥ࡭ࡨࠣࡪࡷࡵ࡭ࠡࡣࠣࡦ࡮ࡴࡡࡳࡻࠣࡷࡹࡸࡩ࡯ࡩࠣࡥࡳࡪࠠࡴࡧࡵ࡭ࡦࡲࡩࡻࡧࠣ࡭ࡹࡹࡥ࡭ࡨࠣࡸࡴࠦࡡࠡࡤ࡬ࡲࡦࡸࡹࠡࡵࡷࡶ࡮ࡴࡧ࠯ࠌࠍࠤࠥࠦࠠࡔࡪࡲࡹࡱࡪࠠࡣࡧࠣࡷࡺࡨࡣ࡭ࡣࡶࡷࡪࡪࠠࡣࡻࠣࡧࡱࡧࡳࡴࡧࡶࠤࡹ࡮ࡡࡵࠢ࡬ࡲࡸࡺࡩࡵࡷࡷࡩࠥࡹࡰࡦࡥ࡬ࡪ࡮ࡩࠠ࡬࡫ࡱࡨࡸࠦ࡯ࡧࠢࡗࡐ࡛࠴ࠊࠋࠢࠣࠤࠥࡖࡲࡰࡸ࡬ࡨࡪࡹࠠࡴࡶࡤࡸ࡮ࡩࠠ࡮ࡧࡷ࡬ࡴࡪࡳࠡࡨࡲࡶࠥࡹࡥࡳ࡫ࡤࡰ࡮ࢀࡡࡵ࡫ࡲࡲࠥࡧ࡮ࡥࠢࡧࡩࡸ࡫ࡲࡪࡣ࡯࡭ࡿࡧࡴࡪࡱࡱ࠲ࠏࠦࠠࠡࠢࠥࠦࠧૄ")
    def __ne__(self, other):
        return not self.__eq__(other)
    def __eq__(self, other):
        return NotImplemented
    @classmethod
    def l111ll11ll_opy_(cls):
        l11ll_opy_ (u"ࠨࠢࠣࠢࡖࡸࡦࡺࡩࡤࠢࡰࡩࡹ࡮࡯ࡥࠢࡷࡳࠥ࡭ࡥࡵࠢࡤࠤࡱࡵࡧࡨࡧࡵࠤࡳࡧ࡭ࡦࡦࠣࡪࡴࡸࠠࡵࡪࡨࠤࡨࡲࡡࡴࡵ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࡔࡩࡧࠣࡶࡪࡹࡵ࡭ࡶࠣ࡭ࡸࠦࡩ࡯ࡶࡨࡶࡳࡧ࡬࡭ࡻࠣࡧࡦࡩࡨࡦࡦ࠯ࠤࡸࡵࠠࡵࡪ࡬ࡷࠥࡳࡥࡵࡪࡲࡨࠥࡳࡡࡺࠢࡥࡩࠥࡩࡡ࡭࡮ࡨࡨࠥ࡫ࡶࡦࡴࡼࠤࡹ࡯࡭ࡦࠢࡷ࡬ࡪࠦࡣࡢ࡮࡯ࡩࡷࠦࡷࡢࡰࡷࡷࠥࡺ࡯ࠡࡵࡨࡲࡩࠦࡡࠡ࡮ࡲ࡫ࠥࡳࡥࡴࡵࡤ࡫ࡪ࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢࡉࡳࡷࠦࡥࡹࡣࡰࡴࡱ࡫࠺ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠲࠳ࠦࡣࡰࡦࡨ࠱ࡧࡲ࡯ࡤ࡭࠽࠾ࠥࡶࡹࡵࡪࡲࡲࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡨࡲࡡࡴࡵࠣࡑࡾ࡚ࡌࡗࠪࡗࡐ࡛࠯࠺ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡨࡪ࡬ࠠ࡮ࡧࡷ࡬ࡴࡪࠨࡴࡧ࡯ࡪ࠮ࡀࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡸ࡫࡬ࡧ࠰ࡪࡩࡹࡥ࡬ࡰࡩࡪࡩࡷ࠮ࠩ࠯ࡹࡤࡶࡳ࡯࡮ࡨࠪࠪࡱࡾࠦࡩ࡯ࡵࡷࡥࡳࡩࡥࠡࡹࡤࡶࡳ࡯࡮ࡨࠢ࡫ࡩࡷ࡫ࠧࠪࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡆࡣ࡭ࡣࡶࡷࡲ࡫ࡴࡩࡱࡧࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡤࡦࡨࠣࡳࡹ࡮ࡥࡳࡡࡰࡩࡹ࡮࡯ࡥࠪࡦࡰࡸ࠯࠺ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡩ࡬ࡴ࠰ࡪࡩࡹࡥ࡬ࡰࡩࡪࡩࡷ࠮ࠩ࠯ࡹࡤࡶࡳ࡯࡮ࡨࠪࠪࡱࡾࠦࡣ࡭ࡣࡶࡷࠥࡽࡡࡳࡰ࡬ࡲ࡬ࠦࡨࡦࡴࡨࠫ࠮ࠐࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢࡘࡷ࡮ࡴࡧࠡࡶ࡫࡭ࡸࠦ࡭ࡦࡶ࡫ࡳࡩࠦࡥ࡯ࡵࡸࡶࡪࡹࠠࡵࡪࡨࠤࡱࡵࡧࡨࡧࡵࠤࡼ࡯࡬࡭ࠢࡥࡩࠥࡧࡴࠡࡶ࡫ࡩࠥࡶࡲࡰࡲࡨࡶࠥࡲ࡯ࡨࡩ࡬ࡲ࡬ࠦࡳࡤࡱࡳࡩ࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡩࡹࡻࡲ࡯ࡵࠣࡰࡴ࡭ࡧࡪࡰࡪ࠲ࡑࡵࡧࡨࡧࡵ࠾ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤૅ")
        if None is getattr(cls, l11ll_opy_ (u"ࠧࡠࡎࡒࡋࡌࡋࡒࠨ૆"), None):
            cls._LOGGER = _MODULE_LOGGER.getChild(cls.__name__)
        return cls._LOGGER
    def serialize(self):
        l11ll_opy_ (u"ࠣࠤࠥࠤࡆࠦࡤࡰ࠯ࡱࡳࡹ࡮ࡩ࡯ࡩࠣࡦࡦࡹࡥࠡ࡯ࡨࡸ࡭ࡵࡤࠡࡨࡲࡶࠥࡨࡵࡪ࡮ࡧ࡭ࡳ࡭ࠠࡕࡎ࡙ࠤࡩࡧࡴࡢࠢࡩࡶࡴࡳࠠࡢࠢࡗࡐ࡛ࠦࡣ࡭ࡣࡶࡷࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࡔࡪࡲࡹࡱࡪࠠࡣࡧࠣ࡭ࡲࡶ࡬ࡦ࡯ࡨࡲࡹ࡫ࡤࠡࡤࡼࠤࡸࡻࡢࡤ࡮ࡤࡷࡸ࡫ࡳࠡࡶࡲࠤࡧࡻࡩ࡭ࡦࠣࡸ࡭࡫ࠠࡱࡣࡼࡰࡴࡧࡤࠡࡱࡱࡰࡾ࠴ࠠࡕࡪ࡬ࡷࠥࡳࡥࡵࡪࡲࡨࠥࡹࡨࡰࡷ࡯ࡨࠥࡴ࡯ࡵࠢࡥࡩࠥࡩࡡ࡭࡮ࡨࡨࠥࡪࡩࡳࡧࡦࡸࡱࡿ࠻ࠡ࡫ࡱࡷࡹ࡫ࡡࡥ࠮ࠣࡹࡸ࡫ࠠ࠻ࡲࡼ࠾ࡲ࡫ࡴࡩ࠼ࡣࡘࡑ࡜࠮ࡵࡱࡢࡦࡾࡺࡥࡴࡢ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣે")
        raise NotImplementedError
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        l11ll_opy_ (u"ࠤࠥࠦࠥࡇࠠࡥࡱ࠰ࡲࡴࡺࡨࡪࡰࡪࠤࡧࡧࡳࡦࠢࡦࡰࡦࡹࡳ࡮ࡧࡷ࡬ࡴࡪࠠࡧࡱࡵࠤࡵࡧࡲࡴ࡫ࡱ࡫ࠥࡧࠠࡕࡎ࡙ࠤ࡫ࡸ࡯࡮ࠢࡶࡩࡷ࡯ࡡ࡭࡫ࡽࡩࡩࠦࡤࡢࡶࡤ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࡔࡪࡲࡹࡱࡪࠠࡣࡧࠣ࡭ࡲࡶ࡬ࡦ࡯ࡨࡲࡹ࡫ࡤࠡࡤࡼࠤࡸࡻࡢࡤ࡮ࡤࡷࡸ࡫ࡳࠡࡶࡲࠤࡵࡧࡲࡴࡧࠣࡨࡦࡺࡡࠡࡨࡵࡳࡲࠦࡴࡩࡧࠣࡺࡦࡲࡵࡦ࠰ࠣࡗࡺࡨࡣ࡭ࡣࡶࡷࡪࡹࠠ࡮ࡣࡼࠤࡦࡹࡳࡶ࡯ࡨࠤࡹ࡮ࡡࡵࠢࡷ࡬࡮ࡹࠠ࡮ࡧࡷ࡬ࡴࡪࠠࡸ࡫࡯ࡰࠥࡵ࡮࡭ࡻࠣࡦࡪࠦࡣࡢ࡮࡯ࡩࡩࠦࡩࡧࠢ࡬ࡸࠥ࡯ࡳࠡ࡫ࡱࠤ࡫ࡧࡣࡵࠢࡧࡥࡹࡧࠠࡧࡱࡵࠤࡹ࡮ࡡࡵࠢࡶࡹࡧࡩ࡬ࡢࡵࡶ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࡔࡪࡲࡹࡱࡪࠠ࡯ࡱࡷࠤࡧ࡫ࠠࡤࡣ࡯ࡰࡪࡪࠠࡥ࡫ࡵࡩࡨࡺ࡬ࡺ࠽ࠣ࡭ࡳࡹࡴࡦࡣࡧ࠰ࠥࡻࡳࡦࠢ࠽ࡴࡾࡀ࡭ࡦࡶ࡫࠾ࡥ࡬ࡲࡰ࡯ࡢࡦࡾࡺࡥࡴࡢࠣࡳࡷࠦ࠺ࡱࡻ࠽ࡱࡪࡺࡨ࠻ࡢࡰࡹࡱࡺࡩࡱ࡮ࡨࡣ࡫ࡸ࡯࡮ࡡࡥࡽࡹ࡫ࡳࡡࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨૈ")
        cls.l111ll11ll_opy_().warning(l11ll_opy_ (u"ࠥࡘࡑ࡜ࠠࡼࡿࠣ࡭ࡸࠦࡰࡳࡧࡶࡩࡳࡺࠠࡣࡷࡷࠤࡳࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠨૉ")
                                 .format(cls.__name__))
        obj = cls()
        setattr(obj, l11ll_opy_ (u"ࠫࡤࡪࡥࡧࡣࡸࡰࡹࡥࡶࡢ࡮ࡸࡩࠬ૊"), l111l1ll1l_opy_)
        return obj
    @classmethod
    def _111l11111_opy_(cls, l111lll111_opy_, l111l1ll1l_opy_, l111ll1111_opy_):
        l11ll_opy_ (u"ࠧࠨࠢࠡࡄࡸ࡭ࡱࡪࠠࡵࡪࡨࠤࡦࡶࡰࡳࡱࡳࡶ࡮ࡧࡴࡦࠢࡦࡰࡦࡹࡳࠡࡨࡵࡳࡲࠦࡡࠡࡵࡲࡱࡪࡽࡨࡢࡶࠣࡴࡦࡸࡳࡦࡦࠣࡘࡑ࡜࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣࡐࡴࡵ࡫ࡴࠢࡸࡴࠥࡧ࡬࡭ࠢࡶࡹࡧࡩ࡬ࡢࡵࡶࡩࡸࠦ࡯ࡧࠢࡗࡐ࡛ࠦࡩ࡯ࠢࡪࡰࡴࡨࡡ࡭ࡵࠫ࠭ࠥࡧ࡮ࡥࠢࡦࡶࡪࡧࡴࡦࡵࠣࡥࡳࠦࡩ࡯ࡵࡷࡥࡳࡩࡥࠡࡱࡩࠤࡹ࡮ࡥࠡࡣࡳࡴࡷࡵࡰࡳ࡫ࡤࡸࡪࠦ࡯࡯ࡧࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢો")
        l111lll1ll_opy_ = (obj
                    for obj in l111ll1111_opy_
                    if issubclass(obj, cls) and obj is not cls)
        lookup = {obj.l1l11ll1ll_opy_ : obj for obj in l111lll1ll_opy_}
        try:
            return lookup[l111lll111_opy_].deserialize(l111l1ll1l_opy_)
        except KeyError:
            pass
        except:
            cls.l111ll11ll_opy_().exception(l11ll_opy_ (u"ࠨࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡧࡩࡸ࡫ࡲࡪࡣ࡯࡭ࡿ࡫ࠠࡕࡎ࡙ࠤࢀࢃࠢૌ")
                                       .format(l111lll111_opy_))
            raise KeyError
    @classmethod
    def l1ll11llll_opy_(cls, bytestring, l111ll1111_opy_):
        l11ll_opy_ (u"ࠢࠣࠤࠣࡔࡦࡸࡳࡦࠢࡤࠤࡸ࡯࡮ࡨ࡮ࡨࠤ࡙ࡒࡖࠡࡨࡵࡳࡲࠦࡡࠡࡤࡼࡸࡪࡹࡴࡳࡧࡤࡱࠥࡺࡨࡢࡶࠣ࡭ࡸࠦࡥࡹࡲࡨࡧࡹ࡫ࡤࠡࡶࡲࠤࡨࡵ࡮ࡵࡣ࡬ࡲࠥࡳ࡯ࡳࡧ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࡔࡩ࡫ࡶࠤ࡮ࡹࠠࡷࡧࡵࡽࠥࡹࡩ࡮࡫࡯ࡥࡷࠦࡴࡰࠢ࠽ࡴࡾࡀ࡭ࡦࡶ࡫࠾ࡥ࡬ࡲࡰ࡯ࡢࡦࡾࡺࡥࡴࡢࠣࡦࡺࡺࠠࡪࡰࠣࡥࡩࡪࡩࡵ࡫ࡲࡲࠥࡺ࡯ࠡࡴࡨࡸࡺࡸ࡮ࡪࡰࡪࠤࡹ࡮ࡥࠡࡲࡤࡶࡸ࡫ࡤࠡࡖࡏ࡚࠱ࠦࡡ࡭ࡵࡲࠤࡷ࡫ࡴࡶࡴࡱࡷࠥࡺࡨࡦࠢࡵࡩࡲࡧࡩ࡯࡫ࡱ࡫ࠥࡨࡹࡵࡧࡶ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤ્")
        l1111lll11_opy_ = goTenna.util.l1l11l11_opy_(bytestring[0])
        l1111lll1l_opy_ = goTenna.util.l1l11l11_opy_(bytestring[1])
        value = bytestring[2:l1111lll1l_opy_+2]
        return (cls._111l11111_opy_(l1111lll11_opy_, value, l111ll1111_opy_),
                bytestring[l1111lll1l_opy_+2:])
    @classmethod
    def from_bytes(cls, bytestring, l111ll1111_opy_):
        l11ll_opy_ (u"ࠣࠤࠥࠤࡈࡸࡥࡢࡶࡨࠤࡦࠦࡳࡪࡰࡪࡰࡪࠦࡔࡍࡘࠣࡪࡷࡵ࡭ࠡࡣࠣࡦࡾࡺࡥࡴࡶࡵࡩࡦࡳ࠮ࠡࡋࡩࠤࡲࡻ࡬ࡵ࡫ࡳࡰࡪࠦࡔࡍࡘࡶࠤࡦࡸࡥࠡࡦࡨࡷࡨࡸࡩࡣࡧࡧࠤ࡮ࡴࠠࡵࡪࡨࠤࡧࡿࡴࡦࡵࡷࡶࡪࡧ࡭࠭ࠢࡦࡶࡪࡧࡴࡦࠢࡲࡲࡱࡿࠠࡵࡪࡨࠤ࡫࡯ࡲࡴࡶࠣࡳࡳ࡫࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡦࡾࡺࡥࡴࠢࡥࡽࡹ࡫ࡳࡵࡴ࡬ࡲ࡬ࡀࠠࡕࡪࡨࠤࡻࡧ࡬ࡶࡧࠣࡸࡴࠦࡤࡦࡥࡲࡨࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡤ࡭ࡸ࡫ࡳࠡࡧࡻࡧࡪࡶࡴࡪࡱࡱ࠲ࡎࡴࡤࡦࡺࡈࡶࡷࡵࡲ࠻ࠢࡌࡪࠥࡺࡨࡦࠢࡥࡽࡹ࡫ࡳࡵࡴࡨࡥࡲࠦࡩࡴࠢࡷࡳࡴࠦࡳࡩࡱࡵࡸࠥ࡬࡯ࡳࠢࡷ࡬ࡪࠦࡥ࡯ࡥࡲࡨࡪࡪࠠࡕࡎ࡙ࠤ࡮ࡴࡦࡰࡴࡰࡥࡹ࡯࡯࡯࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤ࡮ࡺࡥࡳࡣࡥࡰࡪࡡࡴࡺࡲࡨࡷࡢࠦࡥࡹࡲࡨࡧࡹ࡫ࡤࡠࡶࡼࡴࡪࡹ࠺ࠡࡃࡱࠤ࡮ࡺࡥࡳࡣࡥࡰࡪࠦࡣࡰࡰࡷࡥ࡮ࡴࡩ࡯ࡩࠣࡘࡑ࡜ࠠࡴࡷࡥࡧࡱࡧࡳࡴࡧࡶࠤࡹ࡮ࡡࡵࠢࡺࡩࠥ࡫ࡸࡱࡧࡦࡸࠥࡳࡩࡨࡪࡷࠤࡧ࡫ࠠࡪࡰࠣࡸ࡭࡯ࡳࠡࡤࡼࡸࡪࡹࡴࡳ࡫ࡱ࡫ࠥ࠮ࡡࡵࠢࡷ࡬ࡪࠦࡴࡰࡲࠣࡰࡪࡼࡥ࡭ࠫ࠱ࠤ࡙࡮ࡩࡴࠢ࡬ࡷࠥࡴࡥࡤࡧࡶࡷࡦࡸࡹࠡࡤࡨࡧࡦࡻࡳࡦࠢࡧ࡭࡫࡬ࡥࡳࡧࡱࡸ࡚ࠥࡌࡗࡵࠣࡥࡹࠦࡤࡪࡨࡩࡩࡷ࡫࡮ࡵࠢ࡯ࡩࡻ࡫࡬ࡴࠢࡰ࡭࡬࡮ࡴࠡࡪࡤࡺࡪࠦ࡯ࡷࡧࡵࡰࡦࡶࡰࡪࡰࡪࠤࡹࡿࡰࡦࡵ࠽ࠤ࡫ࡵࡲࠡ࡫ࡱࡷࡹࡧ࡮ࡤࡧ࠯ࠤࡹ࡮ࡥࠡ࡯ࡨࡷࡸࡧࡧࡦࠢࡷࡽࡵ࡫ࠠࡕࡎ࡙ࠤࡦࡴࡤࠡ࡯ࡨࡷࡸࡧࡧࡦࠢࡳࡥࡾࡲ࡯ࡢࡦࠣࡘࡑ࡜ࡳࠡࡣࡵࡩࠥࡨ࡯ࡵࡪࠣࡸࡾࡶࡥࠡ࠷࠱ࠤ࡙࡮ࡩࡴࠢࡰࡳࡩࡻ࡬ࡦࠢࡧࡩ࡫࡯࡮ࡦࡵࠣࡷࡴࡳࡥࠡࡣࡷࡸࡷ࡯ࡢࡶࡶࡨࡷࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡯࡮ࡨࠢࡱࡥࡹࡻࡲࡢ࡮ࠣ࡫ࡷࡵࡵࡱ࡫ࡱ࡫ࡸࠦ࡯ࡧࠢࡷࡽࡵ࡫ࡳ࠭ࠢࡤࡲࡩࠦࡴࡩࡱࡶࡩࠥ࡭ࡲࡰࡷࡳ࡭ࡳ࡭ࡳࠡࡣࡵࡩࠥࡩ࡯࡮࡯ࡲࡲࠥࡼࡡࡳ࡫ࡤࡦࡱ࡫ࡳࠡࡨࡲࡶࠥࡺࡨࡪࡵࠣࡥࡷ࡭ࡵ࡮ࡧࡱࡸ࠳ࠦࡓࡦࡧࠣ࠾ࡵࡿ࠺ࡢࡶࡷࡶ࠿ࡦࡍࡆࡕࡖࡅࡌࡋ࡟ࡕࡎ࡙ࡗࡥࠦࡡ࡯ࡦࠣ࠾ࡵࡿ࠺ࡢࡶࡷࡶ࠿ࡦࡐࡂ࡛ࡏࡓࡆࡊ࡟ࡕࡎ࡙ࡗࡥ࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰࡶࠤ࡙ࡒࡖ࠻ࠢࡗ࡬ࡪࠦࡰࡢࡴࡶࡩࡩࠦࡔࡍࡘࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡡࡪࡵࡨࡷࠥ࡫ࡸࡤࡧࡳࡸ࡮ࡵ࡮࠯ࡋࡱࡨࡪࡾࡅࡳࡴࡲࡶ࠿ࠦࡉࡧࠢࡷ࡬ࡪࡸࡥࠡࡹࡤࡷࠥࡧࠠࡷࡣ࡯࡭ࡩࠦࡔࡍࡘࠣࡦࡺࡺࠠ࡯ࡱࡷࠤࡪࡴ࡯ࡶࡩ࡫ࠤࡩࡧࡴࡢࠢࡩࡳࡷࠦࡴࡩࡧࠣࡰࡪࡴࡧࡵࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡡࡪࡵࡨࡷࠥ࡫ࡸࡤࡧࡳࡸ࡮ࡵ࡮࠯ࡍࡨࡽࡊࡸࡲࡰࡴ࠽ࠤࡎ࡬ࠠࡵࡪࡨࠤ࡙ࡒࡖࠡࡷࡱ࡯ࡳࡵࡷ࡯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨ૎")
        return cls.l1ll11llll_opy_(bytestring, l111ll1111_opy_)[0]
    @staticmethod
    def l111l1l111_opy_(bytestring, l111ll1111_opy_):
        l11ll_opy_ (u"ࠤࠥࠦࠥࡉࡲࡦࡣࡷࡩࠥ࠶ࠠࡰࡴࠣࡱࡴࡸࡥࠡࡖࡏ࡚ࡸࠦࡦࡳࡱࡰࠤࡦࠦࡢࡺࡶࡨࡷࡹࡸࡥࡢ࡯࠱ࠤࡎ࡬ࠠ࡮ࡷ࡯ࡸ࡮ࡶ࡬ࡦࠢࡗࡐ࡛ࡹࠠࡢࡴࡨࠤࡩ࡫ࡳࡤࡴ࡬ࡦࡪࡪࠠࡪࡰࠣࡸ࡭࡫ࠠࡣࡻࡷࡩࡸࡺࡲࡦࡣࡰ࠰ࠥࡺࡨࡦࡻࠣࡻ࡮ࡲ࡬ࠡࡤࡨࠤࡵࡧࡲࡴࡧࡧࠤࡸ࡫ࡲࡪࡣ࡯ࡰࡾ࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡥࡽࡹ࡫ࡳࠡࡤࡼࡸࡪࡹࡴࡳ࡫ࡱ࡫࠿ࠦࡔࡩࡧࠣࡺࡦࡲࡵࡦࠢࡷࡳࠥࡪࡥࡤࡱࡧࡩࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡪࡶࡨࡶࡦࡨ࡬ࡦ࡝ࡷࡽࡵ࡫ࡳ࡞ࠢࡨࡼࡵ࡫ࡣࡵࡧࡧࡣࡹࡿࡰࡦࡵ࠽ࠤࡆࡴࠠࡪࡶࡨࡶࡦࡨ࡬ࡦࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡔࡍࡘࠣࡷࡺࡨࡣ࡭ࡣࡶࡷࡪࡹࠠࡵࡪࡤࡸࠥࡽࡥࠡࡧࡻࡴࡪࡩࡴࠡ࡯࡬࡫࡭ࡺࠠࡣࡧࠣ࡭ࡳࠦࡴࡩ࡫ࡶࠤࡧࡿࡴࡦࡵࡷࡶ࡮ࡴࡧࠡࠪࡤࡸࠥࡺࡨࡦࠢࡷࡳࡵࠦ࡬ࡦࡸࡨࡰ࠮࠴ࠠࡕࡪ࡬ࡷࠥ࡯ࡳࠡࡰࡨࡧࡪࡹࡳࡢࡴࡼࠤࡧ࡫ࡣࡢࡷࡶࡩࠥࡪࡩࡧࡨࡨࡶࡪࡴࡴࠡࡖࡏ࡚ࡸࠦࡡࡵࠢࡧ࡭࡫࡬ࡥࡳࡧࡱࡸࠥࡲࡥࡷࡧ࡯ࡷࠥࡳࡩࡨࡪࡷࠤ࡭ࡧࡶࡦࠢࡲࡺࡪࡸ࡬ࡢࡲࡳ࡭ࡳ࡭ࠠࡵࡻࡳࡩࡸࡀࠠࡧࡱࡵࠤ࡮ࡴࡳࡵࡣࡱࡧࡪ࠲ࠠࡵࡪࡨࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡺࡹࡱࡧࠣࡘࡑ࡜ࠠࡢࡰࡧࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡶࡡࡺ࡮ࡲࡥࡩࠦࡔࡍࡘࡶࠤࡦࡸࡥࠡࡤࡲࡸ࡭ࠦࡴࡺࡲࡨࠤ࠺࠴ࠠࡕࡪ࡬ࡷࠥࡳ࡯ࡥࡷ࡯ࡩࠥࡪࡥࡧ࡫ࡱࡩࡸࠦࡳࡰ࡯ࡨࠤࡦࡺࡴࡳ࡫ࡥࡹࡹ࡫ࡳࠡࡥࡲࡲࡹࡧࡩ࡯࡫ࡱ࡫ࠥࡴࡡࡵࡷࡵࡥࡱࠦࡧࡳࡱࡸࡴ࡮ࡴࡧࡴࠢࡲࡪࠥࡺࡹࡱࡧࡶ࠰ࠥࡧ࡮ࡥࠢࡷ࡬ࡴࡹࡥࠡࡩࡵࡳࡺࡶࡩ࡯ࡩࡶࠤࡦࡸࡥࠡࡥࡲࡱࡲࡵ࡮ࠡࡸࡤࡶ࡮ࡧࡢ࡭ࡧࡶࠤ࡫ࡵࡲࠡࡶ࡫࡭ࡸࠦࡡࡳࡩࡸࡱࡪࡴࡴ࠯ࠢࡖࡩࡪࠦ࠺ࡱࡻ࠽ࡥࡹࡺࡲ࠻ࡢࡷࡰࡻ࠴ࡁࡍࡎࡢࡘࡑ࡜ࡓࡡ࠮ࠣ࠾ࡵࡿ࠺ࡢࡶࡷࡶ࠿ࡦࡴ࡭ࡸ࠱ࡑࡊ࡙ࡓࡂࡉࡈࡣ࡙ࡒࡖࡔࡢ࠯ࠤ࠿ࡶࡹ࠻ࡣࡷࡸࡷࡀࡠࡵ࡮ࡹ࠲ࡕࡇ࡙ࡍࡑࡄࡈࡤ࡚ࡌࡗࡕࡣࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴࡳࠡ࡮࡬ࡷࡹࡡࡔࡍࡘࡠ࠾࡚ࠥࡨࡦࠢࡳࡥࡷࡹࡥࡥࠢࡗࡐ࡛ࡹࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦ૏")
        return [it for it in TLV.iterator_from_bytes(bytestring, l111ll1111_opy_)]
    @staticmethod
    def l111ll1l11_opy_(bytestring, l111l1llll_opy_):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡌࡪ࡭ࡨࠤ࠿ࡶࡹ࠻࡯ࡨࡸ࡭ࡀࡠ࡮ࡷ࡯ࡸ࡮ࡶ࡬ࡦࡡࡩࡶࡴࡳ࡟ࡣࡻࡷࡩࡸࡦࠠࡣࡷࡷࠤࡷ࡫ࡴࡶࡴࡱࡷࠥࡻ࡮ࡱࡣࡵࡷࡪࡪࠠࡥࡣࡷࡥࠥࡧࡳࠡࡹࡨࡰࡱࠦࡡࡴࠢࡷ࡬ࡪࠦࡰࡢࡴࡶࡩࡩࠦࡔࡍࡘࡶ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤૐ")
        class l111lll11l_opy_(object):
            def __init__(self):
                self.remaining = six.b(l11ll_opy_ (u"ࠫࠬ૑"))
            def __call__(self, l111ll111l_opy_):
                self.remaining = l111ll111l_opy_
        l11ll11l_opy_ = l111lll11l_opy_()
        tlvs = []
        try:
            for tlv in TLV.iterator_from_bytes(bytestring, l111l1llll_opy_, l11ll11l_opy_):
                tlvs.append(tlv)
        except Exception:
            _MODULE_LOGGER.exception(l11ll_opy_ (u"ࠧࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡲࡤࡶࡸ࡫ࠠࡢ࡮࡯ࠤ࡙ࡒࡖࡔ࠮ࠣࡿࢂࠦࠨࡼࡿࡅ࠭ࠥࡸࡥ࡮ࡣ࡬ࡲ࡮ࡴࡧࠣ૒")
                                     .format(goTenna.util.display_bytestring(l11ll11l_opy_.remaining),
                                             len(l11ll11l_opy_.remaining)))
        return (tlvs, l11ll11l_opy_.remaining)
    @staticmethod
    def iterator_from_bytes(bytestring, l111ll1111_opy_, l111l1l11l_opy_=None):
        l11ll_opy_ (u"ࠨࠢࠣࠢࡏࡥࡿ࡯࡬ࡺࠢࡳࡥࡷࡹࡥࡴࠢࡗࡐ࡛ࡹࠠࡧࡴࡲࡱࠥࡧࠠࡣࡻࡷࡩࡸࡺࡲࡦࡣࡰ࠰ࠥࡸࡥࡵࡷࡵࡲ࡮ࡴࡧࠡࡣࡱࠤ࡮ࡺࡥࡳࡣࡷࡳࡷࠦࡴࡩࡣࡷࠤࡼ࡯࡬࡭ࠢࡼ࡭ࡪࡲࡤࠡࡲࡤࡶࡸ࡫ࡤࠡࡖࡏ࡚ࡸ࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡥࡽࡹ࡫ࡳࠡࡤࡼࡸࡪࡹࡴࡳ࡫ࡱ࡫࠿ࠦࡔࡩࡧࠣࡺࡦࡲࡵࡦࠢࡷࡳࠥࡪࡥࡤࡱࡧࡩࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡪࡶࡨࡶࡦࡨ࡬ࡦ࡝ࡷࡽࡵ࡫ࡳ࡞ࠢࡨࡼࡵ࡫ࡣࡵࡧࡧࡣࡹࡿࡰࡦࡵ࠽ࠤࡆࡴࠠࡪࡶࡨࡶࡦࡨ࡬ࡦࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡔࡍࡘࠣࡷࡺࡨࡣ࡭ࡣࡶࡷࡪࡹࠠࡵࡪࡤࡸࠥࡽࡥࠡࡧࡻࡴࡪࡩࡴࠡ࡯࡬࡫࡭ࡺࠠࡣࡧࠣ࡭ࡳࠦࡴࡩ࡫ࡶࠤࡧࡿࡴࡦࡵࡷࡶ࡮ࡴࡧࠡࠪࡤࡸࠥࡺࡨࡦࠢࡷࡳࡵࠦ࡬ࡦࡸࡨࡰ࠮࠴ࠠࡕࡪ࡬ࡷࠥ࡯ࡳࠡࡰࡨࡧࡪࡹࡳࡢࡴࡼࠤࡧ࡫ࡣࡢࡷࡶࡩࠥࡪࡩࡧࡨࡨࡶࡪࡴࡴࠡࡖࡏ࡚ࡸࠦࡡࡵࠢࡧ࡭࡫࡬ࡥࡳࡧࡱࡸࠥࡲࡥࡷࡧ࡯ࡷࠥࡳࡩࡨࡪࡷࠤ࡭ࡧࡶࡦࠢࡲࡺࡪࡸ࡬ࡢࡲࡳ࡭ࡳ࡭ࠠࡵࡻࡳࡩࡸࡀࠠࡧࡱࡵࠤ࡮ࡴࡳࡵࡣࡱࡧࡪ࠲ࠠࡵࡪࡨࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡺࡹࡱࡧࠣࡘࡑ࡜ࠠࡢࡰࡧࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡶࡡࡺ࡮ࡲࡥࡩࠦࡔࡍࡘࡶࠤࡦࡸࡥࠡࡤࡲࡸ࡭ࠦࡴࡺࡲࡨࠤ࠺࠴ࠠࡕࡪ࡬ࡷࠥࡳ࡯ࡥࡷ࡯ࡩࠥࡪࡥࡧ࡫ࡱࡩࡸࠦࡳࡰ࡯ࡨࠤࡦࡺࡴࡳ࡫ࡥࡹࡹ࡫ࡳࠡࡥࡲࡲࡹࡧࡩ࡯࡫ࡱ࡫ࠥࡴࡡࡵࡷࡵࡥࡱࠦࡧࡳࡱࡸࡴ࡮ࡴࡧࡴࠢࡲࡪࠥࡺࡹࡱࡧࡶ࠰ࠥࡧ࡮ࡥࠢࡷ࡬ࡴࡹࡥࠡࡩࡵࡳࡺࡶࡩ࡯ࡩࡶࠤࡦࡸࡥࠡࡥࡲࡱࡲࡵ࡮ࠡࡸࡤࡶ࡮ࡧࡢ࡭ࡧࡶࠤ࡫ࡵࡲࠡࡶ࡫࡭ࡸࠦࡡࡳࡩࡸࡱࡪࡴࡴ࠯ࠢࡖࡩࡪࠦ࠺ࡱࡻ࠽ࡥࡹࡺࡲ࠻ࡢࡐࡉࡘ࡙ࡁࡈࡇࡢࡘࡑ࡜ࡓࡡ࠮ࠣࡥࡳࡪࠠ࠻ࡲࡼ࠾ࡦࡺࡴࡳ࠼ࡣࡔࡆ࡟ࡌࡐࡃࡇࡣ࡙ࡒࡖࡔࡢࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡷ࡫࡭ࡢ࡫ࡱ࡭ࡳ࡭࡟ࡤࡤ࠽ࠤࡆࠦࡣࡢ࡮࡯ࡥࡧࡲࡥࠡࡱࡩࠤࡹ࡮ࡥࠡࡨࡲࡶࡲࠦࡠࡡࡴࡨࡱࡦ࡯࡮ࡪࡰࡪࡣࡨࡨࠨࡳࡧࡰࡥ࡮ࡴࡩ࡯ࡩࠬࡤࡥ࠲ࠠࠡࡹ࡫ࡩࡷ࡫ࠠࡳࡧࡰࡥ࡮ࡴࡩ࡯ࡩࠣ࡭ࡸࠦࡴࡩࡧࠣࡹࡳࡶࡡࡳࡵࡨࡨࠥࡨࡹࡵࡧࡶࠤࡦ࡬ࡴࡦࡴࠣࡸ࡭࡯ࡳࠡࡨࡸࡲࡨࡺࡩࡰࡰࠣ࡭ࡸࠦࡤࡰࡰࡨ࠰ࠥࡵࡲࠡࡢࡣࡒࡴࡴࡥࡡࡢ࠱ࠤࡎ࡬ࠠࡴࡲࡨࡧ࡮࡬ࡩࡦࡦ࠯ࠤࡥࡦࡲࡦ࡯ࡤ࡭ࡳ࡯࡮ࡨࡡࡦࡦࡥࡦࠠࡸ࡫࡯ࡰࠥࡨࡥࠡࡥࡤࡰࡱ࡫ࡤࠡࡵ࡫ࡳࡷࡺ࡬ࡺࠢࡥࡩ࡫ࡵࡲࡦࠢࡷ࡬ࡪࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠡࡨ࡬ࡲ࡮ࡹࡨࡦࡵࠣࡻ࡮ࡺࡨࠡࡣࡱࡽࠥࡪࡡࡵࡣࠣࡸ࡭ࡧࡴࠡࡪࡤࡷࠥࡴ࡯ࡵࠢࡼࡩࡹࠦࡢࡦࡧࡱࠤࡵࡧࡲࡴࡧࡧ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡨࡸࡺࡸ࡮ࡴࠢ࡬ࡸࡪࡸࡡࡵࡱࡵ࡟࡙ࡒࡖ࡞࠼ࠣࡅࡳࠦࡩࡵࡧࡵࡥࡹࡵࡲࠡࡶ࡫ࡥࡹࠦࡹࡪࡧ࡯ࡨࡸࠦࡡࠡࡶࡸࡴࡱ࡫ࠠࡰࡨࠣࠬࡵࡧࡲࡴࡧࡧࠤ࡙ࡒࡖࡴ࠮ࠣࡶࡪࡳࡡࡪࡰࡧࡩࡷ࠯࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ૓")
        l1111ll1ll_opy_ = goTenna.util.l1111l1l_opy_(bytestring)
        while True:
            try:
                l111ll1ll1_opy_ = goTenna.util.l1l11l11_opy_(next(l1111ll1ll_opy_))
                l111lll1l1_opy_ = goTenna.util.l1l11l11_opy_(next(l1111ll1ll_opy_))
                l1111lllll_opy_ = goTenna.util.l1l1l1ll_opy_(itertools.islice(l1111ll1ll_opy_,
                                                                l111lll1l1_opy_))
            except StopIteration:
                break
            if len(l1111lllll_opy_) != l111lll1l1_opy_:
                remaining = goTenna.util.l1111l_opy_(l111ll1ll1_opy_)\
                            + goTenna.util.l1111l_opy_(l111lll1l1_opy_)\
                            + l1111lllll_opy_
                TLV.l111ll11ll_opy_().error(l11ll_opy_ (u"ࠢࡕࡎ࡙ࠤࢀࢃࠠࡱࡣࡵࡷࡪࡪࠠ࡭ࡧࡱ࡫ࡹ࡮ࠠࡣࡣࡧ࠰ࠥࢁࡽࠡࡹ࡬ࡸ࡭ࠦ࡯࡯࡮ࡼࠤࢀࢃࠠࡳࡧࡰࡥ࡮ࡴࡩ࡯ࡩࠥ૔")
                                       .format(l111ll1ll1_opy_,
                                               l111lll1l1_opy_, len(l1111lllll_opy_)))
                if l111l1l11l_opy_:
                    l111l1l11l_opy_(remaining)
                break
            try:
                yield TLV._111l11111_opy_(l111ll1ll1_opy_, l1111lllll_opy_,
                                           l111ll1111_opy_)
            except (IndexError, struct.error, KeyError):
                TLV.l111ll11ll_opy_().error(l11ll_opy_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡗࡐ࡛ࠦࡴࡺࡲࡨࠤࢀࢃࠬࠡࡰࡲࡸࠥ࡯࡮ࠡࡽࢀࠫ૕")
                                       .format(hex(l111ll1ll1_opy_),
                                               l111ll1111_opy_))
                remaining = goTenna.util.l1111l_opy_(l111ll1ll1_opy_)\
                            + goTenna.util.l1111l_opy_(l111lll1l1_opy_)\
                            + l1111lllll_opy_\
                            + goTenna.util.l1l1l1ll_opy_(l1111ll1ll_opy_)
                if l111l1l11l_opy_:
                    l111l1l11l_opy_(remaining)
                break
    def to_bytes(self):
        l11ll_opy_ (u"ࠤ࡙ࠥࠦࠥࡥࡳ࡫ࡤࡰ࡮ࢀࡥࠡࡣࠣࡘࡑ࡜ࠠࡵࡱࠣࡥࠥࡨࡹࡵࡧࡶࡸࡷ࡯࡮ࡨࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲࡸࠦࡢࡺࡶࡨࡷ࠿ࠦࡔࡩࡧࠣࡩࡳࡩ࡯ࡥࡧࡧࠤ࡙ࡒࡖࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ૖")
        payload = self.serialize()
        return struct.pack(l11ll_opy_ (u"ࠪࠥࡇࡈࡻࡾࡵࠪ૗").format(len(payload)),
                           self.l111lll111_opy_, len(payload),
                           payload)
    @property
    def l111lll111_opy_(self):
        l11ll_opy_ (u"ࠦࠧࠨࠠࡑࡴࡲࡴࡪࡸࡴࡺࠢࡩࡳࡷࠦࡧࡦࡶࡷ࡭ࡳ࡭ࠠࡵࡪࡨࠤ࡙ࡒࡖࠡࡶࡼࡴࡪ࠴ࠠࡔࡪࡲࡹࡱࡪࠠࡣࡧࠣࡳࡻ࡫ࡲࡳ࡫ࡧࡨࡪࡴࠠࡣࡻࠣࡧ࡭࡯࡬ࡥࡴࡨࡲ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ૘")
        raise NotImplementedError()
class l111l11lll_opy_(TLV):
    l11ll_opy_ (u"ࠧࠨࠢࠡࡃࠣࡘࡑ࡜ࠠࡣࡣࡶࡩࠥࡺࡨࡢࡶࠣ࡬ࡴࡲࡤࡴࠢࡲࡲࡱࡿࠠࡵࡧࡻࡸ࠳ࠐࠊࠡࠢࠣࠤ࡙࡮ࡩࡴࠢࡦࡥࡳࠦࡢࡦࠢ࡬ࡲ࡭࡫ࡲࡪࡶࡨࡨࠥࡺ࡯ࠡࡲࡵࡳࡻ࡯ࡤࡦࠢࡥࡥࡸ࡯ࡣࠡࡶࡨࡼࡹࠦࡣࡢࡲࡤࡦ࡮ࡲࡩࡵ࡫ࡨࡷ࠳ࠦࡉ࡯ࠢࡤࡨࡩ࡯ࡴࡪࡱࡱࠤࡹࡵࠠࡵࡪࡨࠤࡳࡵࡲ࡮ࡣ࡯ࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡲ࡫࡮ࡵࡵࠣࡪࡴࡸࠠࡰࡸࡨࡶࡷ࡯ࡤࡪࡰࡪࠤ࠿ࡶࡹ࠻ࡥ࡯ࡥࡸࡹ࠺ࡡࡖࡏ࡚ࡥ࠲ࠠࡤࡪ࡬ࡰࡩࡸࡥ࡯ࠢࡶ࡬ࡴࡻ࡬ࡥࠢ࡫ࡥࡻ࡫ࠊࠡࠢࠣࠤ࠲ࠦࡁࠡࡥ࡯ࡥࡸࡹࠠࡢࡶࡷࡶ࡮ࡨࡵࡵࡧࠣࡤࡥࡓࡁ࡙ࡡࡏࡉࡓࡍࡔࡉࡢࡣࠤࡩ࡫࡮ࡰࡶ࡬ࡲ࡬ࠦࡴࡩࡧࠣࡱࡦࡾࠠ࡭ࡧࡱ࡫ࡹ࡮ࠠࡴࡶ࡫ࡩࡾࠦࡣࡢࡰࠣ࡬ࡴࡲࡤࠋࠢࠣࠤࠥ࠳ࠠࡂࠢࡳࡶࡴࡶࡥࡳࡶࡼࠤࡥࡦ࡭ࡢࡺࡢࡰࡪࡴࡧࡵࡪࡣࡤࠥࡸࡥࡵࡷࡵࡲ࡮ࡴࡧࠡࡶ࡫ࡥࡹࠦࡡࡵࡶࡵ࡭ࡧࡻࡴࡦࠌࠣࠤࠥࠦࠢࠣࠤ૙")
    def __repr__(self):
        return l11ll_opy_ (u"࠭࠼ࡼࡿ࠽ࠤࡹ࡫ࡸࡵ࠿࡟ࠫࢀࢃ࡜ࠨࡀࠪ૚").format(self.__class__.__name__,
                                          self.contents)
    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and other.contents == self.contents
    @property
    def l111lll111_opy_(self):
        l11ll_opy_ (u"ࠢࠣࠤࠣࡔࡷࡵࡰࡦࡴࡷࡽࠥ࡬࡯ࡳࠢࡪࡩࡹࡺࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡕࡎ࡙ࠤࡹࡿࡰࡦ࠰ࠣࡗ࡭ࡵࡵ࡭ࡦࠣࡦࡪࠦ࡯ࡷࡧࡵࡶ࡮ࡪࡤࡦࡰࠣࡦࡾࠦࡣࡩ࡫࡯ࡨࡷ࡫࡮࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨ૛")
        raise NotImplementedError()
    @property
    def contents(self):
        l11ll_opy_ (u"ࠣࠤࠥࠤ࡙࡮ࡥࠡࡶࡨࡼࡹࠦࡣࡰࡰࡷࡩࡳࡺࡳࠡࡱࡩࠤࡹ࡮ࡥࠡࡖࡏ࡚࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡩࡹࡻࡲ࡯ࡵࠣࡷࡹࡸ࠺ࠡࡖ࡫ࡩࠥࡩ࡯࡯ࡶࡨࡲࡹࡹࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦ૜")
        return self._contents
    def __init__(self, text):
        l11ll_opy_ (u"ࠤࠥࠦࠥࡈࡵࡪ࡮ࡧࠤࡦࠦࡢࡢࡵ࡬ࡧࠥࡺࡥࡹࡶࠣࡘࡑ࡜ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡷࡩࡽࡺ࠺ࠡࡖ࡫ࡩࠥࡺࡥࡹࡶࠣࡪࡴࡸࠠࡵࡪࡨࠤࡲ࡫ࡳࡴࡣࡪࡩ࠳ࠦࡗࡪ࡮࡯ࠤࡧ࡫ࠠࡦࡰࡦࡳࡩ࡫ࡤࠡࡣࡶࠤ࡚࡚ࡆ࠮࠺࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣ૝")
        if not isinstance(text, (str, goTenna.util.UnicodeType)):
            raise TypeError
        l111l111l1_opy_ = goTenna.util.s2b(text)
        if len(l111l111l1_opy_) > self.l111ll11l1_opy_:
            raise ValueError(l11ll_opy_ (u"ࠥࡉࡳࡩ࡯ࡥࡧࡧࠤࡒ࡫ࡳࡴࡣࡪࡩࠥࡺ࡯ࡰࠢ࡯ࡳࡳ࡭ࠡࠣ૞"))
        self._contents = text
    @property
    def l111ll11l1_opy_(self):
        l11ll_opy_ (u"ࠦࠧࠨࠠࡕࡪࡨࠤࡲࡧࡸࡪ࡯ࡸࡱࠥࡲࡥ࡯ࡩࡷ࡬ࠥࡵࡦࠡࡧࡱࡧࡴࡪࡥࡥࠢࡷࡩࡽࡺࠠࡵࡪࡨࠤ࡙ࡒࡖࠡࡥࡤࡲࠥࡩ࡯࡯ࡶࡤ࡭ࡳࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡩࡹࡻࡲ࡯ࡵࠣ࡭ࡳࡺ࠺ࠡࡖ࡫ࡩࠥࡲࡥ࡯ࡩࡷ࡬࠱ࠦࡩ࡯ࠢࡥࡽࡹ࡫ࡳ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨ૟")
        raise NotImplementedError()
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        return cls(goTenna.util.b2s(l111l1ll1l_opy_))
    def serialize(self):
        return goTenna.util.s2b(self.contents)
class l111l1111l_opy_(TLV):
    l11ll_opy_ (u"ࠧࠨࠢࠡࡃࠣࡦࡦࡹࡩࡤࠢࡗࡐ࡛ࠦࡴࡩࡣࡷࠤࡨࡵ࡮ࡵࡣ࡬ࡲࡸࠦࡡࠡࡥࡲࡰࡴࡸࠠࡤࡱࡰࡴࡦࡺࡩࡣ࡮ࡨࠤࡼ࡯ࡴࡩࠢࡷ࡬ࡪࠦ࡯ࡵࡪࡨࡶ࡙ࠥࡄࡌࡵ࠱ࠎࠏࠦࠠࠡࠢࡗ࡬࡮ࡹࠠࡤ࡮ࡤࡷࡸࠦࡥ࡯ࡥࡲࡱࡵࡧࡳࡴࡧࡶࠤࡨࡵ࡮ࡴࡶࡵࡹࡨࡺࡩࡰࡰ࠯ࠤࡦࡩࡣࡦࡵࡶ࠰ࠥࡧ࡮ࡥࠢࡶࡩࡷ࠵ࡤࡦࡵࠣࡱࡪࡺࡨࡰࡦࡶࠤ࡫ࡵࡲࠡࡶ࡫ࡩࠥࡩ࡯࡭ࡱࡵࡷ࠱ࠦࡢࡶࡶࠣ࡭ࡸࠦ࡮ࡰࡶࠣ࡭ࡹࡹࡥ࡭ࡨࠣࡥ࡚ࠥࡌࡗࠢࡺࡩࠥࡶࡡࡴࡵࠣࡥࡷࡵࡵ࡯ࡦ࠱ࠤࡎࡺࠠࡩࡣࡶࠤࡳࡵࠠࡵࡻࡳࡩࠥࡧ࡮ࡥࠢࡶ࡬ࡴࡻ࡬ࡥࠢࡱࡳࡹࠦࡢࡦࠢ࡬ࡲࡸࡺࡡ࡯ࡶ࡬ࡥࡹ࡫ࡤࠡࡦ࡬ࡶࡪࡩࡴ࡭ࡻ࠱ࠤࡎࡴࡳࡵࡧࡤࡨ࠱ࠦࡩ࡯ࡵࡷࡥࡳࡺࡩࡢࡶࡨࠤࡹ࡮ࡥࠡࡲࡵࡳࡵ࡫ࡲࠡࡥ࡫࡭ࡱࡪࠠࡧࡱࡵࠤࡦࠦࡧࡪࡸࡨࡲࠥࡻࡳࡦ࠰ࠍࠤࠥࠦࠠࠣࠤࠥૠ")
    def __repr__(self):
        return l11ll_opy_ (u"࠭࠼ࡼࡿ࠽ࠤࡷࡃࡻࡾ࠮ࠣ࡫ࡂࢁࡽ࠭ࠢࡥࡁࢀࢃࠬࠡࡣࡀࡿࢂࡄࠧૡ")\
            .format(self.__class__.__name__,
                    self.l111l1ll11_opy_, self.l1111llll1_opy_, self.l111ll1lll_opy_, self.alpha)
    @property
    def l111lll111_opy_(self):
        raise NotImplementedError()
    @property
    def color(self):
        l11ll_opy_ (u"ࠢࠣࠤࠣࡘ࡭࡫ࠠࡤࡱ࡯ࡳࡷࠦࡡࡴࡵࡲࡧ࡮ࡧࡴࡦࡦࠣࡻ࡮ࡺࡨࠡࡶ࡫ࡩ࡚ࠥࡌࡗ࠮ࠣࡥࡸࠦࡡࠡ࠶࠰ࡦࡾࡺࡥࠡ࡫ࡱࡸࡪ࡭ࡥࡳ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤ࡚ࠥࡨࡦࠢࡩ࡭ࡷࡹࡴࠡࡤࡼࡸࡪࠦࡩࡴࠢࡤࡰࡵ࡮ࡡࠋࠢࠣࠤࠥࠦࠠࠡࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡢࡺࡶࡨࠤ࡮ࡹࠠࡳࡧࡧࠎࠥࠦࠠࠡࠢࠣࠤ࡚ࠥࡨࡦࠢࡷ࡬࡮ࡸࡤࠡࡤࡼࡸࡪࠦࡩࡴࠢࡪࡶࡪ࡫࡮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࡗ࡬ࡪࠦࡦࡰࡷࡵࡸ࡭ࠦࡢࡺࡶࡨࠤ࡮ࡹࠠࡣ࡮ࡸࡩࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࡕࡪࡨࡷࡪࠦࡡࡳࡧࠣࡥࡨࡩࡥࡴࡵ࡬ࡦࡱ࡫ࠠࡪࡰࡧ࡭ࡻ࡯ࡤࡶࡣ࡯ࡰࡾࠦࡷࡪࡶ࡫ࠤࡹ࡮ࡥࠡ࠼ࡳࡽ࠿ࡧࡴࡵࡴ࠽ࡤࡦࡲࡰࡩࡣࡣ࠰ࠥࡀࡰࡺ࠼ࡤࡸࡹࡸ࠺ࡡࡴࡨࡨࡥ࠲ࠠ࠻ࡲࡼ࠾ࡦࡺࡴࡳ࠼ࡣ࡫ࡷ࡫ࡥ࡯ࡢ࠯ࠤࡦࡴࡤࠡ࠼ࡳࡽ࠿ࡧࡴࡵࡴ࠽ࡤࡧࡲࡵࡦࡢࠣࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠠࡰࡨࠣࡸ࡭࡯ࡳࠡࡥ࡯ࡥࡸࡹ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧૢ")
        return self._color
    @property
    def alpha(self):
        l11ll_opy_ (u"ࠣࠤࠥࠤ࡙࡮ࡥࠡࡣ࡯ࡴ࡭ࡧࠠࡷࡣ࡯ࡹࡪࠦࡡࡴࡵࡲࡧ࡮ࡧࡴࡦࡦࠣࡻ࡮ࡺࡨࠡࡶ࡫ࡩ࡚ࠥࡌࡗࠢࠥࠦࠧૣ")
        return (self._color & 0xff000000) >> 24
    @property
    def l111l1ll11_opy_(self):
        l11ll_opy_ (u"ࠤ࡚ࠥࠦࠥࡨࡦࠢࡵࡩࡩࠦࡶࡢ࡮ࡸࡩࠥࡧࡳࡴࡱࡦ࡭ࡦࡺࡥࡥࠢࡺ࡭ࡹ࡮ࠠࡵࡪࡨࠤ࡙ࡒࡖࠡࠤࠥࠦ૤")
        return (self._color & 0x00ff0000) >> 16
    @property
    def l1111llll1_opy_(self):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡔࡩࡧࠣ࡫ࡷ࡫ࡥ࡯ࠢࡹࡥࡱࡻࡥࠡࡣࡶࡷࡴࡩࡩࡢࡶࡨࡨࠥࡽࡩࡵࡪࠣࡸ࡭࡫ࠠࡕࡎ࡙ࠤࠧࠨࠢ૥")
        return (self._color & 0x0000ff00) >> 8
    @property
    def l111ll1lll_opy_(self):
        l11ll_opy_ (u"ࠦࠧࠨࠠࡕࡪࡨࠤࡧࡲࡵࡦࠢࡹࡥࡱࡻࡥࠡࡣࡶࡷࡴࡩࡩࡢࡶࡨࡨࠥࡽࡩࡵࡪࠣࡸ࡭࡫ࠠࡕࡎ࡙ࠤࠧࠨࠢ૦")
        return self._color & 0x000000ff
    @property
    def color_tuple(self):
        l11ll_opy_ (u"ࠧࠨࠢࠡࡖ࡫ࡩࠥࡩ࡯࡭ࡱࡵࠤࡦࡹࠠࡢࠢࡷࡹࡵࡲࡥࠩࡴ࠯࡫࠱ࡨࠬࡢࠫࠥࠦࠧ૧")
        return (self.l111l1ll11_opy_, self.l1111llll1_opy_, self.l111ll1lll_opy_, self.alpha)
    def __init__(self, l111l1ll11_opy_=None, l1111llll1_opy_=None, l111ll1lll_opy_=None, alpha=None,
                 l111l11ll1_opy_=None, color_tuple=None):
        l11ll_opy_ (u"ࠨࠢࠣࠢࡅࡹ࡮ࡲࡤࠡࡣࠣࡆࡦࡹࡩࡤࡅࡲࡰࡴࡸࡔࡍࡘ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࡔࡩࡧࡵࡩࠥࡧࡲࡦࠢࡤࠤࡨࡵࡵࡱ࡮ࡨࠤࡩ࡯ࡦࡧࡧࡵࡩࡳࡺࠠࡸࡣࡼࡷࠥࡺ࡯ࠡࡤࡸ࡭ࡱࡪࠠࡵࡪ࡬ࡷ࡚ࠥࡌࡗࠢࡥࡥࡸ࡫ࡤࠡࡱࡱࠤࡩ࡯ࡦࡧࡧࡵࡩࡳࡺࠠࡪࡰࡳࡹࡹࠦࡤࡢࡶࡤ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࡕࡪࡨࠤ࡫࡯ࡲࡴࡶࠣࡻࡦࡿࠠࡪࡵࠣࡸࡴࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡴࡱࡰࡩࠥࡵࡲࠡࡣ࡯ࡰࠥࡵࡦࠡࡢࡣࡶࡪࡪࡠࡡ࠮ࠣࡤࡥ࡭ࡲࡦࡧࡱࡤࡥ࠲ࠠࡡࡢࡥࡰࡺ࡫ࡠࡡ࠮ࠣࡥࡳࡪࠠࡡࡢࡤࡰࡵ࡮ࡡࡡࡢ࠱ࠤࡎ࡬ࠠࡢࡰࡼࠤࡴ࡬ࠠࡵࡪࡨࡷࡪࠦࡡࡳࡧࠣࡷࡵ࡫ࡣࡪࡨ࡬ࡩࡩ࠲ࠠࡵࡪࡨࠤࡴࡺࡨࡦࡴࡶࠤࡦࡸࡥࠡࡣࡶࡷࡺࡳࡥࡥࠢࡷࡳࠥࡨࡥࠡ࠲࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࡔࡩࡧࠣࡷࡪࡩ࡯࡯ࡦࠣࡻࡦࡿࠠࡪࡵࠣࡸࡴࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡡࡢࡦࡳࡱࡵࡲࡠ࡫ࡱࡸࡥࡦࠠࡢࡵࠣࡥࡳࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡵࡪࡤࡸࠥࡽࡩ࡭࡮ࠣࡦࡪࠦࡩ࡯ࡶࡨࡶࡵࡸࡥࡵࡧࡧࠤࡦࡹࠠࡢࠢࡦࡳࡱࡵࡲࠡࡲࡤࡧࡰ࡫ࡤࠡ࡫ࡱࡸࡴࠦࠨࡢ࡮ࡳ࡬ࡦ࠲ࠠࡳࡧࡧ࠰ࠥ࡭ࡲࡦࡧࡱ࠰ࠥࡨ࡬ࡶࡧࠬࠤࡼ࡯ࡴࡩࠢࡤࠤࡧࡿࡴࡦࠢࡩࡳࡷࠦࡥࡢࡥ࡫ࠤ࠭ࡺࡨࡪࡵࠣ࡭ࡸࠦࡵࡴࡧࡧࠤࡵࡸࡩ࡮ࡣࡵ࡭ࡱࡿࠠࡧࡱࡵࠤࡩ࡫ࡳࡦࡴ࡬ࡥࡱ࡯ࡺࡢࡶ࡬ࡳࡳ࠯࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣࡘ࡭࡫ࠠࡵࡪ࡬ࡶࡩࠦࡷࡢࡻࠣ࡭ࡸࠦࡴࡰࠢࡶࡴࡪࡩࡩࡧࡻࠣࡤࡥࡩ࡯࡭ࡱࡵࡣࡹࡻࡰ࡭ࡧࡣࡤࠥࡧࡳࠡࡣࠣࡸࡺࡶ࡬ࡦࠢࡲࡪࠥ࠮ࡲࡦࡦ࠯ࠤ࡬ࡸࡥࡦࡰ࠯ࠤࡧࡲࡵࡦ࠮ࠣࡥࡱࡶࡨࡢࠫ࠱ࠤࡎ࡬ࠠࡵࡪ࡬ࡷࠥ࡯ࡳࠡࡷࡶࡩࡩ࠲ࠠࡪࡶࠣࡱࡺࡹࡴࠡࡤࡨࠤ࠹ࠦࡥ࡭ࡧࡰࡩࡳࡺࡳࠡ࡮ࡲࡲ࡬ࠦࡡ࡯ࡦࠣࡥࡱࡲࠠࡦ࡮ࡨࡱࡪࡴࡴࡴࠢࡰࡹࡸࡺࠠࡣࡧࠣࡲࡺࡳࡥࡳ࡫ࡦ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࡊࡨࠣࡥࡳࡿࠠࡴࡲࡨࡧ࡮࡬ࡩࡦࡦࠣࡩࡱ࡫࡭ࡦࡰࡷࠤ࡮ࡹࠠࡢࠢࡩࡰࡴࡧࡴࠡ࡫ࡷࠤࡼ࡯࡬࡭ࠢࡥࡩࠥ࡯࡮ࡵࡧࡵࡴࡷ࡫ࡴࡦࡦࠣࡥࡸࠦࡩࡧࠢࡩࡹࡱࡲࠠࡪࡰࡷࡩࡳࡹࡩࡵࡻࠣ࡭ࡸࠦ࠱ࠡࡣࡱࡨࠥࡴ࡯ࠡ࡫ࡱࡸࡪࡴࡳࡪࡶࡼࠤ࡮ࡹࠠ࠱࠰ࠣࡍ࡫ࠦࡡ࡯ࡻࠣࡷࡵ࡫ࡣࡪࡨ࡬ࡩࡩࠦࡥ࡭ࡧࡰࡩࡳࡺࠠࡪࡵࠣࡥࡳࠦࡩ࡯ࡶࠣ࡭ࡹࠦࡷࡪ࡮࡯ࠤࡧ࡫ࠠࡪࡰࡷࡩࡷࡶࡲࡦࡶࡨࡨࠥࡧࡳࠡ࡫ࡩࠤ࡫ࡻ࡬࡭ࠢ࡬ࡲࡹ࡫࡮ࡴ࡫ࡷࡽࠥ࡯ࡳࠡ࠴࠸࠹ࠥࡧ࡮ࡥࠢࡱࡳࠥ࡯࡮ࡵࡧࡱࡷ࡮ࡺࡹࠡ࡫ࡶࠤ࠵࠴ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢࡌࡪࠥࡳ࡯ࡳࡧࠣࡸ࡭ࡧ࡮ࠡࡱࡱࡩࠥࡹࡥࡵࠢࡲࡪࠥࡧࡲࡨࡷࡰࡩࡳࡺࡳࠡ࡫ࡶࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠬࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡸࡪ࡬ࡧ࡭ࠦ࡯࡯ࡧࠣࡻ࡮ࡲ࡬ࠡࡤࡨࠤࡵࡧࡲࡴࡧࡧ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡤ࡭ࡸ࡫ࡳࠡࡘࡤࡰࡺ࡫ࡅࡳࡴࡲࡶ࠿ࠦࡉࡧࠢࡱࡳࡳ࡫ࠠࡰࡨࠣࡸ࡭࡫ࠠࡢࡤࡲࡺࡪࠦࡳࡦࡶࡶࠤࡴ࡬ࠠࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠣ࡭ࡸࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥ࠮ࠣ࡭࡫ࠦࡡ࡯ࠢ࡬ࡲࡹ࡫ࡧࡳࡣ࡯ࠤࡦࡸࡧࡶ࡯ࡨࡲࡹࠦࠨࡰࡶ࡫ࡩࡷࠦࡴࡩࡣࡱࠤࡥࡦࡣࡰ࡮ࡲࡶࡤ࡯࡮ࡵࡢࡣ࠭ࠥ࡯ࡳࠡࡱࡸࡸࡸ࡯ࡤࡦࠢ࡞࠴࠱ࠦ࠲࠶࠷ࡠࠤࡴࡸࠠࡢࠢࡩࡰࡴࡧࡴࠡࡣࡵ࡫ࡺࡳࡥ࡯ࡶࠣ࡭ࡸࠦ࡯ࡶࡶࡶ࡭ࡩ࡫ࠠ࡜࠲࠱࠴࠱ࠦ࠱࠯࠲ࡠࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡢ࡫ࡶࡩࡸࠦࡔࡺࡲࡨࡉࡷࡸ࡯ࡳ࠼ࠣࡍ࡫ࠦ࡯࡯ࡧࠣࡳ࡫ࠦࡴࡩࡧࠣࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸ࠭ࠠࡵࡻࡳࡩࡸࠦࡩࡴࠢࡥࡥࡩࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ૨")
        if not any([arg is not None
                    for arg
                    in [l111l1ll11_opy_, l1111llll1_opy_, l111ll1lll_opy_, alpha, l111l11ll1_opy_, color_tuple]]):
            raise ValueError(l11ll_opy_ (u"ࠢࡔࡱࡰࡩࠥࡧࡲࡨࡷࡰࡩࡳࡺࡳࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡶࡴࡪࡩࡩࡧ࡫ࡨࡨࠧ૩"))
        def _111l1l1ll_opy_(pieces):
            color = 0
            for index, arg in enumerate(reversed(pieces)):
                if arg is None:
                    arg = 0
                if isinstance(arg, int):
                    if arg < 0 or arg > 255:
                        raise ValueError(l11ll_opy_ (u"ࠨ࡫ࡱࡨ࡮ࡼࡩࡥࡷࡤࡰࠥࡩࡨࡢࡰࡱࡩࡱࡹࠠࡴࡲࡨࡧ࡮࡬ࡩࡦࡦࠣࡻ࡮ࡺࡨࠡ࡫ࡱࡸࡸࠦ࡭ࡶࡵࡷࠤࡧ࡫ࠠࡪࡰࠣ࡟࠵࠲ࠠ࠳࠷࠸ࡡ࠱ࠦ࡮ࡰࡶࠣࡿࢂ࠭૪")
                                         .format(arg))
                    color += arg << (index*8)
                elif isinstance(arg, float):
                    if arg < 0 or arg > 1.0:
                        raise ValueError(l11ll_opy_ (u"ࠩ࡬ࡲࡩ࡯ࡶࡪࡦࡸࡥࡱࠦࡣࡩࡣࡱࡲࡪࡲࡳࠡࡵࡳࡩࡨ࡯ࡦࡪࡧࡧࠤࡼ࡯ࡴࡩࠢࡩࡰࡴࡧࡴࡴࠢࡰࡹࡸࡺࠠࡣࡧࠣ࡭ࡳ࡛ࠦ࠱࠰࠳࠰ࠥ࠷࠮࠱࡟࠯ࠤࡳࡵࡴࠡࡽࢀࠫ૫")
                                         .format(arg))
                    color += int(arg*255) << (index*8)
                else:
                    raise TypeError(l11ll_opy_ (u"ࠪ࡭ࡳࡪࡩࡷ࡫ࡧࡹࡦࡲࠠࡤࡪࡤࡲࡳ࡫࡬ࡴࠢࡰࡹࡸࡺࠠࡣࡧࠣࡷࡵ࡫ࡣࡪࡨ࡬ࡩࡩࠦࡷࡪࡶ࡫ࠤࡪ࡯ࡴࡩࡧࡵࠤ࡮ࡴࡴࡴࠢ࡬ࡲࠥࡡ࠰࠭ࠢ࠵࠹࠺ࡣࠠࡰࡴࠣࡪࡱࡵࡡࡵࡵࠣ࡭ࡳ࡛ࠦ࠱࠰࠳࠰ࠥ࠷࠮࠱࡟ࠣࡲࡴࡺࠠࡼࡿࠪ૬")
                                    .format(type(arg)))
            return color
        if any([arg is not None for arg in [l111l1ll11_opy_, l1111llll1_opy_, l111ll1lll_opy_, alpha]]):
            self._color = _111l1l1ll_opy_((alpha, l111l1ll11_opy_, l1111llll1_opy_, l111ll1lll_opy_))
        elif l111l11ll1_opy_ is not None:
            if not isinstance(l111l11ll1_opy_, int):
                raise TypeError(l11ll_opy_ (u"ࠫ࡮࡬ࠠࡤࡱ࡯ࡳࡷࡥࡩ࡯ࡶࠣ࡭ࡸࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢ࡬ࡸࠥࡳࡵࡴࡶࠣࡦࡪࠦࡩ࡯ࡶࡨ࡫ࡷࡧ࡬࠭ࠢ࡬ࡷࠥࢁࡽࠨ૭").format(type(l111l11ll1_opy_)))
            if l111l11ll1_opy_ < 0 or l111l11ll1_opy_ > (2**32-1):
                raise ValueError(l11ll_opy_ (u"ࠬࡩ࡯࡭ࡱࡵࡣ࡮ࡴࡴࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡤࠤࡵࡵࡳࡪࡶ࡬ࡺࡪࠦ࠳࠳࠯ࡥ࡭ࡹࠦࡩ࡯ࡶࠪ૮"))
            self._color = l111l11ll1_opy_
        elif color_tuple is not None:
            if not isinstance(color_tuple, tuple):
                raise TypeError(l11ll_opy_ (u"࠭ࡩࡧࠢࡶࡴࡪࡩࡩࡧ࡫ࡨࡨ࠱ࠦࡣࡰ࡮ࡲࡶࡤࡺࡵࡱ࡮ࡨࠤࡲࡻࡳࡵࠢࡥࡩࠥࡧࠠࡵࡷࡳࡰࡪࠦࡢࡶࡶࠣ࡭ࡸࠦࡻࡾࠩ૯")
                                .format(type(color_tuple)))
            if len(color_tuple) != 4:
                raise ValueError
            self._color = _111l1l1ll_opy_((color_tuple[3], color_tuple[0],
                                              color_tuple[1], color_tuple[2]))
        else:
            raise ValueError
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        return cls(l111l11ll1_opy_=struct.unpack(l11ll_opy_ (u"ࠧࠢࡋࠪ૰"), l111l1ll1l_opy_)[0])
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠨࠣࡌࠫ૱"), self._color)
    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.color == other.color
class l111llll11_opy_(TLV):
    l11ll_opy_ (u"ࠤࠥࠦࠥࡇࠠࡕࡎ࡙ࠤࡹ࡮ࡡࡵࠢࡧࡳࡪࡹࠠ࡯ࡱࡷ࡬࡮ࡴࡧࠡࡤࡸࡸࠥ࡫࡮ࡤࡣࡳࡷࡺࡲࡡࡵࡧࠣࡳࡹ࡮ࡥࡳࠢࡗࡐ࡛ࡹࠊࠋࠢࠣࠤ࡚ࠥࡨࡪࡵࠣ࡭ࡸࠦࡵࡴࡧࡧࠤࡦࡹࠠࡢࠢࡦࡳࡳࡺࡡࡪࡰࡨࡶࠥ࡬࡯ࡳࠢࡗࡐ࡛ࡹ࠮ࠡࡋࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡷࡹࠠࡰࡨࠣࡘࡑ࡜ࡳࠡࡶ࡫ࡥࡹࠦࡣࡰࡰࡷࡥ࡮ࡴࠠࡰࡶ࡫ࡩࡷࠦࡔࡍࡘࡶࠤࡨࡧ࡮ࠡ࡫ࡱ࡬ࡪࡸࡩࡵࠢࡩࡶࡴࡳࠠࡵࡪ࡬ࡷࠥࡩ࡬ࡢࡵࡶ࠰ࠥࡧࡳࠡ࡮ࡲࡲ࡬ࠦࡡࡴࠢࡷ࡬ࡪࡿࠠࡪ࡯ࡳࡰࡪࡳࡥ࡯ࡶࠣࠬ࡮ࡴࠠࡢࡦࡧ࡭ࡹ࡯࡯࡯ࠢࡷࡳࠥࡺࡨࡦࠢࡗࡐ࡛ࠦࡴࡺࡲࡨࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡲ࡫࡮ࡵࡵࠬ࠾ࠏࠐࠠࠡࠢࠣ࠱ࠥࡇࠠࡤ࡮ࡤࡷࡸࠦࡡࡵࡶࡵ࡭ࡧࡻࡴࡦࠢࡄࡇࡈࡋࡐࡕࡃࡅࡐࡊࡥࡃࡐࡐࡗࡉࡓ࡚ࡓࠡࡥࡲࡲࡹࡧࡩ࡯࡫ࡱ࡫ࠥࡧࠠࡵࡷࡳࡰࡪࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡔࡍࡘࠣࡧࡱࡧࡳࡴࡧࡶࠤࡪࡾࡰࡦࡥࡷࡩࡩࠦࡴࡰࠢࡥࡩࠥࡶࡲࡦࡵࡨࡲࡹࠦࡩ࡯ࠢࡷ࡬ࡪࠦࡣࡰࡰࡷࡩࡳࡺࡳࠋࠢࠣࠤࠥ࠳ࠠࡂࠢࡳࡶࡴࡶࡥࡳࡶࡼࠤࡥࡦࡡࡤࡥࡨࡴࡹࡧࡢ࡭ࡧࡢࡧࡴࡴࡴࡦࡰࡷࡷࡥࡦࠠࡳࡧࡷࡹࡷࡴࡩ࡯ࡩࠣࡸ࡭ࡧࡴࠡࡣࡷࡸࡷ࡯ࡢࡶࡶࡨࠎࠏࠦࠠࠡࠢࡗ࡬࡮ࡹࠠࡪࡵࠣࡥࠥ࡮ࡥ࡭ࡲࡨࡶࠥࡩ࡬ࡢࡵࡶࠤࡦࡴࡤࠡࡵ࡫ࡳࡺࡲࡤࠡࡰࡲࡸࠥࡨࡥࠡ࡫ࡱࡷࡹࡧ࡮ࡵ࡫ࡤࡸࡪࡪࠠࡥ࡫ࡵࡩࡨࡺ࡬ࡺ࠰ࠍࠤࠥࠦࠠࠣࠤࠥ૲")
    def __repr__(self):
        return l11ll_opy_ (u"ࠪࡀࢀࢃ࠺ࠡࡥࡲࡲࡹ࡫࡮ࡵࡵࡀࡿࢂࡄࠧ૳").format(self.__class__.__name__,
                                          self.contents)
    def __eq__(self, other):
        return isinstance(other, self.__class__)\
            and other.contents == self.contents
    @property
    def contents(self):
        l11ll_opy_ (u"ࠦࠧࠨࠠࡓࡧࡷࡹࡷࡴࠠࡵࡪࡨࠤ࡙ࡒࡖࡴࠢ࡬ࡲࠥࡺࡨࡦࠢࡦࡳࡳࡺࡡࡪࡰࡨࡶࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡨࡸࡺࡸ࡮ࡴࠢ࡯࡭ࡸࡺ࡛ࡕࡎ࡙ࡡ࠿ࠦࡔࡩࡧࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡩࠦࡔࡍࡘࡶࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣ૴")
        return self._contents
    @property
    def l111l1l1l1_opy_(self):
        l11ll_opy_ (u"ࠧࠨࠢࠡࡔࡨࡸࡺࡸ࡮ࠡࡣࡱࠤ࡮ࡺࡥࡳࡣࡥࡰࡪࠦࡣࡰࡰࡷࡥ࡮ࡴࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡵࡻࡳࡩࡸࠦࡴࡩ࡫ࡶࠤࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠠ࡮ࡣࡼࠤࡸࡺ࡯ࡳࡧ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࡔࡩ࡫ࡶࠤ࡮ࡹࠠࡶࡵࡨࡨࠥࡨࡹࠡࡶ࡫ࡩࠥࡪࡥࡴࡧࡵ࡭ࡦࡲࡩࡻࡣࡷ࡭ࡴࡴࠠ࡮ࡣࡦ࡬࡮ࡴࡥࡳࡻࠣࡸࡴࠦࡤࡦࡶࡨࡶࡲ࡯࡮ࡦࠢ࡬ࡪࠥࡧࠠࡴࡷࡥࡧࡱࡧࡳࡴࠢ࡬ࡷࠥࡧࠠࡷࡣ࡯࡭ࡩࠦࡣࡢࡰࡧ࡭ࡩࡧࡴࡦࠢࡩࡳࡷࠦࡤࡦࡵࡨࡶ࡮ࡧ࡬ࡪࡼࡤࡸ࡮ࡵ࡮࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲࡸࠦࡩࡵࡧࡵࡥࡧࡲࡥ࡜ࡶࡼࡴࡪࡣ࠺ࠡࡖ࡫ࡩࠥࡺࡹࡱࡧࡶࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣ૵")
        raise NotImplementedError()
    def __init__(self, tlvs):
        l11ll_opy_ (u"ࠨࠢࠣࠢࡅࡹ࡮ࡲࡤࠡࡣࠣࡔࡪࡸࡩ࡮ࡧࡷࡩࡷࡊࡡࡵࡣࡗࡐ࡛࠴ࠊࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡸࡱࡼࡳ࠻ࠢࡄࡲࠥ࡯ࡴࡦࡴࡤࡦࡱ࡫ࠠࡰࡨࠣ࡭ࡳࡹࡴࡢࡰࡦࡩࡸࠦ࡯ࡧࠢࡦࡰࡦࡹࡳࡦࡵࠣ࡭ࡳࠦ࠺ࡱࡻ࠽ࡥࡹࡺࡲ࠻ࡢࡄࡇࡈࡋࡐࡕࡃࡅࡐࡊࡥࡃࡐࡐࡗࡉࡓ࡚ࡓࡡ࠰ࠣࡘ࡭࡫ࡲࡦࠢࡶ࡬ࡴࡻ࡬ࡥࠢࡥࡩࠥࡧࡴࠡ࡯ࡲࡷࡹࠦ࡯࡯ࡧࠣࡳ࡫ࠦࡥࡢࡥ࡫࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤ૶")
        l111ll1l1l_opy_ = set()
        for item in tlvs:
            if not isinstance(item, self.l111l1l1l1_opy_):
                raise TypeError(item)
            if isinstance(item, tuple(l111ll1l1l_opy_)):
                raise ValueError
            l111ll1l1l_opy_.add(type(item))
        self._contents = tuple(tlvs)
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        return cls(TLV.l111l1l111_opy_(l111l1ll1l_opy_, cls.l111l11l1l_opy_))
    def serialize(self):
        return six.b(l11ll_opy_ (u"ࠧࠨ૷")).join([t.to_bytes() for t in self._contents])
class l111l111ll_opy_(TLV):
    l11ll_opy_ (u"ࠣࠤࠥࠤࡆࠦࡔࡍࡘࠣࡪࡴࡸࠠࡩࡱ࡯ࡨ࡮ࡴࡧࠡࡣࠣࡂ࠷࠻࠵࠮ࡤࡼࡸࡪࠦࡔࡍࡘࠍࠤࠥࠦࠠࠣࠤࠥ૸")
    l1l11ll1ll_opy_ = 253
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
class l111l1lll1_opy_(TLV):
    l11ll_opy_ (u"ࠤࠥࠦࠥࡇࠠࡕࡎ࡙ࠤ࡫ࡵࡲࠡࡪࡲࡰࡩ࡯࡮ࡨࠢࡤࠤࡃ࠼࠵࠶࠵࠸࠱ࡧࡿࡴࡦࠢࡗࡐ࡛ࠐࠠࠡࠢࠣࠦࠧࠨૹ")
    l1l11ll1ll_opy_ = 254
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
class l111l11l11_opy_(TLV):
    l11ll_opy_ (u"ࠥࠦࠧࠦࡁࠡࡖࡏ࡚ࠥ࡬࡯ࡳࠢ࡫ࡳࡱࡪࡩ࡯ࡩࠣࡥࠥࡄ࠲ࠫࠬ࠵࠸࠲ࡨࡹࡵࡧࠣࡘࡑ࡜ࠊࠡࠢࠣࠤࠧࠨࠢૺ")
    l1l11ll1ll_opy_ = 255
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_