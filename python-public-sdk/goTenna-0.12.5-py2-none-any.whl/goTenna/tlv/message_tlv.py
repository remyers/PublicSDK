# coding: utf8
from __future__ import print_function
import sys
l1111_opy_ = sys.version_info [0] == 2
l1lll1_opy_ = 2048
l1ll1_opy_ = 7
def l11ll_opy_ (l1_opy_):
    global l1llll_opy_
    l11l1l_opy_ = ord (l1_opy_ [-1])
    l111l_opy_ = l1_opy_ [:-1]
    l1ll_opy_ = l11l1l_opy_ % len (l111l_opy_)
    l1l1_opy_ = l111l_opy_ [:l1ll_opy_] + l111l_opy_ [l1ll_opy_:]
    if l1111_opy_:
        l1ll1l_opy_ = unicode () .join ([unichr (ord (char) - l1lll1_opy_ - (l1l11_opy_ + l11l1l_opy_) % l1ll1_opy_) for l1l11_opy_, char in enumerate (l1l1_opy_)])
    else:
        l1ll1l_opy_ = str () .join ([chr (ord (char) - l1lll1_opy_ - (l1l11_opy_ + l11l1l_opy_) % l1ll1_opy_) for l1l11_opy_, char in enumerate (l1l1_opy_)])
    return eval (l1ll1l_opy_)
# Copyright (C) 2018 goTenna, Inc. This file is distributed as part of the
# goTenna USB SDK. See the associated license for more information.
# pylint: disable=line-too-long
l11ll_opy_ (u"ࠤࠥࠦࠥࡓ࡯ࡥࡷ࡯ࡩࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡯࡮ࡨࠢࡗࡐ࡛ࡹࠠࡳࡧ࡯ࡩࡻࡧ࡮ࡵࠢࡷࡳࠥࡺࡨࡦࠢࡷࡳࡵࠦ࡬ࡦࡸࡨࡰࠥࡵࡦࠡ࡯ࡨࡷࡸࡧࡧࡦࡵ࠱ࠎࠏ࡚ࡨࡦࠢࡗࡐ࡛ࡹࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡦࠣ࡬ࡪࡸࡥࠡࡣࡵࡩࠥ࡯࡮ࡵࡧࡵࡲࡦࡲࠠࡢࡰࡧࠤ࡮ࡴࡴࡦࡰࡧࡩࡩࠦࡦࡰࡴࠣࡴࡦࡸࡳࡪࡰࡪࠤࡹ࡮ࡥࠡࡪࡨࡥࡩ࡫ࡲࠡࡦࡤࡸࡦࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡࡤࡼࠤࡦࡴࡤࠡࡧࡰ࡭ࡹࡺࡥࡥࠢࡥࡽࠥࡺࡨࡦࠢࡩ࡭ࡷࡳࡷࡢࡴࡨࠤࡼ࡮ࡥ࡯ࠢࡳࡥࡸࡹࡩ࡯ࡩࠣࡱࡪࡹࡳࡢࡩࡨࡷ࠳ࠦࡔࡩࡧࡼࠤࡦࡸࡥࠡࡰࡲࡸࠥ࡯࡮ࡵࡧࡱࡨࡪࡪࠠࡧࡱࡵࠤࡪࡾࡴࡦࡴࡱࡥࡱࠦࡵࡴࡧ࠱ࠎࠧࠨࠢ஡")
# pylint: enable=line-too-long
import struct
import logging
import binascii
import six
import goTenna.settings
from goTenna.tlv import basic_tlv
from goTenna.tlv import payload_tlv
_MODULE_LOGGER = logging.getLogger(__name__)
class MessageAckTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠥࠦࠧࠦࡔࡩࡧࠣࡘࡑ࡜ࠠࡴࡧࡱࡸࠥࡨࡹࠡࡶ࡫ࡩࠥ࡬ࡩࡳ࡯ࡺࡥࡷ࡫ࠠࡸࡪࡨࡲࠥࡧࡣ࡬ࡰࡲࡻࡱ࡫ࡤࡨ࡫ࡱ࡫ࠥࡧࠠࡱࡴ࡬ࡺࡦࡺࡥࠡࡱࡵࠤ࡬ࡸ࡯ࡶࡲࠣࡱࡪࡹࡳࡢࡩࡨ࠲ࠏࠦࠠࠡࠢࠥࠦࠧ஢")
    l1l11ll1ll_opy_ = 0x21
    def __repr__(self):
        return l11ll_opy_ (u"ࠫࡁࡓࡥࡴࡵࡤ࡫ࡪࡇࡣ࡬ࡖࡏ࡚࠿ࠦࡴࡵ࡮ࡀࡿࢂࠦࡨࡢࡵ࡫ࡁࢀࢃ࠾ࠨண").format(self.ttl, self.hash_id)
    def __eq__(self, other):
        return isinstance(other, MessageAckTLV)\
            and self.ttl == other.ttl\
            and self.hash_id == other.hash_id
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, ttl, hash_id):
        l11ll_opy_ (u"ࠧࠨࠢࠡࡄࡸ࡭ࡱࡪࠠࡵࡪࡨࠤ࡙ࡒࡖࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣ࡭ࡳࡺࠠࡵࡶ࡯࠾࡚ࠥࡨࡦࠢࡵࡩࡲࡧࡩ࡯࡫ࡱ࡫ࠥࡺࡩ࡮ࡧࠣࡸࡴࠦ࡬ࡪࡸࡨࠤ࡫ࡵࡲࠡࡶ࡫ࡩࠥࡶࡡࡤ࡭ࡨࡸ࠳ࠦࡃࡢࡰࠣࡹࡸࡻࡡ࡭࡮ࡼࠤࡧ࡫ࠠࡪࡩࡱࡳࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣ࡭ࡳࡺࠠࡩࡣࡶ࡬ࡤ࡯ࡤ࠻ࠢࡗ࡬ࡪࠦࡨࡢࡵ࡫ࠤࡴ࡬ࠠࡵࡪࡨࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡺࡨࡪࡵࠣࡥࡨࡱࠠࡪࡵࠣࡪࡴࡸ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧத")
        self.ttl = ttl
        self.hash_id = hash_id
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        (ttl, hash_id) = struct.unpack(l11ll_opy_ (u"࠭ࠡࡃࡊࠪ஥"), l111l1ll1l_opy_)
        return cls(ttl, hash_id)
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠧࠢࡄࡋࠫ஦"), self.ttl, self.hash_id)
class HopCountMaxTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠣࠤࠥࠤ࡙࡮ࡥࠡࡖࡏ࡚ࠥࡹࡰࡦࡥ࡬ࡪࡾ࡯࡮ࡨࠢࡷ࡬ࡪࠦ࡭ࡢࡺࠣࡲࡺࡳࡢࡦࡴࠣࡳ࡫ࠦࡴࡪ࡯ࡨࠤࡦࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡴࡪࡲࡹࡱࡪࠠࡩࡱࡳࠎࠥࠦࠠࠡࠤࠥࠦ஧")
    l1l11ll1ll_opy_ = 0x22
    def __repr__(self):
        return l11ll_opy_ (u"ࠩ࠿ࡌࡴࡶࡃࡰࡷࡱࡸࡒࡧࡸࡕࡎ࡙࠾ࠥࡩ࡯ࡶࡰࡷࡁࢀࢃ࠾ࠨந").format(self.count)
    def __eq__(self, other):
        return isinstance(other, HopCountMaxTLV) and self.count == other.count
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, count):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡂࡶ࡫࡯ࡨࠥࡺࡨࡦࠢࡗࡐ࡛ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡ࡫ࡱࡸࠥࡩ࡯ࡶࡰࡷ࠾࡚ࠥࡨࡦࠢࡱࡹࡲࡨࡥࡳࠢࡲࡪࠥ࡮࡯ࡱࡵࠣࠬࡦࡲࡳࡰࠢ࡮ࡲࡴࡽ࡮ࠡࡣࡶࠤࡹ࡮ࡥࠡࡖࡗࡐ࠮ࠦࡦࡰࡴࠣࡸ࡭࡯ࡳࠡ࡯ࡨࡷࡸࡧࡧࡦ࠰ࠣࡑࡦࡾࡩ࡮ࡷࡰࠤࡴ࡬ࠠ࠻ࡲࡼ࠾ࡴࡨࡪ࠻ࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡦࡳࡳࡹࡴࡢࡰࡷࡷ࠳ࡓࡁ࡙ࡡࡋࡓࡕ࡙ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡩࡹࡻࡲ࡯ࠢࡋࡳࡵࡉ࡯ࡶࡰࡷࡑࡦࡾࡔࡍࡘ࠽ࠤ࡙࡮ࡥࠡࡥࡲࡲࡸࡺࡲࡶࡥࡷࡩࡩࠦ࡯ࡣ࡬ࡨࡧࡹࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥன")
        self.count = count
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        (count, ) = struct.unpack(l11ll_opy_ (u"ࠫࠦࡈࠧப"), l111l1ll1l_opy_)
        return cls(count)
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠬࠧࡂࠨ஫"), self.count)
class MessageHeaderTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠨࠢࠣࠢࡗ࡬ࡪࠦࡔࡍࡘࠣࡪࡴࡸࠠࡵࡪࡨࠤࡲ࡫ࡳࡴࡣࡪࡩࠥ࡮ࡥࡢࡦࡨࡶࠏࠦࠠࠡࠢࠥࠦࠧ஬")
    l1l11ll1ll_opy_ = 6
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __repr__(self):
        return l11ll_opy_ (u"ࠧ࠽ࡏࡨࡷࡸࡧࡧࡦࡊࡨࡥࡩ࡫ࡲࡕࡎ࡙࠾ࠥࡧࡰࡱࡡ࡬ࡨࡂࢁࡽ࠭ࠢࡷࡽࡵ࡫࠽ࡼࡿ࠯ࠤࡩ࡫ࡳࡵ࠿ࡾࢁ࠱ࠦ࡭ࡦ࡯ࡥࡩࡷࡹࡨࡪࡲࡀࡿࢂࡄࠧ஭")\
            .format(self.l11_opy_, self.message_type, self.destination, self.membership)
    def __eq__(self, other):
        return isinstance(other, MessageHeaderTLV)\
            and self.l11_opy_ == other.l11_opy_\
            and self.message_type == other.message_type\
            and self.destination == other.destination\
            and self.membership == other.membership
    def __init__(self, l11_opy_, message_type, destination=None, membership=None):
        l11ll_opy_ (u"ࠣࠤࠥࠤࡇࡻࡩ࡭ࡦࠣࡸ࡭࡫ࠠ࡮ࡧࡶࡷࡦ࡭ࡥ࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤ࡮ࡴࡴࠡࡣࡳࡴࡤ࡯ࡤ࠻ࠢࡗ࡬ࡪࠦࡡࡱࡲࠣࡍࡉࠦࡦࡰࡴࠣࡸ࡭࡫ࠠ࡮ࡧࡶࡷࡦ࡭ࡥ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡷࡹࡸࠠ࡮ࡧࡶࡷࡦ࡭ࡥࡠࡶࡼࡴࡪࡀࠠࡕࡪࡨࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡺࡹࡱࡧࠣ࠱ࠥࡧࠠ࡬ࡧࡼࠤࡴࡸࠠࡷࡣ࡯ࡹࡪࠦ࡯ࡧࠢ࠽ࡴࡾࡀࡡࡵࡶࡵ࠾ࡥ࡭࡯ࡕࡧࡱࡲࡦ࠴ࡧࡰࡖࡨࡲࡳࡧ࠮ࡤࡱࡱࡷࡹࡧ࡮ࡵࡵ࠱ࡑࡊ࡙ࡓࡂࡉࡈࡣ࡙࡟ࡐࡆࡕࡣࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡪࡥࡴࡶ࡬ࡲࡦࡺࡩࡰࡰ࠽ࠤ࡙࡮ࡥࠡࡦࡨࡷࡹ࡯࡮ࡢࡶ࡬ࡳࡳࠦ࡯ࡧࠢࡷ࡬ࡪࠦ࡭ࡦࡵࡶࡥ࡬࡫࠮ࠡࡋࡩࠤࡹ࡮ࡩࡴࠢࡰࡩࡸࡹࡡࡨࡧࠣࡨࡴ࡫ࡳࠡࡰࡲࡸࠥࡸࡥࡲࡷ࡬ࡶࡪࠦࡡࠡࡦࡨࡷࡹ࡯࡮ࡢࡶ࡬ࡳࡳ࠲ࠠࡪࡶࠣࡱࡦࡿࠠࡣࡧࠣࡒࡴࡴࡥ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡹࡿࡰࡦࠢࡧࡩࡸࡺࡩ࡯ࡣࡷ࡭ࡴࡴ࠺ࠡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡉࡅࠢࡲࡶࠥࡔ࡯࡯ࡧࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤ࡮ࡴࡴࠡ࡯ࡨࡱࡧ࡫ࡲࡴࡪ࡬ࡴ࠿ࠦࡔࡩࡧࠣࡱࡪࡳࡢࡦࡴࡶ࡬࡮ࡶࠠࡪࡰࡧࡩࡽ࠲ࠠࡪࡨࠣࡸ࡭࡫ࠠࡥࡧࡶࡸ࡮ࡴࡡࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡣࠣ࡫ࡷࡵࡵࡱ࠰ࠣࡇࡺࡸࡲࡦࡰࡷࡰࡾࠦࡩࡨࡰࡲࡶࡪࡪ࠮ࠡࡋࡩࠤࡹ࡮ࡩࡴࠢࡰࡩࡸࡹࡡࡨࡧࠣࡨࡴ࡫ࡳࠡࡰࡲࡸࠥࡸࡥࡲࡷ࡬ࡶࡪࠦࡡࠡࡦࡨࡷࡹ࡯࡮ࡢࡶ࡬ࡳࡳ࠲ࠠࡪࡶࠣࡱࡦࡿࠠࡣࡧࠣࡒࡴࡴࡥ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷࡧࡩࡴࡧࡶࠤࡪࡾࡣࡦࡲࡷ࡭ࡴࡴ࠮ࡕࡻࡳࡩࡊࡸࡲࡰࡴ࠽ࠤࡎ࡬ࠠࡢࡰࠣࡥࡷ࡭ࡵ࡮ࡧࡱࡸࠥࡺࡹࡱࡧࠣ࡭ࡸࠦࡩ࡯ࡸࡤࡰ࡮ࡪࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥࡴࠢࡨࡼࡨ࡫ࡰࡵ࡫ࡲࡲ࠳ࡑࡥࡺࡇࡵࡶࡴࡸ࠺ࠡࡋࡩࠤࡥࡦ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡵࡻࡳࡩࡥࡦࠠࡪࡵࠣ࡭ࡳࡼࡡ࡭࡫ࡧࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣம")
        if not isinstance(l11_opy_, int):
            raise TypeError(l11ll_opy_ (u"ࠩࡤࡴࡵࡥࡩࡥࠢࡰࡹࡸࡺࠠࡣࡧࠣ࡭ࡳࡺࠬࠡ࡫ࡶࠤࢀࢃࠧய").format(type(l11_opy_)))
        self.l11_opy_ = l11_opy_
        if isinstance(message_type, (str, goTenna.util.UnicodeType)):
            self.message_type = goTenna.constants.MESSAGE_TYPES[message_type]
        elif isinstance(message_type, int):
            if message_type not in goTenna.constants.MESSAGE_TYPES.values():
                raise KeyError(message_type)
            self.message_type = message_type
        else:
            raise TypeError(l11ll_opy_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࡣࡹࡿࡰࡦࠢࡰࡹࡸࡺࠠࡣࡧࠣࡷࡹࡸࠠࡰࡴࠣ࡭ࡳࡺࠬࠡ࡫ࡶࠤࢀࢃࠧர")
                            .format(type(message_type)))
        if not isinstance(destination, goTenna.settings.GID)\
           and None is not destination:
            raise TypeError(l11ll_opy_ (u"ࠫࡩ࡫ࡳࡵ࡫ࡱࡥࡹ࡯࡯࡯ࠢࡰࡹࡸࡺࠠࡣࡧࠣࡋࡎࡊࠬࠡ࡫ࡶࠤࢀࢃࠧற")
                            .format(type(destination)))
        if self.message_type == goTenna.constants.MESSAGE_TYPES[l11ll_opy_ (u"ࠬࡨࡲࡰࡣࡧࡧࡦࡹࡴࠨல")]:
            self.destination = goTenna.settings.GID.broadcast()
        elif self.message_type == goTenna.constants.MESSAGE_TYPES[l11ll_opy_ (u"࠭ࡥ࡮ࡧࡵ࡫ࡪࡴࡣࡺࠩள")]:
            self.destination = goTenna.settings.GID.emergency()
        else:
            if None is destination:
                raise TypeError(l11ll_opy_ (u"ࠧࡥࡧࡶࡸ࡮ࡴࡡࡵ࡫ࡲࡲࠥࡳࡵࡴࡶࠣࡦࡪࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢࡩࡳࡷࠦ࡮ࡰࡰ࠰ࡦࡷࡵࡡࡥࡥࡤࡷࡹ࠭ழ"))
            self.destination = destination
        if self.message_type in (goTenna.constants.MESSAGE_TYPES[l11ll_opy_ (u"ࠨࡤࡵࡳࡦࡪࡣࡢࡵࡷࠫவ")],
                                 goTenna.constants.MESSAGE_TYPES[l11ll_opy_ (u"ࠩࡨࡱࡪࡸࡧࡦࡰࡦࡽࠬஶ")],
                                 goTenna.constants.MESSAGE_TYPES[l11ll_opy_ (u"ࠪࡴࡷ࡯ࡶࡢࡶࡨࠫஷ")]):
            self.membership = None
        elif None is membership:
            raise TypeError(l11ll_opy_ (u"ࠫࡲ࡫࡭ࡣࡧࡵࡷ࡭࡯ࡰࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡶࡴࡪࡩࡩࡧ࡫ࡨࡨࠥ࡬࡯ࡳࠢࡪࡶࡴࡻࡰࡴࠩஸ"))
        elif isinstance(membership, int):
            self.membership = membership
        else:
            raise TypeError(l11ll_opy_ (u"ࠬࡳࡥ࡮ࡤࡨࡶࡸ࡮ࡩࡱࠢࡰࡹࡸࡺࠠࡣࡧࠣ࡭ࡳࡺࠠࡰࡴࠣࡒࡴࡴࡥ࠭ࠢ࡬ࡷࠥࢁࡽࠨஹ")
                            .format(type(membership)))
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        if len(l111l1ll1l_opy_) < 3:
            raise ValueError(l11ll_opy_ (u"࠭ࡔࡍࡘࠣࡱࡺࡹࡴࠡࡤࡨࠤࡦࡺࠠ࡭ࡧࡤࡷࡹࠦ࠳ࠡ࡮ࡲࡲ࡬࠲ࠠࡪࡵࠣࡿࢂ࠭஺")
                             .format(len(l111l1ll1l_opy_)))
        (l1llllllll1_opy_, l11_opy_) = struct.unpack(l11ll_opy_ (u"ࠧࠢࡄࡋࠫ஻"), l111l1ll1l_opy_[:3])
        if len(l111l1ll1l_opy_) > 3:
            l1lllllll1l_opy_ = six.b(l11ll_opy_ (u"ࠨ࡞ࡻ࠴࠵ࡢࡸ࠱࠲ࠪ஼")) + l111l1ll1l_opy_[3:]
            (gid, l1llll11ll1_opy_) = struct.unpack(l11ll_opy_ (u"ࠩࠤࡕࡇ࠭஽"), l1lllllll1l_opy_)
            membership = (l1llll11ll1_opy_ & 0x7f) >> 4
            gid = goTenna.settings.GID(gid, l1llllllll1_opy_)
        else:
            if l1llllllll1_opy_ == goTenna.constants.MESSAGE_TYPES[l11ll_opy_ (u"ࠪࡦࡷࡵࡡࡥࡥࡤࡷࡹ࠭ா")]:
                gid = goTenna.settings.GID.broadcast()
            elif l1llllllll1_opy_ == goTenna.constants.MESSAGE_TYPES[l11ll_opy_ (u"ࠫࡪࡳࡥࡳࡩࡨࡲࡨࡿࠧி")]:
                gid = goTenna.settings.GID.emergency()
            else:
                raise ValueError(l11ll_opy_ (u"ࠬࡔ࡯ࠡࡉࡌࡈࠥࡹࡰࡦࡥ࡬ࡪ࡮࡫ࡤࠡࡨࡲࡶࠥࡳࡥࡴࡵࡤ࡫ࡪࠦࡴࡩࡣࡷࠤࡸ࡮࡯ࡶ࡮ࡧࠤ࡭ࡧࡶࡦࠢࡲࡲࡪ࠭ீ"))
            membership = None
        return MessageHeaderTLV(l11_opy_, l1llllllll1_opy_, gid, membership)
    def serialize(self):
        prefix = struct.pack(l11ll_opy_ (u"࠭ࠡࡃࡊࠪு"), self.message_type, self.l11_opy_)
        if self.message_type in (goTenna.constants.MESSAGE_TYPES[l11ll_opy_ (u"ࠧࡣࡴࡲࡥࡩࡩࡡࡴࡶࠪூ")],
                                 goTenna.constants.MESSAGE_TYPES[l11ll_opy_ (u"ࠨࡧࡰࡩࡷ࡭ࡥ࡯ࡥࡼࠫ௃")]):
            return prefix
        l1llllll111_opy_ = self.membership << 4 if self.membership else 0
        suffix = struct.pack(l11ll_opy_ (u"ࠩࠤࡕࡇ࠭௄"), self.destination.gid_val,
                             l1llllll111_opy_)
        return prefix + suffix[2:]
class MessagePayloadTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠥࠦࠧࠦࡔࡩࡧࠣࡸࡴࡶ࠭࡭ࡧࡹࡩࡱࠦࡔࡍࡘࠣࡧࡴࡴࡴࡢ࡫ࡱ࡭ࡳ࡭ࠠࡢࠢࡰࡩࡸࡹࡡࡨࡧࠣࡴࡦࡿ࡬ࡰࡣࡧ࠲ࠏࠦࠠࠡࠢࠥࠦࠧ௅")
    l1l11ll1ll_opy_ = 5
    def __repr__(self):
        return l11ll_opy_ (u"ࠫࡁࡓࡥࡴࡵࡤ࡫ࡪࡖࡡࡺ࡮ࡲࡥࡩ࡚ࡌࡗ࠼ࠣࡩࡳࡩࡲ࠾ࡽࢀ࠰ࠥࡺ࡬ࡷࡵࡀࡿࢂ࠲ࠠࡳࡣࡺࡁࢀࢃ࠾ࠨெ")\
            .format(self.encryption, self.payload_tlvs,
                    goTenna.util.display_bytestring(self.payload_bytes)
                    if self.payload_bytes else None)
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __eq__(self, other):
        return isinstance(other, MessagePayloadTLV)\
            and self.encryption == other.encryption\
            and self.l1lllll111l_opy_ == other.l1lllll111l_opy_
    l111l11l1l_opy_ = payload_tlv.ALL
    @property
    def l111l1l1l1_opy_(self):
        return self.l111l11l1l_opy_
    @classmethod
    def _1llll1l1ll_opy_(cls, data):
        l11ll_opy_ (u"ࠧࠨࠢࠡࡅ࡫ࡩࡨࡱࠠࡪࡨࠣࡸ࡭࡯ࡳࠡ࡫ࡶࠤࡦࠦࡳࡦࡳࡸࡩࡳࡩࡥࠡࡱࡩࠤ࡙ࡒࡖࡴࠢࠥࠦࠧே")
        for obj in data:
            if type(obj) not in cls.l111l11l1l_opy_:
                return False
        return True
    @classmethod
    def _1lllllll11_opy_(cls, data):
        l11ll_opy_ (u"ࠨࠢࠣࠢࡆ࡬ࡪࡩ࡫ࠡ࡫ࡩࠤࡩࡧࡴࡢࠢ࡬ࡷࠥࡧࠠࡣࡻࡷࡩࡸࡲࡩ࡬ࡧࠣࡳࡧࡰࡥࡤࡶࠣ࡭ࡳࠦࡡࠡ࠴࠲࠷ࠥࡩ࡯࡮ࡲࡤࡸ࡮ࡨ࡬ࡦࠢࡺࡥࡾࠦࠢࠣࠤை")
        try:
            struct.pack(l11ll_opy_ (u"ࠧ࠲ࡵࠪ௉"), data[:1])
        except struct.error:
            return False
        else:
            return True
    @classmethod
    def _1llllll11l_opy_(cls, data):
        l11ll_opy_ (u"ࠣࠤࠥࠤࡈ࡮ࡥࡤ࡭ࠣ࡭࡫ࠦࡤࡢࡶࡤࠤ࡮ࡹࠠࡢࡰࠣࡩࡲࡶࡴࡺࠢࡶࡩࡶࡻࡥ࡯ࡥࡨࠤ࡚࠭ࡲࡶࡧࠬࠤࡦࠦ࡮ࡰࡰ࠰ࡩࡲࡶࡴࡺࠢࡶࡩࡶࡻࡥ࡯ࡥࡨࠤ࠭ࡌࡡ࡭ࡵࡨ࠭ࠥࡵࡲࠡࡰࡲࡸࠥࡧࠠࡴࡧࡴࡹࡪࡴࡣࡦࠢࠫࡘࡾࡶࡥࡆࡴࡵࡳࡷ࠯ࠢࠣࠤொ")
        try:
            _ = data[0]
        except IndexError:
            return True
        else:
            return False
    def __init__(self, encryption, payload_tlvs=None, payload_bytes=None,
                 l1llll11l1l_opy_=None,
                 encrypt_hook=None):
        l11ll_opy_ (u"ࠤࠥࠦࠥࡈࡵࡪ࡮ࡧࠤࡹ࡮ࡥࠡࡖࡏ࡚࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡖࡏ࡚ࠥ࡫࡮ࡤࡴࡼࡴࡹ࡯࡯࡯࠼ࠣࡘ࡭࡫ࠠࡦࡰࡦࡶࡾࡶࡴࡪࡱࡱࠤ࡙ࡒࡖࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢ࡯࡭ࡸࡺ࡛ࡕࡎ࡙ࡡࠥࡶࡡࡺ࡮ࡲࡥࡩࡥࡴ࡭ࡸࡶ࠾࡚ࠥࡌࡗࡵࠣࡸࡴࠦࡰࡶࡶࠣ࡭ࡳࠦࡴࡩࡧࠣࡴࡦࡿ࡬ࡰࡣࡧࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡴࡳࠢࡲࡶࠥࡨࡹࡵࡧࡶࠤࡵࡧࡹ࡭ࡱࡤࡨࡤࡨࡹࡵࡧࡶ࠾࡛ࠥ࡮ࡥ࡫ࡩࡪࡪࡸࡥ࡯ࡶ࡬ࡥࡹ࡫ࡤࠡࡤࡼࡸࡪࡹࠠࡵࡱࠣࡴࡺࡺࠠࡪࡰࠣࡸ࡭࡫ࠠࡱࡣࡼࡰࡴࡧࡤࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡸࡷࠦ࡯ࡳࠢࡥࡽࡹ࡫ࡳࠡࡷࡱࡨࡪࡩࡲࡺࡲࡷࡩࡩࡥࡢࡺࡶࡨࡷ࠿ࠦࡂࡺࡶࡨࡷࠥࡺࡨࡢࡶࠣ࡬ࡦࡼࡥࠡࡰࡲࡸࠥࡿࡥࡵࠢࡥࡩࡪࡴࠠࡥࡧࡦࡶࡾࡶࡴࡦࡦ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡩࡡ࡭࡮ࡤࡦࡱ࡫ࠠࡦࡰࡦࡶࡾࡶࡴࡪࡱࡱࡣ࡫ࡻ࡮ࡤ࠼ࠣࡤࡥࡔ࡯࡯ࡧࡣࡤࠥࡵࡲࠡࡣࠣࡧࡦࡲ࡬ࡢࡤ࡯ࡩࠥࡻࡳࡦࡦࠣࡸࡴࠦࡥ࡯ࡥࡵࡽࡵࡺࠠࡵࡪࡨࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡶࡡࡺ࡮ࡲࡥࡩ࠴ࠠࡊࡨࠣࡸ࡭࡫ࠠࡦࡰࡦࡶࡾࡶࡴࡪࡱࡱࠤ࡙ࡒࡖࠡࡵࡳࡩࡨ࡯ࡦࡪࡧࡶࠤࡹ࡮ࡡࡵࠢࡷ࡬ࡪࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡪࡵࠣࡩࡳࡩࡲࡺࡲࡷࡩࡩ࠲ࠠࡵࡪ࡬ࡷࠥࡳࡵࡴࡶࠣࡦࡪࠦࡡ࡯ࠢࡨࡲࡨࡸࡹࡱࡶ࡬ࡳࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮࠼ࠢࡲࡸ࡭࡫ࡲࡸ࡫ࡶࡩ࠱ࠦࡩࡵࠢࡰࡥࡾࠦࡢࡦࠢࡣࡤࡓࡵ࡮ࡦࡢࡣࠤ࠭ࡧ࡮ࡥࠢࡺ࡭ࡱࡲࠠ࡯ࡱࡷࠤࡧ࡫ࠠࡤࡣ࡯ࡰࡪࡪࠠࡦࡸࡨࡲࠥ࡯ࡦࠡࡰࡲࡲ࠲ࡦࡠࡏࡱࡱࡩࡥࡦࠩ࠯ࠢࡌࡪࠥࡹࡰࡦࡥ࡬ࡪ࡮࡫ࡤ࠭ࠢࡷ࡬ࡪࠦࡣࡢ࡮࡯ࡥࡧࡲࡥࠡࡵ࡫ࡳࡺࡲࡤࠡࡤࡨࠤࡴ࡬ࠠࡵࡪࡨࠤ࡫ࡵࡲ࡮ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠯࠰ࠣࡪࡺࡴࡣࡵ࡫ࡲࡲ࠿ࡀࠠࡦࡰࡦࡶࡾࡶࡴࡠࡪࡲࡳࡰ࠮ࡳࡦࡰࡧࡩࡷࡥࡧࡪࡦ࠯ࠤࡹ࡯࡭ࡦࡡࡶࡩࡳࡺࠬࠡࡧࡱࡧࡷࡿࡰࡵ࡫ࡲࡲࡤࡩ࡯ࡶࡰࡷࡩࡷ࠲ࠠࡱ࡮ࡤ࡭ࡳࡺࡥࡹࡶࠬࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡧࡰࡖࡨࡲࡳࡧ࠮ࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡍࡉࠦࡳࡦࡰࡧࡩࡷࡥࡧࡪࡦ࠽ࠤ࡙࡮ࡥࠡࡵࡨࡲࡩ࡫ࡲࠡࡱࡩࠤࡹ࡮ࡥࠡ࡯ࡨࡷࡸࡧࡧࡦࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡩࡧࡴࡦࡶ࡬ࡱࡪ࠴ࡤࡢࡶࡨࡸ࡮ࡳࡥࠡࡶ࡬ࡱࡪࡥࡳࡦࡰࡷ࠾࡚ࠥࡨࡦࠢࡷ࡭ࡲ࡫ࠠࡵࡪࡨࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡽࡡࡴࠢࡶࡩࡳࡺࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢ࡬ࡲࡹࠦࡥ࡯ࡥࡵࡽࡵࡺࡩࡰࡰࡢࡧࡴࡻ࡮ࡵࡧࡵ࠾࡚ࠥࡨࡦࠢࡳࡥࡾࡲ࡯ࡢࡦࠣࡩࡳࡩࡲࡺࡲࡷ࡭ࡴࡴ࡟ࡤࡱࡸࡲࡹ࡫ࡲ࠭ࠢࡤࠤ࠶࠼࠭ࡣ࡫ࡷࠤࡨࡵࡵ࡯ࡶࡨࡶࠥࡺࡨࡢࡶࠣࡧ࡭ࡧ࡮ࡨࡧࡶࠤࡼ࡯ࡴࡩࠢࡨࡺࡪࡸࡹࠡ࡯ࡨࡥࡳࡺ࠭ࡵࡱ࠰ࡦࡪ࠳ࡵ࡯࡫ࡴࡹࡪࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡴࡧࡱࡸࠥ࡬ࡲࡰ࡯ࠣࡥࠥࡹࡰࡦࡥ࡬ࡪ࡮ࡩࠠࡴࡧࡱࡨࡪࡸࠠࡵࡱࠣࡥࠥࡹࡰࡦࡥ࡬ࡪ࡮ࡩࠠࡥࡧࡶࡸ࡮ࡴࡡࡵ࡫ࡲࡲࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡣࡻࡷࡩࡸࡲࡩ࡬ࡧࠣࡴࡱࡧࡩ࡯ࡶࡨࡼࡹࡀࠠࡕࡪࡨࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡩ࡯࡯ࡶࡨࡲࡹࠦࡴࡰࠢࡨࡲࡨࡸࡹࡱࡶࠍࠎࠥࠦࠠࠡࠢࠣࠤ࡚ࠥࡨࡦࠢࡓࡥࡾࡲ࡯ࡢࡦࠣࡘࡑ࡜ࠠࡪࡵࠣ࡭ࡳࠦࡴࡩࡧࠣࡹࡳ࡬࡯ࡳࡶࡸࡲࡦࡺࡥࠡࡲࡲࡷ࡮ࡺࡩࡰࡰࠣࡳ࡫ࠦࡣࡢࡴࡵࡽ࡮ࡴࡧࠡࡵࡲࡱࡪࠦࡩ࡯ࡨࡲࡶࡲࡧࡴࡪࡱࡱࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࠦࡢࡺࠢࡷ࡬ࡪࠦࡳࡺࡵࡷࡩࡲࠦࠨࡵࡪࡨࠤࡪࡴࡣࡳࡻࡳࡸ࡮ࡵ࡮ࠡࡪࡨࡥࡩ࡫ࡲ࠭ࠢࡺ࡬࡮ࡩࡨࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࠦࡡ࡯ࡦࠣࡶࡪࡷࡵࡪࡴࡨࡨࠥࡺ࡯ࠡࡤࡨࠤࡦࠦࡔࡍࡘࠬ࠿ࠥࡹ࡯࡮ࡧࠣ࡭ࡳ࡬࡯ࡳ࡯ࡤࡸ࡮ࡵ࡮ࠡࡶ࡫ࡥࡹࠦࡩࡴࠢࡦࡹࡸࡺ࡯࡮ࡣࡵ࡭ࡱࡿࠠࡱࡴࡨࡷࡪࡴࡴࠡࡴࡨ࡫ࡦࡸࡤ࡭ࡧࡶࡷࠥࡵࡦࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡨࡲࡹࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡰࡢࡻ࡯ࡳࡦࡪࠠࠩࡵࡨࡲࡩ࡫ࡲࠡ࡫ࡱ࡭ࡹ࡯ࡡ࡭ࡵ࠯ࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡺࡹࡱࡧࠣ࡬ࡪࡧࡤࡦࡴࠬ࠿ࠥࡧ࡮ࡥࠢࡶࡳࡲ࡫ࠠࡱࡣࡼࡰࡴࡧࡤࠡ࡫ࡱࡪࡴࡸ࡭ࡢࡶ࡬ࡳࡳࠦࡷࡩࡱࡶࡩࠥࡺࡹࡱࡧࠣࡻࡪࠦࡷࡢࡰࡷࠤࡹࡵࠠ࡭ࡧࡤࡺࡪࠦࡵࡱࠢࡷࡳࠥࡺࡨࡦࠢࡦࡥࡱࡲࡥࡳ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤ࡚ࠥ࡯ࠡࡶ࡫ࡥࡹࠦࡥ࡯ࡦ࠯ࠤࡹ࡮ࡥࠡࡥࡤࡰࡱ࡫ࡲࠡࡥࡤࡲࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡢࡰࡶ࡫ࠤࡦࠦ࡬ࡪࡵࡷࠤࡴ࡬ࠠࡕࡎ࡙ࡷࠥࡧ࡮ࡥࠢࡶࡳࡲ࡫ࠠࡶࡰࡩࡳࡷࡳࡡࡵࡶࡨࡨࠥࡪࡡࡵࡣ࠱ࠤࡓ࡫ࡩࡵࡪࡨࡶࠥ࡯ࡳࠡࡴࡨࡵࡺ࡯ࡲࡦࡦ࠾ࠤ࡮࡬ࠠࡵࡪࡨࠤࡨࡧ࡬࡭ࡧࡵࠤࡼࡧ࡮ࡵࡵࠣࡥࡳࠦࡥ࡮ࡲࡷࡽࠥࡶࡡࡺ࡮ࡲࡥࡩ࠲ࠠࡣࡱࡷ࡬ࠥࡩࡡ࡯ࠢࡥࡩࠥࡔ࡯࡯ࡧ࠱ࠤࡎࡪࡥࡢ࡮࡯ࡽ࠱ࠦࡴࡩࡧࠣࡷࡪࡴࡤࡦࡴࠣ࡭ࡳ࡯ࡴࡪࡣ࡯ࡷࠥࡧ࡮ࡥࠢࡰࡩࡸࡹࡡࡨࡧࠣࡸࡾࡶࡥࠡࡖࡏ࡚ࡸࠦࠨࡢࡶࠣࡰࡪࡧࡳࡵࠫࠣࡻ࡮ࡲ࡬ࠡࡤࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡰࠣࡤࡥࡶࡡࡺ࡮ࡲࡥࡩࡥࡴ࡭ࡸࡶࡤࡥࠦࡥࡷࡧࡱࠤ࡮࡬ࠠࡵࡪࡨࠤࡩ࡫ࡳࡪࡴࡨࡨࠥࡩ࡯࡯ࡶࡨࡲࡹࠦࡩࡴࠢࡱࡳࡹࠦࡔࡍࡘࡶ࠿ࠥ࡮࡯ࡸࡧࡹࡩࡷ࠲ࠠࡵࡪ࡬ࡷࠥ࡯ࡳࠡࡰࡲࡸࠥࡳࡡ࡯ࡦࡤࡸࡴࡸࡹ࠯ࠢࡗࡐ࡛ࡹࠠࡢࡴࡨࠤࡸ࡫ࡲࡪࡣ࡯࡭ࡿ࡫ࡤࠡ࡫ࡱࡸࡴࠦࡴࡩࡧࠣࡳࡺࡺࡰࡶࡶࠣࡪ࡮ࡸࡳࡵ࠮ࠣࡦࡪࡩࡡࡶࡵࡨࠤࡹ࡮ࡥࠡ࡫ࡱࡴࡺࡺࠠࡴ࡫ࡧࡩࠥࡽࡩ࡭࡮ࠣࡳࡳࡲࡹࠡࡴࡨࡥࡩࠦࡔࡍࡘࡶࠤ࡫ࡸ࡯࡮ࠢࡷ࡬ࡪࠦࡢࡦࡩ࡬ࡲࡳ࡯࡮ࡨࠢࡲࡪࠥࡺࡨࡦࠢࡰࡩࡸࡹࡡࡨࡧ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࡔࡩ࡫ࡶࠤ࡮ࡹࠠࡢ࡮ࡶࡳࠥࡽࡨࡦࡴࡨࠤࡹ࡮ࡥࠡࡥࡤࡰࡱ࡫ࡲࠡࡵࡳࡩࡨ࡯ࡦࡪࡧࡶࠤ࡭ࡵࡷࠡࡶ࡫ࡩࠥࡶࡡࡺ࡮ࡲࡥࡩࠦࡳࡩࡱࡸࡰࡩࠦࡢࡦࠢࡨࡲࡨࡸࡹࡱࡶࡨࡨ࠳ࠦࡔࡩࡧࠣࡤࡥ࡫࡮ࡤࡴࡼࡴࡹࡥࡨࡰࡱ࡮ࡤࡥࠦࡩࡴࠢࡤࠤࡨࡧ࡬࡭ࡤࡤࡧࡰࠦࡴࡩࡣࡷࠤ࡮ࡹࠠࡨ࡫ࡹࡩࡳࠦࡴࡩࡧࠣࡱࡪࡺࡡࡥࡣࡷࡥࠥࡧ࡮ࡥࠢࡳࡰࡦ࡯࡮ࡵࡧࡻࡸࠥࡱ࡮ࡰࡹࡱࠤࡧࡿࠠࡵࡪ࡬ࡷ࡚ࠥࡌࡗࠢࡤࡲࡩࠦࡥࡹࡲࡨࡧࡹ࡫ࡤࠡࡶࡲࠤࡷ࡫ࡴࡶࡴࡱࠤࡹ࡮ࡥࠡࡧࡱࡧࡷࡿࡰࡵࡧࡧࠤࡵࡧࡲࡵࠢࡲࡪࠥࡺࡨࡦࠢࡳࡥࡾࡲ࡯ࡢࡦ࠱ࠤ࡙࡮ࡩࡴࠢࡦࡥࡳࠦࡢࡦࠢࡣࡤࡓࡵ࡮ࡦࡢࡣࠤ࡮࡬ࠠࡵࡪࡨࠤࡵࡧࡹ࡭ࡱࡤࡨࠥ࡯ࡳࠡࡰࡲࡸࠥ࡫࡮ࡤࡴࡼࡴࡹ࡫ࡤࠡࡱࡵࠤ࡮࡬ࠠࡵࡪ࡬ࡷࠥ࡯ࡳࠡࡣࠣࡶࡪࡩࡥࡪࡸࡨࡨࠥࡶࡡࡺ࡮ࡲࡥࡩ࠲ࠠࡣࡷࡷࠤࡪ࡯ࡴࡩࡧࡵࠤࡼࡧࡹࠡ࡫ࡩࠤࡹ࡮ࡥࠡࡲࡤࡽࡱࡵࡡࡥࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡨࡲࡨࡸࡹࡱࡶࡨࡨࠥ࡯ࡴࠡࡹ࡬ࡰࡱࠦ࡮ࡦࡸࡨࡶࠥࡨࡥࠡࡥࡤࡰࡱ࡫ࡤ࠯ࠢࡗ࡬࡮ࡹࠠࡱࡴࡲࡺ࡮ࡪࡥࡴࠢࡷ࡬ࡪࠦࡩ࡯ࡸࡨࡶࡸ࡫ࠠࡰࡲࡨࡶࡦࡺࡩࡰࡰࠣࡸࡴࠦ࠺ࡱࡻ࠽ࡱࡪࡺࡨ࠻ࡢࡧࡩࡨࡸࡹࡱࡶࡣ࠲ࠥࡦࡠࡦࡰࡦࡶࡾࡶࡴࡠࡪࡲࡳࡰࡦࡠࠡࡥࡤࡲࠥࡧ࡬ࡴࡱࠣࡦࡪࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢࡺ࡭ࡹ࡮ࠠ࠻ࡲࡼ࠾ࡲ࡫ࡴࡩ࠼ࡣࡷࡪࡺ࡟ࡦࡰࡦࡶࡾࡶࡴࡠࡪࡲࡳࡰࡦ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧோ")
        if not isinstance(encryption, payload_tlv.EncryptionInfoTLV):
            raise TypeError(l11ll_opy_ (u"ࠪࡩࡳࡩࡲࡺࡲࡷ࡭ࡴࡴࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡇࡱࡧࡷࡿࡰࡵ࡫ࡲࡲࡎࡴࡦࡰࡖࡏ࡚࠱ࠦࡩࡴࠢࡾࢁࠬௌ")
                            .format(type(encryption)))
        if None is not payload_tlvs\
           and not self._1llllll11l_opy_(payload_tlvs)\
           and not self._1llll1l1ll_opy_(payload_tlvs):
            raise TypeError(l11ll_opy_ (u"ࠫࡵࡧࡹ࡭ࡱࡤࡨࡤࡺ࡬ࡷࡵࠣࡱࡺࡹࡴࠡࡤࡨࠤࡦࠦ࡬ࡪࡵࡷࠤࡴ࡬ࠠࡵ࡮ࡹࡷ࠱ࠦࡩࡴࠢࡾࢁ்ࠬ")
                            .format(type(payload_tlvs)))
        if None is not payload_bytes\
           and not self._1llllll11l_opy_(payload_bytes)\
           and not self._1lllllll11_opy_(payload_bytes):
            raise TypeError(l11ll_opy_ (u"ࠬࡶࡡࡺ࡮ࡲࡥࡩࡥࡢࡺࡶࡨࡷࠥࡳࡵࡴࡶࠣࡦࡪࠦࡢࡺࡶࡨࡰ࡮ࡱࡥ࠭ࠢ࡬ࡷࠥࢁࡽࠨ௎")
                            .format(type(payload_bytes)))
        self.l1lllll1lll_opy_(encrypt_hook)
        self._1llll1ll11_opy_ = encryption
        if None is payload_tlvs:
            self._1lllll11l1_opy_ = []
        else:
            self._1lllll11l1_opy_ = payload_tlvs
        if None is payload_bytes:
            self._1llllll1l1_opy_ = six.b(l11ll_opy_ (u"࠭ࠧ௏"))
        else:
            self._1llllll1l1_opy_ = payload_bytes
        if None is l1llll11l1l_opy_:
            self._1lllll1111_opy_ = six.b(l11ll_opy_ (u"ࠧࠨௐ"))
        else:
            self._1lllll1111_opy_ = l1llll11l1l_opy_
    def l1lllll1lll_opy_(self, encrypt_hook):
        l11ll_opy_ (u"ࠣࠤࠥࠤࡘ࡫ࡴࠡࡶ࡫ࡩࠥ࡫࡮ࡤࡴࡼࡴࡹࡵࡲࠡࡨࡸࡲࡨࡺࡩࡰࡰࠣࡪࡴࡸࠠࡵࡪࡨࠤ࡙ࡒࡖ࠯ࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡨࡧ࡬࡭ࡣࡥࡰࡪࠦࡥ࡯ࡥࡵࡽࡵࡺ࡯ࡳࡡࡩࡹࡳࡩ࠺ࠡࡖ࡫ࡩࠥ࡫࡮ࡤࡴࡼࡴࡹࡵࡲ࠯ࠢࡉࡳࡷࠦࡤࡦࡶࡤ࡭ࡱࡹࠠࡰࡰࠣࡸ࡭࡫ࠠࡧࡱࡵࡱࠥࡹࡥࡦࠢ࠽ࡴࡾࡀ࡭ࡦࡶ࡫࠾ࡥࡥ࡟ࡪࡰ࡬ࡸࡤࡥࡠ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨ௑")
        if encrypt_hook and not hasattr(encrypt_hook, l11ll_opy_ (u"ࠩࡢࡣࡨࡧ࡬࡭ࡡࡢࠫ௒")):
            raise TypeError(l11ll_opy_ (u"ࠪࡍ࡫ࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥ࠮ࠣࡩࡳࡩࡲࡺࡲࡷࡣ࡭ࡵ࡯࡬ࠢࡰࡹࡸࡺࠠࡣࡧࠣࡧࡦࡲ࡬ࡢࡤ࡯ࡩࠥࡨࡵࡵࠢࡾࢁࠥ࡯ࡳࠡࡰࡲࡸࠬ௓")
                            .format(type(encrypt_hook)))
        self._encrypt_hook = encrypt_hook
    def decrypt(self, l1lllllllll_opy_):
        l11ll_opy_ (u"ࠦࠧࠨࠠࡕࡴࡼࠤࡦࡴࡤࠡࡦࡨࡧࡷࡿࡰࡵࠢࡤࡲࡾࠦࡵ࡯ࡲࡤࡶࡸ࡫ࡤࠡࡤࡼࡸࡪࡹࠠ࡭ࡧࡩࡸࠥࡵࡶࡦࡴࠣࡪࡷࡵ࡭ࠡࡦࡨࡷࡪࡸࡩࡢ࡮࡬ࡾࡦࡺࡩࡰࡰ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡣࡢ࡮࡯ࡥࡧࡲࡥࠡࡦࡨࡧࡷࡿࡰࡵࡱࡵࡣ࡫ࡻ࡮ࡤ࠼ࠣࡅࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡵࡱࠣࡧࡦࡲ࡬ࠡࡶࡲࠤࡩ࡫ࡣࡳࡻࡳࡸࠥࡺࡨࡦࠢࡦࡳࡳࡺࡥ࡯ࡶࡶࠤࡴ࡬ࠠࡵࡪࡨࠤࡵࡧࡹ࡭ࡱࡤࡨ࠳ࠦࡔࡩࡧࠣ࡬ࡴࡵ࡫ࠡ࡫ࡶࠤ࡬࡯ࡶࡦࡰࠣࡸ࡭࡫ࠠࡱࡣࡼࡰࡴࡧࡤࠡ࡯ࡨࡸࡦࡪࡡࡵࡣ࠱ࠤ࡙࡮ࡥࠡࡨࡲࡶࡲࠦࡩࡴࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠯࠰ࠣࡪࡺࡴࡣࡵ࡫ࡲࡲ࠿ࡀࠠࡥࡧࡦࡶࡾࡶࡴࡠࡪࡲࡳࡰ࠮ࡳࡦࡰࡧࡩࡷࡥࡧࡪࡦ࠯ࠤࡹ࡯࡭ࡦࡡࡶࡩࡳࡺࠬࠡࡧࡱࡧࡷࡿࡰࡵ࡫ࡲࡲࡤࡩ࡯ࡶࡰࡷࡩࡷ࠲ࠠࡱ࡮ࡤ࡭ࡳࡺࡥࡹࡶࠬࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡧࡰࡖࡨࡲࡳࡧ࠮ࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡍࡉࠦࡳࡦࡰࡧࡩࡷࡥࡧࡪࡦ࠽ࠤ࡙࡮ࡥࠡࡵࡨࡲࡩ࡫ࡲࠡࡱࡩࠤࡹ࡮ࡥࠡ࡯ࡨࡷࡸࡧࡧࡦࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡩࡧࡴࡦࡶ࡬ࡱࡪ࠴ࡤࡢࡶࡨࡸ࡮ࡳࡥࠡࡶ࡬ࡱࡪࡥࡳࡦࡰࡷ࠾࡚ࠥࡨࡦࠢࡷ࡭ࡲ࡫ࠠࡵࡪࡨࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡽࡡࡴࠢࡶࡩࡳࡺࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢ࡬ࡲࡹࠦࡥ࡯ࡥࡵࡽࡵࡺࡩࡰࡰࡢࡧࡴࡻ࡮ࡵࡧࡵ࠾࡚ࠥࡨࡦࠢࡳࡥࡾࡲ࡯ࡢࡦࠣࡩࡳࡩࡲࡺࡲࡷ࡭ࡴࡴ࡟ࡤࡱࡸࡲࡹ࡫ࡲ࠭ࠢࡤࠤ࠶࠼࠭ࡣ࡫ࡷࠤࡨࡵࡵ࡯ࡶࡨࡶࠥࡺࡨࡢࡶࠣࡧ࡭ࡧ࡮ࡨࡧࡶࠤࡼ࡯ࡴࡩࠢࡨࡺࡪࡸࡹࠡ࡯ࡨࡥࡳࡺ࠭ࡵࡱ࠰ࡦࡪ࠳ࡵ࡯࡫ࡴࡹࡪࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡴࡧࡱࡸࠥ࡬ࡲࡰ࡯ࠣࡥࠥࡹࡰࡦࡥ࡬ࡪ࡮ࡩࠠࡴࡧࡱࡨࡪࡸࠠࡵࡱࠣࡥࠥࡹࡰࡦࡥ࡬ࡪ࡮ࡩࠠࡥࡧࡶࡸ࡮ࡴࡡࡵ࡫ࡲࡲࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡣࡻࡷࡩࡸࡲࡩ࡬ࡧࠣࡧ࡮ࡶࡨࡦࡴࡷࡩࡽࡺ࠺ࠡࡖ࡫ࡩࠥࡳࡥࡴࡵࡤ࡫ࡪࠦࡣࡰࡰࡷࡩࡳࡺࠠࡵࡱࠣࡨࡪࡩࡲࡺࡲࡷࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹࡦࡶ࡮ࠣࡨࡪࡩࡲࡺࡲࡷ࡭ࡴࡴࠠࡰࡥࡦࡹࡷࡹࠠࡪࡨࠣࡥࡳࡪࠠࡰࡰ࡯ࡽࠥ࡯ࡦ࠻ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠱࡚ࠥࡨࡦࠢࡧࡩࡨࡸࡹࡱࡶࡲࡶࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡥࡱࡨࡷࠥࡴ࡯ࡵࠢࡵࡥ࡮ࡹࡥࠡࡣࡱࠤࡪࡾࡣࡦࡲࡷ࡭ࡴࡴࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠯ࠣࡘ࡭࡫ࠠ࡭ࡣࡶࡸࠥࡺࡷࡰࠢࡥࡽࡹ࡫ࡳࠡࡱࡩࠤࡹ࡮ࡥࠡࡦࡨࡧࡷࡿࡰࡵࡧࡧࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡧࡲࡦࠢࡤࠤࡻࡧ࡬ࡪࡦࠣࡇࡗࡉࠠࡧࡱࡵࠤࡹ࡮ࡥࠡࡴࡨࡷࡹࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡤࡦࡥࡵࡽࡵࡺࡥࡥࠢࡰࡩࡸࡹࡡࡨࡧࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡏࡦࠡࡦࡨࡧࡷࡿࡰࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡰࡲࡸࠥࡹࡵࡤࡥࡨࡷࡸ࡬ࡵ࡭࠮ࠣࡸ࡭࡫ࠠࡤࡱࡱࡸࡪࡴࡴࠡࡱࡩࠤࡹ࡮ࡥࠡࡲࡤࡽࡱࡵࡡࡥࠢࡵࡩࡲࡧࡩ࡯ࡵࠣࡥࡸࠦࡵ࡯ࡲࡤࡶࡸ࡫ࡤࠡࡤࡼࡸࡪࡹ࠮ࠡࡋࡩࠤ࡮ࡺࠠࡪࡵࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲࠬࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡨࡲࡹࠦࡷࡪ࡮࡯ࠤࡧ࡫ࠠࡱࡣࡵࡷࡪࡪࠠࡪࡰࡷࡳࠥࡧࠠ࡭࡫ࡶࡸࠥࡵࡦࠡࡖࡏ࡚ࡸ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦ௔")
        l1lllll1ll1_opy_ = False
        try:
            decrypted = l1lllllllll_opy_(self.encryption.sender, self.encryption.time,
                                       self.encryption.counter, self._1lllll1111_opy_)
            if decrypted == self._1lllll1111_opy_:
                raise ValueError(l11ll_opy_ (u"ࠬࡈࡡࡥࠢࡧࡩࡨࡸࡹࡱࡶ࡬ࡳࡳࠦࠨ࡯ࡱ࠰ࡳࡵ࠯ࠧ௕"))
            self._1llll111ll_opy_(decrypted)
            self._1lllll1111_opy_ = None
            l1lllll1ll1_opy_ = True
        except Exception: # pylint: disable=broad-except
            _MODULE_LOGGER.getChild(self.__class__.__name__)\
                          .exception(l11ll_opy_ (u"࠭ࡄࡦࡥࡵࡽࡵࡺࡩࡰࡰࠣࡪࡦ࡯࡬ࡦࡦࠤࠫ௖"))
            decrypted = self._1lllll1111_opy_
        tlvs, l1lllll1l1l_opy_\
            = basic_tlv.TLV.l111ll1l11_opy_(decrypted[:-2],
                                                self.l111l11l1l_opy_)
        if l1lllll1ll1_opy_:
            self._1llll1l111_opy_(tlvs, l1lllll1l1l_opy_, decrypted[-2:])
        else:
            _MODULE_LOGGER.getChild(self.__class__.__name__)\
                          .warning(l11ll_opy_ (u"ࠧࡔ࡭࡬ࡴࡵ࡯࡮ࡨࠢࡆࡖࡈࠦࡣࡩࡧࡦ࡯ࠥ࠮ࡤࡦࡥࡵࡽࡵࡺࠠࡧࡣ࡬ࡰࡪࡪࠩࠨௗ"))
        self._1lllll11l1_opy_ = tlvs
        self._1llllll1l1_opy_ = l1lllll1l1l_opy_[:-2]
    @staticmethod
    def _1llll111ll_opy_(plaintext):
        l1llll1lll1_opy_ = plaintext[-2:]
        l1llll1llll_opy_ = struct.unpack(l11ll_opy_ (u"ࠨࠣࡋࠫ௘"), l1llll1lll1_opy_)[0]
        l1lllll11ll_opy_ = binascii.crc_hqx(plaintext[:-2], 0)
        if l1lllll11ll_opy_ != l1llll1llll_opy_:
            raise ValueError(l11ll_opy_ (u"ࠩࡆࡖࡈࠦ࡭ࡪࡵࡰࡥࡹࡩࡨࠡࡣࡩࡸࡪࡸࠠࡥࡧࡦࡶࡾࡶࡴ࠻ࠢࡆࡥࡱࡩࡵ࡭ࡣࡷࡩࡩࠦࡻࡾ࠮ࠣࡴࡦࡸࡳࡦࡦࠣࡿࢂࠦࡦࡳࡱࡰࠤࢀࢃࠧ௙").format(l1lllll11ll_opy_, l1llll1llll_opy_,
                                                                                                   plaintext))
    @staticmethod
    def _1llll1l111_opy_(tlvs, l1lllll1l1l_opy_, l1llll1lll1_opy_):
        l1lllll1l11_opy_ = six.b(l11ll_opy_ (u"ࠪࠫ௚"))
        if tlvs:
            l1lllll1l11_opy_ += goTenna.util.l1ll1ll1_opy_(*[t.to_bytes()
                                                   for t in tlvs])
        if l1lllll1l1l_opy_:
            l1lllll1l11_opy_ += l1lllll1l1l_opy_
        l1llll1llll_opy_ = struct.unpack(l11ll_opy_ (u"ࠫࠦࡎࠧ௛"), l1llll1lll1_opy_)[0]
        l1llll1ll1l_opy_ = binascii.crc_hqx(l1lllll1l11_opy_, 0)
        if l1llll1ll1l_opy_ != l1llll1llll_opy_:
            raise ValueError(l11ll_opy_ (u"ࠬࡉࡒࡄࠢࡰ࡭ࡸࡳࡡࡵࡥ࡫࠾ࠥࢁࡽࠡࡥࡤࡰࡨ࠲ࠠࡼࡿࠣࡴࡦࡸࡳࡦ࠮ࠣࡿࢂࠦࡲࡦࡵࡨࡶ࠱ࠦࡰࡢࡴࡶࡩࡩࠦࡻࡾࠢࡺ࡭ࡹ࡮ࠠࡼࡿࠣࡰࡪ࡬ࡴࠡࡱࡹࡩࡷ࠭௜")
                             .format(hex(l1llll1ll1l_opy_),
                                     hex(l1llll1llll_opy_),
                                     goTenna.util.display_bytestring(l1lllll1l11_opy_),
                                     tlvs,
                                     goTenna.util.display_bytestring(l1lllll1l1l_opy_)))
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        l1llll1lll1_opy_ = l111l1ll1l_opy_[-2:]
        l111l1ll1l_opy_ = l111l1ll1l_opy_[:-2]
        encryption, remaining\
            = basic_tlv.TLV.l1ll11llll_opy_(l111l1ll1l_opy_,
                                           (payload_tlv.EncryptionInfoTLV,))
        if encryption.encrypted: # pylint: disable=no-else-return
            return MessagePayloadTLV(encryption, None, None,
                                     remaining+l1llll1lll1_opy_)
        else:
            tlvs, l1lllll1l1l_opy_\
                = basic_tlv.TLV.l111ll1l11_opy_(remaining,
                                                    cls.l111l11l1l_opy_)
            cls._1llll1l111_opy_(tlvs, l1lllll1l1l_opy_, l1llll1lll1_opy_)
            return MessagePayloadTLV(encryption,
                                     tlvs if tlvs else None,
                                     l1lllll1l1l_opy_ if l1lllll1l1l_opy_ else None)
    def serialize(self):
        l11ll_opy_ (u"ࠨࠢࠣࠢࡌࡱࡵࡲࡥ࡮ࡧࡱࡸࡦࡺࡩࡰࡰࠣࡳ࡫ࠦ࠺ࡱࡻ࠽ࡱࡪࡺࡨ࠻ࡢࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡸࡱࡼ࠮ࡣࡣࡶ࡭ࡨࡥࡴ࡭ࡸ࠱ࡘࡑ࡜࠮ࡴࡧࡵ࡭ࡦࡲࡩࡻࡧࡣࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣ௝")
        l1llll1l11l_opy_ = self.encryption.to_bytes()
        rest = self.l1lllll111l_opy_
        rest += struct.pack(l11ll_opy_ (u"ࠧࠢࡊࠪ௞"), binascii.crc_hqx(rest, 0))
        if self.encryption.encrypted:
            if not hasattr(self._encrypt_hook, l11ll_opy_ (u"ࠨࡡࡢࡧࡦࡲ࡬ࡠࡡࠪ௟")):
                raise TypeError(l11ll_opy_ (u"ࠩࡖࡩࡷ࡯ࡡ࡭࡫ࡽ࡭ࡳ࡭ࠠࡦࡰࡦࡶࡾࡶࡴࡦࡦࠣࡴࡦࡿ࡬ࡰࡣࡧࡷࠥࡸࡥࡲࡷ࡬ࡶࡪࡹࠠࡢࡰࠣࡩࡳࡩࡲࡺࡲࡷ࡭ࡴࡴࠠࡧࡷࡱࡧࠥࡨࡵࡵࠢࡨࡲࡨࡸࡹࡱࡶ࡬ࡳࡳࡥࡦࡶࡰࡦࠤ࡮ࡹࠠࡼࡿࠪ௠")
                                .format(type(self._encrypt_hook)))
            rest = self._encrypt_hook(self.encryption.sender,
                                      self.encryption.time,
                                      self.encryption.counter,
                                      rest)
        return l1llll1l11l_opy_ + rest
    @property
    def encryption(self):
        l11ll_opy_ (u"ࠥࠦࠧࠦࡔࡩࡧࠣࡱࡦࡴࡤࡢࡶࡲࡶࡾࠦࡥ࡯ࡥࡵࡽࡵࡺࡩࡰࡰࠣ࡬ࡪࡧࡤࡦࡴ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴࡳࠡࡩࡲࡘࡪࡴ࡮ࡢ࠰ࡳࡥࡾࡲ࡯ࡢࡦࡢࡸࡱࡼ࠮ࡆࡰࡦࡶࡾࡶࡴࡪࡱࡱࡍࡳ࡬࡯ࡕࡎ࡙࠾࡚ࠥࡨࡦࠢࡨࡲࡨࡸࡹࡱࡶ࡬ࡳࡳࠦࡩ࡯ࡨࡲ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤ௡")
        return self._1llll1ll11_opy_
    @property
    def payload_bytes(self):
        l11ll_opy_ (u"ࠦࠧࠨࠠࡕࡪࡨࠤࡵࡧࡲࡵࠢࡲࡪࠥࡺࡨࡦࠢࡳࡥࡾࡲ࡯ࡢࡦࠣࡸ࡭ࡧࡴࠡࡹࡤࡷࠥࡹࡰࡦࡥ࡬ࡪ࡮࡫ࡤࠡࡣࡶࠤࡧࡿࡴࡦࡵࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡦࡶࡸࡶࡳࡹࠠࡣࡻࡷࡩࡸࠦ࡯ࡳࠢࡶࡸࡷࡀࠠࡕࡪࡨࠤࡩࡧࡴࡢࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨ௢")
        return self._1llllll1l1_opy_
    @property
    def payload_tlvs(self):
        l11ll_opy_ (u"ࠧࠨࠢࠡࡖ࡫ࡩࠥࡶࡡࡳࡶࠣࡳ࡫ࠦࡴࡩࡧࠣࡴࡦࡿ࡬ࡰࡣࡧࠤࡹ࡮ࡡࡵࠢࡺࡥࡸࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢࡤࡷ࡚ࠥࡌࡗࡵ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴࡳࠡ࡮࡬ࡷࡹࡡࡔࡍࡘࡠ࠾࡚ࠥࡨࡦࠢࡗࡐ࡛ࡹࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦ௣")
        return self._1lllll11l1_opy_
    @property
    def l1lllll111l_opy_(self):
        l11ll_opy_ (u"ࠨࠢࠣࠢࡗ࡬ࡪࠦࡥ࡯ࡶ࡬ࡶࡪࡺࡹࠡࡱࡩࠤࡹ࡮ࡥࠡࡥࡲࡲࡹ࡫࡮ࡵࠢࡲࡪࠥࡺࡨࡦࠢࡳࡥࡾࡲ࡯ࡢࡦࠣࠬࡪ࠴ࡧ࠯ࠢࡨࡺࡪࡸࡹࡵࡪ࡬ࡲ࡬ࠦࡢࡶࡶࠣࡸ࡭࡫ࠠࡦࡰࡦࡶࡾࡶࡴࡪࡱࡱࠤ࡭࡫ࡡࡥࡧࡵ࠭ࠥࡧࡳࠡࡤࡼࡸࡪࡹ࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣࡘ࡭࡯ࡳࠡࡹ࡬ࡰࡱࠦࡩ࡮ࡲ࡯࡭ࡨ࡯ࡴ࡭ࡻࠣࡷࡪࡸࡩࡢ࡮࡬ࡾࡪࠦࡡ࡯ࡻࠣࡘࡑ࡜ࡳࠡࡵࡷࡳࡷ࡫ࡤࠡࡤࡼࠤࡹ࡮ࡥࠡࡵࡼࡷࡹ࡫࡭ࠡࡣࡱࡨࠥࡩ࡯࡯ࡥࡤࡸࡪࡴࡡࡵࡧࠣࡸ࡭࡫ࠠࡱࡣࡵࡸࠥࡵࡦࠡࡶ࡫ࡩࠥࡶࡡࡺ࡮ࡲࡥࡩࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢࡤࡷࠥࡨࡹࡵࡧࡶࠤࡹࡵࠠࡵࡪࡨࠤࡷ࡫ࡳࡶ࡮ࡷ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤ௤")
        to_return = goTenna.util.l111ll_opy_()
        if self._1lllll11l1_opy_:
            for tlv in self._1lllll11l1_opy_:
                to_return += tlv.to_bytes()
        if self._1llllll1l1_opy_:
            to_return += self._1llllll1l1_opy_
        return to_return
class PublicKeyHashTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠢࠣࠤࠣࡘ࡭࡫ࠠࡵࡱࡳ࠱ࡱ࡫ࡶࡦ࡮ࠣࡘࡑ࡜ࠠࡤࡱࡱࡸࡦ࡯࡮ࡪࡰࡪࠤࡦࠦࡰࡶࡤ࡯࡭ࡨࠦ࡫ࡦࡻࠣ࡬ࡦࡹࡨ࠯ࠌࠣࠤࠥࠦࠢࠣࠤ௥")
    l1l11ll1ll_opy_ = 4
    def __repr__(self):
        return l11ll_opy_ (u"ࠨ࠾ࡓࡹࡧࡑࡥࡺࡊࡤࡷ࡭࡚ࡌࡗ࠼ࠣ࡭ࡳࡪࡥࡹ࠿ࡾࢁࠥ࡮ࡡࡴࡪࡀࡿࢂࡄࠧ௦").format(self.index,
                                                          self.l1llll11lll_opy_)
    def __eq__(self, other):
        return isinstance(other, PublicKeyHashTLV)\
            and self.index == other.index\
            and self.l1llll11lll_opy_ == other.l1llll11lll_opy_
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, index=None, l1llll11lll_opy_=None):
        l11ll_opy_ (u"ࠤࠥࠦࠥࡈࡵࡪ࡮ࡧࠤࡹ࡮ࡥࠡࡖࡏ࡚࠳ࠐࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡ࡫ࡱࡸࠥ࡯࡮ࡥࡧࡻ࠾࡚ࠥࡨࡦࠢ࡬ࡲࡩ࡫ࡸࠡࡹ࡬ࡸ࡭࡯࡮ࠡࡶ࡫ࡩࠥࡱࡥࡺ࠰ࠣࡍ࡬ࡴ࡯ࡳࡧࡧࠤࡼ࡮ࡥ࡯ࠢࡶࡩࡷ࡯ࡡ࡭࡫ࡽ࡭ࡳ࡭࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢ࡬ࡲࡹࠦ࡫ࡦࡻ࡫ࡥࡸ࡮࠺ࠡࡖ࡫ࡩࠥ࠷࠶ࠡࡤ࡬ࡸࡸࠦ࡯ࡧࠢ࡮ࡩࡾࠦࡡࡵࠢࡷ࡬ࡪࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢ࡬ࡲࡩ࡫ࡸ࠯ࠢࡌ࡫ࡳࡵࡲࡦࡦࠣࡻ࡭࡫࡮ࠡࡵࡨࡶ࡮ࡧ࡬ࡪࡼ࡬ࡲ࡬࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦ௧")
        if None is index:
            self.index = 255
        elif isinstance(index, int):
            if index > 255 or index < 0:
                raise ValueError(l11ll_opy_ (u"ࠪ࡭ࡳࡪࡥࡹࠢࡰࡹࡸࡺࠠࡣࡧࠣࡻ࡮ࡺࡨࡪࡰࠣ࠴ࠥࡧ࡮ࡥࠢ࠵࠹࠺࠲ࠠࡪࡵࠣࡿࢂ࠭௨")
                                 .format(index))
            self.index = index
        else:
            raise TypeError(l11ll_opy_ (u"ࠫ࡮ࡴࡤࡦࡺࠣࡱࡺࡹࡴࠡࡤࡨࠤ࡮ࡴࡴ࠭ࠢ࡬ࡷࠥࢁࡽࠨ௩").format(type(index)))
        if None is l1llll11lll_opy_:
            self.l1llll11lll_opy_ = 0
        elif isinstance(l1llll11lll_opy_, int):
            if l1llll11lll_opy_ < 0 or l1llll11lll_opy_ > 0xffff:
                raise ValueError(l11ll_opy_ (u"ࠬࡱࡥࡺࡪࡤࡷ࡭ࠦ࡭ࡶࡵࡷࠤࡧ࡫ࠠࡸ࡫ࡷ࡬࡮ࡴࠠ࠱ࠢࡤࡲࡩࠦ࠰ࡹࡨࡩࡪ࡫࠲ࠠࡪࡵࠣࡿࢂ࠭௪")
                                 .format(l1llll11lll_opy_))
            self.l1llll11lll_opy_ = l1llll11lll_opy_
        else:
            raise TypeError(l11ll_opy_ (u"࠭࡫ࡦࡻ࡫ࡥࡸ࡮ࠠ࡮ࡷࡶࡸࠥࡨࡥࠡ࡫ࡱࡸ࠱ࠦࡩࡴࠢࡾࢁࠬ௫").format(type(l1llll11lll_opy_)))
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        (index, l1llll11lll_opy_) = struct.unpack(l11ll_opy_ (u"ࠧࠢࡄࡋࠫ௬"), l111l1ll1l_opy_)
        return cls(index, l1llll11lll_opy_)
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠨࠣࡅࡌࠬ௭"), self.index, self.l1llll11lll_opy_)
class HopCountTLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠤ࡚ࠥࠦࠥࡨࡦࠢࡗࡐ࡛ࠦࡳࡱࡧࡦ࡭࡫ࡿࡩ࡯ࡩࠣࡥࠥࡳࡥࡴࡵࡤ࡫ࡪ࠭ࡳࠡࡪࡲࡴࠥࡩ࡯ࡶࡰࡷ࠲ࠏࠦࠠࠡࠢࠥࠦࠧ௮")
    l1l11ll1ll_opy_ = 0x20
    def __repr__(self):
        return l11ll_opy_ (u"ࠪࡀࡍࡵࡰࡄࡱࡸࡲࡹ࡚ࡌࡗ࠼ࠣࡧࡴࡻ࡮ࡵ࠿ࡾࢁࡃ࠭௯").format(self.count)
    def __eq__(self, other):
        return isinstance(other, HopCountTLV) and self.count == other.count
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, count=None, l1llll11l11_opy_=None):
        l11ll_opy_ (u"ࠦࠧࠨࠠࡃࡷ࡬ࡰࡩࠦࡴࡩࡧࠣࡘࡑ࡜ࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢ࡬ࡲࡹࠦࡣࡰࡷࡱࡸ࠿ࠦࡔࡩࡧࠣࡲࡺࡳࡢࡦࡴࠣࡳ࡫ࠦࡨࡰࡲࡶࠤ࠭ࡧ࡬ࡴࡱࠣ࡯ࡳࡵࡷ࡯ࠢࡤࡷࠥࡺࡨࡦࠢࡗࡘࡑ࠯ࠠࡧࡱࡵࠤࡹ࡮ࡩࡴࠢࡰࡩࡸࡹࡡࡨࡧ࠱ࠤࡒࡧࡸࡪ࡯ࡸࡱࠥࡵࡦࠡ࠼ࡳࡽ࠿ࡵࡢ࡫࠼ࡪࡳ࡙࡫࡮࡯ࡣ࠱ࡧࡴࡴࡳࡵࡣࡱࡸࡸ࠴ࡍࡂ࡚ࡢࡌࡔࡖࡓࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰࠣࡌࡴࡶࡃࡰࡷࡱࡸ࡙ࡒࡖ࠻ࠢࡗ࡬ࡪࠦࡣࡰࡰࡶࡸࡷࡻࡣࡵࡧࡧࠤࡴࡨࡪࡦࡥࡷ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤ௰")
        if None is count:
            count = 0
        if None is l1llll11l11_opy_:
            l1llll11l11_opy_ = 0
        if not isinstance(count, int):
            raise TypeError(l11ll_opy_ (u"ࠬࡩ࡯ࡶࡰࡷࠤࡲࡻࡳࡵࠢࡥࡩࠥ࡯࡮ࡵ࠮ࠣ࡭ࡸࠦࡻࡾࠩ௱").format(type(count)))
        if 0 > count or count > 255:
            raise ValueError(l11ll_opy_ (u"࠭ࡣࡰࡷࡱࡸࠥࡳࡵࡴࡶࠣࡦࡪࠦࡢࡦࡶࡺࡩࡪࡴࠠ࠱ࠢࡤࡲࡩࠦ࠲࠶࠸࠯ࠤ࡮ࡹࠠࡼࡿࠪ௲")
                             .format(count))
        if not isinstance(count, int):
            raise TypeError(l11ll_opy_ (u"ࠧࡳࡵࡶ࡭ࠥࡳࡵࡴࡶࠣࡦࡪࠦࡩ࡯ࡶ࠯ࠤ࡮ࡹࠠࡼࡿࠪ௳").format(type(count)))
        try:
            _ = struct.pack(l11ll_opy_ (u"ࠨࡤࠪ௴"), count)
        except struct.error:
            raise ValueError(l11ll_opy_ (u"ࠩࡵࡷࡸ࡯ࠠ࡮ࡷࡶࡸࠥ࡬ࡩࡵࠢ࡬ࡲࠥࡵ࡮ࡦࠢࡶ࡭࡬ࡴࡥࡥࠢࡥࡽࡹ࡫ࠧ௵"))
        self.count = count
        self.l1llll11l11_opy_ = l1llll11l11_opy_
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        try:
            (count, l1llll11l11_opy_) = struct.unpack(l11ll_opy_ (u"ࠪࠥࡇࡨࠧ௶"), l111l1ll1l_opy_)
        except struct.error:
            (count,) = struct.unpack(l11ll_opy_ (u"ࠫࠦࡈࠧ௷"), l111l1ll1l_opy_)
            l1llll11l11_opy_ = None
        return cls(count, l1llll11l11_opy_)
    def serialize(self):
        if None is self.l1llll11l11_opy_:
            l1llll11l11_opy_ = 0
        else:
            l1llll11l11_opy_ = self.l1llll11l11_opy_
        if None is self.count:
            count = 0
        else:
            count = self.count
        return struct.pack(l11ll_opy_ (u"ࠬࠧࡂࡣࠩ௸"), count, l1llll11l11_opy_)
class PLITLV(basic_tlv.TLV):
    l11ll_opy_ (u"ࠨࠢࠣࠢࡄࠤ࡙ࡒࡖࠡࡵࡳࡩࡨ࡯ࡦࡺ࡫ࡱ࡫ࠥࡽࡨࡦࡶ࡫ࡩࡷࠦࡡࠡ࡯ࡨࡷࡸࡧࡧࡦࠢ࡬ࡷࠥࡶࡡࡳࡶࠣࡳ࡫ࠦࡡࠡࡵࡨࡸࠥࡵࡦࠡࡣࡸࡸࡴࡳࡡࡵ࡫ࡦࡥࡱࡲࡹࠡࡵࡦ࡬ࡪࡪࡵ࡭ࡧࡧࠤࡷ࡫ࡰࡦࡣࡷ࡭ࡳ࡭ࠠ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠌࠣࠤࠥࠦࠢࠣࠤ௹")
    l1l11ll1ll_opy_ = 0x36
    def __repr__(self):
        return l11ll_opy_ (u"ࠧ࠽ࡒࡏࡍ࡙ࡒࡖ࠻ࠢ࡬ࡷࡤࡶ࡬ࡪ࠿ࡾࢁࡃ࠭௺").format(self.l1llll1l1l1_opy_)
    def __eq__(self, other):
        return isinstance(other, PLITLV) and self.l1llll1l1l1_opy_ == other.l1llll1l1l1_opy_
    @property
    def l111lll111_opy_(self):
        return self.l1l11ll1ll_opy_
    def __init__(self, l1llll1l1l1_opy_=False):
        l11ll_opy_ (u"ࠣࠤࠥࠤࡇࡻࡩ࡭ࡦࠣࡸ࡭࡫ࠠࡕࡎ࡙ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣ௻")
        self.l1llll1l1l1_opy_ = l1llll1l1l1_opy_
    @classmethod
    def deserialize(cls, l111l1ll1l_opy_):
        (l1llllll1ll_opy_,) = struct.unpack(l11ll_opy_ (u"ࠩࠤࡆࠬ௼"), l111l1ll1l_opy_)
        return cls(bool(l1llllll1ll_opy_))
    def serialize(self):
        return struct.pack(l11ll_opy_ (u"ࠪࠥࡇ࠭௽"), self.l1llll1l1l1_opy_)
l11ll_opy_ (u"ࠦࠧࠨࠠࡂࠢ࡯࡭ࡸࡺࠠࡰࡨࠣࡥࡱࡲࠠࡵࡪࡨࠤ࡙ࡒࡖࡴࠢࡨࡼࡵ࡫ࡣࡵࡧࡧࠤ࡮ࡴࠠࡵࡪࡨࠤࡹࡵࡰࠡ࡮ࡨࡺࡪࡲࠠࡰࡨࠣࡥࠥࡳࡥࡴࡵࡤ࡫ࡪࠦࠢࠣࠤ௾")
ALL = [l111111l11_opy_ for l111111l11_opy_ in vars().values()
       if isinstance(l111111l11_opy_, type)
       and issubclass(l111111l11_opy_, basic_tlv.TLV)]